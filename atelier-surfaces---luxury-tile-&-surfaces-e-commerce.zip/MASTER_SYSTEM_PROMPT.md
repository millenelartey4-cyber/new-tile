# Master Specification Prompt: Atelier Surfaces Platform
## Architectural Luxury Stone & Tile Storefront, Physical POS, Real-Time Sync, and Enterprise Administration Console

Copy and paste the prompt below into Google AI Studio Build to recreate this complete application from scratch:

---

```markdown
Build a production-grade, full-stack architectural luxury surface and tile enterprise platform called "Atelier Surfaces" (Ghana Flagship Showroom & Global Stone Importers). The application unifies a high-end e-commerce storefront for architects, interior designers, and luxury homeowners with a physical Point of Sale (POS) terminal, real-time showroom-to-web inventory synchronization, an interactive Three.js 3D specimen studio, manual slab media uploading, and an enterprise visual Permission Matrix with lock/unlock security.

### 1. CORE ARCHITECTURE & DESIGN CONSTITUTION
- Framework: React 18 SPA with TypeScript, Tailwind CSS, and Lucide icons.
- Visual Language & Aesthetics: Ultra-luxury architectural aesthetic inspired by high-end Italian stone quarries and architectural design houses. Use a refined dark obsidian palette (#0c0a09, #1c1917, #292524) with warm champagne gold accents (#D4AF37, #C5A059), crisp muted stone borders, subtle emerald success indicators (#10b981), elegant serif headers (Playfair Display / Cormorant style), and technical monospace typography for SKUs, coordinates, and dimensions. Strictly avoid generic rounded pill buttons or colorful gradients.
- Currency & Localization: Default currency is Ghanaian Cedi (GH₵ / GHS) with comma-separated formatting (e.g. GH₵12,500.00). Support Ghana Post GPS formatting (e.g. GA-082-4190) and local Ghanaian logistics regions (Airport Residential, Cantonments, Ridge West, East Legon).
- Multi-Tenant Company Support: Built-in company registry (e.g., "Atelier Surfaces Flagship", "Verona Stone Imports", "Nordic Ceramic Works"). Include instant tenant switching, company-scoped local storage, and export/import of full tenant configurations.

### 2. DUAL-ENGINE NAVIGATION & ROUTING
Provide client-side routing supporting both public storefront and authenticated administrative console:
- Storefront Routes:
  - `/`: Cinematic architectural hero landing page with luxury marble textures, curated collections, showroom video consultation preview, and live inventory tickers.
  - `/shop`: Granular filtering by category (Porcelain Slabs, Natural Marble, Limestone, Travertine, Terrazzo), material geology, finish (Polished, Honed, Brushed, Bush-hammered), sizes (e.g. 120x240cm, 160x320cm), slip resistance (R9-R12), and price range.
  - `/product/:slug`: Interactive product detail view featuring multi-image gallery, 3D specimen inspection studio, 2D photometric lighting simulator, box-to-m² area calculators, trade sample ordering, and real-time live stock indicators.
  - `/cart` & `/checkout`: Multi-step checkout with Paystack payment gateway simulation, bank transfer invoices, and Ghana Post GPS delivery dispatch.
  - `/account`, `/wishlist`, `/install`: Client trade accounts, moodboard wishlist, and PWA install prompt.
- Admin & POS Routes:
  - `/admin`: Enterprise dashboard with real-time revenue analytics, active orders, and low-stock telemetry.
  - `/pos`: High-speed physical retail POS register for showroom floor staff with barcode/SKU quick-search, trade buyer discounts, instant receipt generation, and live inventory deductions.
  - `/admin/products`: Product Catalog & Slabs management, bulk pricing modifiers, and Manual Product Upload.
  - `/admin/inventory`: Stock levels, warehouse crate locations, and reorder alerts.
  - `/admin/roles`: Enterprise Permission Matrix with 20 business modules, lock/unlock protection, granular toggles, and role deletion.
  - `/admin/settings`: Flagship showroom contact, Google Maps showroom pin, Ghana Post GPS credentials, Paystack keys, and display theme settings with "Apply & Save".
  - `/admin/audit-logs`: Cryptographic audit trails tracking price changes, user role modifications, and inventory transactions.

### 3. REAL-TIME EVENT STREAMING & POS-TO-STOREFRONT WEBSOCKET PIPELINE
- Implement a real-time event pipeline (`realtimeSyncService`) backed by WebSocket (`/ws/pos`) with Server-Sent Events (`/api/pos/stream`) and browser DOM event fallbacks (`pos_inventory_synced`, `pos_price_synced`, `roles_updated`, `storage`).
- Whenever a sale is completed at the physical POS register or inventory is updated in the back-office:
  - Stock levels are immediately deducted.
  - A real-time `INVENTORY_ADJUSTED` or `PRICE_UPDATED` event is broadcasted.
  - The storefront catalog (`/shop`), product detail pages (`/product/:slug`), and open customer carts immediately update their stock count and pricing without requiring a page reload.
  - Toast alerts notify customers of live physical showroom transactions (e.g. "⚡ In-Store Sale: 48 m² Calacatta Gold just purchased at Accra counter").

### 4. MANUAL PRODUCT & SLAB UPLOAD (APPLY & SAVE TO STOREFRONT)
Under `/admin/products`, add a dedicated "Manual Product Upload" workflow:
- Image Upload Options:
  - Drag-and-drop zone and native file selector supporting image files (JPG, PNG, WebP). Files must be converted to base64 data URLs via `FileReader` for persistent cross-session storage.
  - Curated luxury stone presets (Calacatta Gold, Nero Marquina, French Limestone, Roman Travertine, Terrazzo Moderno).
  - Direct image URL input.
  - Interactive thumbnail strip allowing admins to remove photos or designate any image as the primary cover specimen.
- Technical & Aesthetic Specifications:
  - Name, URL slug (with auto-generation), category, material geology, finish sheen.
  - Pricing per m² (GH₵), compare-at price, available stock in m², box coverage (m² per crate), minimum reorder threshold.
  - Color variation name, visual hex color picker swatch, and custom or auto-generated SKU.
  - Rectification status, water absorption rate (< 0.05%), slip resistance rating (R10), country of origin, and architectural applications (Floors, Walls, Countertops, Wet Rooms, Pool Decks, Facades).
- Action Handler:
  - Provide a prominent "Apply & Save to Storefront" button.
  - Clicking commits the slab to `storeService`, broadcasts `PRICE_UPDATED` and `INVENTORY_ADJUSTED` events over the real-time WebSocket pipeline, and triggers immediate storefront re-rendering.
  - Display a live confirmation banner in the admin table with the uploaded photo thumbnail, SKU, live badge, and a direct "View on Storefront →" link.
- Also equip the comprehensive editor (`/admin/products/:id`) with variant photo file upload inputs.

### 5. FLAGSHIP SHOWROOM CONTACT & GPS CREDENTIALS (APPLY & SAVE)
In the administrative settings panel:
- Provide editable controls for Flagship Showroom Name, Physical Address (Plot 48, Embassy Road, Airport Residential Area, Accra), Ghana Post GPS digital address (GA-082-4190), Showroom Phone, Concierge Email, Google Maps embed/pin coordinates (Latitude 5.6037, Longitude -0.1870), and VIP Opening Hours.
- An explicit "Apply & Save Showroom Credentials" button must save changes, replace old credentials across all customer footer components, contact pages, and POS receipts, and dispatch real-time events.

### 6. ENTERPRISE PERMISSION MATRIX (LOCK/UNLOCK, SELECT/UNSELECT, APPLY & SAVE, DELETE ROLE)
Under `/admin/roles`, provide an enterprise-grade visual Role-Based Access Control (RBAC) permission matrix:
- Matrix Scope: 20 business modules (Dashboard, Reports, Audit Logs, Products, Product Variations, Categories, Inventory, Stock Adjustments, Suppliers, Purchases, Orders, Customers, Discounts, Payments, Refunds, Showroom POS, Roles, Personnel, System Settings, Security) across 8 action columns (View, Create, Edit, Delete, Approve, Export, Settings, Publish).
- Lock & Unlock Security State:
  - Default state is Locked (`[🔒 Permission Matrix Locked: Protected Read-Only]`).
  - When locked, all permission checkboxes and role deletion actions are disabled to prevent accidental tampering.
  - Clicking "Unlock Matrix to Edit" requires administrator credentials (master password `admin123` or company password) if not already logged in, unlocking the matrix into Edit Mode (`[🔓 Permission Matrix Unlocked: Edit Mode Active]`).
- Granular & Batch Authorization:
  - In Edit Mode, admins can freely select or unselect any individual checkbox.
  - Module row toggles ("Select" / "Clear").
  - Action column headers (click column header to toggle that action across all modules).
  - Quick-action batch buttons: "Select All (Grant All)" and "Unselect All (Clear All)" for the entire active role.
- Apply & Save:
  - Prominent "Apply & Save" and "Apply, Save & Lock" buttons save the role permissions to `storeService.saveRole()` and emit `roles_updated` events so all active user sessions reflect changes immediately.
  - A prominent "Lock Matrix" / "Lock It Again" button immediately returns the matrix to protected read-only mode.
- Role Deletion:
  - When unlocked, a "Delete Role" button opens a confirmation modal detailing the role and number of affected personnel.
  - Confirming safely reassigns all affected staff to a fallback role (Super Admin/Staff) and purges the role definition.
  - Admin can immediately lock the matrix again after deleting.

### 7. THREE.JS 3D SPECIMEN STUDIO & 2D PHOTOMETRIC LIGHTING SIMULATOR
On the product detail page (`/product/:slug`), provide an interactive surface inspection studio:
- Three.js 3D View: Interactive 3D slab rendered on a canvas with realistic specular highlights, surface bump mapping, rotation, zoom, and dynamic ambient lighting.
- Photometric Lighting Simulator: Adjust color temperatures (Daylight 5500K, Warm Golden Hour 3200K, Architectural Spotlight 4000K) and illumination intensity (LUX slider) to simulate how stone veining and sheen react in real architectural environments.
```
