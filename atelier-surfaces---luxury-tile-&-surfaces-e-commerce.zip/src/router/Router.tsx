import React, { createContext, useContext, useState, useEffect } from 'react';

interface RouterContextType {
  currentPath: string;
  navigate: (path: string, options?: { replace?: boolean }) => void;
  searchParams: URLSearchParams;
  params: Record<string, string>;
}

const RouterContext = createContext<RouterContextType | undefined>(undefined);

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const [currentPath, setCurrentPath] = useState(() => window.location.pathname || '/');
  const [searchParams, setSearchParams] = useState(() => new URLSearchParams(window.location.search));

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
      setSearchParams(new URLSearchParams(window.location.search));
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string, options?: { replace?: boolean }) => {
    const [pathname, search] = path.split('?');
    const existingCompany = searchParams.get('company') || searchParams.get('tenant');
    const newSearchParams = new URLSearchParams(search || '');
    
    // Automatically preserve active company/tenant parameter unless explicitly overridden
    if (existingCompany && !newSearchParams.has('company') && !newSearchParams.has('tenant')) {
      newSearchParams.set('company', existingCompany);
    }
    
    const finalSearch = newSearchParams.toString();
    const finalUrl = finalSearch ? `${pathname}?${finalSearch}` : pathname;

    if (options?.replace) {
      window.history.replaceState({}, '', finalUrl);
    } else {
      window.history.pushState({}, '', finalUrl);
    }
    setCurrentPath(pathname);
    setSearchParams(newSearchParams);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Extract params based on common patterns
  const extractParams = (path: string): Record<string, string> => {
    const params: Record<string, string> = {};
    const parts = path.split('/').filter(Boolean);

    if (parts[0] === 'category' && parts[1]) {
      params.slug = parts[1];
    } else if (parts[0] === 'product' && parts[1]) {
      params.slug = parts[1];
    } else if (parts[0] === 'order-confirmation' && parts[1]) {
      params.orderId = parts[1];
    } else if (parts[0] === 'account' && parts[1] === 'orders' && parts[2]) {
      params.orderId = parts[2];
    } else if (parts[0] === 'admin' && parts[1] === 'products' && parts[2] && parts[3] === 'edit') {
      params.id = parts[2];
    } else if (parts[0] === 'admin' && parts[1] === 'orders' && parts[2]) {
      params.id = parts[2];
    }

    return params;
  };

  const params = extractParams(currentPath);

  return (
    <RouterContext.Provider value={{ currentPath, navigate, searchParams, params }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const context = useContext(RouterContext);
  if (!context) throw new Error('useRouter must be used within RouterProvider');
  return context;
}

export function Link({
  href,
  children,
  className = '',
  onClick,
  ...props
}: React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) {
  const { navigate, currentPath, searchParams } = useRouter();
  const isActive = currentPath === href || (href !== '/' && currentPath.startsWith(href));

  // Compute href with company parameter preservation for native browser behavior
  const existingCompany = searchParams.get('company') || searchParams.get('tenant');
  let computedHref = href;
  if (existingCompany && href.startsWith('/') && !href.includes('company=') && !href.includes('tenant=')) {
    const separator = href.includes('?') ? '&' : '?';
    computedHref = `${href}${separator}company=${encodeURIComponent(existingCompany)}`;
  }

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (onClick) onClick(e);
    if (!e.defaultPrevented && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey) {
      e.preventDefault();
      navigate(computedHref);
    }
  };

  return (
    <a
      href={computedHref}
      onClick={handleClick}
      className={`${className} ${isActive ? 'is-active' : ''}`}
      {...props}
    >
      {children}
    </a>
  );
}

