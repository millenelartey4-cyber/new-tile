import React, { createContext, useContext, useState, useEffect } from 'react';
import { CompanyTenant } from '../types';
import { storeService } from '../services/store';

interface CompanyContextType {
  activeCompany: CompanyTenant;
  companies: CompanyTenant[];
  switchCompany: (companyIdOrSlug: string) => void;
  deployCompany: (data: Partial<CompanyTenant>, seedTemplate?: 'copy' | 'empty') => CompanyTenant;
  deleteCompany: (companyId: string) => boolean;
  updateCompany: (company: CompanyTenant) => void;
  getCompanyShareUrl: (companySlugOrId: string) => string;
  exportCompany: (companyId: string) => string;
  importCompany: (jsonString: string) => { success: boolean; companyId?: string; error?: string };
  isSwitcherOpen: boolean;
  setIsSwitcherOpen: (open: boolean) => void;
  isDeployModalOpen: boolean;
  setIsDeployModalOpen: (open: boolean) => void;
}

const CompanyContext = createContext<CompanyContextType | undefined>(undefined);

export function CompanyProvider({ children }: { children: React.ReactNode }) {
  const [companies, setCompanies] = useState<CompanyTenant[]>(() => storeService.getCompanies());
  const [activeCompany, setActiveCompany] = useState<CompanyTenant>(() => storeService.getActiveCompany());
  const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);

  // Sync when active tenant or store settings change in storeService
  useEffect(() => {
    const handleSync = () => {
      setCompanies(storeService.getCompanies());
      setActiveCompany(storeService.getActiveCompany());
    };

    const unsubscribeTenant = storeService.onTenantChange(handleSync);
    const unsubscribeSettings = storeService.onSettingsChange(handleSync);

    window.addEventListener('atelier_settings_updated', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      unsubscribeTenant();
      unsubscribeSettings();
      window.removeEventListener('atelier_settings_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  const switchCompany = (companyIdOrSlug: string) => {
    storeService.setActiveTenantId(companyIdOrSlug);
    setCompanies(storeService.getCompanies());
    setActiveCompany(storeService.getActiveCompany());
    setIsSwitcherOpen(false);
  };

  const deployCompany = (data: Partial<CompanyTenant>, seedTemplate: 'copy' | 'empty' = 'copy'): CompanyTenant => {
    const newCompany = storeService.cloneCompanyWorkspace(activeCompany.id, data, seedTemplate);
    setCompanies(storeService.getCompanies());
    setActiveCompany(newCompany);
    setIsDeployModalOpen(false);
    return newCompany;
  };

  const deleteCompany = (companyId: string): boolean => {
    const success = storeService.deleteCompany(companyId);
    if (success) {
      setCompanies(storeService.getCompanies());
      setActiveCompany(storeService.getActiveCompany());
    }
    return success;
  };

  const updateCompany = (company: CompanyTenant) => {
    const updated = storeService.saveCompany(company);
    setCompanies(storeService.getCompanies());
    if (updated.id === activeCompany.id) {
      setActiveCompany(updated);
    }
  };

  const getCompanyShareUrl = (companySlugOrId: string): string => {
    try {
      if (typeof window !== 'undefined') {
        const url = new URL(window.location.origin + window.location.pathname);
        url.searchParams.set('company', companySlugOrId);
        return url.toString();
      }
    } catch {}
    return `/?company=${companySlugOrId}`;
  };

  const exportCompany = (companyId: string): string => {
    return storeService.exportCompanyJson(companyId);
  };

  const importCompany = (jsonString: string) => {
    const res = storeService.importCompanyJson(jsonString);
    if (res.success && res.companyId) {
      setCompanies(storeService.getCompanies());
      setActiveCompany(storeService.getActiveCompany());
    }
    return res;
  };

  return (
    <CompanyContext.Provider
      value={{
        activeCompany,
        companies,
        switchCompany,
        deployCompany,
        deleteCompany,
        updateCompany,
        getCompanyShareUrl,
        exportCompany,
        importCompany,
        isSwitcherOpen,
        setIsSwitcherOpen,
        isDeployModalOpen,
        setIsDeployModalOpen
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
}

export function useCompany() {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within CompanyProvider');
  }
  return context;
}
