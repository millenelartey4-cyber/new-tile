import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { useCompany } from './CompanyContext';
import { createVirtualMediaStream } from '../utils/videoStreamGenerator';

export interface VideoMessage {
  id: string;
  sender: string;
  senderId: string;
  role: string;
  content: string;
  timestamp: string;
  attachment?: {
    type: string;
    title: string;
    image?: string;
    price?: number;
    currency?: string;
    details?: string;
    sku?: string;
  };
}

export interface VideoParticipant {
  id: string;
  name: string;
  role: string;
  cameraOn: boolean;
  micOn: boolean;
  isPresenting: boolean;
  joinedAt: string;
}

interface VideoCallContextType {
  isCallActive: boolean;
  activeRoomId: string | null;
  localStream: MediaStream | null;
  hasCameraPermission: boolean;
  isCameraMuted: boolean;
  isMicMuted: boolean;
  isChatOpen: boolean;
  feedMode: 'webcam' | 'virtual';
  messages: VideoMessage[];
  participants: VideoParticipant[];
  presentingSlab: any | null;
  callDuration: number;
  startCall: (roomId?: string, role?: string, initialSlab?: any) => Promise<string>;
  endCall: () => void;
  toggleCamera: () => void;
  toggleMic: () => void;
  toggleChat: () => void;
  switchVideoFeed: (mode: 'webcam' | 'virtual') => Promise<void>;
  sendMessage: (content: string, attachment?: any) => Promise<void>;
  presentSlab: (slab: any) => Promise<void>;
  stopPresenting: () => Promise<void>;
}

const VideoCallContext = createContext<VideoCallContextType | undefined>(undefined);

export function VideoCallProvider({ children }: { children: React.ReactNode }) {
  const { currentUser, currentRole } = useAuth();
  const { activeCompany } = useCompany();

  const [isCallActive, setIsCallActive] = useState(false);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState(false);
  const [isCameraMuted, setIsCameraMuted] = useState(false);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [feedMode, setFeedMode] = useState<'webcam' | 'virtual'>('webcam');
  const [messages, setMessages] = useState<VideoMessage[]>([]);
  const [participants, setParticipants] = useState<VideoParticipant[]>([]);
  const [presentingSlab, setPresentingSlab] = useState<any | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  const localStreamRef = useRef<MediaStream | null>(null);
  const durationTimerRef = useRef<number | null>(null);
  const heartbeatTimerRef = useRef<number | null>(null);
  const pollMessagesTimerRef = useRef<number | null>(null);

  const userId = useRef(`user-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`);

  // Call timer
  useEffect(() => {
    if (isCallActive) {
      durationTimerRef.current = window.setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
      setCallDuration(0);
    }
    return () => {
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    };
  }, [isCallActive]);

  // Request real camera & mic stream with auto virtual fallback
  const acquireMediaStream = async (targetMode: 'webcam' | 'virtual' = 'webcam'): Promise<MediaStream> => {
    // 1. Stop existing tracks if any
    if (localStreamRef.current) {
      try {
        (localStreamRef.current as any).stopVirtualStream?.();
        localStreamRef.current.getTracks().forEach(t => t.stop());
      } catch {}
    }

    // 2. Try physical webcam if requested
    if (targetMode === 'webcam') {
      try {
        if (typeof navigator !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: {
              width: { ideal: 1280 },
              height: { ideal: 720 },
              facingMode: 'user',
            },
            audio: true,
          });
          localStreamRef.current = stream;
          setLocalStream(stream);
          setHasCameraPermission(true);
          setFeedMode('webcam');
          return stream;
        }
      } catch (err) {
        console.warn('Physical camera/mic denied or blocked in iframe sandbox. Auto-switching to high-definition virtual architectural studio stream:', err);
        setHasCameraPermission(false);
      }
    }

    // 3. High-definition Virtual Architectural Camera Stream (guaranteed 100% working in all browsers/iframes)
    const userName = currentUser?.name || 'Architectural Partner';
    const virtualStream = createVirtualMediaStream({
      participantName: userName,
      role: (currentRole?.id as any) || 'architect',
      isConsultant: false,
      width: 1280,
      height: 720,
      fps: 30,
    });

    localStreamRef.current = virtualStream;
    setLocalStream(virtualStream);
    setFeedMode('virtual');
    return virtualStream;
  };

  const switchVideoFeed = async (mode: 'webcam' | 'virtual') => {
    await acquireMediaStream(mode);
  };

  // Start Call
  const startCall = async (roomId?: string, roleParam?: string, initialSlab?: any): Promise<string> => {
    const targetRoomId = roomId || `atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`;
    const userRole = roleParam || currentRole?.id || 'client';
    const userName = currentUser?.name || (userRole === 'consultant' ? 'Kwame Mensah (Architectural Consultant)' : 'Guest Client');

    // Acquire camera & audio
    await acquireMediaStream();

    setActiveRoomId(targetRoomId);
    setIsCallActive(true);
    if (initialSlab) {
      setPresentingSlab(initialSlab);
    }

    try {
      const res = await fetch(`/api/video/rooms/${targetRoomId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userId.current,
          name: userName,
          role: userRole,
          cameraOn: !isCameraMuted,
          micOn: !isMicMuted,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setParticipants(data.room.participants || []);
        setMessages(data.messages || []);
        if (data.room.presentingSlab) {
          setPresentingSlab(data.room.presentingSlab);
        }
      }
    } catch (err) {
      console.warn('Could not register room on server, running offline/local video call mode:', err);
      // Fallback local participant
      setParticipants([
        {
          id: userId.current,
          name: userName,
          role: userRole,
          cameraOn: true,
          micOn: true,
          isPresenting: false,
          joinedAt: new Date().toISOString(),
        },
        {
          id: 'consultant-kwame',
          name: 'Kwame Mensah (Lead Surface Consultant)',
          role: 'consultant',
          cameraOn: true,
          micOn: true,
          isPresenting: false,
          joinedAt: new Date().toISOString(),
        }
      ]);
    }

    // Start background polling for room messages & participants
    startRoomPolling(targetRoomId);
    return targetRoomId;
  };

  // Polling loop
  const startRoomPolling = (roomId: string) => {
    if (pollMessagesTimerRef.current) clearInterval(pollMessagesTimerRef.current);
    if (heartbeatTimerRef.current) clearInterval(heartbeatTimerRef.current);

    pollMessagesTimerRef.current = window.setInterval(async () => {
      try {
        const [roomRes, msgRes] = await Promise.all([
          fetch(`/api/video/rooms/${roomId}`),
          fetch(`/api/video/rooms/${roomId}/messages`),
        ]);

        if (roomRes.ok) {
          const roomData = await roomRes.json();
          // Always ensure at least the consultant avatar is visible if testing alone
          const serverParts: VideoParticipant[] = roomData.participants || [];
          const hasConsultant = serverParts.some(p => p.role === 'consultant');
          if (!hasConsultant && serverParts.length <= 1) {
            serverParts.push({
              id: 'consultant-kwame',
              name: 'Kwame Mensah (Lead Surface Consultant)',
              role: 'consultant',
              cameraOn: true,
              micOn: true,
              isPresenting: false,
              joinedAt: new Date().toISOString(),
            });
          }
          setParticipants(serverParts);
          if (roomData.presentingSlab !== undefined) {
            setPresentingSlab(roomData.presentingSlab);
          }
        }

        if (msgRes.ok) {
          const msgs = await msgRes.json();
          setMessages(msgs);
        }
      } catch {
        // local network mode
      }
    }, 2000);

    // Heartbeat
    heartbeatTimerRef.current = window.setInterval(async () => {
      try {
        await fetch(`/api/video/rooms/${roomId}/heartbeat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: userId.current,
            cameraOn: !isCameraMuted,
            micOn: !isMicMuted,
            isPresenting: !!presentingSlab,
          }),
        });
      } catch {}
    }, 15000);
  };

  // End Call
  const endCall = () => {
    if (activeRoomId) {
      try {
        fetch(`/api/video/rooms/${activeRoomId}/leave`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: userId.current }),
        });
      } catch {}
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    setLocalStream(null);

    if (pollMessagesTimerRef.current) clearInterval(pollMessagesTimerRef.current);
    if (heartbeatTimerRef.current) clearInterval(heartbeatTimerRef.current);

    setIsCallActive(false);
    setActiveRoomId(null);
    setPresentingSlab(null);
  };

  // Toggle Camera
  const toggleCamera = async () => {
    if (isCameraMuted) {
      if (!localStreamRef.current) {
        await acquireMediaStream(feedMode);
      } else {
        const videoTracks = localStreamRef.current.getVideoTracks();
        videoTracks.forEach(t => {
          t.enabled = true;
        });
      }
      setIsCameraMuted(false);
    } else {
      if (localStreamRef.current) {
        const videoTracks = localStreamRef.current.getVideoTracks();
        videoTracks.forEach(t => {
          t.enabled = false;
        });
      }
      setIsCameraMuted(true);
    }
  };

  // Toggle Mic
  const toggleMic = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach(t => {
        t.enabled = isMicMuted;
      });
    }
    setIsMicMuted(prev => !prev);
  };

  // Toggle Chat
  const toggleChat = () => {
    setIsChatOpen(prev => !prev);
  };

  // Send Message
  const sendMessage = async (content: string, attachment?: any) => {
    if (!content.trim() && !attachment) return;
    if (!activeRoomId) return;

    const senderName = currentUser?.name || 'You';
    const senderRole = currentRole?.id || 'client';

    try {
      const res = await fetch(`/api/video/rooms/${activeRoomId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: senderName,
          senderId: userId.current,
          role: senderRole,
          content: content.trim(),
          attachment,
        }),
      });

      if (res.ok) {
        const newMsg = await res.json();
        setMessages(prev => [...prev, newMsg]);
      }
    } catch {
      // Local fallback
      const localMsg: VideoMessage = {
        id: `local-msg-${Date.now()}`,
        sender: senderName,
        senderId: userId.current,
        role: senderRole,
        content: content.trim(),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        attachment,
      };
      setMessages(prev => [...prev, localMsg]);
    }
  };

  // Present 3D Slab on Call
  const presentSlab = async (slab: any) => {
    setPresentingSlab(slab);
    if (activeRoomId) {
      try {
        await fetch(`/api/video/rooms/${activeRoomId}/present`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ slab }),
        });
      } catch {}
    }
  };

  // Stop Presenting
  const stopPresenting = async () => {
    setPresentingSlab(null);
    if (activeRoomId) {
      try {
        await fetch(`/api/video/rooms/${activeRoomId}/present`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ slab: null }),
        });
      } catch {}
    }
  };

  return (
    <VideoCallContext.Provider
      value={{
        isCallActive,
        activeRoomId,
        localStream,
        hasCameraPermission,
        isCameraMuted,
        isMicMuted,
        isChatOpen,
        feedMode,
        messages,
        participants,
        presentingSlab,
        callDuration,
        startCall,
        endCall,
        toggleCamera,
        toggleMic,
        toggleChat,
        switchVideoFeed,
        sendMessage,
        presentSlab,
        stopPresenting,
      }}
    >
      {children}
    </VideoCallContext.Provider>
  );
}

export function useVideoCall() {
  const context = useContext(VideoCallContext);
  if (!context) {
    throw new Error('useVideoCall must be used within VideoCallProvider');
  }
  return context;
}
