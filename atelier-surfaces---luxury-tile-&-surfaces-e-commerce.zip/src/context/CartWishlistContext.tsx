import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product, ProductVariant, AppliedBulkDiscount } from '../types';
import { storeService } from '../services/store';

interface CartWishlistContextType {
  cart: CartItem[];
  addToCart: (product: Product, variant: ProductVariant, quantity?: number) => void;
  requestSample: (product: Product, variant: ProductVariant, sampleCost?: number) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  itemCount: number;
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  bulkDiscount: number;
  appliedBulkTiers: AppliedBulkDiscount[];
  total: number;
  freeShippingProgress: number;
  freeShippingThreshold: number;
  
  // Wishlist
  wishlist: { productId: string; variantId: string; addedAt: string }[];
  toggleWishlist: (productId: string, variantId: string) => boolean;
  isInWishlist: (productId: string, variantId: string) => boolean;
  wishlistCount: number;
}

const CartWishlistContext = createContext<CartWishlistContextType | undefined>(undefined);

const getCartKey = (tid: string) => `tenant_${tid}_cart_v1`;
const getWishlistKey = (tid: string) => `tenant_${tid}_wishlist_v1`;

export function CartWishlistProvider({ children }: { children: React.ReactNode }) {
  const [activeTenantId, setActiveTenantId] = useState(() => storeService.getActiveTenantId());

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const tid = storeService.getActiveTenantId();
      const saved = localStorage.getItem(getCartKey(tid));
      if (saved) return JSON.parse(saved);
      // Legacy fallback for default tenant
      if (tid === 'atelier-surfaces') {
        const leg = localStorage.getItem('atelier_surfaces_cart_v2');
        if (leg) return JSON.parse(leg);
      }
      return [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<{ productId: string; variantId: string; addedAt: string }[]>(() => {
    try {
      const tid = storeService.getActiveTenantId();
      const saved = localStorage.getItem(getWishlistKey(tid));
      if (saved) return JSON.parse(saved);
      if (tid === 'atelier-surfaces') {
        const leg = localStorage.getItem('atelier_surfaces_wishlist_v2');
        if (leg) return JSON.parse(leg);
      }
      return [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const settings = storeService.getStoreSettings();

  // Listen to company switches and swap cart/wishlist
  useEffect(() => {
    const unsubscribe = storeService.onTenantChange((newTenantId) => {
      setActiveTenantId(newTenantId);
      try {
        const savedCart = localStorage.getItem(getCartKey(newTenantId));
        setCart(savedCart ? JSON.parse(savedCart) : []);
        const savedWish = localStorage.getItem(getWishlistKey(newTenantId));
        setWishlist(savedWish ? JSON.parse(savedWish) : []);
      } catch {
        setCart([]);
        setWishlist([]);
      }
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(getCartKey(activeTenantId), JSON.stringify(cart));
    } catch (e) {
      console.warn('Failed to persist tenant cart:', e);
    }
  }, [cart, activeTenantId]);

  useEffect(() => {
    try {
      localStorage.setItem(getWishlistKey(activeTenantId), JSON.stringify(wishlist));
    } catch (e) {
      console.warn('Failed to persist tenant wishlist:', e);
    }
  }, [wishlist, activeTenantId]);

  // Real-time listener: Update cart items if price or stock changes at physical store
  useEffect(() => {
    const handleStockSync = (e: any) => {
      const { productId, variantId, newStock } = e.detail || {};
      if (productId && variantId && typeof newStock === 'number') {
        setCart(prev => prev.map(item => {
          if (item.productId === productId && item.variantId === variantId) {
            return {
              ...item,
              maxStock: newStock,
              quantity: Math.min(item.quantity, Math.max(0, newStock))
            };
          }
          return item;
        }));
      }
    };

    const handlePriceSync = (e: any) => {
      const { productId, variantId, newPrice } = e.detail || {};
      if (productId && variantId && typeof newPrice === 'number') {
        setCart(prev => prev.map(item => {
          if (item.productId === productId && item.variantId === variantId) {
            return {
              ...item,
              unitPrice: newPrice
            };
          }
          return item;
        }));
      } else {
        // Bulk or general refresh: reload prices from storeService
        const freshProducts = storeService.getProducts(activeTenantId);
        setCart(prev => prev.map(item => {
          const prod = freshProducts.find(p => p.id === item.productId);
          const variant = prod?.variants.find(v => v.id === item.variantId);
          if (variant) {
            return {
              ...item,
              unitPrice: variant.price,
              maxStock: variant.stock
            };
          }
          return item;
        }));
      }
    };

    window.addEventListener('pos_inventory_synced', handleStockSync);
    window.addEventListener('pos_price_synced', handlePriceSync);
    window.addEventListener('pos_sale_broadcast', handlePriceSync);
    window.addEventListener('bulk_pricing_updated', handlePriceSync);

    return () => {
      window.removeEventListener('pos_inventory_synced', handleStockSync);
      window.removeEventListener('pos_price_synced', handlePriceSync);
      window.removeEventListener('pos_sale_broadcast', handlePriceSync);
      window.removeEventListener('bulk_pricing_updated', handlePriceSync);
    };
  }, [activeTenantId]);

  const addToCart = (product: Product, variant: ProductVariant, quantity: number = 1) => {
    const lineId = `${product.id}_${variant.id}`;
    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.id === lineId);
      if (existingIndex > -1) {
        const existing = prev[existingIndex];
        const newQty = Math.min(existing.quantity + quantity, variant.stock);
        const updated = [...prev];
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          maxStock: variant.stock
        };
        return updated;
      } else {
        const newItem: CartItem = {
          id: lineId,
          productId: product.id,
          productName: product.name,
          productSlug: product.slug,
          variantId: variant.id,
          colorName: variant.colorName,
          colorHex: variant.colorHex,
          image: variant.images[0] || product.variants[0]?.images[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg',
          sku: variant.sku,
          unitPrice: variant.price,
          quantity: Math.min(quantity, variant.stock),
          unit: variant.unit,
          boxCoverage: variant.boxCoverage,
          maxStock: variant.stock
        };
        return [newItem, ...prev];
      }
    });

    // Auto open cart drawer to give immediate feedback
    setIsCartOpen(true);
  };

  const requestSample = (product: Product, variant: ProductVariant, sampleCost: number = 35) => {
    const sampleLineId = `${product.id}_${variant.id}_sample_4x4`;
    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.id === sampleLineId);
      if (existingIndex > -1) {
        const existing = prev[existingIndex];
        const updated = [...prev];
        updated[existingIndex] = {
          ...existing,
          quantity: Math.min(existing.quantity + 1, 10), // Allow up to 10 sample pieces
        };
        return updated;
      } else {
        const sampleItem: CartItem = {
          id: sampleLineId,
          productId: product.id,
          productName: `${product.name} (4" × 4" Sample)`,
          productSlug: product.slug,
          variantId: variant.id,
          colorName: variant.colorName,
          colorHex: variant.colorHex,
          image: variant.images[0] || product.variants[0]?.images[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg',
          sku: `${variant.sku}-SAMPLE-4X4`,
          unitPrice: sampleCost,
          quantity: 1,
          unit: 'sample',
          boxCoverage: 0.01,
          maxStock: 10,
          isSample: true,
          sampleDimensions: '4" × 4" (10 × 10 cm)'
        };
        return [sampleItem, ...prev];
      }
    });

    // Auto open cart drawer with specimen
    setIsCartOpen(true);
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setCart(prev => prev.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          quantity: Math.min(quantity, item.maxStock)
        };
      }
      return item;
    }));
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Calculations
  const itemCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const subtotal = cart.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0);
  
  // Bulk pricing calculations
  const bulkResult = storeService.calculateCartBulkDiscount(cart, activeTenantId);
  const bulkDiscount = bulkResult.totalBulkDiscount;
  const appliedBulkTiers = bulkResult.appliedRules;

  const discount = 0; // Standard storefront coupon discounts (applied at checkout)
  const freeShippingThreshold = settings.freeDeliveryThreshold || 5000;
  const effectiveSubtotalAfterBulk = Math.max(0, subtotal - bulkDiscount);
  const shipping = effectiveSubtotalAfterBulk >= freeShippingThreshold || effectiveSubtotalAfterBulk === 0 ? 0 : settings.standardDeliveryCost;
  const tax = effectiveSubtotalAfterBulk * (settings.taxRatePercent / 100);
  const total = Math.max(0, effectiveSubtotalAfterBulk + shipping + tax - discount);
  const freeShippingProgress = Math.min(100, (effectiveSubtotalAfterBulk / freeShippingThreshold) * 100);

  // Wishlist
  const toggleWishlist = (productId: string, variantId: string): boolean => {
    let isNowIn = false;
    setWishlist(prev => {
      const exists = prev.some(w => w.productId === productId && w.variantId === variantId);
      if (exists) {
        isNowIn = false;
        return prev.filter(w => !(w.productId === productId && w.variantId === variantId));
      } else {
        isNowIn = true;
        return [{ productId, variantId, addedAt: new Date().toISOString() }, ...prev];
      }
    });
    return isNowIn;
  };

  const isInWishlist = (productId: string, variantId: string) => {
    return wishlist.some(w => w.productId === productId && w.variantId === variantId);
  };

  return (
    <CartWishlistContext.Provider
      value={{
        cart,
        addToCart,
        requestSample,
        updateQuantity,
        removeFromCart,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        itemCount,
        subtotal,
        tax,
        shipping,
        discount,
        bulkDiscount,
        appliedBulkTiers,
        total,
        freeShippingProgress,
        freeShippingThreshold,
        wishlist,
        toggleWishlist,
        isInWishlist,
        wishlistCount: wishlist.length
      }}
    >
      {children}
    </CartWishlistContext.Provider>
  );
}

export function useCartWishlist() {
  const context = useContext(CartWishlistContext);
  if (!context) throw new Error('useCartWishlist must be used within CartWishlistProvider');
  return context;
}
