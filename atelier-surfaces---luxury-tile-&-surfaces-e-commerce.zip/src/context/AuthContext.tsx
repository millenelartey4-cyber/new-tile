import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppUser, UserRole, ModuleKey, ActionType } from '../types';
import { storeService } from '../services/store';

interface AuthContextType {
  currentUser: AppUser | null;
  currentRole: UserRole | null;
  isAuthenticated: boolean;
  isAdminOrStaff: boolean;
  isAdminConsoleUnlocked: boolean;
  unlockAdminConsole: (password: string) => { success: boolean; error?: string };
  lockAdminConsole: () => void;
  hasPermission: (module: ModuleKey, action: ActionType) => boolean;
  switchUser: (userId: string) => void;
  switchRole: (roleId: string) => void;
  login: (email: string, roleId?: string) => boolean;
  logout: () => void;
  register: (name: string, email: string, phone: string) => AppUser;
  availableUsers: AppUser[];
  availableRoles: UserRole[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_UNLOCK_KEY = 'atelier_admin_console_unlocked_v1';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<AppUser[]>(() => storeService.getUsers());
  const [roles, setRoles] = useState<UserRole[]>(() => storeService.getRoles());
  
  // Admin Console Lock status: Default to locked (false) unless validated with password
  const [isAdminConsoleUnlocked, setIsAdminConsoleUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(ADMIN_UNLOCK_KEY) === 'true' || 
             localStorage.getItem(ADMIN_UNLOCK_KEY) === 'true';
    } catch {
      return false;
    }
  });

  // Default active user is customer unless console is explicitly unlocked
  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const isUnlocked = (() => {
      try {
        return sessionStorage.getItem(ADMIN_UNLOCK_KEY) === 'true' || 
               localStorage.getItem(ADMIN_UNLOCK_KEY) === 'true';
      } catch {
        return false;
      }
    })();

    const saved = localStorage.getItem('atelier_active_user_id');
    if (isUnlocked) {
      return saved || 'usr-admin-1';
    }
    // If not unlocked, preserve customer user or default to customer
    if (saved && saved !== 'usr-admin-1') {
      return saved;
    }
    return 'usr-customer-1';
  });

  const currentUser = React.useMemo(() => {
    return users.find(u => u.uid === currentUserId) || users[0];
  }, [users, currentUserId]);

  const currentRole = React.useMemo(() => {
    if (!currentUser) return null;
    return roles.find(r => r.id === currentUser.roleId) || null;
  }, [currentUser, roles]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('atelier_active_user_id', currentUser.uid);
    }
  }, [currentUser]);

  useEffect(() => {
    const handleRolesUpdate = () => {
      setRoles(storeService.getRoles());
      setUsers(storeService.getUsers());
    };
    window.addEventListener('roles_updated', handleRolesUpdate);
    window.addEventListener('storage', handleRolesUpdate);
    return () => {
      window.removeEventListener('roles_updated', handleRolesUpdate);
      window.removeEventListener('storage', handleRolesUpdate);
    };
  }, []);

  const hasPermission = (module: ModuleKey, action: ActionType): boolean => {
    if (!currentRole) return false;
    // Super admin has all permissions
    if (currentRole.id === 'super-admin') return true;

    const modulePermissions = currentRole.permissions[module];
    if (!modulePermissions) return false;
    return modulePermissions.includes(action);
  };

  const switchUser = (userId: string) => {
    const user = users.find(u => u.uid === userId);
    if (user) {
      setCurrentUserId(userId);
    }
  };

  const switchRole = (roleId: string) => {
    if (!currentUser) return;
    const role = roles.find(r => r.id === roleId);
    if (role) {
      storeService.updateUserRole(currentUser.uid, role.id, currentUser.name);
      setUsers(storeService.getUsers());
      setRoles(storeService.getRoles());
    }
  };

  const login = (email: string, roleId?: string): boolean => {
    let user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      // Find matching by role or create
      user = users.find(u => u.roleId === (roleId || 'customer'));
    }
    if (user) {
      setCurrentUserId(user.uid);
      return true;
    }
    return false;
  };

  const logout = () => {
    // Switch to customer or guest
    const customerUser = users.find(u => u.roleId === 'customer') || users[users.length - 1];
    setCurrentUserId(customerUser.uid);
  };

  const register = (name: string, email: string, phone: string): AppUser => {
    const newUser: AppUser = {
      uid: `usr-${Date.now()}`,
      name,
      email,
      phone,
      roleId: 'customer',
      roleName: 'Customer / Trade Buyer',
      active: true,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    };
    const updated = [...users, newUser];
    setUsers(updated);
    storeService.saveProduct // Trigger state sync
    localStorage.setItem('atelier_surfaces_users_v2', JSON.stringify(updated));
    setCurrentUserId(newUser.uid);
    return newUser;
  };

  const unlockAdminConsole = (password: string): { success: boolean; error?: string } => {
    const inputPass = password.trim();
    const activeCompany = storeService.getActiveCompany();
    const companyPass = activeCompany?.adminPassword?.trim();

    const isValid = inputPass === 'admin123' || (companyPass && inputPass === companyPass);

    if (isValid) {
      setIsAdminConsoleUnlocked(true);
      try {
        sessionStorage.setItem(ADMIN_UNLOCK_KEY, 'true');
        localStorage.setItem(ADMIN_UNLOCK_KEY, 'true');
      } catch (e) {
        console.warn('Failed to save admin unlock state:', e);
      }
      
      // Auto-elevate to Super Admin
      const adminUser = users.find(u => u.roleId === 'super-admin') || users[0];
      if (adminUser) {
        setCurrentUserId(adminUser.uid);
        localStorage.setItem('atelier_active_user_id', adminUser.uid);
      }

      storeService.addAuditLog(
        adminUser?.name || 'Administrator',
        'Super Admin',
        'ADMIN_CONSOLE_UNLOCKED',
        'Security',
        'console',
        `Admin control console unlocked successfully for ${activeCompany?.name || 'Storefront'}.`
      );

      return { success: true };
    }

    storeService.addAuditLog(
      'Anonymous Visitor',
      'Public',
      'ADMIN_CONSOLE_FAILED_ATTEMPT',
      'Security',
      'console',
      'Failed attempt to unlock admin control console with incorrect password.'
    );

    return { 
      success: false, 
      error: 'Incorrect admin password. Access restricted. Please enter the valid master password.' 
    };
  };

  const lockAdminConsole = () => {
    setIsAdminConsoleUnlocked(false);
    try {
      sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
      localStorage.removeItem(ADMIN_UNLOCK_KEY);
    } catch (e) {
      console.warn('Failed to clear admin unlock state:', e);
    }

    // Demote current session to customer user
    const customerUser = users.find(u => u.roleId === 'customer') || users[users.length - 1];
    if (customerUser) {
      setCurrentUserId(customerUser.uid);
      localStorage.setItem('atelier_active_user_id', customerUser.uid);
    }

    storeService.addAuditLog(
      currentUser?.name || 'Administrator',
      currentRole?.name || 'Super Admin',
      'ADMIN_CONSOLE_LOCKED',
      'Security',
      'console',
      'Admin console locked securely. Master password required for subsequent entry.'
    );
  };

  const isAdminOrStaff = isAdminConsoleUnlocked && currentUser?.roleId !== 'customer';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentRole,
        isAuthenticated: !!currentUser,
        isAdminOrStaff,
        isAdminConsoleUnlocked,
        unlockAdminConsole,
        lockAdminConsole,
        hasPermission,
        switchUser,
        switchRole,
        login,
        logout,
        register,
        availableUsers: users,
        availableRoles: roles
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
