import React, { createContext, useContext, useState, useEffect } from 'react';
import { ThemePreset, ThemeTokens } from '../types';
import { PRESET_THEMES, DEFAULT_THEME_ID, getThemeById, getContrastRatio } from '../data/themes';
import { storeService } from '../services/store';

interface ThemeContextType {
  activeTheme: ThemePreset;
  previewTheme: ThemePreset | null;
  customThemes: { id: string; name: string; tokens: ThemeTokens; updatedAt: string }[];
  allPresets: ThemePreset[];
  setPreviewTheme: (theme: ThemePreset | null) => void;
  applyTheme: (themeId: string, actorName?: string) => void;
  saveCustomTheme: (name: string, tokens: ThemeTokens, actorName?: string) => void;
  deleteCustomTheme: (id: string, actorName?: string) => void;
  resetToBrandDefault: () => void;
  contrastRatio: number;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [activeThemeId, setActiveThemeId] = useState<string>(() => {
    const settings = storeService.getStoreSettings();
    return settings.activeThemeId || DEFAULT_THEME_ID;
  });

  const [previewTheme, setPreviewTheme] = useState<ThemePreset | null>(null);
  const [customThemes, setCustomThemes] = useState(() => storeService.getCustomThemes());

  // Listen to company tenant change and apply that company's active theme
  useEffect(() => {
    const unsubscribe = storeService.onTenantChange(() => {
      const settings = storeService.getStoreSettings();
      setActiveThemeId(settings.activeThemeId || DEFAULT_THEME_ID);
      setCustomThemes(storeService.getCustomThemes());
    });
    return unsubscribe;
  }, []);

  // Determine current effective theme
  const currentTheme = React.useMemo(() => {
    if (previewTheme) return previewTheme;
    // Check if custom theme
    const custom = customThemes.find(t => t.id === activeThemeId);
    if (custom) {
      return {
        id: custom.id,
        name: custom.name,
        family: 'Custom',
        description: 'Customized atelier color theme.',
        category: 'Luxury' as const,
        tokens: custom.tokens,
        appearanceMode: 'light' as const,
        isBuiltIn: false
      };
    }
    return getThemeById(activeThemeId);
  }, [previewTheme, activeThemeId, customThemes]);

  // Apply CSS variables to :root
  useEffect(() => {
    const root = document.documentElement;
    const tokens = currentTheme.tokens;

    root.style.setProperty('--theme-bg', tokens.bg);
    root.style.setProperty('--theme-surface', tokens.surface);
    root.style.setProperty('--theme-surface-subtle', tokens.surfaceSubtle);
    root.style.setProperty('--theme-surface-elevated', tokens.surfaceElevated);
    root.style.setProperty('--theme-text', tokens.text);
    root.style.setProperty('--theme-text-muted', tokens.textMuted);
    root.style.setProperty('--theme-primary', tokens.primary);
    root.style.setProperty('--theme-primary-contrast', tokens.primaryContrast);
    root.style.setProperty('--theme-secondary', tokens.secondary);
    root.style.setProperty('--theme-accent', tokens.accent);
    root.style.setProperty('--theme-accent-hover', tokens.accentHover);
    root.style.setProperty('--theme-accent-contrast', tokens.accentContrast);
    root.style.setProperty('--theme-border', tokens.border);
    root.style.setProperty('--theme-border-subtle', tokens.borderSubtle);
    root.style.setProperty('--theme-input-bg', tokens.inputBg);
    root.style.setProperty('--theme-nav-bg', tokens.navBg);
    root.style.setProperty('--theme-sidebar-bg', tokens.sidebarBg);
    root.style.setProperty('--theme-sidebar-text', tokens.sidebarText);
    root.style.setProperty('--theme-sidebar-muted', tokens.sidebarMuted);
    root.style.setProperty('--theme-sidebar-border', tokens.sidebarBorder);
    root.style.setProperty('--theme-sidebar-active', tokens.sidebarActive);
    root.style.setProperty('--theme-success', tokens.success);
    root.style.setProperty('--theme-warning', tokens.warning);
    root.style.setProperty('--theme-danger', tokens.danger);
  }, [currentTheme]);

  const applyTheme = (themeId: string, actorName: string = 'Super Admin') => {
    setActiveThemeId(themeId);
    setPreviewTheme(null);
    storeService.updateStoreSettings({ activeThemeId: themeId }, actorName);
  };

  const saveCustomTheme = (name: string, tokens: ThemeTokens, actorName: string = 'Super Admin') => {
    const saved = storeService.saveCustomTheme('', name, tokens, actorName);
    setCustomThemes(storeService.getCustomThemes());
    applyTheme(saved.id, actorName);
  };

  const deleteCustomTheme = (id: string, actorName: string = 'Super Admin') => {
    storeService.deleteCustomTheme(id, actorName);
    setCustomThemes(storeService.getCustomThemes());
    if (activeThemeId === id) {
      applyTheme(DEFAULT_THEME_ID, actorName);
    }
  };

  const resetToBrandDefault = () => {
    applyTheme(DEFAULT_THEME_ID, 'Super Admin');
  };

  const contrastRatio = React.useMemo(() => {
    return getContrastRatio(currentTheme.tokens.text, currentTheme.tokens.bg);
  }, [currentTheme]);

  return (
    <ThemeContext.Provider
      value={{
        activeTheme: currentTheme,
        previewTheme,
        customThemes,
        allPresets: PRESET_THEMES,
        setPreviewTheme,
        applyTheme,
        saveCustomTheme,
        deleteCustomTheme,
        resetToBrandDefault,
        contrastRatio
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
}
