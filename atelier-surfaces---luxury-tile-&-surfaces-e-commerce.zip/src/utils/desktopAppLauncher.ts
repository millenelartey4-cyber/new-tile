/**
 * Desktop App Package & Launcher generator for ATELIER Surfaces SaaS Web App.
 * Generates portable, downloadable application packages that users can save to their computer
 * and run offline or via desktop dock launchers without encountering external Cloud Run auth barriers.
 */

import { storeService } from '../services/store';

export function getAppBaseUrl(): string {
  if (typeof window !== 'undefined') {
    return window.location.origin;
  }
  return '';
}

/**
 * Downloads a desktop shortcut file (.url for Windows, .webloc for macOS, .desktop for Linux)
 */
export function downloadDesktopShortcut(appName: string = 'Atelier-Surfaces-SaaS'): void {
  const url = getAppBaseUrl();
  const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '';
  const isMac = /macintosh|mac os x/.test(userAgent);
  const isLinux = /linux/.test(userAgent) && !/android/.test(userAgent);

  let fileContent: string;
  let fileName: string;
  let mimeType: string;

  if (isMac) {
    fileName = `${appName}.webloc`;
    mimeType = 'application/xml';
    fileContent = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>URL</key>
  <string>${url}/</string>
</dict>
</plist>`;
  } else if (isLinux) {
    fileName = `${appName.toLowerCase()}.desktop`;
    mimeType = 'application/x-desktop';
    fileContent = `[Desktop Entry]
Version=1.0
Type=Application
Name=${appName.replace(/-/g, ' ')}
Comment=Official ATELIER Luxury Surfaces E-Commerce & SaaS Platform
Exec=xdg-open "${url}/"
Icon=${url}/favicon.png
Terminal=false
Categories=Office;Business;Network;`;
  } else {
    fileName = `${appName}.url`;
    mimeType = 'application/internet-shortcut';
    fileContent = `[InternetShortcut]
URL=${url}/
IconFile=${url}/favicon.png
IconIndex=0
[{000214A0-0000-0000-C000-000000000046}]
Prop3=19,11
`;
  }

  triggerBrowserDownload(fileName, fileContent, mimeType);
}

/**
 * Downloads a standalone, self-contained offline WebApp package (.html).
 * Can be opened by double clicking anywhere on Mac/Windows/Linux with zero internet required.
 */
export function downloadStandaloneWebApp(appName: string = 'Atelier-Surfaces-SaaS-Offline-App'): void {
  const products = storeService.getProducts();
  const companies = storeService.getCompanies();
  const settings = storeService.getStoreSettings();

  const productsJson = JSON.stringify(products);
  const companiesJson = JSON.stringify(companies);
  const settingsJson = JSON.stringify(settings);

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ATELIER SURFACES - Official Offline SaaS Application</title>
  <meta name="description" content="Official offline architectural surfaces and tile specification application." />
  <style>
    :root {
      --bg: #141311;
      --surface: #1c1b18;
      --surface-subtle: #24221e;
      --border: #33302a;
      --text: #f5f4f0;
      --text-muted: #a6a39d;
      --accent: #d4af37;
      --accent-hover: #b5952f;
      --primary: #f5f4f0;
      --primary-contrast: #141311;
      --success: #10b981;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      line-height: 1.5;
      padding-bottom: 80px;
    }
    .header {
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      position: sticky;
      top: 0;
      z-index: 50;
      padding: 16px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
    }
    .brand {
      font-family: "Georgia", serif;
      font-size: 20px;
      font-weight: 700;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: var(--text);
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .badge {
      font-size: 10px;
      font-family: monospace;
      padding: 3px 8px;
      background: rgba(212, 175, 55, 0.15);
      border: 1px solid rgba(212, 175, 55, 0.4);
      color: var(--accent);
      text-transform: uppercase;
      font-weight: bold;
      border-radius: 2px;
    }
    .status-badge {
      font-size: 11px;
      color: var(--success);
      display: flex;
      align-items: center;
      gap: 6px;
      font-weight: 600;
    }
    .status-dot {
      width: 8px;
      height: 8px;
      background: var(--success);
      border-radius: 50%;
      display: inline-block;
    }
    .container {
      max-width: 1280px;
      margin: 0 auto;
      padding: 32px 24px;
    }
    .hero {
      background: var(--surface);
      border: 1px solid var(--border);
      padding: 32px;
      margin-bottom: 32px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
    }
    .hero-title {
      font-family: "Georgia", serif;
      font-size: 28px;
      font-weight: 600;
      margin-bottom: 8px;
    }
    .hero-subtitle {
      color: var(--text-muted);
      font-size: 14px;
      max-w: 600px;
    }
    .calc-card {
      background: var(--surface-subtle);
      border: 1px solid var(--border);
      padding: 20px;
      border-radius: 4px;
      min-width: 300px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 24px;
    }
    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      transition: transform 0.2s, border-color 0.2s;
    }
    .card:hover {
      border-color: var(--accent);
      transform: translateY(-2px);
    }
    .card-img-placeholder {
      height: 200px;
      background: #2a2824;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--accent);
      font-family: "Georgia", serif;
      font-size: 24px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 1px solid var(--border);
    }
    .card-body {
      padding: 20px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .card-category {
      font-size: 11px;
      text-transform: uppercase;
      color: var(--accent);
      font-weight: 600;
      letter-spacing: 1px;
    }
    .card-title {
      font-family: "Georgia", serif;
      font-size: 18px;
      font-weight: 600;
      margin: 4px 0 8px;
    }
    .card-desc {
      font-size: 12px;
      color: var(--text-muted);
      margin-bottom: 16px;
      line-height: 1.4;
    }
    .card-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-top: 1px solid var(--border);
      padding-top: 12px;
    }
    .price {
      font-size: 16px;
      font-weight: 700;
      color: var(--text);
    }
    .unit {
      font-size: 11px;
      color: var(--text-muted);
      font-weight: normal;
    }
    .stock-tag {
      font-size: 10px;
      padding: 2px 6px;
      background: rgba(16, 185, 129, 0.1);
      color: var(--success);
      border: 1px solid rgba(16, 185, 129, 0.3);
      font-weight: 600;
    }
    .btn {
      padding: 8px 16px;
      background: var(--primary);
      color: var(--primary-contrast);
      border: none;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      cursor: pointer;
      transition: opacity 0.2s;
    }
    .btn:hover { opacity: 0.9; }
    .btn-secondary {
      background: var(--surface-subtle);
      border: 1px solid var(--border);
      color: var(--text);
    }
    .input-field {
      width: 100%;
      padding: 8px 12px;
      background: var(--bg);
      border: 1px solid var(--border);
      color: var(--text);
      font-size: 13px;
      margin-top: 6px;
      margin-bottom: 12px;
    }
    .tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 24px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 12px;
    }
    .tab-btn {
      padding: 6px 14px;
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-muted);
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .tab-btn.active {
      color: var(--text);
      border-color: var(--border);
      background: var(--surface);
    }
  </style>
</head>
<body>

  <header class="header">
    <div class="brand">
      <span>ATELIER SURFACES</span>
      <span class="badge">Standalone SaaS App</span>
    </div>
    <div style="display: flex; align-items: center; gap: 16px;">
      <div class="status-badge">
        <span class="status-dot"></span>
        <span>100% Offline Active</span>
      </div>
      <button class="btn btn-secondary" onclick="exportData()">Export Data</button>
    </div>
  </header>

  <div class="container">
    
    <div class="hero">
      <div>
        <h1 class="hero-title">${settings.brandName || 'ATELIER SURFACES'}</h1>
        <p class="hero-subtitle">
          Portable Offline Architecture & Tile Specification App. Loaded with your full product catalog, active currency (${settings.currency || 'GHS'}), and local calculation tools.
        </p>
      </div>

      <div class="calc-card">
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--accent); margin-bottom: 8px;">
          Fast Tile Area Estimator
        </div>
        <div style="display: flex; gap: 8px;">
          <div>
            <label style="font-size: 11px; color: var(--text-muted);">Floor/Wall Area (m²)</label>
            <input type="number" id="calc-area" class="input-field" value="45" oninput="runCalculator()" />
          </div>
          <div>
            <label style="font-size: 11px; color: var(--text-muted);">Wastage %</label>
            <input type="number" id="calc-waste" class="input-field" value="10" oninput="runCalculator()" />
          </div>
        </div>
        <div id="calc-result" style="font-size: 12px; font-weight: 600; color: var(--accent);">
          Total Requirement: 49.50 m² (~35 Boxes)
        </div>
      </div>
    </div>

    <div class="tabs">
      <button class="tab-btn active" onclick="filterCategory('all', this)">All Materials</button>
      <button class="tab-btn" onclick="filterCategory('Porcelain', this)">Porcelain Slabs</button>
      <button class="tab-btn" onclick="filterCategory('Marble', this)">Marble</button>
      <button class="tab-btn" onclick="filterCategory('Travertine', this)">Travertine</button>
      <button class="tab-btn" onclick="filterCategory('Terrazzo', this)">Terrazzo</button>
    </div>

    <div class="grid" id="product-grid">
      <!-- Injected via JavaScript -->
    </div>

  </div>

  <script>
    const productsData = ${productsJson};
    const settingsData = ${settingsJson};

    function renderProducts(items) {
      const grid = document.getElementById('product-grid');
      grid.innerHTML = '';
      
      items.forEach(p => {
        const variant = p.variants?.[0] || {};
        const price = variant.price || p.price || 0;
        const unit = variant.unit || 'm²';
        const stock = variant.stock ?? 100;
        const currency = settingsData.currencySymbol || 'GH₵';

        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = \`
          <div class="card-img-placeholder">
            <span>\${p.material || 'SURFACE'}</span>
          </div>
          <div class="card-body">
            <div>
              <span class="card-category">\${p.material || 'Architectural Surface'}</span>
              <h3 class="card-title">\${p.name}</h3>
              <p class="card-desc">\${p.description || 'Ultra-compact surface specimen with calibrated rectified edges.'}</p>
            </div>
            <div class="card-meta">
              <div>
                <span class="price">\${currency} \${price}</span>
                <span class="unit"> / \${unit}</span>
              </div>
              <span class="stock-tag">\${stock > 0 ? stock + ' ' + unit + ' in stock' : 'Pre-order'}</span>
            </div>
          </div>
        \`;
        grid.appendChild(card);
      });
    }

    function filterCategory(cat, el) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      el.classList.add('active');
      
      if (cat === 'all') {
        renderProducts(productsData);
      } else {
        const filtered = productsData.filter(p => 
          (p.material && p.material.toLowerCase().includes(cat.toLowerCase())) ||
          (p.categoryName && p.categoryName.toLowerCase().includes(cat.toLowerCase()))
        );
        renderProducts(filtered);
      }
    }

    function runCalculator() {
      const area = parseFloat(document.getElementById('calc-area').value) || 0;
      const waste = parseFloat(document.getElementById('calc-waste').value) || 0;
      const total = area * (1 + waste / 100);
      const boxes = Math.ceil(total / 1.44); // 1.44m2 average box
      document.getElementById('calc-result').innerText = 
        'Total Requirement: ' + total.toFixed(2) + ' m² (~' + boxes + ' Boxes)';
    }

    function exportData() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
        settings: settingsData,
        products: productsData
      }, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "atelier-surfaces-data.json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    }

    // Initial render
    renderProducts(productsData);
  </script>
</body>
</html>`;

  triggerBrowserDownload(
    `${appName}.html`,
    htmlContent,
    'text/html'
  );
}

function triggerBrowserDownload(fileName: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const downloadUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(downloadUrl);
}
