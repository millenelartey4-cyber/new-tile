import { 
  EcomSpineConfig, 
  EcomSpineWaybill, 
  EcomSpineSettlement, 
  EcomSpineMilestone, 
  EcomSpineWaypoint 
} from '../types/ecomspine';
import { Order } from '../types';

const DEFAULT_CONFIG: EcomSpineConfig = {
  enabled: true,
  merchantId: 'ESP-MCH-ATELIER-GH',
  publishableKey: 'esp_live_pub_77f4c99a21b38e09f',
  liveSecretKey: 'esp_live_sec_••••••••••••••••8492',
  settlementBankName: 'Stanbic Bank Ghana (Airport City Branch)',
  settlementAccountName: 'Atelier Surfaces Ghana Ltd',
  settlementAccountNumber: '9040003928174',
  settlementBranch: 'Airport City, Accra',
  settlementSwiftCode: 'SBICGHAC',
  linkedMastercardNumber: '5399 4182 9901 8492',
  linkedMastercardHolder: 'KWAME MENSAH (DIRECTOR)',
  linkedMastercardExpiry: '08/29',
  linkedMastercardBrand: 'mastercard',
  settlementCadence: 'instant',
  fraudShieldLevel: 'maximum',
  require3DSecure: true,
  zeroTheftGuarantee: true,
  blockSuspiciousIps: true,
  payoutAutoLock: true,
  enableGpsTracking: true,
  enableSmsDispatchAlerts: true,
  defaultFleetVehicle: 'Heavy Hydraulic Tailgate (10-Wheel)',
  logisticsHubName: 'Atelier Central Logistics Hub, Spintex Road, Accra',
  isLocked: false
};

const DEFAULT_WAYBILLS: EcomSpineWaybill[] = [
  {
    id: 'esp-wb-001',
    waybillNumber: 'ESP-GH-849102',
    orderId: 'ord-1002',
    orderNumber: 'ORD-2026-1002',
    createdAt: new Date(Date.now() - 3600 * 1000 * 14).toISOString(),
    clientName: 'Dr. Joseph Darko',
    clientPhone: '+233 24 411 9022',
    destinationAddress: 'Villa 14, Senchi Street, Airport Residential Area',
    destinationCity: 'Accra, Greater Accra',
    destinationGps: 'GA-110-3849',
    vehicleType: 'Heavy Hydraulic Tailgate (10-Wheel)',
    vehiclePlate: 'GT-4820-24',
    driverName: 'Emmanuel Tetteh',
    driverPhone: '+233 50 892 1104',
    currentMilestone: 'in_transit',
    estimatedDeliveryTime: 'Today at 16:30 GMT',
    verificationPin: '4829',
    packageDetails: {
      totalPallets: 4,
      totalWeightKg: 1850,
      specimensCount: 12,
      fragileFlag: true
    },
    waypoints: [
      {
        id: 'wp-1',
        status: 'crated_at_hub',
        title: 'Crated & Shock-Wrapped at Central Hub',
        location: 'Spintex Road Depot, Bay 4',
        description: 'Specimen slabs packed in steel A-frame with pneumatic tension banding. Tilt/Drop sensors activated.',
        timestamp: new Date(Date.now() - 3600 * 1000 * 8).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        completed: true,
        gpsCoordinates: '5.6294° N, 0.1039° W'
      },
      {
        id: 'wp-2',
        status: 'tailgate_loaded',
        title: 'Hydraulic Tailgate Loaded & Secured',
        location: 'Atelier Logistics Bay 2',
        description: 'Loaded onto 10-wheel hydraulic carrier plate GT-4820-24. Driver Emmanuel Tetteh inspected cargo seals.',
        timestamp: new Date(Date.now() - 3600 * 1000 * 4).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        completed: true,
        gpsCoordinates: '5.6298° N, 0.1042° W'
      },
      {
        id: 'wp-3',
        status: 'in_transit',
        title: 'En Route to Site with Active Escort',
        location: 'Liberation Road / Airport Bypass',
        description: 'Fleet traveling at 38 km/h. Live telemetry confirms zero tilt angle variations.',
        timestamp: new Date(Date.now() - 3600 * 1000 * 1).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        completed: true,
        gpsCoordinates: '5.5941° N, 0.1772° W'
      },
      {
        id: 'wp-4',
        status: 'arrived_on_site',
        title: 'Arrived at Destination Site',
        location: 'Senchi Street, Airport Residential Area',
        description: 'Driver initiates contact with site manager. Parking hydraulic arm.',
        timestamp: 'Pending arrival',
        completed: false
      },
      {
        id: 'wp-5',
        status: 'tailgate_offload',
        title: 'Hydraulic Tailgate Rigging & Offloading',
        location: 'Ground Level Offload Zone',
        description: 'Lowering slabs via 4-stage pneumatic hydraulic bed to prevent micro-fracturing.',
        timestamp: 'Pending offload',
        completed: false
      },
      {
        id: 'wp-6',
        status: 'client_inspected_and_delivered',
        title: 'Client Inspection & PIN Handover',
        location: 'Site Delivery Verification',
        description: 'Customer reviews slabs for perfection and provides 4-digit EcomSpine security PIN 4829.',
        timestamp: 'Pending sign-off',
        completed: false
      }
    ]
  },
  {
    id: 'esp-wb-002',
    waybillNumber: 'ESP-GH-991403',
    orderId: 'ord-1001',
    orderNumber: 'ORD-2026-1001',
    createdAt: new Date(Date.now() - 3600 * 1000 * 48).toISOString(),
    clientName: 'Nana Osei Bonsu',
    clientPhone: '+233 20 812 7700',
    destinationAddress: 'Ridge West Embassy Enclave, House 7B',
    destinationCity: 'Ridge West, Accra',
    destinationGps: 'GA-029-9182',
    vehicleType: 'Flatbed Hiab Crane Truck',
    vehiclePlate: 'GN-1092-23',
    driverName: 'Kofi Asare',
    driverPhone: '+233 24 330 9911',
    currentMilestone: 'client_inspected_and_delivered',
    estimatedDeliveryTime: 'Delivered Successfully',
    verificationPin: '9120',
    packageDetails: {
      totalPallets: 6,
      totalWeightKg: 2900,
      specimensCount: 18,
      fragileFlag: true
    },
    waypoints: [
      {
        id: 'wp-21',
        status: 'crated_at_hub',
        title: 'Crated & Shock-Wrapped at Central Hub',
        location: 'Spintex Road Depot',
        description: 'Calacatta Borghese Jumbo slabs packed in reinforced oak crates.',
        timestamp: 'Yesterday 09:00',
        completed: true
      },
      {
        id: 'wp-22',
        status: 'tailgate_loaded',
        title: 'Hiab Crane Mounted & Locked',
        location: 'Logistics Bay 1',
        description: 'Fastened with ratchet webbings.',
        timestamp: 'Yesterday 10:30',
        completed: true
      },
      {
        id: 'wp-23',
        status: 'in_transit',
        title: 'In Transit via Independence Ave',
        location: 'Ridge Corridor',
        description: 'Clear route verified.',
        timestamp: 'Yesterday 12:15',
        completed: true
      },
      {
        id: 'wp-24',
        status: 'arrived_on_site',
        title: 'Arrived at Site',
        location: 'Ridge West Embassy Enclave',
        description: 'Safety cones and crane outriggers deployed.',
        timestamp: 'Yesterday 13:00',
        completed: true
      },
      {
        id: 'wp-25',
        status: 'tailgate_offload',
        title: 'Crane Offloaded Directly into Penthouse Staging',
        location: 'Penthouse Service Deck',
        description: 'Smooth crane lift to level 3.',
        timestamp: 'Yesterday 14:10',
        completed: true
      },
      {
        id: 'wp-26',
        status: 'client_inspected_and_delivered',
        title: 'Client Inspection & PIN Handover Complete',
        location: 'Site Delivery Verification',
        description: 'Delivered and verified. Digital signature captured. PIN 9120 accepted.',
        timestamp: 'Yesterday 15:00',
        completed: true
      }
    ]
  }
];

const DEFAULT_SETTLEMENTS: EcomSpineSettlement[] = [
  {
    id: 'esp-set-001',
    settlementNumber: 'ESP-SET-9812',
    orderId: 'ord-1002',
    orderNumber: 'ORD-2026-1002',
    grossAmount: 48500,
    feeAmount: 388,
    netAmount: 48112,
    currency: 'GHS',
    cardBrand: 'mastercard',
    cardLast4: '8492',
    cardholderName: 'Joseph Darko',
    settledToBank: 'Stanbic Bank Ghana (Acct: 9040003928174)',
    settledToAccountNumber: '9040003928174',
    settledToMastercard: '5399 •••• •••• 8492',
    status: 'settled',
    antiTheftScore: 99.8,
    fraudShieldChecks: {
      threeDSecurePassed: true,
      avsAddressVerified: true,
      cvvMatched: true,
      zeroTheftSignature: 'SHA256-ESP-SEC-90214a90fbc28a01874b'
    },
    settledAt: new Date(Date.now() - 3600 * 1000 * 13).toISOString()
  },
  {
    id: 'esp-set-002',
    settlementNumber: 'ESP-SET-9811',
    orderId: 'ord-1001',
    orderNumber: 'ORD-2026-1001',
    grossAmount: 82000,
    feeAmount: 656,
    netAmount: 81344,
    currency: 'GHS',
    cardBrand: 'mastercard',
    cardLast4: '2019',
    cardholderName: 'Nana Osei Bonsu',
    settledToBank: 'Stanbic Bank Ghana (Acct: 9040003928174)',
    settledToAccountNumber: '9040003928174',
    settledToMastercard: '5399 •••• •••• 8492',
    status: 'settled',
    antiTheftScore: 100.0,
    fraudShieldChecks: {
      threeDSecurePassed: true,
      avsAddressVerified: true,
      cvvMatched: true,
      zeroTheftSignature: 'SHA256-ESP-SEC-84119e71ab00398f8101'
    },
    settledAt: new Date(Date.now() - 3600 * 1000 * 47).toISOString()
  }
];

class EcomSpineService {
  private getStorageKey(type: string, tenantId?: string): string {
    const tid = tenantId || 'default';
    return `ecomspine_${type}_${tid}`;
  }

  // --- Configuration ---
  getConfig(tenantId?: string): EcomSpineConfig {
    try {
      const stored = localStorage.getItem(this.getStorageKey('config', tenantId));
      if (stored) {
        return { ...DEFAULT_CONFIG, ...JSON.parse(stored) };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_CONFIG;
  }

  saveConfig(config: EcomSpineConfig, tenantId?: string): void {
    try {
      localStorage.setItem(this.getStorageKey('config', tenantId), JSON.stringify(config));
      window.dispatchEvent(new CustomEvent('ecomspine_config_updated', { detail: config }));
    } catch (e) {
      console.error('Failed to save EcomSpine config:', e);
    }
  }

  // --- Waybills ---
  getWaybills(tenantId?: string): EcomSpineWaybill[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey('waybills', tenantId));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    // Seed defaults
    this.saveWaybills(DEFAULT_WAYBILLS, tenantId);
    return DEFAULT_WAYBILLS;
  }

  saveWaybills(waybills: EcomSpineWaybill[], tenantId?: string): void {
    try {
      localStorage.setItem(this.getStorageKey('waybills', tenantId), JSON.stringify(waybills));
      window.dispatchEvent(new CustomEvent('ecomspine_waybills_updated', { detail: waybills }));
    } catch (e) {
      console.error('Failed to save EcomSpine waybills:', e);
    }
  }

  getWaybillByNumber(waybillNumber: string, tenantId?: string): EcomSpineWaybill | undefined {
    const list = this.getWaybills(tenantId);
    return list.find(w => w.waybillNumber.toLowerCase() === waybillNumber.toLowerCase().trim());
  }

  getWaybillByOrderId(orderId: string, tenantId?: string): EcomSpineWaybill | undefined {
    const list = this.getWaybills(tenantId);
    return list.find(w => w.orderId === orderId);
  }

  createWaybillFromOrder(order: Order, options?: Partial<EcomSpineWaybill>, tenantId?: string): EcomSpineWaybill {
    const existing = this.getWaybillByOrderId(order.id, tenantId);
    if (existing) return existing;

    const waybills = this.getWaybills(tenantId);
    const randomSuffix = Math.floor(100000 + Math.random() * 900000);
    const waybillNumber = `ESP-GH-${randomSuffix}`;
    const pin = Math.floor(1000 + Math.random() * 9000).toString();

    const config = this.getConfig(tenantId);

    const initialWaypoints: EcomSpineWaypoint[] = [
      {
        id: `wp-${Date.now()}-1`,
        status: 'crated_at_hub',
        title: 'Crated & Shock-Wrapped at Central Hub',
        location: config.logisticsHubName,
        description: 'Heavy architectural specimen slabs secured in structural cradles.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        completed: true,
        gpsCoordinates: '5.6294° N, 0.1039° W'
      },
      {
        id: `wp-${Date.now()}-2`,
        status: 'tailgate_loaded',
        title: 'Hydraulic Tailgate Loaded & Fleet Dispatched',
        location: 'Bay 3, Tailgate Loading Ramp',
        description: 'Slotted onto automated hydraulic lifter. Securing straps torque-tested.',
        timestamp: 'Estimated +2 hours',
        completed: false
      },
      {
        id: `wp-${Date.now()}-3`,
        status: 'in_transit',
        title: 'Secure Fleet Transit with Live GPS',
        location: 'Accra Transport Corridor',
        description: 'Transit with anti-vibration damping monitoring.',
        timestamp: 'Pending transit',
        completed: false
      },
      {
        id: `wp-${Date.now()}-4`,
        status: 'arrived_on_site',
        title: 'Arrived at Destination Site',
        location: order.shippingAddress.addressLine1 || 'Destination Site',
        description: 'Driver initiates contact with site coordinator.',
        timestamp: 'Pending arrival',
        completed: false
      },
      {
        id: `wp-${Date.now()}-5`,
        status: 'tailgate_offload',
        title: 'Hydraulic Tailgate Rigging & Offloading',
        location: 'Site Offload Zone',
        description: 'Hydraulic lift lower sequence under certified rigger oversight.',
        timestamp: 'Pending offload',
        completed: false
      },
      {
        id: `wp-${Date.now()}-6`,
        status: 'client_inspected_and_delivered',
        title: 'Client Inspection & PIN Handover',
        location: 'Final Placement',
        description: `Client verification with 4-digit PIN (${pin}).`,
        timestamp: 'Pending handover',
        completed: false
      }
    ];

    const newWaybill: EcomSpineWaybill = {
      id: `esp-wb-${Date.now()}`,
      waybillNumber,
      orderId: order.id,
      orderNumber: order.orderNumber,
      createdAt: new Date().toISOString(),
      clientName: order.customerSnapshot.name || 'Valued Client',
      clientPhone: order.customerSnapshot.phone || '+233 24 000 0000',
      destinationAddress: order.shippingAddress.addressLine1,
      destinationCity: `${order.shippingAddress.city}, ${order.shippingAddress.region || 'Ghana'}`,
      destinationGps: 'GPS: GA-110-3849',
      vehicleType: 'Heavy Hydraulic Tailgate (10-Wheel)',
      vehiclePlate: 'GT-5120-25',
      driverName: 'Emmanuel Tetteh',
      driverPhone: '+233 50 892 1104',
      currentMilestone: 'crated_at_hub',
      estimatedDeliveryTime: 'Estimated next business day (14:00 - 17:00 GMT)',
      verificationPin: pin,
      waypoints: initialWaypoints,
      packageDetails: {
        totalPallets: Math.max(1, Math.ceil(order.itemsSnapshot.length / 2)),
        totalWeightKg: Math.round(order.itemsSnapshot.reduce((sum, item) => sum + (item.quantity * 140), 200)),
        specimensCount: order.itemsSnapshot.length,
        fragileFlag: true
      },
      ...options
    };

    waybills.unshift(newWaybill);
    this.saveWaybills(waybills, tenantId);
    return newWaybill;
  }

  updateMilestone(waybillId: string, milestone: EcomSpineMilestone, note?: string, tenantId?: string): EcomSpineWaybill | undefined {
    const waybills = this.getWaybills(tenantId);
    const index = waybills.findIndex(w => w.id === waybillId);
    if (index === -1) return undefined;

    const wb = { ...waybills[index] };
    wb.currentMilestone = milestone;

    const milestoneOrder: EcomSpineMilestone[] = [
      'crated_at_hub',
      'tailgate_loaded',
      'in_transit',
      'arrived_on_site',
      'tailgate_offload',
      'client_inspected_and_delivered'
    ];

    const targetIdx = milestoneOrder.indexOf(milestone);
    wb.waypoints = wb.waypoints.map(wp => {
      const wpIdx = milestoneOrder.indexOf(wp.status);
      const isPastOrCurrent = wpIdx <= targetIdx;
      return {
        ...wp,
        completed: isPastOrCurrent,
        timestamp: wp.status === milestone 
          ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          : wp.timestamp,
        description: wp.status === milestone && note ? `${wp.description} [${note}]` : wp.description
      };
    });

    waybills[index] = wb;
    this.saveWaybills(waybills, tenantId);
    return wb;
  }

  // --- Settlements & Anti-Theft Payments ---
  getSettlements(tenantId?: string): EcomSpineSettlement[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey('settlements', tenantId));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    this.saveSettlements(DEFAULT_SETTLEMENTS, tenantId);
    return DEFAULT_SETTLEMENTS;
  }

  saveSettlements(settlements: EcomSpineSettlement[], tenantId?: string): void {
    try {
      localStorage.setItem(this.getStorageKey('settlements', tenantId), JSON.stringify(settlements));
      window.dispatchEvent(new CustomEvent('ecomspine_settlements_updated', { detail: settlements }));
    } catch (e) {
      console.error('Failed to save EcomSpine settlements:', e);
    }
  }

  recordSettlement(
    order: Order,
    cardInfo: {
      brand: 'mastercard' | 'visa';
      last4: string;
      cardholderName: string;
      antiTheftScore?: number;
    },
    tenantId?: string
  ): EcomSpineSettlement {
    const settlements = this.getSettlements(tenantId);
    const config = this.getConfig(tenantId);

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const settlementNumber = `ESP-SET-${randomSuffix}`;
    const feeRate = 0.008; // 0.8% secure merchant processing fee
    const feeAmount = Math.round(order.total * feeRate);
    const netAmount = order.total - feeAmount;

    // Cryptographic anti-theft proof simulation
    const hashSeed = `${order.orderNumber}-${cardInfo.last4}-${Date.now()}`;
    const zeroTheftSignature = `SHA256-ESP-SEC-${Math.abs(hashSeed.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(16)}`;

    const newSettlement: EcomSpineSettlement = {
      id: `esp-set-${Date.now()}`,
      settlementNumber,
      orderId: order.id,
      orderNumber: order.orderNumber,
      grossAmount: order.total,
      feeAmount,
      netAmount,
      currency: order.currency || 'GHS',
      cardBrand: cardInfo.brand,
      cardLast4: cardInfo.last4,
      cardholderName: cardInfo.cardholderName,
      settledToBank: `${config.settlementBankName} (Acct: ${config.settlementAccountNumber})`,
      settledToAccountNumber: config.settlementAccountNumber,
      settledToMastercard: config.linkedMastercardNumber,
      status: 'settled',
      antiTheftScore: cardInfo.antiTheftScore ?? 99.9,
      fraudShieldChecks: {
        threeDSecurePassed: true,
        avsAddressVerified: true,
        cvvMatched: true,
        zeroTheftSignature
      },
      settledAt: new Date().toISOString()
    };

    settlements.unshift(newSettlement);
    this.saveSettlements(settlements, tenantId);
    return newSettlement;
  }
}

export const ecomspineService = new EcomSpineService();
