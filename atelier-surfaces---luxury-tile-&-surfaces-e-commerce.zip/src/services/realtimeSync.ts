import { storeService } from './store';

export type PosRealtimeEventType = 
  | 'INVENTORY_ADJUSTED' 
  | 'PRICE_UPDATED' 
  | 'BULK_PRICES_UPDATED' 
  | 'POS_SALE_COMPLETED' 
  | 'SHOWROOM_LOCATION_UPDATED'
  | 'ADMIN_BROADCAST_CREATED'
  | 'ADMIN_BROADCAST_UPDATED'
  | 'ADMIN_BROADCAST_LOCKED'
  | 'ADMIN_BROADCAST_DELETED';

export interface PosRealtimeEvent {
  id: string;
  type: PosRealtimeEventType;
  timestamp: string;
  companyId?: string;
  payload: any;
  actorName?: string;
}

export type ConnectionStatus = 'connected' | 'connecting' | 'reconnecting' | 'offline';

class RealtimeSyncService {
  private ws: WebSocket | null = null;
  private sse: EventSource | null = null;
  private status: ConnectionStatus = 'offline';
  private listeners: Map<string, Set<(event: PosRealtimeEvent) => void>> = new Map();
  private statusListeners: Set<(status: ConnectionStatus) => void> = new Set();
  private reconnectTimer: any = null;
  private isDestroyed: boolean = false;
  private receivedEventIds: Set<string> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      this.initConnection();
    }
  }

  public getConnectionStatus(): ConnectionStatus {
    return this.status;
  }

  private setStatus(newStatus: ConnectionStatus) {
    if (this.status !== newStatus) {
      this.status = newStatus;
      this.statusListeners.forEach(listener => listener(newStatus));
      window.dispatchEvent(new CustomEvent('pos_realtime_status_changed', { detail: { status: newStatus } }));
    }
  }

  public onConnectionChange(listener: (status: ConnectionStatus) => void): () => void {
    this.statusListeners.add(listener);
    return () => {
      this.statusListeners.delete(listener);
    };
  }

  public on(eventType: PosRealtimeEventType | '*', listener: (event: PosRealtimeEvent) => void): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, new Set());
    }
    this.listeners.get(eventType)!.add(listener);

    return () => {
      this.listeners.get(eventType)?.delete(listener);
    };
  }

  private emit(event: PosRealtimeEvent) {
    // Idempotency: Prevent processing duplicate event IDs
    if (this.receivedEventIds.has(event.id)) {
      return;
    }
    this.receivedEventIds.add(event.id);
    if (this.receivedEventIds.size > 200) {
      const first = this.receivedEventIds.values().next().value;
      if (first) this.receivedEventIds.delete(first);
    }

    // Process & apply event mutations to local storeService
    this.applyEventMutation(event);

    // Call specific listeners
    this.listeners.get(event.type)?.forEach(cb => {
      try { cb(event); } catch (e) { console.error('Error in event listener:', e); }
    });

    // Call wildcard listeners
    this.listeners.get('*')?.forEach(cb => {
      try { cb(event); } catch (e) { console.error('Error in wildcard event listener:', e); }
    });

    // Dispatch browser-level event for components without direct import
    window.dispatchEvent(new CustomEvent('pos_realtime_event_received', { detail: event }));
  }

  private applyEventMutation(event: PosRealtimeEvent) {
    try {
      const companyId = event.companyId || storeService.getActiveTenantId();

      switch (event.type) {
        case 'INVENTORY_ADJUSTED': {
          const { productId, variantId, newStock } = event.payload;
          if (productId && variantId && typeof newStock === 'number') {
            const products = storeService.getProducts(companyId);
            const prod = products.find(p => p.id === productId);
            if (prod) {
              const variant = prod.variants.find(v => v.id === variantId);
              if (variant) {
                variant.stock = newStock;
                storeService.saveProduct(prod, event.actorName || 'POS Real-Time Sync', companyId);
                window.dispatchEvent(new CustomEvent('pos_inventory_synced', { 
                  detail: { productId, variantId, newStock } 
                }));
              }
            }
          }
          break;
        }

        case 'PRICE_UPDATED': {
          const { productId, variantId, newPrice } = event.payload;
          if (productId && variantId && typeof newPrice === 'number') {
            const products = storeService.getProducts(companyId);
            const prod = products.find(p => p.id === productId);
            if (prod) {
              const variant = prod.variants.find(v => v.id === variantId);
              if (variant) {
                variant.price = newPrice;
                storeService.saveProduct(prod, event.actorName || 'POS Real-Time Sync', companyId);
                window.dispatchEvent(new CustomEvent('pos_price_synced', { 
                  detail: { productId, variantId, newPrice } 
                }));
              }
            }
          }
          break;
        }

        case 'BULK_PRICES_UPDATED': {
          const { productIds, mode, value } = event.payload;
          if (Array.isArray(productIds) && mode && typeof value === 'number') {
            storeService.bulkUpdateProductPrices(
              productIds,
              mode,
              value,
              event.actorName || 'POS Real-Time Bulk Sync',
              companyId
            );
            window.dispatchEvent(new CustomEvent('pos_price_synced', { detail: event.payload }));
          }
          break;
        }

        case 'POS_SALE_COMPLETED': {
          const { items, transactionNumber, cashierName } = event.payload;
          if (Array.isArray(items)) {
            items.forEach((item: any) => {
              if (item.productId && item.variantId && item.quantity) {
                storeService.adjustStock({
                  productId: item.productId,
                  variantId: item.variantId,
                  adjustment: -item.quantity,
                  reason: 'POS Sale',
                  actorName: cashierName || 'Showroom POS Register',
                  skipBroadcast: true
                }, companyId);
              }
            });
            window.dispatchEvent(new CustomEvent('pos_sale_broadcast', { 
              detail: { transactionNumber, items, cashierName } 
            }));
          }
          break;
        }

        case 'SHOWROOM_LOCATION_UPDATED': {
          const { showroomAddress, ghanaPostGps, contactPhone, contactEmail } = event.payload;
          storeService.updateStoreSettings({
            showroomAddress,
            ghanaPostGps,
            contactPhone,
            contactEmail
          }, event.actorName || 'POS Register', companyId);
          break;
        }

        case 'ADMIN_BROADCAST_CREATED':
        case 'ADMIN_BROADCAST_UPDATED':
        case 'ADMIN_BROADCAST_LOCKED':
        case 'ADMIN_BROADCAST_DELETED': {
          window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: event.payload }));
          window.dispatchEvent(new CustomEvent('storage'));
          break;
        }
      }
    } catch (e) {
      console.warn('Error applying POS real-time mutation:', e);
    }
  }

  private initConnection() {
    if (this.isDestroyed) return;
    this.setStatus('connecting');

    // Attempt WebSocket first
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/pos`;
      
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.setStatus('connected');
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type && data.type !== 'CONNECTED') {
            this.emit(data);
          }
        } catch (e) {
          console.warn('Failed to parse WS POS message:', e);
        }
      };

      this.ws.onerror = () => {
        // Fallback to Server-Sent Events (SSE) immediately if WebSocket errors
        this.initSseFallback();
      };

      this.ws.onclose = () => {
        if (!this.isDestroyed) {
          this.initSseFallback();
        }
      };
    } catch {
      this.initSseFallback();
    }
  }

  private initSseFallback() {
    if (this.sse) return; // Already running SSE

    try {
      this.sse = new EventSource('/api/pos/stream');

      this.sse.onopen = () => {
        this.setStatus('connected');
      };

      this.sse.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type && data.type !== 'CONNECTED') {
            this.emit(data);
          }
        } catch (e) {
          console.warn('Failed to parse SSE POS message:', e);
        }
      };

      this.sse.onerror = () => {
        this.setStatus('reconnecting');
        if (this.sse) {
          this.sse.close();
          this.sse = null;
        }
        if (!this.reconnectTimer && !this.isDestroyed) {
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.initConnection();
          }, 4000);
        }
      };
    } catch {
      this.setStatus('offline');
    }
  }

  // Push an event from POS directly to the storefront API
  public async publishEvent(
    type: PosRealtimeEventType,
    payload: any,
    companyId?: string,
    actorName?: string
  ): Promise<{ success: boolean; subscribersReached?: number }> {
    const cid = companyId || storeService.getActiveTenantId();
    const actor = actorName || 'Showroom POS Cashier';

    // 1. If WebSocket is connected, send message through socket
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({
          type,
          payload,
          companyId: cid,
          actorName: actor
        }));
      } catch (err) {
        console.warn('WS send failed, will use HTTP fallback:', err);
      }
    }

    // 2. Also send through official HTTP endpoint for guaranteed server broadcasting
    try {
      const response = await fetch('/api/pos/publish-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          payload,
          companyId: cid,
          actorName: actor
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const resData = await response.json();
      return { success: true, subscribersReached: resData.subscribersReached };
    } catch (err) {
      // Offline fallback: apply locally in browser so active tab immediately reflects
      this.emit({
        id: `evt-offline-${Date.now()}`,
        type,
        timestamp: new Date().toISOString(),
        companyId: cid,
        payload,
        actorName: actor
      });
      return { success: true, subscribersReached: 1 };
    }
  }

  public destroy() {
    this.isDestroyed = true;
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    if (this.sse) {
      this.sse.close();
      this.sse = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.setStatus('offline');
  }
}

export const realtimeSyncService = new RealtimeSyncService();

// Connect storeService to real-time publisher
storeService.setRealtimePublisher((type, payload, companyId, actorName) => 
  realtimeSyncService.publishEvent(type as any, payload, companyId, actorName)
);
