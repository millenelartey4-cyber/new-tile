/**
 * Architectural Visualizer & Tile Image Resolution Service
 * Provides instant, high-resolution architectural photography, slab close-ups,
 * laying pattern diagrams, and room scene installations for any customer or architect request.
 */

export interface ArchitecturalImageRecord {
  id: string;
  url: string;
  thumbnailUrl: string;
  title: string;
  caption: string;
  category: string;
  roomType: string;
  material: string;
  finish: string;
  rRating: string;
  dimensions: string;
  aspectRatio: string;
  origin?: string;
  waterAbsorption?: string;
  productSlug?: string;
  unitPrice?: number;
  boxCoverage?: number;
  source: 'catalog' | 'installation' | 'render' | 'texture';
  tags: string[];
  altViews: Array<{
    url: string;
    title: string;
    caption: string;
    viewType: 'room' | 'slab' | 'detail' | 'pattern';
  }>;
}

export const ARCHITECTURAL_IMAGES: ArchitecturalImageRecord[] = [
  // 1. Calacatta Statuario
  {
    id: 'calacatta-statuario',
    productSlug: 'calacatta-statuario-porcelain',
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    title: 'Calacatta Statuario Imperiale - Grand Architectural Foyer',
    caption: 'Ultra-luxurious grand double-height foyer paved in continuous 120×240cm Calacatta Statuario polished porcelain slabs with bookmatched smoke and gold veins.',
    category: 'Marble-Look Porcelain',
    roomType: 'Grand Foyer & Living Pavilion',
    material: 'Vitrified Italian Porcelain',
    finish: 'Mirror High-Gloss Polished',
    rRating: 'R10 / PTV 36+',
    dimensions: '120×240cm & 120×60cm (9mm thickness)',
    aspectRatio: '16:9',
    origin: 'Sassuolo, Italy',
    waterAbsorption: '< 0.05% (Impervious)',
    unitPrice: 420,
    boxCoverage: 1.44,
    source: 'installation',
    tags: ['calacatta', 'statuario', 'carrara', 'white marble', 'foyer', 'living room', 'luxury', 'polished', 'slabs'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85',
        title: 'Foyer Architectural Installation',
        caption: 'Seamless slab installation with minimal 1mm micro-grout joints.',
        viewType: 'room'
      },
      {
        url: '/assets/images/category_marble_slabs_1792523067297.jpg',
        title: 'Slab Close-Up & Vein Detail',
        caption: 'Apuan Alpine crystalline white matrix with warm honey and graphite calcite veins.',
        viewType: 'slab'
      },
      {
        url: '/assets/images/category_stone_bathroom_1792523067646.jpg',
        title: 'Master Spa Wet-Room Installation',
        caption: 'Bookmatched shower elevation paired with freestanding matte white soaking tub.',
        viewType: 'detail'
      },
      {
        url: '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg',
        title: 'Accra Flagship Showroom Display',
        caption: 'Full-height 3-meter architectural display monolith at Ridge West showroom.',
        viewType: 'pattern'
      }
    ]
  },

  // 2. Nero Marquina Black Marble
  {
    id: 'nero-marquina',
    productSlug: 'nero-marquina-velvet',
    url: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=600&q=80',
    title: 'Nero Marquina Velvet - Dark Luxury Master Suite & Bath',
    caption: 'Dramatic, moody architectural bathroom clad in continuous Nero Marquina black marble with contrasting calcite lightning veining, freestanding soaking tub, and concealed brass tapware.',
    category: 'Black Marble Porcelain',
    roomType: 'Master Spa Bathroom & Powder Room',
    material: 'Ultra-Dense Vitrified Porcelain',
    finish: 'Satin Velvet / Mirror Polished',
    rRating: 'R10/R11 Anti-Slip',
    dimensions: '120×60cm (9.5mm thickness)',
    aspectRatio: '16:9',
    origin: 'Modena, Italy',
    waterAbsorption: '< 0.05% (Impervious)',
    unitPrice: 450,
    boxCoverage: 1.44,
    source: 'installation',
    tags: ['nero marquina', 'black marble', 'dark marble', 'black tile', 'moody bathroom', 'powder room', 'brass', 'luxury bath'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=1600&q=85',
        title: 'Moody Penthouse Bathroom',
        caption: 'Dark monochrome luxury aesthetic with brushed gold architectural fixtures.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1600&q=85',
        title: 'Calcite Vein Micro-Macro Study',
        caption: 'Pure carbon black base with razor-sharp white and pale amber crystallization.',
        viewType: 'slab'
      },
      {
        url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1600&q=85',
        title: 'Architectural Fireplace Feature Elevation',
        caption: 'Floor-to-ceiling bookmatched black porcelain surround with recessed linear flame.',
        viewType: 'detail'
      }
    ]
  },

  // 3. French Charente Limestone Pavers (Outdoor & Pool)
  {
    id: 'french-charente-limestone',
    productSlug: 'french-charente-limestone',
    url: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=600&q=80',
    title: 'French Charente Limestone 20mm - Infinity Pool Terrace',
    caption: 'Sunlit Mediterranean coastal villa terrace and pool coping paved with 20mm structural French Charente aged limestone flags with tumbled chiselled edges and certified R11 wet-slip resistance.',
    category: 'Outdoor Pavers & Natural Stone',
    roomType: 'Outdoor Pool Deck & Exterior Terrace',
    material: '20mm Structural Quarried Natural Stone / Porcelain',
    finish: 'Aged Tumbled Chiselled Edge',
    rRating: 'R11 Anti-Slip Certified',
    dimensions: '60×90cm × 20mm thick',
    aspectRatio: '16:9',
    origin: 'Charente Basin, France',
    waterAbsorption: '< 0.4% (Frost & Tropical Rain Proof)',
    unitPrice: 520,
    boxCoverage: 1.08,
    source: 'installation',
    tags: ['outdoor', 'pool', 'patio', 'terrace', 'french limestone', 'charente', 'pavers', '20mm', 'r11', 'anti-slip', 'exterior'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1600&q=85',
        title: 'Infinity Pool Coping & Sunken Deck',
        caption: 'Cool-to-the-touch natural stone finish that stays comfortable under blazing tropical sun.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85',
        title: 'Alfresco Verandah & Garden Walkway',
        caption: 'Modular Versailles pattern installation connecting interior salon to lush outdoor gardens.',
        viewType: 'detail'
      },
      {
        url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85',
        title: 'Surface Chiselled Texture Close-Up',
        caption: 'Authentic aged fossilization with tactile micro-grip providing zero slip hazard.',
        viewType: 'slab'
      }
    ]
  },

  // 4. Nordic Oak Porcelain Wood Plank (Herringbone & Straight)
  {
    id: 'nordic-oak-porcelain-wood',
    productSlug: 'nordic-oak-porcelain-wood',
    url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=600&q=80',
    title: 'Nordic Oak Porcelain Wood Plank - Classical Herringbone Parquet',
    caption: 'Open-concept Scandinavian living and dining space featuring Nordic White Oak porcelain planks laid in an intricate 45° herringbone pattern. Organic warmth with complete immunity to water, rot, and termites.',
    category: 'Porcelain Wood Plank',
    roomType: 'Living Salon, Dining & Master Bedroom',
    material: 'Vitrified Woodgrain Porcelain',
    finish: 'Embossed Natural Woodgrain Relief',
    rRating: 'R10 Comfort Grip',
    dimensions: '20×120cm (9mm thickness)',
    aspectRatio: '16:9',
    origin: 'Emilia-Romagna, Italy',
    waterAbsorption: '< 0.05% (Zero Swelling / Zero Warping)',
    unitPrice: 290,
    boxCoverage: 1.20,
    source: 'installation',
    tags: ['herringbone', 'wood tile', 'wood plank', 'parquet', 'nordic oak', 'oak', 'timber look', 'living room', 'scandinavian', 'bedroom'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85',
        title: '45° Herringbone Living Room',
        caption: 'Classical European parquet pattern creating optical depth and directional dynamism.',
        viewType: 'pattern'
      },
      {
        url: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1600&q=85',
        title: 'Minimalist Master Bedroom Suite',
        caption: 'Straight 1/3 offset staggered plank lay creating calm horizontal visual lines.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1600&q=85',
        title: 'Woodgrain Emboss Texture Study',
        caption: 'Synchronized digital embossing replicating natural timber rings, knots, and tactile saw marks.',
        viewType: 'detail'
      }
    ]
  },

  // 5. Roman Travertine Navona
  {
    id: 'roman-travertine-navona',
    productSlug: 'roman-travertine-navona',
    url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=600&q=80',
    title: 'Roman Travertine Navona - Warm Mediterranean Open-Plan Living',
    caption: 'Sunlit modern villa featuring Roman Travertine Navona cross-cut porcelain floors. Creamy beige and warm oatmeal sedimentary tones that diffuse natural sunlight with gentle velvety softness.',
    category: 'Natural Travertine Porcelain',
    roomType: 'Open-Plan Living, Lounge & Verandah',
    material: 'Vitrified Italian Porcelain',
    finish: 'Honed Velvety Matte',
    rRating: 'R10 / PTV 36+',
    dimensions: '120×60cm (9.5mm thickness)',
    aspectRatio: '16:9',
    origin: 'Tivoli & Sassuolo, Italy',
    waterAbsorption: '< 0.08% (Non-Porous)',
    unitPrice: 380,
    boxCoverage: 1.44,
    source: 'installation',
    tags: ['travertine', 'roman travertine', 'navona', 'beige tile', 'cream stone', 'mediterranean', 'living room', 'matte', 'honed'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1600&q=85',
        title: 'Mediterranean Villa Living Room',
        caption: 'Seamless continuous floor extending from interior salon through cavity sliding glass doors.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1600&q=85',
        title: 'Cross-Cut Sedimentary Vein Study',
        caption: 'Cloud-like soft porosity filled and honed flush for effortless maintenance.',
        viewType: 'slab'
      },
      {
        url: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1600&q=85',
        title: 'Curbless Walk-In Spa Shower',
        caption: 'Floor-to-ceiling travertine wet-room with integrated bench and niche shelving.',
        viewType: 'detail'
      }
    ]
  },

  // 6. Milano Terrazzo Grigio
  {
    id: 'milano-terrazzo-grigio',
    productSlug: 'milano-terrazzo-grigio',
    url: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
    title: 'Milano Terrazzo Grigio - Architectural Chef Kitchen & Dining',
    caption: 'Modern minimalist kitchen with large-format Milano Terrazzo Grigio tiles. Micro-aggregate fragments of Carrara marble, granite, and basalt bound in cool grey cementitious matrix.',
    category: 'Architectural Terrazzo',
    roomType: 'Gourmet Kitchen, Cafe & Gallery Hall',
    material: 'Engineered Compact Terrazzo Porcelain',
    finish: 'Honed Micro-Aggregate Satin',
    rRating: 'R10 Slip Resistance',
    dimensions: '60×60cm & 120×60cm (10mm thickness)',
    aspectRatio: '16:9',
    origin: 'Milan, Italy',
    waterAbsorption: '< 0.08% (Stain Proof)',
    unitPrice: 340,
    boxCoverage: 1.44,
    source: 'installation',
    tags: ['terrazzo', 'milano terrazzo', 'kitchen tile', 'dining floor', 'grey tile', 'aggregate', 'cafe', 'modern kitchen', 'speckled'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1600&q=85',
        title: 'Architectural Kitchen & Waterfall Island',
        caption: 'Durable stain-resistant kitchen floor impervious to cooking oils, citrus juices, and wine.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1600&q=85',
        title: 'Commercial Boutique Retail Installation',
        caption: 'High-traffic commercial showroom corridor exhibiting zero surface wear after years of use.',
        viewType: 'detail'
      },
      {
        url: 'https://images.unsplash.com/photo-1581404476143-fb31d742929f?auto=format&fit=crop&w=1600&q=85',
        title: 'Aggregate Fragment Macro Detail',
        caption: 'Densely packed quarried marble chips creating mid-century Italian modernist charm.',
        viewType: 'slab'
      }
    ]
  },

  // 7. Grigio Orobico 3D Fluted Wall Relief
  {
    id: 'grigio-orobico-fluted',
    productSlug: 'grigio-orobico-fluted',
    url: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=600&q=80',
    title: 'Grigio Orobico 3D Fluted Relief - Feature Wall & Reception',
    caption: 'Sculptural 3D fluted architectural porcelain wall panels. Linear ribbed grooves that cast dynamic shadow lines under directional grazing illumination in high-end reception areas.',
    category: '3D Wall Relief & Cladding',
    roomType: 'Feature Wall, Powder Room & Reception Monolith',
    material: 'Molded Architectural Porcelain',
    finish: '3D Fluted Ribbed Relief',
    rRating: 'N/A (Vertical Wall Surface)',
    dimensions: '40×120cm (11mm profile depth)',
    aspectRatio: '16:9',
    origin: 'Bergamo & Sassuolo, Italy',
    waterAbsorption: '< 0.1% (Moisture Proof)',
    unitPrice: 480,
    boxCoverage: 0.96,
    source: 'installation',
    tags: ['fluted', '3d wall', 'relief', 'grigio orobico', 'feature wall', 'textured wall', 'ribbed', 'reception', 'powder room niche'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85',
        title: 'Feature Wall with Grazing Lighting',
        caption: 'Concealed ceiling linear LED highlights the tactile peaks and valleys of each fluted rib.',
        viewType: 'room'
      },
      {
        url: 'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=1600&q=85',
        title: 'Powder Room Vanity Backdrop',
        caption: 'Curved vertical fluting framing a backlit circular bronze vanity mirror.',
        viewType: 'detail'
      }
    ]
  },

  // 8. Emerald Botanical Green Onyx & Luxury Bath
  {
    id: 'emerald-onyx-luxury',
    productSlug: 'emerald-onyx-porcelain',
    url: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=600&q=80',
    title: 'Emerald Green Botanical Onyx - Translucent Feature Wall',
    caption: 'Jewel-toned emerald green onyx slab with crystalline gold veining. Engineered for backlighting in presidential suites, private bars, and master bathroom focal points.',
    category: 'Exotic Onyx & Gemstone Porcelain',
    roomType: 'Master Spa Wet-Room & Vanity Suite',
    material: 'Translucent Composite Vitrified Slab',
    finish: 'Mirror Crystal Gloss',
    rRating: 'R10 Polished',
    dimensions: '120×280cm (6mm & 9mm thickness)',
    aspectRatio: '16:9',
    origin: 'Carrara, Italy',
    waterAbsorption: '< 0.02% (Impervious)',
    unitPrice: 580,
    boxCoverage: 1.44,
    source: 'installation',
    tags: ['emerald', 'green onyx', 'green marble', 'onyx', 'luxury bathroom', 'backlit', 'feature wall', 'vanity', 'jewel tone'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1600&q=85',
        title: 'Translucent Backlit Installation',
        caption: 'LED light diffusion panel behind 6mm slab illuminating crystalline emerald rings.',
        viewType: 'room'
      }
    ]
  },

  // 9. Artisanal Handmade Zellige Glazed Subway
  {
    id: 'artisanal-zellige-glaze',
    productSlug: 'artisanal-zellige-glaze',
    url: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=1600&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=600&q=80',
    title: 'Artisanal Zellige Glazed Ceramic - Kitchen Splashback & Bath Niche',
    caption: 'Handcrafted Moroccan zellige glazed tiles with subtle chromatic depth and undulating surface reflections that shimmer under natural sunlight.',
    category: 'Artisanal Glazed Ceramic & Subway',
    roomType: 'Kitchen Splashback, Bar & Shower Surround',
    material: 'Kiln-Fired Glazed Terracotta',
    finish: 'Lustrous Enamelled High-Gloss',
    rRating: 'N/A (Wall Cladding)',
    dimensions: '10×10cm & 5×15cm',
    aspectRatio: '16:9',
    origin: 'Fez & Seville',
    waterAbsorption: '< 3% (Glazed Impervious Face)',
    unitPrice: 320,
    boxCoverage: 1.00,
    source: 'installation',
    tags: ['zellige', 'subway', 'handmade tile', 'kitchen splashback', 'splashback', 'backsplash', 'glazed tile', 'green tile', 'olive'],
    altViews: [
      {
        url: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=1600&q=85',
        title: 'Artisan Kitchen Splashback',
        caption: 'Irregular handmade glaze reflecting natural kitchen daylight.',
        viewType: 'room'
      }
    ]
  }
];

/**
 * Intelligent Image Resolver
 * Analyzes natural language queries and returns the best matching architectural photo record.
 */
export function resolveArchitecturalImage(userQuery: string): ArchitecturalImageRecord {
  const q = userQuery.toLowerCase().trim();

  // 1. Direct product name / slug matches
  if (q.includes('calacatta') || q.includes('statuario') || q.includes('carrara') || q.includes('white marble')) {
    return ARCHITECTURAL_IMAGES[0];
  }
  if (q.includes('nero') || q.includes('marquina') || q.includes('black marble') || q.includes('black tile') || q.includes('dark marble')) {
    return ARCHITECTURAL_IMAGES[1];
  }
  if (q.includes('limestone') || q.includes('charente') || q.includes('paver') || q.includes('outdoor') || q.includes('pool') || q.includes('patio') || q.includes('exterior') || q.includes('terrace') || q.includes('r11')) {
    return ARCHITECTURAL_IMAGES[2];
  }
  if (q.includes('herringbone') || q.includes('wood') || q.includes('plank') || q.includes('nordic') || q.includes('oak') || q.includes('parquet') || q.includes('timber')) {
    return ARCHITECTURAL_IMAGES[3];
  }
  if (q.includes('travertine') || q.includes('navona') || q.includes('beige') || q.includes('cream stone') || q.includes('mediterranean')) {
    return ARCHITECTURAL_IMAGES[4];
  }
  if (q.includes('terrazzo') || q.includes('milano') || q.includes('aggregate') || q.includes('speckled') || q.includes('cafe floor')) {
    return ARCHITECTURAL_IMAGES[5];
  }
  if (q.includes('fluted') || q.includes('3d') || q.includes('relief') || q.includes('ribbed') || q.includes('orobico') || q.includes('wall panel')) {
    return ARCHITECTURAL_IMAGES[6];
  }
  if (q.includes('emerald') || q.includes('onyx') || q.includes('green marble') || q.includes('translucent')) {
    return ARCHITECTURAL_IMAGES[7];
  }
  if (q.includes('zellige') || q.includes('subway') || q.includes('splashback') || q.includes('backsplash') || q.includes('glazed')) {
    return ARCHITECTURAL_IMAGES[8];
  }

  // 2. Room-based matches
  if (q.includes('kitchen')) {
    return ARCHITECTURAL_IMAGES[5]; // Milano Terrazzo Kitchen
  }
  if (q.includes('bathroom') || q.includes('bath') || q.includes('shower') || q.includes('wet room') || q.includes('spa')) {
    return ARCHITECTURAL_IMAGES[1]; // Nero Marquina / Master Spa Bath
  }
  if (q.includes('foyer') || q.includes('entrance') || q.includes('hallway') || q.includes('slab')) {
    return ARCHITECTURAL_IMAGES[0]; // Calacatta Foyer
  }
  if (q.includes('bedroom')) {
    return ARCHITECTURAL_IMAGES[3]; // Nordic Oak bedroom
  }
  if (q.includes('living room') || q.includes('salon')) {
    return ARCHITECTURAL_IMAGES[4]; // Roman Travertine living room
  }

  // 3. Fallback to crown jewel Calacatta Statuario Imperiale
  return ARCHITECTURAL_IMAGES[0];
}

/**
 * Returns a curated gallery of multi-space architectural imagery
 */
export function getCuratedArchitecturalGallery(theme?: string): ArchitecturalImageRecord[] {
  if (theme === 'outdoor') {
    return [ARCHITECTURAL_IMAGES[2], ARCHITECTURAL_IMAGES[4], ARCHITECTURAL_IMAGES[0]];
  }
  if (theme === 'marble') {
    return [ARCHITECTURAL_IMAGES[0], ARCHITECTURAL_IMAGES[1], ARCHITECTURAL_IMAGES[7]];
  }
  if (theme === 'warm') {
    return [ARCHITECTURAL_IMAGES[4], ARCHITECTURAL_IMAGES[3], ARCHITECTURAL_IMAGES[2]];
  }
  return ARCHITECTURAL_IMAGES.slice(0, 6);
}
