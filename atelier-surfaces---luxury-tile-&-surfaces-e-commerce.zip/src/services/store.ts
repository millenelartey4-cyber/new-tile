import { 
  Product, 
  Category, 
  Order, 
  UserRole, 
  AppUser, 
  StoreSettings, 
  StockAdjustment, 
  AuditLog, 
  OrderStatus, 
  PaymentStatus, 
  ThemeTokens,
  CompanyTenant,
  ConsultationRoom,
  PanelBrightnessConfig,
  POSSettings,
  POSTransaction,
  BulkPricingRule,
  BulkPricingTier,
  AppliedBulkDiscount,
  DiscountCode,
  CartItem,
  AdminBroadcast,
  BroadcastAudience,
  BroadcastUrgency,
  BroadcastPlacement
} from '../types';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_STORE_SETTINGS } from '../data/products';
import { INITIAL_ROLES } from '../data/roles';
import { INITIAL_COMPANIES, getCompanySettings } from '../data/companies';
import { VERONA_STONE_PRODUCTS, NORDIC_CERAMIC_PRODUCTS } from '../data/tenantCatalogs';

const STORAGE_KEYS = {
  COMPANIES_REGISTRY: 'atelier_companies_registry_v1',
  ACTIVE_COMPANY: 'atelier_active_company_id',
  LEGACY_PRODUCTS: 'atelier_surfaces_products_v2',
  LEGACY_CATEGORIES: 'atelier_surfaces_categories_v2',
  LEGACY_SETTINGS: 'atelier_surfaces_settings_v2',
  LEGACY_ORDERS: 'atelier_surfaces_orders_v2',
  ROLES: 'atelier_surfaces_roles_v2',
  USERS: 'atelier_surfaces_users_v2',
  CUSTOM_THEMES: 'atelier_surfaces_custom_themes_v2',
};

const INITIAL_USERS: AppUser[] = [
  {
    uid: 'usr-admin-1',
    name: 'Kofi Mensah',
    email: 'kofi.mensah@ateliersurfaces.com',
    phone: '+233 24 582 9101',
    roleId: 'super-admin',
    roleName: 'Super Admin',
    active: true,
    createdAt: '2026-01-01T08:00:00Z',
    lastLogin: '2026-03-21T09:30:00Z'
  },
  {
    uid: 'usr-manager-1',
    name: 'Ama Osei',
    email: 'ama.osei@ateliersurfaces.com',
    phone: '+233 20 491 8230',
    roleId: 'manager',
    roleName: 'Store Manager',
    active: true,
    createdAt: '2026-01-15T10:00:00Z',
    lastLogin: '2026-03-20T14:15:00Z'
  },
  {
    uid: 'usr-inventory-1',
    name: 'Kwame Asante',
    email: 'kwame.asante@ateliersurfaces.com',
    phone: '+233 55 312 9044',
    roleId: 'inventory-staff',
    roleName: 'Inventory Staff',
    active: true,
    createdAt: '2026-02-01T11:00:00Z',
    lastLogin: '2026-03-21T07:45:00Z'
  },
  {
    uid: 'usr-customer-1',
    name: 'Akosua Adomako (Trade Architect)',
    email: 'akosua.arch@adomakostudio.com',
    phone: '+233 50 128 4799',
    roleId: 'customer',
    roleName: 'Customer / Trade Buyer',
    active: true,
    createdAt: '2026-03-01T14:00:00Z',
    lastLogin: '2026-03-20T11:00:00Z'
  }
];

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-2026-001',
    orderNumber: 'AS-2026-9814',
    customerId: 'usr-customer-1',
    customerSnapshot: {
      name: 'Akosua Adomako (Trade Architect)',
      email: 'akosua.arch@adomakostudio.com',
      phone: '+233 50 128 4799'
    },
    itemsSnapshot: [
      {
        productId: 'prod-calacatta-statuario',
        productName: 'Calacatta Statuario Imperiale',
        productSlug: 'calacatta-statuario-imperiale',
        variantId: 'var-calacatta-gold',
        colorName: 'Calacatta Gold',
        colorHex: '#D4AF37',
        image: '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg',
        sku: 'AS-CSI-GLD-120240',
        unitPrice: 485,
        quantity: 24,
        unit: 'm²',
        lineTotal: 11640
      }
    ],
    shippingAddress: {
      fullName: 'Akosua Adomako',
      email: 'akosua.arch@adomakostudio.com',
      phone: '+233 50 128 4799',
      addressLine1: 'Plot 48, Embassy Road, Airport Residential Area',
      city: 'Accra',
      region: 'Greater Accra',
      ghanaPostGps: 'GA-082-4190',
      deliveryNotes: 'Deliver with heavy hydraulic tailgate truck.'
    },
    subtotal: 11640,
    discount: 582,
    shippingCost: 0,
    tax: 1658.7,
    total: 12716.7,
    currency: 'GHS',
    paymentMethod: 'paystack',
    paymentStatus: 'paid',
    orderStatus: 'shipped',
    paymentReference: 'pstk_live_94819401726',
    trackingNumber: 'AS-LOG-GH-49102',
    trackingTimeline: [
      {
        title: 'Order Placed & Verified',
        description: 'Payment verified via Paystack GH₵12,716.70.',
        timestamp: '2026-03-18 10:24 AM',
        completed: true
      },
      {
        title: 'Crated at Central Warehouse',
        description: 'Palletized with foam cushioning and export bands.',
        timestamp: '2026-03-19 02:15 PM',
        completed: true
      },
      {
        title: 'Dispatched for Site Delivery',
        description: 'Loaded on Scania Flatbed AS-TRK-04, driver assigned.',
        timestamp: '2026-03-20 08:30 AM',
        completed: true
      }
    ],
    internalNotes: 'VIP trade client. Verified architect license.',
    createdAt: '2026-03-18T10:24:00Z',
    updatedAt: '2026-03-20T08:30:00Z'
  }
];

const INITIAL_BULK_PRICING_RULES: BulkPricingRule[] = [
  {
    id: 'bpr-marble-tier',
    name: 'Marble-Look Slabs Commercial Incentive',
    collectionId: 'marble-look',
    collectionName: 'Marble-Look Tiles',
    description: 'Volume discount tiers for large-format Calacatta and Nero Marquina luxury slabs.',
    active: true,
    isLocked: false,
    createdAt: '2026-02-01T08:00:00Z',
    updatedAt: '2026-03-20T10:00:00Z',
    tiers: [
      {
        id: 'tier-m-1',
        minQuantitySqm: 50,
        maxQuantitySqm: 99.99,
        discountType: 'percentage',
        discountValue: 10,
        tierLabel: 'Tier 1 · Site Batch (50 - 99 m²)'
      },
      {
        id: 'tier-m-2',
        minQuantitySqm: 100,
        maxQuantitySqm: 249.99,
        discountType: 'percentage',
        discountValue: 18,
        tierLabel: 'Tier 2 · Estate Contractor (100 - 249 m²)'
      },
      {
        id: 'tier-m-3',
        minQuantitySqm: 250,
        maxQuantitySqm: null,
        discountType: 'percentage',
        discountValue: 25,
        tierLabel: 'Tier 3 · Multi-Container Commercial (250+ m²)'
      }
    ]
  },
  {
    id: 'bpr-floor-tier',
    name: 'Architectural Floor Tiles Volume Program',
    collectionId: 'floor-tiles',
    collectionName: 'Floor Tiles',
    description: 'Scaled commercial volume tiers for heavy-traffic commercial and residential flooring.',
    active: true,
    isLocked: false,
    createdAt: '2026-02-10T09:30:00Z',
    updatedAt: '2026-03-21T12:00:00Z',
    tiers: [
      {
        id: 'tier-f-1',
        minQuantitySqm: 50,
        maxQuantitySqm: 149.99,
        discountType: 'percentage',
        discountValue: 8,
        tierLabel: 'Volume Tier 1 (50 - 149 m²)'
      },
      {
        id: 'tier-f-2',
        minQuantitySqm: 150,
        maxQuantitySqm: null,
        discountType: 'percentage',
        discountValue: 15,
        tierLabel: 'Volume Tier 2 (150+ m²)'
      }
    ]
  },
  {
    id: 'bpr-natural-stone-tier',
    name: 'Roman Travertine & Natural Stone Quarry Direct',
    collectionId: 'natural-stone',
    collectionName: 'Natural Stone',
    description: 'Direct crate and container discounts for quarried stone, French limestone, and travertine.',
    active: true,
    isLocked: false,
    createdAt: '2026-02-15T11:00:00Z',
    updatedAt: '2026-03-22T08:00:00Z',
    tiers: [
      {
        id: 'tier-ns-1',
        minQuantitySqm: 50,
        maxQuantitySqm: 99.99,
        discountType: 'percentage',
        discountValue: 12,
        tierLabel: 'Quarry Tier 1 (50 - 99 m²)'
      },
      {
        id: 'tier-ns-2',
        minQuantitySqm: 100,
        maxQuantitySqm: null,
        discountType: 'percentage',
        discountValue: 20,
        tierLabel: 'Quarry Container Tier (100+ m²)'
      }
    ]
  }
];

const INITIAL_DISCOUNT_CODES: DiscountCode[] = [
  {
    id: 'dsc-1',
    code: 'ARCHITECT5',
    discountPercent: 5,
    description: 'Ghana Institute of Architects (GIA) verified member trade discount',
    minSpend: 5000,
    active: true
  },
  {
    id: 'dsc-2',
    code: 'CONTRACTOR10',
    discountPercent: 10,
    description: 'Commercial multi-container volume purchase discount',
    minSpend: 25000,
    active: true
  },
  {
    id: 'dsc-3',
    code: 'ATELIEROPENING',
    discountPercent: 7.5,
    description: 'Showroom grand opening promotional code',
    minSpend: 2000,
    active: true
  }
];

const INITIAL_BROADCASTS: AdminBroadcast[] = [
  {
    id: 'bc-staff-pos-sync-2',
    tenantId: 'atelier-surfaces',
    title: 'Showroom Staff Protocol: Mid-Day Safety Stock Audit',
    message: 'All Ridge West cashiers & inventory specialists: execute live physical slab count on POS Terminal prior to 5:00 PM GMT. Direct Trade WhatsApp line active.',
    audience: 'staff',
    urgency: 'warning',
    placement: 'top_banner',
    actionLabel: 'Open POS Terminal',
    actionUrl: '/admin/pos',
    active: true,
    isLocked: false,
    createdBy: 'Chief Operations Officer',
    createdAt: '2026-03-24T10:15:00Z',
    updatedAt: '2026-03-24T10:15:00Z',
    dismissible: true,
    soundAlert: false
  },
  {
    id: 'bc-cust-easter-3',
    tenantId: 'atelier-surfaces',
    title: 'Complimentary Architectural Freight & Hydraulic Offloading',
    message: 'Enjoy zero-cost hydraulic tailgate offloading across Greater Accra for all orders exceeding 50 m². Visit our Ridge West Flagship showroom for physical slab curation.',
    audience: 'customers',
    urgency: 'info',
    placement: 'top_banner',
    actionLabel: 'Explore Slabs',
    actionUrl: '/shop',
    active: true,
    isLocked: false,
    createdBy: 'Marketing Director',
    createdAt: '2026-03-23T14:30:00Z',
    updatedAt: '2026-03-23T14:30:00Z',
    dismissible: true,
    soundAlert: false
  }
];

class StoreService {
  private currentTenantId: string;
  private tenantListeners: Array<(tenantId: string) => void> = [];
  private settingsListeners: Array<(settings: StoreSettings, tenantId: string) => void> = [];
  private realtimePublisher?: (type: string, payload: any, companyId?: string, actorName?: string) => Promise<any>;

  constructor() {
    this.currentTenantId = this.detectInitialTenantId();
  }

  public setRealtimePublisher(publisher: (type: string, payload: any, companyId?: string, actorName?: string) => Promise<any>): void {
    this.realtimePublisher = publisher;
  }

  private detectInitialTenantId(): string {
    try {
      if (typeof window !== 'undefined') {
        const urlParams = new URLSearchParams(window.location.search);
        const p = urlParams.get('company') || urlParams.get('tenant');
        if (p) {
          const clean = p.toLowerCase().trim();
          localStorage.setItem(STORAGE_KEYS.ACTIVE_COMPANY, clean);
          return clean;
        }
        const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_COMPANY);
        if (saved) return saved;
      }
    } catch {}
    return 'atelier-surfaces';
  }

  getActiveTenantId(): string {
    return this.currentTenantId;
  }

  setActiveTenantId(tenantId: string): void {
    const clean = tenantId.toLowerCase().trim();
    this.currentTenantId = clean;
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_COMPANY, clean);
      if (typeof window !== 'undefined' && window.history) {
        const url = new URL(window.location.href);
        url.searchParams.set('company', clean);
        window.history.replaceState({}, '', url.toString());
      }
    } catch (e) {
      console.warn('LocalStorage error on tenant change:', e);
    }
    this.tenantListeners.forEach(listener => listener(clean));
  }

  onTenantChange(listener: (tenantId: string) => void): () => void {
    this.tenantListeners.push(listener);
    return () => {
      this.tenantListeners = this.tenantListeners.filter(l => l !== listener);
    };
  }

  onSettingsChange(listener: (settings: StoreSettings, tenantId: string) => void): () => void {
    this.settingsListeners.push(listener);
    return () => {
      this.settingsListeners = this.settingsListeners.filter(l => l !== listener);
    };
  }

  private getScopedKey(base: string, tenantId?: string): string {
    const tid = tenantId || this.currentTenantId || 'atelier-surfaces';
    return `tenant_${tid}_${base}`;
  }

  private get<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data);
    } catch {
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  // ==========================================
  // MULTI-COMPANY / TENANT MANAGEMENT
  // ==========================================

  getCompanies(): CompanyTenant[] {
    return this.get<CompanyTenant[]>(STORAGE_KEYS.COMPANIES_REGISTRY, INITIAL_COMPANIES);
  }

  getActiveCompany(): CompanyTenant {
    const companies = this.getCompanies();
    const found = companies.find(c => c.id === this.currentTenantId || c.slug === this.currentTenantId);
    if (found) return found;
    const initial = INITIAL_COMPANIES.find(c => c.id === this.currentTenantId || c.slug === this.currentTenantId);
    if (initial) return initial;
    return companies[0] || INITIAL_COMPANIES[0];
  }

  saveCompany(company: CompanyTenant, actorName: string = 'Super Admin'): CompanyTenant {
    const companies = this.getCompanies();
    const index = companies.findIndex(c => c.id === company.id);
    let updated: CompanyTenant;

    if (index >= 0) {
      updated = { ...company };
      companies[index] = updated;
      this.addAuditLog(actorName, 'super-admin', 'UPDATE_COMPANY', 'Company', company.id, `Updated company "${company.name}".`, company.id);
    } else {
      updated = {
        ...company,
        id: company.id || company.slug.toLowerCase().replace(/[^a-z0-9_-]/g, '') || `company-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      companies.push(updated);
      this.addAuditLog(actorName, 'super-admin', 'CREATE_COMPANY', 'Company', updated.id, `Deployed new company workspace "${company.name}".`, updated.id);
    }

    this.set(STORAGE_KEYS.COMPANIES_REGISTRY, companies);
    return updated;
  }

  deleteCompany(companyId: string, actorName: string = 'Super Admin'): boolean {
    if (companyId === 'atelier-surfaces') return false; // Flagship is protected
    const companies = this.getCompanies();
    const filtered = companies.filter(c => c.id !== companyId && c.slug !== companyId);
    this.set(STORAGE_KEYS.COMPANIES_REGISTRY, filtered);
    if (this.currentTenantId === companyId) {
      this.setActiveTenantId('atelier-surfaces');
    }
    this.addAuditLog(actorName, 'super-admin', 'DELETE_COMPANY', 'Company', companyId, `Deleted company workspace ID ${companyId}.`);
    return true;
  }

  cloneCompanyWorkspace(
    sourceCompanyId: string, 
    newCompanyData: Partial<CompanyTenant>, 
    seedTemplate: 'copy' | 'empty' = 'copy'
  ): CompanyTenant {
    const baseSlug = (newCompanyData.slug || newCompanyData.name || `company-${Date.now()}`)
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '-');
    const slug = baseSlug.replace(/^-+|-+$/g, '') || `company-${Date.now()}`;
    
    const newCompany: CompanyTenant = {
      id: slug,
      slug,
      name: newCompanyData.name || 'Bespoke Tile Co.',
      tagline: newCompanyData.tagline || 'Architectural Tile & Stone Surfaces',
      industry: newCompanyData.industry || 'Architectural Surfaces',
      currency: newCompanyData.currency || 'GHS',
      currencySymbol: newCompanyData.currencySymbol || (newCompanyData.currency === 'USD' ? '$' : newCompanyData.currency === 'EUR' ? '€' : 'GH₵'),
      contactEmail: newCompanyData.contactEmail || `orders@${slug}.com`,
      contactPhone: newCompanyData.contactPhone || '+233 24 000 0000',
      showroomAddress: newCompanyData.showroomAddress || 'Ridge West Architectural Enclave, Accra',
      ghanaPostGps: newCompanyData.ghanaPostGps || 'GA-110-0000',
      activeThemeId: newCompanyData.activeThemeId || 'ivory-gold-ateliers',
      adminPassword: newCompanyData.adminPassword || 'admin123',
      createdAt: new Date().toISOString(),
      isDefault: false
    };

    this.saveCompany(newCompany);

    // Initialize company settings
    const companySettings = getCompanySettings(newCompany);
    this.set(this.getScopedKey('settings', slug), companySettings);

    // Seed categories
    this.set(this.getScopedKey('categories', slug), INITIAL_CATEGORIES);

    // Seed products
    if (seedTemplate === 'copy') {
      const sourceProducts = this.getProducts(sourceCompanyId);
      const clonedProducts: Product[] = sourceProducts.map(p => ({
        ...p,
        id: `prod-${slug}-${p.slug}`,
        variants: p.variants.map(v => ({
          ...v,
          id: `var-${slug}-${v.id}`,
          sku: `${slug.substring(0, 3).toUpperCase()}-${v.sku.split('-').slice(1).join('-')}`
        }))
      }));
      this.set(this.getScopedKey('products', slug), clonedProducts);
    } else {
      this.set(this.getScopedKey('products', slug), []);
    }

    // Orders initialized empty
    this.set(this.getScopedKey('orders', slug), []);

    // Switch to new company
    this.setActiveTenantId(slug);

    return newCompany;
  }

  exportCompanyJson(companyId: string): string {
    const company = this.getCompanies().find(c => c.id === companyId) || this.getActiveCompany();
    const bundle = {
      version: 1,
      format: 'atelier-surfaces-tenant-export',
      exportedAt: new Date().toISOString(),
      company,
      settings: this.getStoreSettings(company.id),
      categories: this.getCategories(company.id),
      products: this.getProducts(company.id),
      orders: this.getOrders(company.id)
    };
    return JSON.stringify(bundle, null, 2);
  }

  importCompanyJson(jsonString: string): { success: boolean; companyId?: string; error?: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data.company || !data.company.name) {
        return { success: false, error: 'Invalid workspace backup file. Missing company metadata.' };
      }
      const company: CompanyTenant = {
        ...data.company,
        id: data.company.id || data.company.slug || `company-${Date.now()}`,
        slug: data.company.slug || data.company.id
      };
      this.saveCompany(company);
      if (data.settings) this.set(this.getScopedKey('settings', company.id), data.settings);
      if (data.categories) this.set(this.getScopedKey('categories', company.id), data.categories);
      if (data.products) this.set(this.getScopedKey('products', company.id), data.products);
      if (data.orders) this.set(this.getScopedKey('orders', company.id), data.orders);

      this.setActiveTenantId(company.id);
      return { success: true, companyId: company.id };
    } catch (e: any) {
      return { success: false, error: e.message || 'Failed to parse JSON file' };
    }
  }

  // ==========================================
  // PRODUCTS (TENANT SCOPED)
  // ==========================================

  private repairImageUrls<T>(data: T): T {
    if (!data) return data;
    try {
      const raw = JSON.stringify(data);
      if (raw.includes('/src/assets/images/')) {
        return JSON.parse(raw.replaceAll('/src/assets/images/', '/assets/images/'));
      }
    } catch {}
    return data;
  }

  getProducts(tenantId?: string): Product[] {
    const tid = tenantId || this.currentTenantId;
    if (this.isProductsZeroed(tid) || this.isDashboardZeroed(tid)) {
      return [];
    }
    const scopedKey = this.getScopedKey('products', tid);
    
    const saved = localStorage.getItem(scopedKey);
    if (saved !== null) {
      try {
        let parsed = JSON.parse(saved);
        if (saved.includes('/src/assets/images/')) {
          parsed = this.repairImageUrls(parsed);
          this.set(scopedKey, parsed);
        }
        return parsed;
      } catch {}
    }

    // Default company seeding
    if (tid === 'atelier-surfaces') {
      const legacy = localStorage.getItem(STORAGE_KEYS.LEGACY_PRODUCTS);
      if (legacy) {
        try {
          let parsed = JSON.parse(legacy);
          if (legacy.includes('/src/assets/images/')) {
            parsed = this.repairImageUrls(parsed);
          }
          this.set(scopedKey, parsed);
          return parsed;
        } catch {}
      }
      this.set(scopedKey, INITIAL_PRODUCTS);
      return INITIAL_PRODUCTS;
    }

    if (tid === 'verona-stone') {
      this.set(scopedKey, VERONA_STONE_PRODUCTS);
      return VERONA_STONE_PRODUCTS;
    }

    if (tid === 'nordic-ceramic') {
      this.set(scopedKey, NORDIC_CERAMIC_PRODUCTS);
      return NORDIC_CERAMIC_PRODUCTS;
    }

    return [];
  }

  getProductById(id: string, tenantId?: string): Product | undefined {
    return this.getProducts(tenantId).find(p => p.id === id);
  }

  getProductBySlug(slug: string, tenantId?: string): Product | undefined {
    return this.getProducts(tenantId).find(p => p.slug === slug);
  }

  saveProduct(product: Product, actorName: string = 'Super Admin', tenantId?: string): Product {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    const index = products.findIndex(p => p.id === product.id);
    let updated: Product;

    if (index >= 0) {
      updated = {
        ...product,
        updatedAt: new Date().toISOString()
      };
      products[index] = updated;
      this.addAuditLog(actorName, 'super-admin', 'UPDATE_PRODUCT', 'Product', product.id, `Updated product "${product.name}".`, tid);
    } else {
      updated = {
        ...product,
        id: product.id || `prod-${Date.now()}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      products.unshift(updated);
      this.addAuditLog(actorName, 'super-admin', 'CREATE_PRODUCT', 'Product', updated.id, `Created new product "${product.name}".`, tid);
    }

    this.set(this.getScopedKey('products', tid), products);

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('pos_price_synced', { detail: { productId: updated.id } }));
        window.dispatchEvent(new CustomEvent('pos_inventory_synced', { detail: { productId: updated.id, productName: updated.name } }));
        window.dispatchEvent(new CustomEvent('pos_realtime_event_received', { detail: { type: 'PRODUCT_SAVED', productId: updated.id } }));
        window.dispatchEvent(new Event('storage'));
      } catch {}
    }

    if (this.realtimePublisher) {
      updated.variants.forEach(v => {
        this.realtimePublisher?.('PRICE_UPDATED', {
          productId: updated.id,
          variantId: v.id,
          newPrice: v.price
        }, tid, actorName);
        this.realtimePublisher?.('INVENTORY_ADJUSTED', {
          productId: updated.id,
          variantId: v.id,
          newStock: v.stock,
          reason: index >= 0 ? 'Catalog update' : 'Initial product catalog publication'
        }, tid, actorName);
      });
    }

    return updated;
  }

  deleteProduct(id: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    const product = products.find(p => p.id === id);
    if (!product) return false;

    const filtered = products.filter(p => p.id !== id);
    this.set(this.getScopedKey('products', tid), filtered);
    this.addAuditLog(actorName, 'super-admin', 'DELETE_PRODUCT', 'Product', id, `Deleted product "${product.name}".`, tid);
    return true;
  }

  bulkUpdateProductPrices(
    productIds: string[], 
    mode: 'percentage' | 'fixed_adjust' | 'set_fixed', 
    value: number, 
    actorName: string = 'Super Admin', 
    tenantId?: string
  ): number {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    let count = 0;

    const updatedProducts = products.map(p => {
      if (!productIds.includes(p.id)) return p;
      count++;
      return {
        ...p,
        updatedAt: new Date().toISOString(),
        variants: p.variants.map(v => {
          let newPrice = v.price;
          if (mode === 'percentage') {
            newPrice = Math.max(1, Math.round(v.price * (1 + value / 100)));
          } else if (mode === 'fixed_adjust') {
            newPrice = Math.max(1, Math.round(v.price + value));
          } else if (mode === 'set_fixed') {
            newPrice = Math.max(1, Math.round(value));
          }
          return { ...v, price: newPrice };
        })
      };
    });

    this.set(this.getScopedKey('products', tid), updatedProducts);

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('pos_price_synced', {
          detail: { productIds, mode, value }
        }));
      } catch {}
    }

    if (this.realtimePublisher) {
      this.realtimePublisher('BULK_PRICES_UPDATED', {
        productIds,
        mode,
        value
      }, tid, actorName);
    }

    this.addAuditLog(
      actorName, 
      'super-admin', 
      'BULK_UPDATE_PRICES', 
      'Product', 
      'bulk', 
      `Bulk updated prices for ${count} products (Mode: ${mode}, Value: ${value}).`, 
      tid
    );
    return count;
  }

  bulkUpdateProductCategory(
    productIds: string[], 
    categoryId: string, 
    categoryName: string, 
    actorName: string = 'Super Admin', 
    tenantId?: string
  ): number {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    let count = 0;

    const updatedProducts = products.map(p => {
      if (!productIds.includes(p.id)) return p;
      count++;
      return {
        ...p,
        categoryId,
        categoryName,
        updatedAt: new Date().toISOString()
      };
    });

    this.set(this.getScopedKey('products', tid), updatedProducts);
    this.addAuditLog(
      actorName, 
      'super-admin', 
      'BULK_UPDATE_CATEGORY', 
      'Product', 
      'bulk', 
      `Bulk changed category to "${categoryName}" for ${count} products.`, 
      tid
    );
    return count;
  }

  bulkUpdateProductVisibility(
    productIds: string[], 
    active: boolean, 
    actorName: string = 'Super Admin', 
    tenantId?: string
  ): number {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    let count = 0;

    const updatedProducts = products.map(p => {
      if (!productIds.includes(p.id)) return p;
      count++;
      return {
        ...p,
        active,
        updatedAt: new Date().toISOString()
      };
    });

    this.set(this.getScopedKey('products', tid), updatedProducts);
    this.addAuditLog(
      actorName, 
      'super-admin', 
      'BULK_UPDATE_VISIBILITY', 
      'Product', 
      'bulk', 
      `Bulk set visibility to ${active ? 'Published' : 'Draft'} for ${count} products.`, 
      tid
    );
    return count;
  }

  bulkDeleteProducts(
    productIds: string[], 
    actorName: string = 'Super Admin', 
    tenantId?: string
  ): number {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    const count = products.filter(p => productIds.includes(p.id)).length;
    const filtered = products.filter(p => !productIds.includes(p.id));

    this.set(this.getScopedKey('products', tid), filtered);
    this.addAuditLog(
      actorName, 
      'super-admin', 
      'BULK_DELETE_PRODUCTS', 
      'Product', 
      'bulk', 
      `Bulk deleted ${count} products.`, 
      tid
    );
    return count;
  }

  // ==========================================
  // CATEGORIES (TENANT SCOPED)
  // ==========================================

  getCategories(tenantId?: string): Category[] {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('categories', tid);
    const saved = localStorage.getItem(scopedKey);
    if (saved) {
      try { 
        let parsed = JSON.parse(saved); 
        if (saved.includes('/src/assets/images/')) {
          parsed = this.repairImageUrls(parsed);
          this.set(scopedKey, parsed);
        }
        return parsed;
      } catch {}
    }
    if (tid === 'atelier-surfaces') {
      const legacy = localStorage.getItem(STORAGE_KEYS.LEGACY_CATEGORIES);
      if (legacy) {
        try {
          let parsed = JSON.parse(legacy);
          if (legacy.includes('/src/assets/images/')) {
            parsed = this.repairImageUrls(parsed);
          }
          this.set(scopedKey, parsed);
          return parsed;
        } catch {}
      }
    }
    this.set(scopedKey, INITIAL_CATEGORIES);
    return INITIAL_CATEGORIES;
  }

  saveCategory(category: Category, actorName: string = 'Super Admin', tenantId?: string): Category {
    const tid = tenantId || this.currentTenantId;
    const categories = this.getCategories(tid);
    const index = categories.findIndex(c => c.id === category.id);
    let updated: Category;

    if (index >= 0) {
      updated = category;
      categories[index] = updated;
      this.addAuditLog(actorName, 'super-admin', 'UPDATE_CATEGORY', 'Category', category.id, `Updated category "${category.name}".`, tid);
    } else {
      updated = {
        ...category,
        id: category.id || `cat-${Date.now()}`
      };
      categories.push(updated);
      this.addAuditLog(actorName, 'super-admin', 'CREATE_CATEGORY', 'Category', updated.id, `Created category "${category.name}".`, tid);
    }

    this.set(this.getScopedKey('categories', tid), categories);
    return updated;
  }

  deleteCategory(id: string, actorName: string = 'Super Admin', tenantId?: string): { success: boolean; error?: string } {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    const inUse = products.some(p => p.categoryId === id);
    if (inUse) {
      return { success: false, error: 'Cannot delete category with associated products. Reassign products first.' };
    }

    const categories = this.getCategories(tid);
    const filtered = categories.filter(c => c.id !== id);
    this.set(this.getScopedKey('categories', tid), filtered);
    this.addAuditLog(actorName, 'super-admin', 'DELETE_CATEGORY', 'Category', id, `Deleted category ID ${id}.`, tid);
    return { success: true };
  }

  // ==========================================
  // INVENTORY & STOCK ADJUSTMENTS
  // ==========================================

  adjustStock(params: {
    productId: string;
    variantId: string;
    adjustment: number;
    reason: StockAdjustment['reason'];
    actorName: string;
    skipBroadcast?: boolean;
  }, tenantId?: string): { success: boolean; newStock?: number; error?: string } {
    const tid = tenantId || this.currentTenantId;
    const products = this.getProducts(tid);
    const product = products.find(p => p.id === params.productId);
    if (!product) return { success: false, error: 'Product not found.' };

    const variant = product.variants.find(v => v.id === params.variantId);
    if (!variant) return { success: false, error: 'Variant not found.' };

    const previousStock = variant.stock;
    const newStock = previousStock + params.adjustment;
    if (newStock < 0) {
      return { success: false, error: 'Stock quantity cannot fall below zero.' };
    }

    variant.stock = newStock;
    product.updatedAt = new Date().toISOString();
    this.set(this.getScopedKey('products', tid), products);

    const adjustments = this.getStockAdjustments(tid);
    const adjustmentEntry: StockAdjustment = {
      id: `adj-${Date.now()}`,
      productId: product.id,
      productName: product.name,
      variantId: variant.id,
      colorName: variant.colorName,
      previousStock,
      newStock,
      adjustment: params.adjustment,
      reason: params.reason,
      actorName: params.actorName,
      timestamp: new Date().toISOString()
    };
    adjustments.unshift(adjustmentEntry);
    this.set(this.getScopedKey('stock_adjustments', tid), adjustments);

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('pos_inventory_synced', {
          detail: { 
            productId: product.id, 
            variantId: variant.id, 
            newStock,
            adjustment: params.adjustment,
            productName: product.name,
            colorName: variant.colorName
          }
        }));
      } catch {}
    }

    if (this.realtimePublisher && !params.skipBroadcast) {
      this.realtimePublisher('INVENTORY_ADJUSTED', {
        productId: product.id,
        variantId: variant.id,
        newStock,
        adjustment: params.adjustment,
        reason: params.reason,
        productName: product.name,
        colorName: variant.colorName
      }, tid, params.actorName);
    }

    this.addAuditLog(
      params.actorName,
      'inventory-staff',
      'STOCK_ADJUSTMENT',
      'Inventory',
      variant.id,
      `Adjusted stock for ${product.name} (${variant.colorName}): ${previousStock} -> ${newStock} (${params.adjustment > 0 ? '+' : ''}${params.adjustment}). Reason: ${params.reason}.`,
      tid
    );

    return { success: true, newStock };
  }

  getStockAdjustments(tenantId?: string): StockAdjustment[] {
    const tid = tenantId || this.currentTenantId;
    return this.get<StockAdjustment[]>(this.getScopedKey('stock_adjustments', tid), []);
  }

  // ==========================================
  // ORDERS (TENANT SCOPED)
  // ==========================================

  getOrders(tenantId?: string): Order[] {
    const tid = tenantId || this.currentTenantId;
    if (this.isRevenuesZeroed(tid) || this.isDashboardZeroed(tid)) {
      return [];
    }
    const scopedKey = this.getScopedKey('orders', tid);
    const saved = localStorage.getItem(scopedKey);
    if (saved !== null) {
      try { return JSON.parse(saved); } catch {}
    }
    if (tid === 'atelier-surfaces') {
      const legacy = localStorage.getItem(STORAGE_KEYS.LEGACY_ORDERS);
      if (legacy) {
        try {
          const parsed = JSON.parse(legacy);
          this.set(scopedKey, parsed);
          return parsed;
        } catch {}
      }
      return INITIAL_ORDERS;
    }
    return [];
  }

  getOrderById(id: string, tenantId?: string): Order | undefined {
    return this.getOrders(tenantId).find(o => o.id === id || o.orderNumber === id);
  }

  createOrder(
    orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'updatedAt' | 'trackingTimeline'>,
    tenantId?: string
  ): Order {
    const tid = tenantId || this.currentTenantId;
    const orders = this.getOrders(tid);
    const prefix = tid.substring(0, 3).toUpperCase();
    const orderNumber = `${prefix}-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      ...orderData,
      id: `ord-${tid}-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      trackingTimeline: [
        {
          title: 'Order Placed & Verified',
          description: `Order verified with ${orderData.paymentMethod.toUpperCase()}. Total: ${newOrderTotalString(orderData.total, orderData.currency)}.`,
          timestamp: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          completed: true
        },
        {
          title: 'Crated at Warehouse',
          description: 'Secured with shock absorbers and edge corner guards.',
          timestamp: 'In progress',
          completed: false
        },
        {
          title: 'Dispatched for Freight Handover',
          description: 'Awaiting transport scheduling.',
          timestamp: 'Pending dispatch',
          completed: false
        }
      ]
    };

    // Deduct stock for items
    orderData.itemsSnapshot.forEach(item => {
      this.adjustStock({
        productId: item.productId,
        variantId: item.variantId,
        adjustment: -item.quantity,
        reason: 'Received shipment',
        actorName: 'System (Checkout)'
      }, tid);
    });

    orders.unshift(newOrder);
    this.set(this.getScopedKey('orders', tid), orders);

    this.addAuditLog(
      orderData.customerSnapshot.name,
      'customer',
      'CREATE_ORDER',
      'Order',
      newOrder.id,
      `Placed order ${newOrder.orderNumber} via ${newOrder.paymentMethod}.`,
      tid
    );

    return newOrder;
  }

  updateOrderStatus(
    orderId: string, 
    status: OrderStatus, 
    paymentStatus?: PaymentStatus, 
    actorName: string = 'Manager',
    tenantId?: string
  ): Order | undefined {
    const tid = tenantId || this.currentTenantId;
    const orders = this.getOrders(tid);
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return undefined;

    const order = orders[index];
    order.orderStatus = status;
    if (paymentStatus) {
      order.paymentStatus = paymentStatus;
    }
    order.updatedAt = new Date().toISOString();

    if (status === 'shipped') {
      const step = order.trackingTimeline.find(t => t.title.includes('Dispatched') || t.title.includes('Freight'));
      if (step) {
        step.completed = true;
        step.timestamp = new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }
    } else if (status === 'delivered') {
      order.trackingTimeline.forEach(t => t.completed = true);
    }

    orders[index] = order;
    this.set(this.getScopedKey('orders', tid), orders);

    this.addAuditLog(
      actorName,
      'manager',
      'UPDATE_ORDER_STATUS',
      'Order',
      order.id,
      `Updated order ${order.orderNumber} status to "${status}".`,
      tid
    );

    return order;
  }

  updateOrder(order: Order, actorName: string = 'System', tenantId?: string): Order {
    const tid = tenantId || this.currentTenantId;
    const orders = this.getOrders(tid);
    const index = orders.findIndex(o => o.id === order.id);
    if (index >= 0) {
      orders[index] = { ...order, updatedAt: new Date().toISOString() };
      this.set(this.getScopedKey('orders', tid), orders);
      this.addAuditLog(actorName, 'system', 'UPDATE_ORDER', 'Order', order.id, `Updated order ${order.orderNumber}.`, tid);
    }
    return order;
  }

  // ==========================================
  // STORE SETTINGS (TENANT SCOPED)
  // ==========================================

  getStoreSettings(tenantId?: string): StoreSettings {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('settings', tid);
    const saved = localStorage.getItem(scopedKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        let changed = false;
        if (parsed.contactPhone === '+233 24 582 9100') {
          parsed.contactPhone = '0542443125/0596334488';
          changed = true;
        }
        if (parsed.whatsAppNumber === '+233 24 582 9100') {
          parsed.whatsAppNumber = '0542443125/0596334488';
          changed = true;
        }
        if (parsed.posSettings) {
          if (parsed.posSettings.contactPhone === '+233 24 582 9100') {
            parsed.posSettings.contactPhone = '0542443125/0596334488';
            changed = true;
          }
          if (parsed.posSettings.whatsAppNumber === '+233 24 582 9100') {
            parsed.posSettings.whatsAppNumber = '0542443125/0596334488';
            changed = true;
          }
          if (parsed.posSettings.momoMerchantNumber === '+233 24 582 9100') {
            parsed.posSettings.momoMerchantNumber = '0542443125/0596334488';
            changed = true;
          }
        }
        if (changed) {
          this.set(scopedKey, parsed);
        }
        return parsed;
      } catch {}
    }
    if (tid === 'atelier-surfaces') {
      const legacy = localStorage.getItem(STORAGE_KEYS.LEGACY_SETTINGS);
      if (legacy) {
        try {
          const parsed = JSON.parse(legacy);
          if (parsed.contactPhone === '+233 24 582 9100') parsed.contactPhone = '0542443125/0596334488';
          if (parsed.whatsAppNumber === '+233 24 582 9100') parsed.whatsAppNumber = '0542443125/0596334488';
          this.set(scopedKey, parsed);
          return parsed;
        } catch {}
      }
      this.set(scopedKey, INITIAL_STORE_SETTINGS);
      return INITIAL_STORE_SETTINGS;
    }

    const company = this.getCompanies().find(c => c.id === tid || c.slug === tid) || this.getActiveCompany();
    const defaults = getCompanySettings(company);
    this.set(scopedKey, defaults);
    return defaults;
  }

  updateStoreSettings(settings: Partial<StoreSettings>, actorName: string = 'Super Admin', tenantId?: string): StoreSettings {
    const tid = tenantId || this.currentTenantId || 'atelier-surfaces';
    const current = this.getStoreSettings(tid);
    const updated: StoreSettings = { ...current, ...settings };
    this.set(this.getScopedKey('settings', tid), updated);

    // Sync legacy settings if default tenant
    if (tid === 'atelier-surfaces') {
      try {
        localStorage.setItem(STORAGE_KEYS.LEGACY_SETTINGS, JSON.stringify(updated));
      } catch {}
    }

    // Sync with companies registry including ghanaPostGps and showroom coordinates
    const companies = this.getCompanies();
    const cIdx = companies.findIndex(c => c.id === tid);
    if (cIdx >= 0) {
      companies[cIdx] = {
        ...companies[cIdx],
        name: updated.brandName || companies[cIdx].name,
        tagline: updated.tagline || companies[cIdx].tagline,
        contactEmail: updated.contactEmail || companies[cIdx].contactEmail,
        contactPhone: updated.contactPhone || companies[cIdx].contactPhone,
        whatsAppNumber: updated.whatsAppNumber || companies[cIdx].whatsAppNumber,
        showroomAddress: updated.showroomAddress || companies[cIdx].showroomAddress,
        ghanaPostGps: updated.ghanaPostGps || companies[cIdx].ghanaPostGps,
        currency: updated.currency || companies[cIdx].currency,
        currencySymbol: updated.currencySymbol || companies[cIdx].currencySymbol,
        activeThemeId: updated.activeThemeId || companies[cIdx].activeThemeId
      };
      this.set(STORAGE_KEYS.COMPANIES_REGISTRY, companies);
    }

    this.addAuditLog(
      actorName,
      'super-admin',
      'UPDATE_STORE_SETTINGS',
      'Settings',
      'global-settings',
      `Updated company store settings for ${tid} (Address: ${updated.showroomAddress}, Phone: ${updated.contactPhone}, GPS: ${updated.ghanaPostGps}).`,
      tid
    );

    // Notify listeners so React state updates immediately
    this.tenantListeners.forEach(listener => listener(tid));
    this.settingsListeners.forEach(listener => listener(updated, tid));

    // Dispatch global events for real-time storefront synchronization
    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('atelier_settings_updated', {
          detail: { tenantId: tid, settings: updated }
        }));
        window.dispatchEvent(new Event('storage'));
      } catch {}
    }

    return updated;
  }

  // ==========================================
  // CONSULTATION ROOMS & VIDEO CALLS (TENANT SCOPED)
  // ==========================================

  getConsultationRooms(tenantId?: string): ConsultationRoom[] {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('consultation_rooms', tid);
    const defaultRooms: ConsultationRoom[] = [
      {
        id: 'atelier-flagship-lounge',
        name: 'Showroom VIP Lounge · Ridge West',
        createdAt: '2026-03-01T10:00:00Z',
        isLocked: false,
        clientName: 'Studio Arch Group',
        clientRole: 'Licensed Architect',
        consultantName: 'Kwame Mensah',
        scheduledTime: 'Live On-Demand',
        activeParticipantsCount: 2,
        presentingSlab: {
          name: 'Calacatta Statuario Imperiale',
          material: 'Porcelain Slab',
          price: 485
        }
      },
      {
        id: 'vein-matching-studio',
        name: 'Vein Matching & Bookmatch Studio',
        createdAt: '2026-03-10T14:30:00Z',
        isLocked: false,
        clientName: 'Kofi & Ama Luxury Villa',
        clientRole: 'Private Homeowner',
        consultantName: 'Kwame Mensah',
        scheduledTime: 'Daily: 11:00 AM & 3:00 PM',
        activeParticipantsCount: 1,
        presentingSlab: {
          name: 'Nero Marquina Velvet Polished',
          material: 'Spanish Marble',
          price: 520
        }
      },
      {
        id: 'private-quarry-briefing',
        name: 'Executive Quarry Specimen Briefing',
        createdAt: '2026-03-15T09:00:00Z',
        isLocked: true,
        clientName: 'West Hills Commercial Plaza',
        clientRole: 'General Contractor',
        consultantName: 'Kwame Mensah',
        scheduledTime: 'Reserved & Admin-Locked',
        activeParticipantsCount: 0
      }
    ];

    return this.get<ConsultationRoom[]>(scopedKey, defaultRooms);
  }

  saveConsultationRoom(room: ConsultationRoom, actorName: string = 'Super Admin', tenantId?: string): ConsultationRoom {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('consultation_rooms', tid);
    const rooms = this.getConsultationRooms(tid);
    const index = rooms.findIndex(r => r.id === room.id);
    let updated: ConsultationRoom;

    if (index >= 0) {
      updated = { ...room };
      rooms[index] = updated;
      this.addAuditLog(actorName, 'super-admin', 'UPDATE_CONSULTATION_ROOM', 'VideoRoom', room.id, `Updated consultation room "${room.name}" (Locked: ${room.isLocked}).`, tid);
    } else {
      updated = {
        ...room,
        id: room.id || `atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: room.createdAt || new Date().toISOString()
      };
      rooms.unshift(updated);
      this.addAuditLog(actorName, 'super-admin', 'CREATE_CONSULTATION_ROOM', 'VideoRoom', updated.id, `Created new consultation room "${updated.name}".`, tid);
    }

    this.set(scopedKey, rooms);
    return updated;
  }

  deleteConsultationRoom(roomId: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('consultation_rooms', tid);
    const rooms = this.getConsultationRooms(tid);
    const filtered = rooms.filter(r => r.id !== roomId);
    this.set(scopedKey, filtered);
    this.addAuditLog(actorName, 'super-admin', 'DELETE_CONSULTATION_ROOM', 'VideoRoom', roomId, `Deleted consultation room ID ${roomId}.`, tid);
    return true;
  }

  toggleRoomLock(roomId: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const rooms = this.getConsultationRooms(tid);
    const room = rooms.find(r => r.id === roomId);
    if (!room) return false;

    room.isLocked = !room.isLocked;
    this.saveConsultationRoom(room, actorName, tid);
    return room.isLocked;
  }

  toggleVideoConsultationLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    settings.videoConsultationLocked = locked;
    this.updateStoreSettings(settings, actorName, tid);
    this.addAuditLog(
      actorName,
      'super-admin',
      locked ? 'LOCK_VIDEO_CONSULTATION' : 'UNLOCK_VIDEO_CONSULTATION',
      'VideoConsultation',
      'global',
      `${locked ? 'LOCKED' : 'UNLOCKED'} all face-to-face video consultations across the storefront.`,
      tid
    );
    return locked;
  }

  toggleContactDetailsLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    settings.contactLocked = locked;
    settings.contactLastSavedBy = actorName;
    this.updateStoreSettings(settings, actorName, tid);
    this.addAuditLog(
      actorName,
      'super-admin',
      locked ? 'LOCK_SHOWROOM_CONTACT' : 'UNLOCK_SHOWROOM_CONTACT',
      'ShowroomContact',
      'global',
      `${locked ? 'LOCKED' : 'UNLOCKED'} flagship showroom address and concierge contact details.`,
      tid
    );
    return locked;
  }

  toggleWhatsAppLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    settings.whatsAppLocked = locked;
    this.updateStoreSettings(settings, actorName, tid);
    this.addAuditLog(
      actorName,
      'super-admin',
      locked ? 'LOCK_WHATSAPP_DESK' : 'UNLOCK_WHATSAPP_DESK',
      'DirectTradeWhatsApp',
      'global',
      `${locked ? 'LOCKED' : 'UNLOCKED'} Direct Trade WhatsApp Desk credentials and phone (${settings.whatsAppNumber || '0542443125/0596334488'}).`,
      tid
    );
    return locked;
  }

  // ==========================================
  // PANEL BRIGHTNESS CONTROLS & LOCK
  // ==========================================

  getPanelBrightness(tenantId?: string): PanelBrightnessConfig {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    const defaults: PanelBrightnessConfig = {
      sidebarBrightness: 100,
      sidebarContrast: 100,
      headerBrightness: 100,
      headerContrast: 100,
      workspaceBrightness: 100,
      workspaceContrast: 100,
      cardsBrightness: 100,
      cardsContrast: 100,
      posBrightness: 100,
      posContrast: 100,
      storefrontHeaderBrightness: 100,
      storefrontHeaderContrast: 100,
      storefrontHeroBrightness: 100,
      storefrontHeroContrast: 100,
      storefrontCatalogBrightness: 100,
      storefrontCatalogContrast: 100,
      storefrontSpecimenBrightness: 100,
      storefrontSpecimenContrast: 100,
      storefrontFooterBrightness: 100,
      storefrontFooterContrast: 100,
      isLocked: false
    };

    return {
      ...defaults,
      ...(settings.panelBrightness || {})
    };
  }

  updatePanelBrightness(config: Partial<PanelBrightnessConfig>, actorName: string = 'Super Admin', tenantId?: string): PanelBrightnessConfig {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    const current = this.getPanelBrightness(tid);
    const updated: PanelBrightnessConfig = {
      ...current,
      ...config,
      lockedBy: config.isLocked ? actorName : current.lockedBy,
      lockedAt: config.isLocked ? new Date().toISOString() : current.lockedAt,
    };
    settings.panelBrightness = updated;
    this.updateStoreSettings(settings, actorName, tid);
    this.addAuditLog(
      actorName,
      'super-admin',
      'UPDATE_PANEL_BRIGHTNESS',
      'ThemeDisplay',
      'panel_brightness',
      `Adjusted and saved panel brightness configuration (Locked: ${updated.isLocked}).`,
      tid
    );
    return updated;
  }

  togglePanelBrightnessLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const current = this.getPanelBrightness(tid);
    current.isLocked = locked;
    current.lockedBy = locked ? actorName : undefined;
    current.lockedAt = locked ? new Date().toISOString() : undefined;
    this.updatePanelBrightness(current, actorName, tid);
    return locked;
  }

  // ==========================================
  // POS (POINT OF SALE) SETTINGS & TRANSACTIONS
  // ==========================================

  getPOSSettings(tenantId?: string): POSSettings {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    const existing = settings.posSettings;
    return {
      registerName: existing?.registerName || 'Ridge West Showroom Terminal #1',
      registerCode: existing?.registerCode || 'RW-POS-01',
      defaultCashierName: existing?.defaultCashierName || 'Kwame Mensah',
      walkInCustomerName: existing?.walkInCustomerName || 'Showroom Walk-in Client',
      taxCalculationMode: existing?.taxCalculationMode || 'inclusive',
      taxRatePercent: existing?.taxRatePercent ?? 15,
      allowNegativeInventory: existing?.allowNegativeInventory ?? false,
      autoDeductInventory: existing?.autoDeductInventory ?? true,
      maxCashierDiscountPercent: existing?.maxCashierDiscountPercent ?? 15,
      requireSupervisorDiscountPin: existing?.requireSupervisorDiscountPin ?? true,
      supervisorPin: existing?.supervisorPin || '9814',
      quickDiscountPresets: existing?.quickDiscountPresets || [5, 10, 15, 20],
      barcodeContinuousScan: existing?.barcodeContinuousScan ?? true,
      cashDrawerAutoKick: existing?.cashDrawerAutoKick ?? true,
      playNotificationSound: existing?.playNotificationSound ?? true,
      receiptPrinterWidth: existing?.receiptPrinterWidth || '80mm',
      receiptShowLogo: existing?.receiptShowLogo ?? true,
      receiptShowBarcode: existing?.receiptShowBarcode ?? true,
      receiptShowGps: existing?.receiptShowGps ?? true,
      receiptHeaderNote: existing?.receiptHeaderNote || 'ATELIER SURFACES · RIDGE WEST FLAGSHIP',
      receiptFooterNote: existing?.receiptFooterNote || 'Thank you for choosing Atelier Surfaces. Goods inspected & verified at Ridge West Showroom.',
      enabledPaymentMethods: existing?.enabledPaymentMethods || {
        cash: true,
        card: true,
        mobileMoney: true,
        bankTransfer: true,
        cheque: false,
        split: true
      },
      momoMerchantNumber: existing?.momoMerchantNumber || settings.contactPhone || '0542443125/0596334488',
      showroomAddress: existing?.showroomAddress || settings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana',
      ghanaPostGps: existing?.ghanaPostGps || settings.ghanaPostGps || 'GA-110-3849',
      contactPhone: existing?.contactPhone || settings.contactPhone || '0542443125/0596334488',
      contactEmail: existing?.contactEmail || settings.contactEmail || 'concierge@ateliersurfaces.com',
      offlineModeEnabled: existing?.offlineModeEnabled ?? true,
      quickCashDenominations: existing?.quickCashDenominations || [10, 20, 50, 100, 200],
      isLocked: existing?.isLocked ?? false,
      lockedBy: existing?.lockedBy,
      lockedAt: existing?.lockedAt
    };
  }

  updatePOSSettings(newSettings: Partial<POSSettings>, actorName: string = 'Super Admin', tenantId?: string): POSSettings {
    const tid = tenantId || this.currentTenantId;
    const settings = this.getStoreSettings(tid);
    const current = this.getPOSSettings(tid);
    const updated: POSSettings = {
      ...current,
      ...newSettings,
      lockedBy: newSettings.isLocked ? actorName : current.lockedBy,
      lockedAt: newSettings.isLocked ? new Date().toISOString() : current.lockedAt,
    };
    settings.posSettings = updated;

    // DIRECT SYNC TO STOREFRONT:
    // If the admin modified showroomAddress, ghanaPostGps, contactPhone, or contactEmail in the POS system,
    // immediately propagate to StoreSettings, CompanyTenant, and notify all storefront listeners!
    if (newSettings.showroomAddress !== undefined) {
      settings.showroomAddress = newSettings.showroomAddress;
    }
    if (newSettings.ghanaPostGps !== undefined) {
      settings.ghanaPostGps = newSettings.ghanaPostGps;
    }
    if (newSettings.contactPhone !== undefined) {
      settings.contactPhone = newSettings.contactPhone;
    }
    if (newSettings.contactEmail !== undefined) {
      settings.contactEmail = newSettings.contactEmail;
    }
    if (newSettings.momoMerchantNumber !== undefined && !newSettings.contactPhone) {
      settings.contactPhone = newSettings.momoMerchantNumber;
    }

    this.updateStoreSettings(settings, actorName, tid);
    this.addAuditLog(
      actorName,
      'super-admin',
      'UPDATE_POS_SETTINGS',
      'POS',
      updated.registerCode,
      `Updated Point of Sale settings and synced showroom location to storefront (${settings.showroomAddress}, ${settings.contactPhone}, ${settings.ghanaPostGps}).`,
      tid
    );
    return updated;
  }

  togglePOSLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const current = this.getPOSSettings(tid);
    current.isLocked = locked;
    current.lockedBy = locked ? actorName : undefined;
    current.lockedAt = locked ? new Date().toISOString() : undefined;
    this.updatePOSSettings(current, actorName, tid);
    return locked;
  }

  getPOSTransactions(tenantId?: string): POSTransaction[] {
    const tid = tenantId || this.currentTenantId;
    if (this.isRevenuesZeroed(tid) || this.isDashboardZeroed(tid)) {
      return [];
    }
    const scopedKey = this.getScopedKey('pos_transactions', tid);
    const now = new Date();
    const defaultTx: POSTransaction[] = [
      {
        id: `pos-${tid}-today-1`,
        transactionNumber: 'RW-POS-8492',
        timestamp: new Date(now.getTime() - 45 * 60 * 1000).toISOString(),
        cashierName: 'Kwame Mensah',
        customerName: 'Arch. Kwesi Osei (Ridge West Showroom)',
        customerPhone: '+233 24 412 8890',
        items: [
          {
            productId: 'prod-calacatta-statuario',
            productName: 'Calacatta Statuario Imperiale',
            variantId: 'var-calacatta-gold',
            colorName: 'Calacatta Gold',
            sku: 'AS-CSI-GLD-120240',
            unitPrice: 485,
            quantity: 32,
            unit: 'm²',
            lineTotal: 15520
          }
        ],
        subtotal: 15520,
        discountPercent: 5,
        discountAmount: 776,
        taxAmount: 2211.60,
        total: 16955.60,
        paymentMethod: 'card',
        paymentDetails: {
          cardLast4: '4192'
        },
        synced: true
      },
      {
        id: `pos-${tid}-today-2`,
        transactionNumber: 'RW-POS-8493',
        timestamp: new Date(now.getTime() - 150 * 60 * 1000).toISOString(),
        cashierName: 'Kwame Mensah',
        customerName: 'Mensa & Partners Penthouse Project',
        customerPhone: '+233 20 882 1045',
        items: [
          {
            productId: 'prod-nero-marquina',
            productName: 'Nero Marquina Velvet Polished',
            variantId: 'var-nero-deep',
            colorName: 'Midnight Deep Nero',
            sku: 'AS-NMV-BLK-120278',
            unitPrice: 520,
            quantity: 18,
            unit: 'm²',
            lineTotal: 9360
          }
        ],
        subtotal: 9360,
        discountPercent: 0,
        discountAmount: 0,
        taxAmount: 1404,
        total: 10764,
        paymentMethod: 'momo',
        paymentDetails: {
          momoPhone: '+233 20 882 1045',
          momoRef: 'MM-GH-91823'
        },
        synced: true
      }
    ];
    return this.get<POSTransaction[]>(scopedKey, defaultTx);
  }

  savePOSTransaction(tx: POSTransaction, actorName: string = 'Cashier', tenantId?: string): POSTransaction {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('pos_transactions', tid);
    const list = this.getPOSTransactions(tid);
    list.unshift(tx);
    this.set(scopedKey, list);

    // Auto deduct inventory if enabled
    const posSettings = this.getPOSSettings(tid);
    if (posSettings.autoDeductInventory) {
      tx.items.forEach(item => {
        try {
          this.adjustStock({
            productId: item.productId,
            variantId: item.variantId,
            adjustment: -item.quantity,
            reason: 'Received shipment',
            actorName: `${actorName} (POS ${tx.transactionNumber})`
          }, tid);
        } catch {}
      });
    }

    this.addAuditLog(
      actorName,
      'manager',
      'POS_SALE_COMPLETED',
      'POSOrder',
      tx.transactionNumber,
      `Completed showroom POS ticket ${tx.transactionNumber} for ${tx.customerName} · Total: GH₵${tx.total.toFixed(2)} (${tx.paymentMethod.toUpperCase()}).`,
      tid
    );

    return tx;
  }

  // ==========================================
  // ROLES & USERS
  // ==========================================

  getRoles(): UserRole[] {
    return this.get<UserRole[]>(STORAGE_KEYS.ROLES, INITIAL_ROLES);
  }

  getRoleById(id: string): UserRole | undefined {
    return this.getRoles().find(r => r.id === id);
  }

  saveRole(role: UserRole, actorName: string = 'Super Admin'): UserRole {
    const roles = this.getRoles();
    const index = roles.findIndex(r => r.id === role.id);
    let updated: UserRole;

    if (index >= 0) {
      if (role.id === 'super-admin') {
        role.builtIn = true;
      }
      updated = {
        ...role,
        updatedAt: new Date().toISOString()
      };
      roles[index] = updated;
      this.addAuditLog(actorName, 'super-admin', 'UPDATE_ROLE', 'Role', role.id, `Updated permissions for role "${role.name}".`);
    } else {
      updated = {
        ...role,
        id: role.id || `role-${Date.now()}`,
        builtIn: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      roles.push(updated);
      this.addAuditLog(actorName, 'super-admin', 'CREATE_ROLE', 'Role', updated.id, `Created new role "${role.name}".`);
    }

    this.set(STORAGE_KEYS.ROLES, roles);

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('roles_updated', { detail: { roleId: updated.id, action: 'saved' } }));
        window.dispatchEvent(new Event('storage'));
      } catch {}
    }

    return updated;
  }

  deleteRole(roleId: string, actorName: string = 'Super Admin'): { success: boolean; error?: string } {
    const roles = this.getRoles();
    if (roles.length <= 1) {
      return { success: false, error: 'Cannot delete the only remaining role in the enterprise directory.' };
    }

    const roleToDelete = roles.find(r => r.id === roleId);
    if (!roleToDelete) {
      return { success: false, error: 'Role not found.' };
    }

    const filteredRoles = roles.filter(r => r.id !== roleId);
    this.set(STORAGE_KEYS.ROLES, filteredRoles);

    // Safely reassign affected personnel to an existing fallback role
    const fallbackRole = filteredRoles.find(r => r.id === 'super-admin') || filteredRoles[0];
    const users = this.getUsers();
    let reassignedCount = 0;
    users.forEach(u => {
      if (u.roleId === roleId) {
        u.roleId = fallbackRole.id;
        u.roleName = fallbackRole.name;
        reassignedCount++;
      }
    });
    if (reassignedCount > 0) {
      this.set(STORAGE_KEYS.USERS, users);
    }

    this.addAuditLog(
      actorName,
      'super-admin',
      'DELETE_ROLE',
      'Role',
      roleId,
      `Deleted role "${roleToDelete.name}". Reassigned ${reassignedCount} personnel to "${fallbackRole.name}".`
    );

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('roles_updated', { detail: { roleId, action: 'deleted' } }));
        window.dispatchEvent(new Event('storage'));
      } catch {}
    }

    return { success: true };
  }

  getUsers(): AppUser[] {
    return this.get<AppUser[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  }

  updateUserRole(userId: string, newRoleId: string, actorName: string = 'Super Admin'): boolean {
    const users = this.getUsers();
    const user = users.find(u => u.uid === userId);
    const role = this.getRoleById(newRoleId);
    if (!user || !role) return false;

    if (user.roleId === 'super-admin' && newRoleId !== 'super-admin') {
      const superAdmins = users.filter(u => u.roleId === 'super-admin');
      if (superAdmins.length <= 1) {
        return false;
      }
    }

    user.roleId = role.id;
    user.roleName = role.name;
    this.set(STORAGE_KEYS.USERS, users);
    this.addAuditLog(actorName, 'super-admin', 'CHANGE_USER_ROLE', 'User', user.uid, `Assigned role "${role.name}" to user ${user.name}.`);
    return true;
  }

  // ==========================================
  // CUSTOM THEMES
  // ==========================================

  getCustomThemes(): { id: string; name: string; tokens: ThemeTokens; updatedAt: string }[] {
    return this.get(STORAGE_KEYS.CUSTOM_THEMES, []);
  }

  saveCustomTheme(
    id: string, 
    name: string, 
    tokens: ThemeTokens, 
    actorName: string = 'Super Admin'
  ): { id: string; name: string; tokens: ThemeTokens; updatedAt: string } {
    const themes = this.getCustomThemes();
    const index = themes.findIndex(t => t.id === id);
    const themeObj = {
      id: id || `custom-theme-${Date.now()}`,
      name,
      tokens,
      updatedAt: new Date().toISOString()
    };

    if (index >= 0) {
      themes[index] = themeObj;
    } else {
      themes.push(themeObj);
    }

    this.set(STORAGE_KEYS.CUSTOM_THEMES, themes);
    this.addAuditLog(actorName, 'super-admin', 'SAVE_CUSTOM_THEME', 'Theme', themeObj.id, `Saved custom theme "${name}".`);
    return themeObj;
  }

  deleteCustomTheme(id: string, actorName: string = 'Super Admin'): boolean {
    const themes = this.getCustomThemes();
    const filtered = themes.filter(t => t.id !== id);
    this.set(STORAGE_KEYS.CUSTOM_THEMES, filtered);
    this.addAuditLog(actorName, 'super-admin', 'DELETE_CUSTOM_THEME', 'Theme', id, `Deleted custom theme ID ${id}.`);
    return true;
  }

  // ==========================================
  // AUDIT LOGS (TENANT SCOPED)
  // ==========================================

  getAuditLogs(tenantId?: string): AuditLog[] {
    const tid = tenantId || this.currentTenantId;
    return this.get<AuditLog[]>(this.getScopedKey('audit_logs', tid), [
      {
        id: `aud-${tid}-001`,
        actorUid: 'usr-admin-1',
        actorName: 'System Provisioner',
        actorRole: 'Super Admin',
        action: 'BOOTSTRAP_TENANT',
        resourceType: 'CompanyWorkspace',
        resourceId: tid,
        safeChangeSummary: `Workspace initialized for tenant ${tid} with isolated catalog, settings, and orders.`,
        timestamp: new Date().toISOString()
      }
    ]);
  }

  addAuditLog(
    actorName: string, 
    actorRole: string, 
    action: string, 
    resourceType: string, 
    resourceId: string | undefined, 
    safeChangeSummary: string,
    tenantId?: string
  ): void {
    const tid = tenantId || this.currentTenantId;
    const logs = this.getAuditLogs(tid);
    const newLog: AuditLog = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actorUid: 'usr-current',
      actorName,
      actorRole,
      action,
      resourceType,
      resourceId,
      safeChangeSummary,
      timestamp: new Date().toISOString()
    };
    logs.unshift(newLog);
    if (logs.length > 200) logs.pop();
    this.set(this.getScopedKey('audit_logs', tid), logs);
  }

  // ==========================================
  // BULK & QUANTITY PRICING TIERS (TENANT SCOPED)
  // ==========================================

  getBulkPricingRules(tenantId?: string): BulkPricingRule[] {
    const tid = tenantId || this.currentTenantId;
    return this.get<BulkPricingRule[]>(this.getScopedKey('bulk_pricing_rules', tid), INITIAL_BULK_PRICING_RULES);
  }

  getBulkPricingRuleById(id: string, tenantId?: string): BulkPricingRule | undefined {
    return this.getBulkPricingRules(tenantId).find(r => r.id === id);
  }

  getBulkPricingRuleForCategory(categoryId: string, tenantId?: string): BulkPricingRule | null {
    const rules = this.getBulkPricingRules(tenantId).filter(r => r.active);
    // Exact category match first
    const specific = rules.find(r => r.collectionId === categoryId);
    if (specific) return specific;
    // Fallback to 'all' collection rule if defined
    const allRule = rules.find(r => r.collectionId === 'all');
    return allRule || null;
  }

  saveBulkPricingRule(rule: BulkPricingRule, actorName: string = 'Super Admin', tenantId?: string): BulkPricingRule {
    const tid = tenantId || this.currentTenantId;
    const rules = this.getBulkPricingRules(tid);
    
    // Sort tiers by minQuantitySqm ascending
    const sortedTiers = [...rule.tiers].sort((a, b) => a.minQuantitySqm - b.minQuantitySqm);
    
    const ruleObj: BulkPricingRule = {
      ...rule,
      id: rule.id || `bpr-${Date.now()}`,
      tiers: sortedTiers,
      updatedAt: new Date().toISOString()
    };

    const existingIndex = rules.findIndex(r => r.id === ruleObj.id);
    if (existingIndex >= 0) {
      rules[existingIndex] = ruleObj;
    } else {
      rules.unshift(ruleObj);
    }

    this.set(this.getScopedKey('bulk_pricing_rules', tid), rules);
    this.addAuditLog(
      actorName,
      'admin',
      existingIndex >= 0 ? 'UPDATE_BULK_PRICING_RULE' : 'CREATE_BULK_PRICING_RULE',
      'BulkPricingRule',
      ruleObj.id,
      `Saved bulk pricing matrix "${ruleObj.name}" for collection "${ruleObj.collectionName}" with ${ruleObj.tiers.length} tier(s).`,
      tid
    );

    // Broadcast change
    window.dispatchEvent(new CustomEvent('bulk_pricing_updated', { detail: { ruleId: ruleObj.id, tenantId: tid } }));

    return ruleObj;
  }

  deleteBulkPricingRule(ruleId: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const rules = this.getBulkPricingRules(tid);
    const target = rules.find(r => r.id === ruleId);
    if (!target) return false;

    if (target.isLocked) {
      throw new Error(`Bulk pricing rule "${target.name}" is locked and cannot be deleted until unlocked.`);
    }

    const filtered = rules.filter(r => r.id !== ruleId);
    this.set(this.getScopedKey('bulk_pricing_rules', tid), filtered);
    this.addAuditLog(
      actorName,
      'admin',
      'DELETE_BULK_PRICING_RULE',
      'BulkPricingRule',
      ruleId,
      `Deleted bulk pricing rule "${target.name}" (${target.collectionName}).`,
      tid
    );

    window.dispatchEvent(new CustomEvent('bulk_pricing_updated', { detail: { ruleId, tenantId: tid } }));
    return true;
  }

  toggleBulkPricingLock(ruleId: string, isLocked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const rules = this.getBulkPricingRules(tid);
    const rule = rules.find(r => r.id === ruleId);
    if (!rule) return false;

    rule.isLocked = isLocked;
    rule.lockedBy = isLocked ? actorName : undefined;
    rule.lockedAt = isLocked ? new Date().toISOString() : undefined;
    rule.updatedAt = new Date().toISOString();

    this.set(this.getScopedKey('bulk_pricing_rules', tid), rules);
    this.addAuditLog(
      actorName,
      'admin',
      isLocked ? 'LOCK_BULK_PRICING_RULE' : 'UNLOCK_BULK_PRICING_RULE',
      'BulkPricingRule',
      ruleId,
      `${isLocked ? 'Locked' : 'Unlocked'} bulk pricing rule "${rule.name}".`,
      tid
    );

    window.dispatchEvent(new CustomEvent('bulk_pricing_updated', { detail: { ruleId, tenantId: tid } }));
    return true;
  }

  toggleBulkPricingActive(ruleId: string, active: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const rules = this.getBulkPricingRules(tid);
    const rule = rules.find(r => r.id === ruleId);
    if (!rule) return false;

    rule.active = active;
    rule.updatedAt = new Date().toISOString();

    this.set(this.getScopedKey('bulk_pricing_rules', tid), rules);
    this.addAuditLog(
      actorName,
      'admin',
      active ? 'ACTIVATE_BULK_PRICING_RULE' : 'PAUSE_BULK_PRICING_RULE',
      'BulkPricingRule',
      ruleId,
      `${active ? 'Activated' : 'Deactivated'} bulk pricing rule "${rule.name}".`,
      tid
    );

    window.dispatchEvent(new CustomEvent('bulk_pricing_updated', { detail: { ruleId, tenantId: tid } }));
    return true;
  }

  /**
   * Calculates bulk discounts for cart items by evaluating qualifying square meter quantities per collection.
   * Samples (isSample: true) are excluded from m² threshold volume accumulation.
   */
  calculateCartBulkDiscount(items: CartItem[], tenantId?: string): { totalBulkDiscount: number; appliedRules: AppliedBulkDiscount[] } {
    const tid = tenantId || this.currentTenantId;
    const rules = this.getBulkPricingRules(tid).filter(r => r.active);
    const products = this.getProducts(tid);

    if (items.length === 0 || rules.length === 0) {
      return { totalBulkDiscount: 0, appliedRules: [] };
    }

    // Map cart items with their product category
    const itemsWithCategory = items.filter(it => !it.isSample).map(it => {
      const prod = products.find(p => p.id === it.productId);
      const categoryId = prod?.categoryId || '';
      const categoryName = prod?.categoryName || 'General';
      const sqm = it.unit === 'box' ? (it.quantity * (it.boxCoverage || 1.44)) : it.quantity;
      const lineSubtotal = it.unitPrice * it.quantity;
      return {
        ...it,
        categoryId,
        categoryName,
        sqm,
        lineSubtotal
      };
    });

    // Group by categoryId
    const categoryTotals: Record<string, { totalSqm: number; totalSubtotal: number; categoryName: string; lineItems: typeof itemsWithCategory }> = {};

    itemsWithCategory.forEach(item => {
      const catKey = item.categoryId || 'uncategorized';
      if (!categoryTotals[catKey]) {
        categoryTotals[catKey] = {
          totalSqm: 0,
          totalSubtotal: 0,
          categoryName: item.categoryName,
          lineItems: []
        };
      }
      categoryTotals[catKey].totalSqm += item.sqm;
      categoryTotals[catKey].totalSubtotal += item.lineSubtotal;
      categoryTotals[catKey].lineItems.push(item);
    });

    let totalBulkDiscount = 0;
    const appliedRules: AppliedBulkDiscount[] = [];

    // For each category group, find matching rule
    Object.entries(categoryTotals).forEach(([catId, data]) => {
      const rule = rules.find(r => r.collectionId === catId) || rules.find(r => r.collectionId === 'all');
      if (!rule || !rule.tiers || rule.tiers.length === 0) return;

      const sortedTiersDesc = [...rule.tiers].sort((a, b) => b.minQuantitySqm - a.minQuantitySqm);
      const matchingTier = sortedTiersDesc.find(t => {
        const meetsMin = data.totalSqm >= t.minQuantitySqm;
        const meetsMax = t.maxQuantitySqm == null || data.totalSqm <= t.maxQuantitySqm;
        return meetsMin && meetsMax;
      });

      if (matchingTier) {
        let discountForGroup = 0;
        let effectivePricePerSqm: number | undefined = undefined;

        if (matchingTier.discountType === 'percentage') {
          discountForGroup = (data.totalSubtotal * matchingTier.discountValue) / 100;
        } else {
          const standardCostPerSqm = data.totalSqm > 0 ? data.totalSubtotal / data.totalSqm : 0;
          if (standardCostPerSqm > matchingTier.discountValue) {
            discountForGroup = (standardCostPerSqm - matchingTier.discountValue) * data.totalSqm;
            effectivePricePerSqm = matchingTier.discountValue;
          }
        }

        if (discountForGroup > 0) {
          totalBulkDiscount += discountForGroup;
          appliedRules.push({
            ruleId: rule.id,
            ruleName: rule.name,
            collectionId: rule.collectionId,
            collectionName: rule.collectionName,
            tierId: matchingTier.id,
            tierLabel: matchingTier.tierLabel,
            qualifyingSqm: Math.round(data.totalSqm * 100) / 100,
            discountType: matchingTier.discountType,
            discountValue: matchingTier.discountValue,
            discountAmount: Math.round(discountForGroup * 100) / 100,
            originalSubtotal: data.totalSubtotal,
            effectivePricePerSqm
          });
        }
      }
    });

    return {
      totalBulkDiscount: Math.round(totalBulkDiscount * 100) / 100,
      appliedRules
    };
  }

  // ==========================================
  // PROMOTIONAL DISCOUNT CODES (TENANT SCOPED)
  // ==========================================

  getDiscountCodes(tenantId?: string): DiscountCode[] {
    const tid = tenantId || this.currentTenantId;
    return this.get<DiscountCode[]>(this.getScopedKey('discount_codes', tid), INITIAL_DISCOUNT_CODES);
  }

  saveDiscountCode(code: DiscountCode, actorName: string = 'Super Admin', tenantId?: string): DiscountCode {
    const tid = tenantId || this.currentTenantId;
    const codes = this.getDiscountCodes(tid);
    const codeObj = {
      ...code,
      id: code.id || `dsc-${Date.now()}`
    };
    const index = codes.findIndex(c => c.id === codeObj.id);
    if (index >= 0) {
      codes[index] = codeObj;
    } else {
      codes.push(codeObj);
    }
    this.set(this.getScopedKey('discount_codes', tid), codes);
    this.addAuditLog(actorName, 'admin', 'SAVE_DISCOUNT_CODE', 'DiscountCode', codeObj.id, `Saved discount code "${codeObj.code}" (${codeObj.discountPercent}%).`, tid);
    return codeObj;
  }

  deleteDiscountCode(codeId: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const codes = this.getDiscountCodes(tid);
    const target = codes.find(c => c.id === codeId);
    if (!target) return false;
    const filtered = codes.filter(c => c.id !== codeId);
    this.set(this.getScopedKey('discount_codes', tid), filtered);
    this.addAuditLog(actorName, 'admin', 'DELETE_DISCOUNT_CODE', 'DiscountCode', codeId, `Deleted coupon code "${target.code}".`, tid);
    return true;
  }

  // ==========================================
  // ADMIN BROADCAST SYSTEM (NOTIFICATIONS & BANNERS)
  // ==========================================

  getBroadcasts(tenantId?: string): AdminBroadcast[] {
    const tid = tenantId || this.currentTenantId;
    const scopedKey = this.getScopedKey('admin_broadcasts', tid);
    const raw = this.get<AdminBroadcast[]>(scopedKey, INITIAL_BROADCASTS);
    const cleaned = (raw || []).filter(b => b.id !== 'bc-urgent-quarry-1' && !b.title?.toLowerCase().includes('urgent freight arrival'));
    if (raw && cleaned.length !== raw.length) {
      this.set(scopedKey, cleaned);
    }
    return cleaned;
  }

  getActiveBroadcasts(audience?: BroadcastAudience, tenantId?: string): AdminBroadcast[] {
    const all = this.getBroadcasts(tenantId);
    return all.filter(b => {
      if (!b.active) return false;
      if (b.scheduledExpiry && new Date(b.scheduledExpiry).getTime() < Date.now()) return false;
      if (audience && audience !== 'all' && b.audience !== 'all' && b.audience !== audience) {
        return false;
      }
      return true;
    });
  }

  getBroadcastById(id: string, tenantId?: string): AdminBroadcast | undefined {
    return this.getBroadcasts(tenantId).find(b => b.id === id);
  }

  saveBroadcast(
    broadcastData: Partial<AdminBroadcast> & { title: string; message: string }, 
    actorName: string = 'Super Admin', 
    tenantId?: string
  ): AdminBroadcast {
    const tid = tenantId || this.currentTenantId;
    const broadcasts = this.getBroadcasts(tid);
    const now = new Date().toISOString();

    let saved: AdminBroadcast;
    const existingIndex = broadcastData.id ? broadcasts.findIndex(b => b.id === broadcastData.id) : -1;

    if (existingIndex >= 0) {
      const existing = broadcasts[existingIndex];
      if (existing.isLocked && !(broadcastData as any).bypassLock) {
        throw new Error('This broadcast is locked. Administrator authentication is required to edit.');
      }
      saved = {
        ...existing,
        ...broadcastData,
        tenantId: tid,
        updatedAt: now
      };
      broadcasts[existingIndex] = saved;
      this.addAuditLog(
        actorName,
        'admin',
        'UPDATE_ADMIN_BROADCAST',
        'AdminBroadcast',
        saved.id,
        `Updated broadcast announcement "${saved.title}" (Audience: ${saved.audience}, Urgency: ${saved.urgency}).`,
        tid
      );
    } else {
      saved = {
        id: broadcastData.id || `bc-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
        tenantId: tid,
        title: broadcastData.title,
        message: broadcastData.message,
        audience: broadcastData.audience || 'all',
        urgency: broadcastData.urgency || 'info',
        placement: broadcastData.placement || 'top_banner',
        actionLabel: broadcastData.actionLabel,
        actionUrl: broadcastData.actionUrl,
        active: broadcastData.active ?? true,
        isLocked: broadcastData.isLocked ?? false,
        lockedBy: broadcastData.isLocked ? (broadcastData.lockedBy || actorName) : undefined,
        lockedAt: broadcastData.isLocked ? now : undefined,
        createdBy: actorName,
        createdAt: now,
        updatedAt: now,
        dismissible: broadcastData.isLocked ? false : (broadcastData.dismissible ?? true),
        soundAlert: broadcastData.soundAlert ?? (broadcastData.urgency === 'critical'),
        dismissedBy: []
      };
      broadcasts.unshift(saved);
      this.addAuditLog(
        actorName,
        'admin',
        'CREATE_ADMIN_BROADCAST',
        'AdminBroadcast',
        saved.id,
        `Published new broadcast announcement "${saved.title}" to ${saved.audience}.`,
        tid
      );
    }

    this.set(this.getScopedKey('admin_broadcasts', tid), broadcasts);

    // Sync to backend API if running
    try {
      fetch('/api/broadcasts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...saved, bypassLock: true })
      }).catch(() => {});
    } catch {}

    window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: { broadcast: saved, tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return saved;
  }

  toggleBroadcastLock(id: string, isLocked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const broadcasts = this.getBroadcasts(tid);
    const target = broadcasts.find(b => b.id === id);
    if (!target) return false;

    target.isLocked = isLocked;
    target.lockedBy = isLocked ? actorName : undefined;
    target.lockedAt = isLocked ? new Date().toISOString() : undefined;
    if (isLocked) {
      target.dismissible = false; // Locked broadcasts cannot be dismissed
    }
    target.updatedAt = new Date().toISOString();

    this.set(this.getScopedKey('admin_broadcasts', tid), broadcasts);
    this.addAuditLog(
      actorName,
      'admin',
      isLocked ? 'LOCK_ADMIN_BROADCAST' : 'UNLOCK_ADMIN_BROADCAST',
      'AdminBroadcast',
      id,
      `${isLocked ? 'Locked' : 'Unlocked'} broadcast announcement "${target.title}".`,
      tid
    );

    try {
      fetch(`/api/broadcasts/${id}/lock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isLocked, actorName })
      }).catch(() => {});
    } catch {}

    window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: { broadcast: target, tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return isLocked;
  }

  toggleBroadcastActive(id: string, active: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const broadcasts = this.getBroadcasts(tid);
    const target = broadcasts.find(b => b.id === id);
    if (!target) return false;

    if (target.isLocked && !active) {
      throw new Error('This broadcast is locked. Please unlock it with administrator authorization before deactivating.');
    }

    target.active = active;
    target.updatedAt = new Date().toISOString();

    this.set(this.getScopedKey('admin_broadcasts', tid), broadcasts);
    this.addAuditLog(
      actorName,
      'admin',
      active ? 'ACTIVATE_ADMIN_BROADCAST' : 'DEACTIVATE_ADMIN_BROADCAST',
      'AdminBroadcast',
      id,
      `${active ? 'Activated' : 'Deactivated'} broadcast announcement "${target.title}".`,
      tid
    );

    try {
      fetch('/api/broadcasts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...target, bypassLock: true })
      }).catch(() => {});
    } catch {}

    window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: { broadcast: target, tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return active;
  }

  deleteBroadcast(id: string, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const broadcasts = this.getBroadcasts(tid);
    const target = broadcasts.find(b => b.id === id);
    if (!target) return false;

    if (target.isLocked) {
      throw new Error('This broadcast is locked. Unlock with administrator credentials before deleting.');
    }

    const filtered = broadcasts.filter(b => b.id !== id);
    this.set(this.getScopedKey('admin_broadcasts', tid), filtered);

    this.addAuditLog(
      actorName,
      'admin',
      'DELETE_ADMIN_BROADCAST',
      'AdminBroadcast',
      id,
      `Deleted broadcast announcement "${target.title}".`,
      tid
    );

    try {
      fetch(`/api/broadcasts/${id}`, {
        method: 'DELETE'
      }).catch(() => {});
    } catch {}

    window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: { deletedId: id, tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return true;
  }

  dismissBroadcast(id: string, userIdentifier: string = 'guest', tenantId?: string): void {
    const tid = tenantId || this.currentTenantId;
    const broadcasts = this.getBroadcasts(tid);
    const target = broadcasts.find(b => b.id === id);
    if (!target || target.isLocked) return;

    if (!target.dismissedBy) target.dismissedBy = [];
    if (!target.dismissedBy.includes(userIdentifier)) {
      target.dismissedBy.push(userIdentifier);
      this.set(this.getScopedKey('admin_broadcasts', tid), broadcasts);
      window.dispatchEvent(new CustomEvent('atelier_broadcast_updated', { detail: { broadcast: target, tenantId: tid } }));
    }
  }

  // ==========================================
  // MASTER SYSTEM RESET & ZEROING CONTROLS
  // ==========================================

  getMasterResetLock(tenantId?: string): { isLocked: boolean; lockedBy?: string; lockedAt?: string } {
    const tid = tenantId || this.currentTenantId;
    return this.get(this.getScopedKey('master_reset_lock', tid), {
      isLocked: true, // Default to locked for safety
      lockedBy: 'System Security Protocol',
      lockedAt: new Date().toISOString()
    });
  }

  toggleMasterResetLock(locked: boolean, actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const lockObj = {
      isLocked: locked,
      lockedBy: actorName,
      lockedAt: new Date().toISOString()
    };
    this.set(this.getScopedKey('master_reset_lock', tid), lockObj);
    this.addAuditLog(
      actorName,
      'super-admin',
      locked ? 'LOCK_MASTER_RESET' : 'UNLOCK_MASTER_RESET',
      'SystemSecurity',
      tid,
      `${locked ? 'Locked' : 'Unlocked'} administrative master zero reset controls.`,
      tid
    );
    window.dispatchEvent(new CustomEvent('master_reset_lock_changed', { detail: lockObj }));
    return locked;
  }

  isDashboardZeroed(tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    return localStorage.getItem(this.getScopedKey('dashboard_zeroed', tid)) === 'true';
  }

  isProductsZeroed(tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    return localStorage.getItem(this.getScopedKey('products_zeroed', tid)) === 'true';
  }

  isRevenuesZeroed(tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    return localStorage.getItem(this.getScopedKey('revenues_zeroed', tid)) === 'true';
  }

  deleteAllProducts(actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const lock = this.getMasterResetLock(tid);
    if (lock.isLocked) {
      throw new Error('Master Reset controls are currently locked. Please unlock using administrator authentication before deleting products.');
    }

    const scopedKey = this.getScopedKey('products', tid);
    this.set(scopedKey, []);
    localStorage.setItem(this.getScopedKey('products_zeroed', tid), 'true');
    if (tid === 'atelier-surfaces') {
      localStorage.setItem(STORAGE_KEYS.LEGACY_PRODUCTS, JSON.stringify([]));
    }

    this.addAuditLog(
      actorName,
      'super-admin',
      'DELETE_ALL_PRODUCTS',
      'Catalog',
      tid,
      'Admin executed master wipe: deleted all product specimens from catalog, reducing inventory to 0.',
      tid
    );

    // Notify components
    window.dispatchEvent(new CustomEvent('atelier_products_updated', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('pos_inventory_synced', { detail: { newStock: 0 } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return true;
  }

  deleteAllRevenues(actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const lock = this.getMasterResetLock(tid);
    if (lock.isLocked) {
      throw new Error('Master Reset controls are currently locked. Please unlock using administrator authentication before zeroing revenue.');
    }

    const ordersKey = this.getScopedKey('orders', tid);
    const posKey = this.getScopedKey('pos_transactions', tid);
    this.set(ordersKey, []);
    this.set(posKey, []);
    localStorage.setItem(this.getScopedKey('orders_zeroed', tid), 'true');
    localStorage.setItem(this.getScopedKey('pos_zeroed', tid), 'true');
    localStorage.setItem(this.getScopedKey('revenues_zeroed', tid), 'true');
    if (tid === 'atelier-surfaces') {
      localStorage.setItem(STORAGE_KEYS.LEGACY_ORDERS, JSON.stringify([]));
    }

    this.addAuditLog(
      actorName,
      'super-admin',
      'DELETE_ALL_REVENUES',
      'Financials',
      tid,
      'Admin executed master revenue wipe: cleared all customer orders and showroom POS transactions, sending dashboard revenue to GH₵0.00.',
      tid
    );

    // Broadcast
    window.dispatchEvent(new CustomEvent('pos_sale_broadcast', { detail: { items: [], total: 0 } }));
    window.dispatchEvent(new CustomEvent('pos_price_synced'));
    window.dispatchEvent(new CustomEvent('atelier_revenue_reset', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return true;
  }

  restartDashboardToZero(actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    const lock = this.getMasterResetLock(tid);
    if (lock.isLocked) {
      throw new Error('Master Reset controls are currently locked. Please unlock using administrator authentication before restarting the dashboard to zero.');
    }

    // 1. Wipe products
    const productsKey = this.getScopedKey('products', tid);
    this.set(productsKey, []);
    localStorage.setItem(this.getScopedKey('products_zeroed', tid), 'true');
    if (tid === 'atelier-surfaces') {
      localStorage.setItem(STORAGE_KEYS.LEGACY_PRODUCTS, JSON.stringify([]));
    }

    // 2. Wipe orders & POS transactions
    const ordersKey = this.getScopedKey('orders', tid);
    const posKey = this.getScopedKey('pos_transactions', tid);
    this.set(ordersKey, []);
    this.set(posKey, []);
    localStorage.setItem(this.getScopedKey('orders_zeroed', tid), 'true');
    localStorage.setItem(this.getScopedKey('pos_zeroed', tid), 'true');
    localStorage.setItem(this.getScopedKey('revenues_zeroed', tid), 'true');
    if (tid === 'atelier-surfaces') {
      localStorage.setItem(STORAGE_KEYS.LEGACY_ORDERS, JSON.stringify([]));
    }

    // 3. Wipe stock adjustments
    const stockAdjKey = this.getScopedKey('stock_adjustments', tid);
    this.set(stockAdjKey, []);

    // 4. Mark dashboard zeroed
    localStorage.setItem(this.getScopedKey('dashboard_zeroed', tid), 'true');

    this.addAuditLog(
      actorName,
      'super-admin',
      'RESTART_DASHBOARD_TO_ZERO',
      'EnterpriseDashboard',
      tid,
      'Executed full system dashboard restart: all catalog products, customer orders, and verified revenue set to zero.',
      tid
    );

    // Global broadcast
    window.dispatchEvent(new CustomEvent('atelier_dashboard_reset', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('atelier_products_updated', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('pos_inventory_synced', { detail: { newStock: 0 } }));
    window.dispatchEvent(new CustomEvent('pos_sale_broadcast', { detail: { items: [], total: 0 } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return true;
  }

  restoreDemoData(actorName: string = 'Super Admin', tenantId?: string): boolean {
    const tid = tenantId || this.currentTenantId;
    localStorage.removeItem(this.getScopedKey('products_zeroed', tid));
    localStorage.removeItem(this.getScopedKey('orders_zeroed', tid));
    localStorage.removeItem(this.getScopedKey('pos_zeroed', tid));
    localStorage.removeItem(this.getScopedKey('revenues_zeroed', tid));
    localStorage.removeItem(this.getScopedKey('dashboard_zeroed', tid));

    // Reset to tenant catalogs
    const scopedKey = this.getScopedKey('products', tid);
    if (tid === 'verona-stone') {
      this.set(scopedKey, VERONA_STONE_PRODUCTS);
    } else if (tid === 'nordic-ceramic') {
      this.set(scopedKey, NORDIC_CERAMIC_PRODUCTS);
    } else {
      this.set(scopedKey, INITIAL_PRODUCTS);
      if (tid === 'atelier-surfaces') {
        localStorage.setItem(STORAGE_KEYS.LEGACY_PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
      }
    }

    const ordersKey = this.getScopedKey('orders', tid);
    this.set(ordersKey, INITIAL_ORDERS);
    if (tid === 'atelier-surfaces') {
      localStorage.setItem(STORAGE_KEYS.LEGACY_ORDERS, JSON.stringify(INITIAL_ORDERS));
    }

    const posKey = this.getScopedKey('pos_transactions', tid);
    localStorage.removeItem(posKey);

    this.addAuditLog(
      actorName,
      'super-admin',
      'RESTORE_DEMO_DATA',
      'EnterpriseDashboard',
      tid,
      'Restored factory catalog specimens and demo transaction records.',
      tid
    );

    window.dispatchEvent(new CustomEvent('atelier_dashboard_reset', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('atelier_products_updated', { detail: { tenantId: tid } }));
    window.dispatchEvent(new CustomEvent('storage'));
    return true;
  }

  // Reset to initial demo data
  resetAllData(): void {
    localStorage.clear();
    this.set(STORAGE_KEYS.COMPANIES_REGISTRY, INITIAL_COMPANIES);
    this.setActiveTenantId('atelier-surfaces');
  }
}

function newOrderTotalString(total: number, currency: string) {
  const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'GBP' ? '£' : 'GH₵';
  return `${symbol}${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export const storeService = new StoreService();
