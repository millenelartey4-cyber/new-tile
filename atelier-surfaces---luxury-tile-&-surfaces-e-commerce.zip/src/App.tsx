import { RouterProvider, useRouter } from './router/Router';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { CartWishlistProvider } from './context/CartWishlistContext';

// Common Components
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { CartDrawer } from './components/cart/CartDrawer';
import { ArchitecturalChatbot } from './components/chat/ArchitecturalChatbot';

// Storefront Pages
import { HomePage } from './pages/storefront/HomePage';
import { ShopPage } from './pages/storefront/ShopPage';
import { ProductDetailPage } from './pages/storefront/ProductDetailPage';
import { WishlistPage } from './pages/storefront/WishlistPage';
import { CartPage } from './pages/storefront/CartPage';
import { CheckoutPage } from './pages/storefront/CheckoutPage';
import { OrderConfirmationPage } from './pages/storefront/OrderConfirmationPage';
import { CustomerAccountPage } from './pages/storefront/CustomerAccountPage';
import { 
  AboutPage, 
  ContactPage, 
  ShippingReturnsPage, 
  TermsPage, 
  PrivacyPage 
} from './pages/storefront/StaticPages';
import { InstallAppPage } from './pages/storefront/InstallAppPage';
import { VideoConsultationPage } from './pages/storefront/VideoConsultationPage';
import { LoginPage } from './pages/auth/LoginPage';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { AdminBroadcastBanner } from './components/common/AdminBroadcastBanner';
import { FloatingVideoCallPill } from './components/video/FloatingVideoCallPill';
import { VideoCallProvider } from './context/VideoCallContext';

// Administration Pages
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminProductsPage } from './pages/admin/AdminProductsPage';
import { AdminProductEditPage } from './pages/admin/AdminProductEditPage';
import { AdminCategoriesPage } from './pages/admin/AdminCategoriesPage';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage';
import { AdminOrdersPage } from './pages/admin/AdminOrdersPage';
import { AdminOrderDetailPage } from './pages/admin/AdminOrderDetailPage';
import { AdminCustomersPage } from './pages/admin/AdminCustomersPage';
import { AdminDiscountsPage } from './pages/admin/AdminDiscountsPage';
import { AdminAnalyticsPage } from './pages/admin/AdminAnalyticsPage';
import { useEffect } from 'react';
import { AdminReportsPage } from './pages/admin/AdminReportsPage';
import { AdminThemeManagementPage } from './pages/admin/AdminThemeManagementPage';
import { AdminRolesPage } from './pages/admin/AdminRolesPage';
import { AdminStoreSettingsPage } from './pages/admin/AdminStoreSettingsPage';
import { AdminVideoConsultationsPage } from './pages/admin/AdminVideoConsultationsPage';
import { AdminAuditLogsPage } from './pages/admin/AdminAuditLogsPage';
import { AdminCompaniesPage } from './pages/admin/AdminCompaniesPage';
import { AdminPOSTerminalPage } from './pages/admin/AdminPOSTerminalPage';
import { AdminPOSSettingsPage } from './pages/admin/AdminPOSSettingsPage';
import { AdminBrightnessPage } from './pages/admin/AdminBrightnessPage';
import { AdminEcomSpinePage } from './pages/admin/AdminEcomSpinePage';
import { AdminLockScreen } from './components/admin/AdminLockScreen';
import { CompanyWorkspaceModal } from './components/common/CompanyWorkspaceModal';
import { CompanyProvider, useCompany } from './context/CompanyContext';
import { useAuth } from './context/AuthContext';

function AppContent() {
  const { currentPath, params } = useRouter();
  const { isAdminConsoleUnlocked } = useAuth();
  const { activeCompany } = useCompany();

  // Sync document title to active company branding
  useEffect(() => {
    if (activeCompany?.name) {
      document.title = `${activeCompany.name} - Luxury Tile & Surfaces E-Commerce`;
    }
  }, [activeCompany?.name]);

  const isAdminRoute = currentPath.startsWith('/admin');

  // Hard Gate: If any admin URL is requested while locked, render the Admin Security Lock Screen
  if (isAdminRoute && !isAdminConsoleUnlocked) {
    return <AdminLockScreen targetPath={currentPath} />;
  }

  // Match Route
  const renderRoute = () => {
    // Admin Routes
    if (currentPath === '/admin' || currentPath === '/admin/dashboard') {
      return <AdminDashboardPage />;
    }
    if (currentPath === '/admin/products') {
      return <AdminProductsPage />;
    }
    if (currentPath === '/admin/products/new') {
      return <AdminProductEditPage />;
    }
    if (currentPath.startsWith('/admin/products/') && currentPath.endsWith('/edit')) {
      return <AdminProductEditPage productId={params.id} />;
    }
    if (currentPath === '/admin/categories') {
      return <AdminCategoriesPage />;
    }
    if (currentPath === '/admin/inventory') {
      return <AdminInventoryPage />;
    }
    if (currentPath === '/admin/orders') {
      return <AdminOrdersPage />;
    }
    if (currentPath.startsWith('/admin/orders/') && params.id) {
      return <AdminOrderDetailPage orderId={params.id} />;
    }
    if (currentPath === '/admin/customers') {
      return <AdminCustomersPage />;
    }
    if (currentPath === '/admin/discounts') {
      return <AdminDiscountsPage />;
    }
    if (currentPath === '/admin/analytics' || currentPath === '/admin/reports/analytics') {
      return <AdminAnalyticsPage />;
    }
    if (currentPath === '/admin/reports') {
      return <AdminReportsPage />;
    }
    if (currentPath === '/admin/users') {
      return <AdminRolesPage />;
    }
    if (currentPath === '/admin/settings/appearance' || currentPath === '/admin/themes') {
      return <AdminThemeManagementPage />;
    }
    if (
      currentPath === '/admin/settings/roles' || 
      currentPath === '/admin/settings/permissions' || 
      currentPath === '/admin/roles'
    ) {
      return <AdminRolesPage />;
    }
    if (currentPath === '/admin/settings/store' || currentPath === '/admin/settings') {
      return <AdminStoreSettingsPage />;
    }
    if (currentPath === '/admin/companies') {
      return <AdminCompaniesPage />;
    }
    if (currentPath === '/admin/audit-logs') {
      return <AdminAuditLogsPage />;
    }
    if (currentPath === '/admin/pos' || currentPath === '/pos') {
      return <AdminPOSTerminalPage />;
    }
    if (
      currentPath === '/admin/pos/settings' || 
      currentPath === '/admin/settings/pos' || 
      currentPath === '/pos/settings'
    ) {
      return <AdminPOSSettingsPage />;
    }
    if (
      currentPath === '/admin/brightness' || 
      currentPath === '/admin/settings/brightness' || 
      currentPath === '/admin/panels' ||
      currentPath === '/admin/settings/panels'
    ) {
      return <AdminBrightnessPage />;
    }
    if (
      currentPath === '/admin/ecomspine' || 
      currentPath === '/admin/storefleet' || 
      currentPath === '/admin/logistics' ||
      currentPath === '/admin/tracking'
    ) {
      return <AdminEcomSpinePage />;
    }
    if (
      currentPath === '/admin/video-consultation' || 
      currentPath === '/admin/video-consultations' || 
      currentPath === '/admin/consultations' ||
      currentPath === '/admin/video'
    ) {
      return <AdminVideoConsultationsPage />;
    }

    // Customer Front & Auth Routes
    if (currentPath === '/' || currentPath === '') {
      return <HomePage />;
    }
    if (currentPath === '/shop' || currentPath === '/search') {
      return <ShopPage />;
    }
    if (currentPath.startsWith('/category/') && params.slug) {
      return <ShopPage initialCategorySlug={params.slug} />;
    }
    if (currentPath.startsWith('/product/') && params.slug) {
      return <ProductDetailPage slug={params.slug} />;
    }
    if (currentPath === '/wishlist') {
      return <WishlistPage />;
    }
    if (currentPath === '/cart') {
      return <CartPage />;
    }
    if (currentPath === '/checkout') {
      return <CheckoutPage />;
    }
    if (currentPath.startsWith('/order-confirmation/') && params.orderId) {
      return <OrderConfirmationPage orderId={params.orderId} />;
    }
    if (currentPath.startsWith('/account/orders/') && params.orderId) {
      return <CustomerAccountPage orderIdParam={params.orderId} />;
    }
    if (currentPath === '/account' || currentPath === '/account/orders') {
      return <CustomerAccountPage />;
    }
    if (currentPath === '/about') {
      return <AboutPage />;
    }
    if (currentPath === '/contact') {
      return <ContactPage />;
    }
    if (currentPath === '/shipping-returns') {
      return <ShippingReturnsPage />;
    }
    if (currentPath === '/terms') {
      return <TermsPage />;
    }
    if (currentPath === '/privacy') {
      return <PrivacyPage />;
    }
    if (currentPath === '/install' || currentPath === '/download') {
      return <InstallAppPage />;
    }
    if (
      currentPath === '/video-consultation' || 
      currentPath === '/consultation' || 
      currentPath === '/video-call' ||
      currentPath === '/video'
    ) {
      return <VideoConsultationPage />;
    }
    if (currentPath === '/login' || currentPath === '/register' || currentPath === '/forgot-password' || currentPath === '/admin/login') {
      return <LoginPage />;
    }

    // Default Fallback
    return <HomePage />;
  };

  return (
    <div className="min-h-screen bg-[var(--theme-bg)] flex flex-col font-sans transition-colors duration-200">
      {/* Universal In-App Admin Broadcast Alerts & Urgency Banners */}
      <AdminBroadcastBanner />

      {!isAdminRoute && <Header />}
      
      <main className="flex-1">
        {renderRoute()}
      </main>

      {!isAdminRoute && <Footer />}

      {/* Persistent slide-out cart drawer */}
      <CartDrawer />

      {/* Gemini AI Architectural Concierge & Autonomous Tile Shop Agent */}
      <ArchitecturalChatbot />

      {/* Multi-Company Workspace Switcher & Deployment Modal */}
      <CompanyWorkspaceModal />

      {/* Offline Connectivity Status Indicator */}
      <OfflineIndicator />

      {/* Persistent Floating Video Call PiP Pill when navigating storefront */}
      <FloatingVideoCallPill />
    </div>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <CompanyProvider>
        <ThemeProvider>
          <AuthProvider>
            <CartWishlistProvider>
              <VideoCallProvider>
                <AppContent />
              </VideoCallProvider>
            </CartWishlistProvider>
          </AuthProvider>
        </ThemeProvider>
      </CompanyProvider>
    </RouterProvider>
  );
}
