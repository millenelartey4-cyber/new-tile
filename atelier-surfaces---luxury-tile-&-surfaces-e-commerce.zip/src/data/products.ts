import { Category, Product } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'floor-tiles',
    name: 'Floor Tiles',
    slug: 'floor-tiles',
    description: 'High-traffic porcelain and stone floor tiles engineered for timeless architectural spaces.',
    imageUrl: '/assets/images/category_porcelain_floors_1792523066985.jpg',
    sortOrder: 1,
    active: true
  },
  {
    id: 'wall-tiles',
    name: 'Wall Tiles',
    slug: 'wall-tiles',
    description: 'Textural ceramic, relief panels, and large-format architectural wall surfaces.',
    imageUrl: '/assets/images/category_marble_slabs_1792523067297.jpg',
    sortOrder: 2,
    active: true
  },
  {
    id: 'porcelain-tiles',
    name: 'Porcelain Tiles',
    slug: 'porcelain-tiles',
    description: 'Ultra-dense, frost-proof vitrified porcelain with zero porosity and extreme durability.',
    imageUrl: '/assets/images/category_porcelain_floors_1792523066985.jpg',
    sortOrder: 3,
    active: true
  },
  {
    id: 'marble-look',
    name: 'Marble-Look Tiles',
    slug: 'marble-look',
    description: 'Masterfully replicated Italian Calacatta, Carrara, and Nero Marquina stone veins.',
    imageUrl: '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg',
    sortOrder: 4,
    active: true
  },
  {
    id: 'natural-stone',
    name: 'Natural Stone',
    slug: 'natural-stone',
    description: 'Quarried French limestone, Roman travertine, and split-face slate slabs.',
    imageUrl: '/assets/images/category_stone_bathroom_1792523067646.jpg',
    sortOrder: 5,
    active: true
  },
  {
    id: 'bathroom-tiles',
    name: 'Bathroom Tiles',
    slug: 'bathroom-tiles',
    description: 'Anti-slip wet-room surfaces, spa mosaics, and bookmatched shower feature walls.',
    imageUrl: '/assets/images/category_stone_bathroom_1792523067646.jpg',
    sortOrder: 6,
    active: true
  },
  {
    id: 'kitchen-tiles',
    name: 'Kitchen Tiles',
    slug: 'kitchen-tiles',
    description: 'Stain-resistant kitchen splashbacks, heat-proof countertops, and durable flooring.',
    imageUrl: '/assets/images/category_porcelain_floors_1792523066985.jpg',
    sortOrder: 7,
    active: true
  },
  {
    id: 'outdoor-tiles',
    name: 'Outdoor Tiles & Pavers',
    slug: 'outdoor-tiles',
    description: '20mm structural porcelain pavers, pool coping, and exterior patio slabs with R11 slip rating.',
    imageUrl: '/assets/images/category_stone_bathroom_1792523067646.jpg',
    sortOrder: 8,
    active: true
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // 1. Calacatta Statuario Imperiale
  {
    id: 'prod-calacatta-statuario',
    name: 'Calacatta Statuario Imperiale',
    slug: 'calacatta-statuario-imperiale',
    description: 'Our crown jewel architectural slab. Captured from rare Apuan Alpine quarries, Calacatta Statuario Imperiale features crystalline white backgrounds laced with bold, dramatic golden and smoke veins. Calibrated for continuous bookmatched layouts in penthouses, grand foyers, and master suites.',
    shortDescription: 'Apuan Alpine bookmatched porcelain slab with golden and smoky veining.',
    categoryId: 'marble-look',
    categoryName: 'Marble-Look Tiles',
    material: 'Porcelain',
    size: '120x240 cm',
    thickness: '9 mm',
    finish: 'Polished',
    applications: ['Floor', 'Wall', 'Interior', 'Bathroom', 'Commercial Foyers'],
    specifications: {
      waterAbsorption: '< 0.05% (Impervious)',
      slipResistance: 'R10 / PTV 36+',
      frostResistant: true,
      rectified: true,
      shadeVariation: 'V3 Moderate',
      origin: 'Sassuolo, Italy'
    },
    featured: true,
    bestSeller: true,
    newArrival: false,
    active: true,
    rating: 4.95,
    reviewCount: 38,
    createdAt: '2026-01-10T00:00:00Z',
    updatedAt: '2026-03-15T00:00:00Z',
    variants: [
      {
        id: 'var-calacatta-gold',
        colorName: 'Calacatta Gold',
        colorHex: '#D4AF37',
        sku: 'AS-CSI-GLD-120240',
        images: [
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 485,
        compareAtPrice: 540,
        stock: 320,
        lowStockThreshold: 45,
        unit: 'm²',
        boxCoverage: 2.88,
        active: true
      },
      {
        id: 'var-calacatta-pearl-white',
        colorName: 'Pearl White',
        colorHex: '#F8F8F6',
        sku: 'AS-CSI-PRL-120240',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 465,
        stock: 280,
        lowStockThreshold: 40,
        unit: 'm²',
        boxCoverage: 2.88,
        active: true
      },
      {
        id: 'var-calacatta-warm-ivory',
        colorName: 'Warm Ivory',
        colorHex: '#F3EFE6',
        sku: 'AS-CSI-IVR-120240',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 475,
        stock: 190,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 2.88,
        active: true
      },
      {
        id: 'var-calacatta-nero-vein',
        colorName: 'Charcoal & Gold Vein',
        colorHex: '#252525',
        sku: 'AS-CSI-CHR-120240',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 510,
        compareAtPrice: 580,
        stock: 140,
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 2.88,
        active: true
      }
    ]
  },

  // 2. Travertino Navona Architectural
  {
    id: 'prod-travertino-navona',
    name: 'Travertino Navona Cross-Cut',
    slug: 'travertino-navona-cross-cut',
    description: 'Inspired by the eternal stone of Rome. Travertino Navona reinterprets porous sedimentary travertine with ultra-realistic micro-veins and velvety soft honed surface texture. Ideal for tranquil spa bathrooms, open living pavilions, and Mediterranean terraces.',
    shortDescription: 'Timeless Roman cross-cut travertine with tactile honed finish.',
    categoryId: 'natural-stone',
    categoryName: 'Natural Stone',
    material: 'Travertine',
    size: '60x120 cm',
    thickness: '10 mm',
    finish: 'Honed',
    applications: ['Floor', 'Wall', 'Bathroom', 'Living Room', 'Wet Areas'],
    specifications: {
      waterAbsorption: '< 0.1%',
      slipResistance: 'R10 / PTV 40 (Dry/Wet)',
      frostResistant: true,
      rectified: true,
      shadeVariation: 'V2 Slight',
      origin: 'Tivoli, Italy'
    },
    featured: true,
    bestSeller: false,
    newArrival: true,
    active: true,
    rating: 4.88,
    reviewCount: 24,
    createdAt: '2026-01-20T00:00:00Z',
    updatedAt: '2026-03-10T00:00:00Z',
    variants: [
      {
        id: 'var-navona-classic-ivory',
        colorName: 'Classic Ivory',
        colorHex: '#EFE7DA',
        sku: 'AS-TNV-IVR-60120',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 360,
        compareAtPrice: 395,
        stock: 450,
        lowStockThreshold: 50,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      },
      {
        id: 'var-navona-walnut-warm',
        colorName: 'Walnut Warm Beige',
        colorHex: '#D8CCA3',
        sku: 'AS-TNV-WNT-60120',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 375,
        stock: 290,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      },
      {
        id: 'var-navona-silver-cloud',
        colorName: 'Silver Cloud Grey',
        colorHex: '#C5C6C2',
        sku: 'AS-TNV-SLV-60120',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 365,
        stock: 18, // Intentionally low to test low stock alerts!
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      }
    ]
  },

  // 3. Nero Marquina Velvet Sintered Slab
  {
    id: 'prod-nero-marquina-velvet',
    name: 'Nero Marquina Velvet Slab',
    slug: 'nero-marquina-velvet-slab',
    description: 'Deep midnight obsidian porcelain with crystalline white and gold lightning veins. The satin velvet honed finish gives a rich, tactile, glare-free aesthetic perfect for dramatic powder rooms, kitchen feature islands, and executive office walls.',
    shortDescription: 'Deep Basque black marble reinterpreted in low-maintenance porcelain.',
    categoryId: 'marble-look',
    categoryName: 'Marble-Look Tiles',
    material: 'Porcelain',
    size: '80x160 cm',
    thickness: '9 mm',
    finish: 'Matte',
    applications: ['Floor', 'Wall', 'Kitchen Splashbacks', 'Feature Wall', 'Commercial'],
    specifications: {
      waterAbsorption: '< 0.05%',
      slipResistance: 'R9',
      frostResistant: true,
      rectified: true,
      shadeVariation: 'V4 High',
      origin: 'Castellón, Spain'
    },
    featured: true,
    bestSeller: true,
    newArrival: false,
    active: true,
    rating: 4.92,
    reviewCount: 31,
    createdAt: '2026-02-01T00:00:00Z',
    updatedAt: '2026-03-20T00:00:00Z',
    variants: [
      {
        id: 'var-marquina-midnight-black',
        colorName: 'Midnight Obsidian',
        colorHex: '#18181A',
        sku: 'AS-NMV-BLK-80160',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 490,
        compareAtPrice: 550,
        stock: 160,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 2.56,
        active: true
      },
      {
        id: 'var-marquina-graphite-grey',
        colorName: 'Graphite Grey',
        colorHex: '#424245',
        sku: 'AS-NMV-GRY-80160',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 470,
        stock: 210,
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 2.56,
        active: true
      },
      {
        id: 'var-marquina-gold-lightning',
        colorName: 'Black with Gold Vein',
        colorHex: '#2E281F',
        sku: 'AS-NMV-GLD-80160',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 520,
        stock: 95,
        lowStockThreshold: 20,
        unit: 'm²',
        boxCoverage: 2.56,
        active: true
      }
    ]
  },

  // 4. Terrazzo Venezia Grand Flake
  {
    id: 'prod-terrazzo-venezia',
    name: 'Terrazzo Venezia Grand Flake',
    slug: 'terrazzo-venezia-grand-flake',
    description: 'Celebrated Venetian craftsmanship brought into the 21st century. Features hand-selected marble chips of Carrara, Verde Alpi, and Bardiglio embedded in a satin cementitious matrix. Unrivaled character for modern dining rooms, creative studios, and boutique retail.',
    shortDescription: 'Venetian terrazzo with embedded marble fragments and matte seal.',
    categoryId: 'floor-tiles',
    categoryName: 'Floor Tiles',
    material: 'Terrazzo',
    size: '80x80 cm',
    thickness: '10 mm',
    finish: 'Matte',
    applications: ['Floor', 'Interior', 'Kitchen', 'Commercial'],
    specifications: {
      waterAbsorption: '< 0.2%',
      slipResistance: 'R10 / PTV 38',
      frostResistant: true,
      rectified: true,
      shadeVariation: 'V2 Slight',
      origin: 'Veneto, Italy'
    },
    featured: false,
    bestSeller: true,
    newArrival: true,
    active: true,
    rating: 4.86,
    reviewCount: 19,
    createdAt: '2026-02-15T00:00:00Z',
    updatedAt: '2026-03-12T00:00:00Z',
    variants: [
      {
        id: 'var-terrazzo-carrara-white',
        colorName: 'Carrara Blanco',
        colorHex: '#EAE6E1',
        sku: 'AS-TVZ-WHT-8080',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_stone_bathroom_1792523067646.jpg'
        ],
        price: 340,
        stock: 310,
        lowStockThreshold: 40,
        unit: 'm²',
        boxCoverage: 1.28,
        active: true
      },
      {
        id: 'var-terrazzo-verde-sage',
        colorName: 'Verde Alpi Sage',
        colorHex: '#8C9A8E',
        sku: 'AS-TVZ-SGE-8080',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 360,
        compareAtPrice: 395,
        stock: 180,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 1.28,
        active: true
      },
      {
        id: 'var-terrazzo-rose-quartz',
        colorName: 'Blush Verona Rose',
        colorHex: '#D6B8B8',
        sku: 'AS-TVZ-RSE-8080',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/category_stone_bathroom_1792523067646.jpg'
        ],
        price: 355,
        stock: 140,
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 1.28,
        active: true
      },
      {
        id: 'var-terrazzo-nero-chips',
        colorName: 'Charcoal Midnight Matrix',
        colorHex: '#2C2C2E',
        sku: 'AS-TVZ-MID-8080',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 370,
        stock: 8, // Very low stock!
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 1.28,
        active: true
      }
    ]
  },

  // 5. Pietra di Vals Alpine Quartzite
  {
    id: 'prod-pietra-di-vals',
    name: 'Pietra di Vals Alpine Quartzite',
    slug: 'pietra-di-vals-alpine-quartzite',
    description: 'Renowned in Swiss architecture by Peter Zumthor. Characterized by parallel stratified quartz bands in silvery grey, graphite, and muted green. Engineered with micro-grip textures, making it the supreme surface for luxury poolside pavilions, master wet rooms, and minimalist villas.',
    shortDescription: 'Swiss alpine quartzite strata with natural mineral mica shimmer.',
    categoryId: 'outdoor-tiles',
    categoryName: 'Outdoor Tiles & Pavers',
    material: 'Natural Stone',
    size: '60x120 cm',
    thickness: '20 mm',
    finish: 'Textured',
    applications: ['Floor', 'Outdoor', 'Pool Deck', 'Bathroom', 'Heavy Traffic'],
    specifications: {
      waterAbsorption: '< 0.05%',
      slipResistance: 'R11 / PTV 52 (Wet)',
      frostResistant: true,
      rectified: true,
      shadeVariation: 'V3 Moderate',
      origin: 'Graubünden, Switzerland'
    },
    featured: true,
    bestSeller: false,
    newArrival: false,
    active: true,
    rating: 4.97,
    reviewCount: 42,
    createdAt: '2026-01-05T00:00:00Z',
    updatedAt: '2026-03-18T00:00:00Z',
    variants: [
      {
        id: 'var-vals-alpine-grey',
        colorName: 'Alpine Quartz Grey',
        colorHex: '#7C8282',
        sku: 'AS-PDV-GRY-60120-20',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 520,
        compareAtPrice: 590,
        stock: 240,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      },
      {
        id: 'var-vals-charcoal-vein',
        colorName: 'Deep Graphite Slate',
        colorHex: '#353A3B',
        sku: 'AS-PDV-CHR-60120-20',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 540,
        stock: 175,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      },
      {
        id: 'var-vals-sand-mineral',
        colorName: 'Warm Sandstone Mica',
        colorHex: '#A39988',
        sku: 'AS-PDV-SND-60120-20',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_stone_bathroom_1792523067646.jpg'
        ],
        price: 530,
        stock: 110,
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      }
    ]
  },

  // 6. Cotto Zellige Artisan Wall Glaze
  {
    id: 'prod-cotto-zellige',
    name: 'Cotto Zellige Artisan Wall Glaze',
    slug: 'cotto-zellige-artisan-wall-glaze',
    description: 'Chiseled by master artisans with delicate irregular edges and undulating glossy enamel surfaces. Each individual tile reflects ambient sunlight differently, creating breathtaking shimmering backsplashes and feature bathroom walls with warmth and soul.',
    shortDescription: 'Handcrafted terracotta tile with vitreous organic enamel glaze.',
    categoryId: 'wall-tiles',
    categoryName: 'Wall Tiles',
    material: 'Ceramic',
    size: '10x10 cm',
    thickness: '12 mm',
    finish: 'Polished',
    applications: ['Wall', 'Kitchen Splashbacks', 'Bathroom Walls', 'Shower Enclosures'],
    specifications: {
      waterAbsorption: '< 0.5%',
      slipResistance: 'N/A (Wall only)',
      frostResistant: false,
      rectified: false,
      shadeVariation: 'V4 High',
      origin: 'Fes, Morocco'
    },
    featured: false,
    bestSeller: true,
    newArrival: false,
    active: true,
    rating: 4.91,
    reviewCount: 27,
    createdAt: '2026-02-10T00:00:00Z',
    updatedAt: '2026-03-05T00:00:00Z',
    variants: [
      {
        id: 'var-zellige-snow-white',
        colorName: 'Alabaster Glaze White',
        colorHex: '#F6F6F2',
        sku: 'AS-CZL-WHT-1010',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 280,
        stock: 420,
        lowStockThreshold: 50,
        unit: 'm²',
        boxCoverage: 0.5,
        active: true
      },
      {
        id: 'var-zellige-emerald-forest',
        colorName: 'Emerald Jade Glaze',
        colorHex: '#1B4734',
        sku: 'AS-CZL-EMR-1010',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 310,
        compareAtPrice: 350,
        stock: 260,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 0.5,
        active: true
      },
      {
        id: 'var-zellige-terracotta-raw',
        colorName: 'Tuscan Raw Terracotta',
        colorHex: '#B25A38',
        sku: 'AS-CZL-TER-1010',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 295,
        stock: 195,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 0.5,
        active: true
      },
      {
        id: 'var-zellige-ocean-azure',
        colorName: 'Aegean Ocean Blue',
        colorHex: '#215A80',
        sku: 'AS-CZL-BLU-1010',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 315,
        stock: 130,
        lowStockThreshold: 25,
        unit: 'm²',
        boxCoverage: 0.5,
        active: true
      }
    ]
  }
];

export const INITIAL_STORE_SETTINGS = {
  brandName: 'ATELIER SURFACES',
  tagline: 'Architectural Stone & Luxury Surfaces',
  activeThemeId: 'ivory-gold-ateliers',
  defaultThemeId: 'ivory-gold-ateliers',
  currency: 'GHS' as const,
  currencySymbol: 'GH₵',
  taxRatePercent: 15,
  freeDeliveryThreshold: 5000,
  standardDeliveryCost: 250,
  expressFreightCost: 550,
  announcementText: 'Complimentary Architectural Consultation & Tile Samples for Trade Orders Over GH₵5,000',
  announcementEnabled: true,
  contactEmail: 'concierge@ateliersurfaces.com',
  contactPhone: '0542443125/0596334488',
  whatsAppNumber: '0542443125/0596334488',
  whatsAppPrefill: 'Hello Atelier Surfaces, I would like to inquire with the Direct Trade WhatsApp Desk regarding tile & marble stock.',
  whatsAppLocked: false,
  showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
  ghanaPostGps: 'GA-110-3849',
  contactLocked: false,
  contactLastSavedBy: 'Super Admin',
  videoConsultationLocked: false,
  videoLockMessage: 'Video consultations are currently locked for a private architectural masterclass. Please contact the concierge or schedule below.',
  videoConsultantName: 'Kwame Mensah',
  videoConsultantTitle: 'Lead Architectural Consultant',
  videoConsultantLocation: '14 Independence Avenue, Ridge West, Accra',
  videoConsultantAvailable: true,
  videoConsultantHours: 'Mon–Sat: 8:00 AM – 6:00 PM GMT',
  videoResolution: '1080p' as const,
  allowGuestVideoCalls: true,
  default3DSpecimenPreset: 'Calacatta Statuario Imperiale',
  panelBrightness: {
    sidebarBrightness: 100,
    sidebarContrast: 100,
    headerBrightness: 100,
    headerContrast: 100,
    workspaceBrightness: 100,
    workspaceContrast: 100,
    cardsBrightness: 100,
    cardsContrast: 100,
    posBrightness: 100,
    posContrast: 100,
    storefrontHeaderBrightness: 100,
    storefrontHeaderContrast: 100,
    storefrontHeroBrightness: 100,
    storefrontHeroContrast: 100,
    storefrontCatalogBrightness: 100,
    storefrontCatalogContrast: 100,
    storefrontSpecimenBrightness: 100,
    storefrontSpecimenContrast: 100,
    storefrontFooterBrightness: 100,
    storefrontFooterContrast: 100,
    isLocked: false
  },
  posSettings: {
    registerName: 'Ridge West Showroom Terminal #1',
    registerCode: 'RW-POS-01',
    defaultCashierName: 'Kwame Mensah',
    walkInCustomerName: 'Showroom Walk-in Client',
    taxCalculationMode: 'inclusive' as const,
    taxRatePercent: 15,
    allowNegativeInventory: false,
    autoDeductInventory: true,
    maxCashierDiscountPercent: 15,
    requireSupervisorDiscountPin: true,
    supervisorPin: '9814',
    quickDiscountPresets: [5, 10, 15, 20],
    barcodeContinuousScan: true,
    cashDrawerAutoKick: true,
    playNotificationSound: true,
    receiptPrinterWidth: '80mm' as const,
    receiptShowLogo: true,
    receiptShowBarcode: true,
    receiptShowGps: true,
    receiptHeaderNote: 'ATELIER SURFACES · RIDGE WEST FLAGSHIP',
    receiptFooterNote: 'Thank you for choosing Atelier Surfaces. Goods inspected & verified at Ridge West Showroom.',
    enabledPaymentMethods: {
      cash: true,
      card: true,
      mobileMoney: true,
      bankTransfer: true,
      cheque: false,
      split: true
    },
    momoMerchantNumber: '0542443125/0596334488',
    whatsAppNumber: '0542443125/0596334488',
    showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
    ghanaPostGps: 'GA-110-3849',
    contactPhone: '0542443125/0596334488',
    contactEmail: 'concierge@ateliersurfaces.com',
    offlineModeEnabled: true,
    quickCashDenominations: [10, 20, 50, 100, 200],
    isLocked: false
  }
};
