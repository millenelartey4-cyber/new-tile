import { ModuleDefinition, ModuleKey, UserRole, ActionType } from '../types';

export const SYSTEM_MODULES: ModuleDefinition[] = [
  // Core
  {
    key: 'dashboard',
    label: 'Dashboard Overview & Analytics',
    category: 'Core',
    supportedActions: ['view', 'export']
  },
  {
    key: 'reports',
    label: 'Sales & AI Business Reports',
    category: 'Core',
    supportedActions: ['view', 'export']
  },
  {
    key: 'audit_logs',
    label: 'System Audit Logs',
    category: 'Core',
    supportedActions: ['view', 'export']
  },

  // Catalog & Stock
  {
    key: 'products',
    label: 'Product Management',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'edit', 'delete', 'export']
  },
  {
    key: 'product_variations',
    label: 'Product Color Variations & Galleries',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'categories',
    label: 'Tile Categories & Collections',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'inventory',
    label: 'Inventory Levels & Reorder Points',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'edit', 'export']
  },
  {
    key: 'stock_adjustments',
    label: 'Stock Adjustments & Loss Audits',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'approve', 'export']
  },
  {
    key: 'suppliers',
    label: 'Quarry & Factory Suppliers',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'purchases',
    label: 'Purchase Orders & Inbound Freight',
    category: 'Catalog & Stock',
    supportedActions: ['view', 'create', 'edit', 'approve']
  },

  // Sales & Fulfillment
  {
    key: 'orders',
    label: 'Order Processing & Tracking',
    category: 'Sales & Fulfillment',
    supportedActions: ['view', 'create', 'edit', 'approve', 'export']
  },
  {
    key: 'customers',
    label: 'Customer Accounts & Trade Profiles',
    category: 'Sales & Fulfillment',
    supportedActions: ['view', 'edit', 'delete', 'export']
  },
  {
    key: 'discounts',
    label: 'Architect & Contractor Discounts',
    category: 'Sales & Fulfillment',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'payments',
    label: 'Payment Verifications & Receipts',
    category: 'Sales & Fulfillment',
    supportedActions: ['view', 'approve', 'export']
  },
  {
    key: 'refunds',
    label: 'Refunds & Credit Notes',
    category: 'Sales & Fulfillment',
    supportedActions: ['view', 'create', 'approve']
  },

  // Administration
  {
    key: 'store_settings',
    label: 'Store & Regional Settings (Ghana GHS)',
    category: 'Administration',
    supportedActions: ['view', 'manage_settings']
  },
  {
    key: 'theme_management',
    label: 'Theme Customizer & 64+ Palettes',
    category: 'Administration',
    supportedActions: ['view', 'edit', 'publish', 'manage_settings']
  },
  {
    key: 'user_management',
    label: 'Staff & Administrator Users',
    category: 'Administration',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'role_management',
    label: 'Role Definitions & Hierarchies',
    category: 'Administration',
    supportedActions: ['view', 'create', 'edit', 'delete']
  },
  {
    key: 'permission_management',
    label: 'Visual Permission Matrix',
    category: 'Administration',
    supportedActions: ['view', 'edit', 'manage_settings']
  }
];

// Helper to create all permissions
function createAllPermissions(): Record<ModuleKey, ActionType[]> {
  const perm: Partial<Record<ModuleKey, ActionType[]>> = {};
  SYSTEM_MODULES.forEach(mod => {
    perm[mod.key] = [...mod.supportedActions];
  });
  return perm as Record<ModuleKey, ActionType[]>;
}

export const INITIAL_ROLES: UserRole[] = [
  // 1. Super Admin
  {
    id: 'super-admin',
    name: 'Super Admin',
    description: 'Unrestricted enterprise administrative access across all 20 modules, security rules, and recovery keys.',
    builtIn: true,
    permissions: createAllPermissions(),
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  },

  // 2. Manager
  {
    id: 'manager',
    name: 'Store Manager',
    description: 'Operational leadership over catalog, inventory, orders, customer relations, and business analytics.',
    builtIn: true,
    permissions: {
      dashboard: ['view', 'export'],
      reports: ['view', 'export'],
      audit_logs: ['view'],
      products: ['view', 'create', 'edit', 'export'],
      product_variations: ['view', 'create', 'edit'],
      categories: ['view', 'create', 'edit'],
      inventory: ['view', 'edit', 'export'],
      stock_adjustments: ['view', 'create', 'approve'],
      suppliers: ['view', 'create', 'edit'],
      purchases: ['view', 'create', 'edit', 'approve'],
      orders: ['view', 'create', 'edit', 'approve', 'export'],
      customers: ['view', 'edit', 'export'],
      discounts: ['view', 'create', 'edit'],
      payments: ['view', 'approve', 'export'],
      refunds: ['view', 'create'],
      store_settings: ['view'],
      theme_management: ['view'],
      user_management: ['view'],
      role_management: ['view'],
      permission_management: ['view']
    },
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  },

  // 3. Inventory Staff
  {
    id: 'inventory-staff',
    name: 'Inventory Staff',
    description: 'Warehouse and fulfillment specialist focused on stock levels, variants, shipments, and receiving.',
    builtIn: true,
    permissions: {
      dashboard: ['view'],
      reports: ['view'],
      audit_logs: [],
      products: ['view'],
      product_variations: ['view', 'edit'],
      categories: ['view'],
      inventory: ['view', 'edit', 'export'],
      stock_adjustments: ['view', 'create'],
      suppliers: ['view'],
      purchases: ['view', 'create'],
      orders: ['view', 'edit'],
      customers: [],
      discounts: [],
      payments: [],
      refunds: [],
      store_settings: [],
      theme_management: [],
      user_management: [],
      role_management: [],
      permission_management: []
    },
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  },

  // 4. Sales Staff
  {
    id: 'sales-staff',
    name: 'Sales Staff',
    description: 'Showroom consultant assisting residential and trade clients with quotes, orders, and samples.',
    builtIn: true,
    permissions: {
      dashboard: ['view'],
      reports: ['view'],
      audit_logs: [],
      products: ['view'],
      product_variations: ['view'],
      categories: ['view'],
      inventory: ['view'],
      stock_adjustments: [],
      suppliers: [],
      purchases: [],
      orders: ['view', 'create', 'edit', 'export'],
      customers: ['view', 'edit'],
      discounts: ['view'],
      payments: ['view'],
      refunds: ['view', 'create'],
      store_settings: [],
      theme_management: [],
      user_management: [],
      role_management: [],
      permission_management: []
    },
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  },

  // 5. Customer Support
  {
    id: 'customer-support',
    name: 'Customer Support',
    description: 'Client success specialist handling order tracking, inquiries, delivery scheduling, and returns.',
    builtIn: true,
    permissions: {
      dashboard: ['view'],
      reports: [],
      audit_logs: [],
      products: ['view'],
      product_variations: ['view'],
      categories: ['view'],
      inventory: ['view'],
      stock_adjustments: [],
      suppliers: [],
      purchases: [],
      orders: ['view', 'edit'],
      customers: ['view'],
      discounts: [],
      payments: ['view'],
      refunds: ['view'],
      store_settings: [],
      theme_management: [],
      user_management: [],
      role_management: [],
      permission_management: []
    },
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  },

  // 6. Customer
  {
    id: 'customer',
    name: 'Customer / Trade Buyer',
    description: 'Storefront account with access strictly limited to own orders, wishlist, and profile.',
    builtIn: true,
    permissions: {
      dashboard: [],
      reports: [],
      audit_logs: [],
      products: [],
      product_variations: [],
      categories: [],
      inventory: [],
      stock_adjustments: [],
      suppliers: [],
      purchases: [],
      orders: [],
      customers: [],
      discounts: [],
      payments: [],
      refunds: [],
      store_settings: [],
      theme_management: [],
      user_management: [],
      role_management: [],
      permission_management: []
    },
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  }
];
