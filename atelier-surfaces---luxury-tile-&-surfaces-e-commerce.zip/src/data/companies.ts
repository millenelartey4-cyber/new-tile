import { CompanyTenant } from '../types';

export const INITIAL_COMPANIES: CompanyTenant[] = [
  {
    id: 'atelier-surfaces',
    slug: 'atelier-surfaces',
    name: 'ATELIER SURFACES',
    tagline: 'Curators of Italian Architectural Marble & Large-Format Porcelain',
    industry: 'Architectural Marble & Porcelain',
    currency: 'GHS',
    currencySymbol: 'GH₵',
    contactEmail: 'concierge@ateliersurfaces.com',
    contactPhone: '0542443125/0596334488',
    whatsAppNumber: '0542443125/0596334488',
    showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
    ghanaPostGps: 'GA-110-3849',
    activeThemeId: 'ivory-gold-ateliers',
    adminPassword: 'admin123',
    createdAt: '2026-01-01T08:00:00Z',
    isDefault: true
  },
  {
    id: 'verona-stone',
    slug: 'verona-stone',
    name: 'VERONA STONE & TERRAZZO CO.',
    tagline: 'Venetian Cast Terrazzo, Roman Travertine & Bespoke Aggregates',
    industry: 'Terrazzo & Architectural Aggregates',
    currency: 'USD',
    currencySymbol: '$',
    contactEmail: 'orders@veronastone.com',
    contactPhone: '+233 30 278 1190',
    showroomAddress: 'Suite 401, Ridge West Tower, Independence Avenue, Accra',
    ghanaPostGps: 'GA-110-8204',
    activeThemeId: 'siena-travertine',
    adminPassword: 'admin123',
    createdAt: '2026-02-01T09:00:00Z',
    isDefault: false
  },
  {
    id: 'nordic-ceramic',
    slug: 'nordic-ceramic',
    name: 'NORDIC & IBERIAN CERAMIC STUDIO',
    tagline: 'Handcrafted Zellige Wall Tiles & Scandinavian Minimalist Porcelain',
    industry: 'Artisan Wall Glazes & Minimalist Ceramics',
    currency: 'EUR',
    currencySymbol: '€',
    contactEmail: 'studio@nordiciberian.com',
    contactPhone: '+233 26 400 8820',
    showroomAddress: 'Cantonments Design Enclave, 5th Circular Road, Accra',
    ghanaPostGps: 'GA-339-1092',
    activeThemeId: 'chalk-nordic',
    adminPassword: 'admin123',
    createdAt: '2026-02-15T11:00:00Z',
    isDefault: false
  }
];

export function getCompanySettings(company: CompanyTenant) {
  return {
    brandName: company.name,
    tagline: company.tagline,
    activeThemeId: company.activeThemeId || 'ivory-gold-ateliers',
    defaultThemeId: company.activeThemeId || 'ivory-gold-ateliers',
    currency: company.currency,
    currencySymbol: company.currencySymbol,
    taxRatePercent: 15,
    freeDeliveryThreshold: company.currency === 'GHS' ? 5000 : company.currency === 'USD' ? 500 : 450,
    standardDeliveryCost: company.currency === 'GHS' ? 250 : company.currency === 'USD' ? 30 : 25,
    expressFreightCost: company.currency === 'GHS' ? 550 : company.currency === 'USD' ? 65 : 60,
    announcementText: `Welcome to ${company.name} · Direct Showroom Specifications & Nominal 4"×4" Tactile Samples`,
    announcementEnabled: true,
    contactEmail: company.contactEmail,
    contactPhone: company.contactPhone,
    whatsAppNumber: company.whatsAppNumber || company.contactPhone || '0542443125/0596334488',
    showroomAddress: company.showroomAddress,
    ghanaPostGps: company.ghanaPostGps || 'GA-000-0000',
    contactLocked: false,
    contactLastSavedBy: 'Super Admin',
    videoConsultationLocked: false,
    videoLockMessage: 'Video consultations are currently locked for a private architectural masterclass. Please contact the concierge or schedule below.',
    videoConsultantName: 'Kwame Mensah',
    videoConsultantTitle: 'Lead Architectural Consultant',
    videoConsultantLocation: company.showroomAddress,
    videoConsultantAvailable: true,
    videoConsultantHours: 'Mon–Sat: 8:00 AM – 6:00 PM GMT',
    videoResolution: '1080p' as const,
    allowGuestVideoCalls: true
  };
}
