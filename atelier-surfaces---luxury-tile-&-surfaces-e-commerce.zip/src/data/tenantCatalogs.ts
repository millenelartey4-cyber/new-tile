import { Product } from '../types';

export const VERONA_STONE_PRODUCTS: Product[] = [
  {
    id: 'prod-verona-terrazzo-veneziano',
    name: 'Venezia Cast Terrazzo Classic',
    slug: 'venezia-cast-terrazzo-classic',
    description: 'Authentic Italian cast terrazzo with multi-tonal Carrara marble, serpentine jade, and Murano glass aggregate set in high-performance hydraulic cement.',
    shortDescription: 'Italian cast terrazzo slab with genuine marble aggregate.',
    categoryId: 'floor-tiles',
    categoryName: 'Floor Tiles',
    material: 'Terrazzo',
    size: '60x120 cm',
    thickness: '20 mm',
    finish: 'Honed',
    applications: ['Floor', 'Interior', 'Commercial', 'Reception Foyers'],
    specifications: {
      waterAbsorption: '< 0.3%',
      slipResistance: 'R10 / PTV 36+',
      rectified: true,
      frostResistant: true,
      shadeVariation: 'V2 Slight',
      origin: 'Verona, Italy'
    },
    featured: true,
    bestSeller: true,
    newArrival: false,
    active: true,
    rating: 4.9,
    reviewCount: 38,
    createdAt: '2026-02-01T09:00:00Z',
    updatedAt: '2026-02-01T09:00:00Z',
    variants: [
      {
        id: 'var-venezia-bianco',
        colorName: 'Bianco Cristallo',
        colorHex: '#EAE6DF',
        sku: 'VST-VNZ-BNC-60120',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 85,
        stock: 350,
        lowStockThreshold: 40,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      },
      {
        id: 'var-venezia-nero',
        colorName: 'Nero Basalto Aggregate',
        colorHex: '#2B2A29',
        sku: 'VST-VNZ-NRO-60120',
        images: [
          '/assets/images/category_marble_slabs_1792523067297.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 92,
        stock: 180,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      }
    ]
  },
  {
    id: 'prod-roman-travertine-veincut',
    name: 'Tivoli Roman Travertine Vein-Cut',
    slug: 'tivoli-roman-travertine-veincut',
    description: 'Quarried in the historic Tivoli basin near Rome, featuring linear thermal banding, warm cream striations, and tactile micro-cleft finish.',
    shortDescription: 'Quarry-direct Italian travertine slab for floors and facade cladding.',
    categoryId: 'natural-stone',
    categoryName: 'Natural Stone',
    material: 'Travertine',
    size: '80x160 cm',
    thickness: '20 mm',
    finish: 'Honed',
    applications: ['Floor', 'Wall', 'Interior', 'Exterior Facade'],
    specifications: {
      waterAbsorption: '< 0.5%',
      slipResistance: 'R10',
      rectified: true,
      frostResistant: true,
      shadeVariation: 'V3 Moderate',
      origin: 'Tivoli, Italy'
    },
    featured: true,
    bestSeller: true,
    newArrival: true,
    active: true,
    rating: 5.0,
    reviewCount: 24,
    createdAt: '2026-02-05T10:00:00Z',
    updatedAt: '2026-02-05T10:00:00Z',
    variants: [
      {
        id: 'var-tivoli-crema',
        colorName: 'Crema Romano',
        colorHex: '#D8CBB6',
        sku: 'VST-TRV-CRM-80160',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
        ],
        price: 110,
        stock: 220,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 1.28,
        active: true
      }
    ]
  }
];

export const NORDIC_CERAMIC_PRODUCTS: Product[] = [
  {
    id: 'prod-nordic-chalk-porcelain',
    name: 'Fjord Chalk Matte Porcelain',
    slug: 'fjord-chalk-matte-porcelain',
    description: 'Scandinavian minimalist ultra-matte surface crafted with refined sedimentary clays, offering anti-glare architectural diffusion and silky tactile touch.',
    shortDescription: 'Scandinavian chalk porcelain for warm minimalist interiors.',
    categoryId: 'floor-tiles',
    categoryName: 'Floor Tiles',
    material: 'Porcelain',
    size: '90x90 cm',
    thickness: '10 mm',
    finish: 'Matte',
    applications: ['Floor', 'Wall', 'Interior', 'Wet Areas'],
    specifications: {
      waterAbsorption: '< 0.05%',
      slipResistance: 'R10',
      rectified: true,
      frostResistant: true,
      shadeVariation: 'V1 Uniform',
      origin: 'Castellon, Spain'
    },
    featured: true,
    bestSeller: true,
    newArrival: false,
    active: true,
    rating: 4.8,
    reviewCount: 42,
    createdAt: '2026-02-15T11:00:00Z',
    updatedAt: '2026-02-15T11:00:00Z',
    variants: [
      {
        id: 'var-fjord-chalk',
        colorName: 'Nordic Chalk White',
        colorHex: '#F2EFE9',
        sku: 'NIC-FJD-CHK-9090',
        images: [
          '/assets/images/category_porcelain_floors_1792523066985.jpg',
          '/assets/images/category_stone_bathroom_1792523067646.jpg'
        ],
        price: 68,
        stock: 450,
        lowStockThreshold: 50,
        unit: 'm²',
        boxCoverage: 1.62,
        active: true
      },
      {
        id: 'var-fjord-clay',
        colorName: 'Raw Clay Taupe',
        colorHex: '#B5A898',
        sku: 'NIC-FJD-CLY-9090',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_porcelain_floors_1792523066985.jpg'
        ],
        price: 72,
        stock: 310,
        lowStockThreshold: 40,
        unit: 'm²',
        boxCoverage: 1.62,
        active: true
      }
    ]
  },
  {
    id: 'prod-artisan-zellige-glaze',
    name: 'Iberian Artisan Glazed Terracotta',
    slug: 'iberian-artisan-glazed-terracotta',
    description: 'Hand-molded terracotta biscuits dipped in translucent vitreous enamels, creating undulating micro-relief, crazing, and lively light play.',
    shortDescription: 'Handmade artisan glazed tile for statement splashbacks and bathrooms.',
    categoryId: 'wall-tiles',
    categoryName: 'Wall Tiles',
    material: 'Ceramic',
    size: '10x10 cm',
    thickness: '12 mm',
    finish: 'Polished',
    applications: ['Wall', 'Interior', 'Wet Areas', 'Kitchen Splashback'],
    specifications: {
      waterAbsorption: '< 2.0%',
      rectified: false,
      frostResistant: false,
      shadeVariation: 'V4 High',
      origin: 'Fez & Seville'
    },
    featured: true,
    bestSeller: true,
    newArrival: true,
    active: true,
    rating: 4.95,
    reviewCount: 56,
    createdAt: '2026-02-18T14:00:00Z',
    updatedAt: '2026-02-18T14:00:00Z',
    variants: [
      {
        id: 'var-zellige-moss',
        colorName: 'Wild Sage Green',
        colorHex: '#526A59',
        sku: 'NIC-ZEL-SGE-1010',
        images: [
          '/assets/images/category_stone_bathroom_1792523067646.jpg',
          '/assets/images/category_marble_slabs_1792523067297.jpg'
        ],
        price: 88,
        stock: 260,
        lowStockThreshold: 35,
        unit: 'm²',
        boxCoverage: 0.5,
        active: true
      }
    ]
  }
];
