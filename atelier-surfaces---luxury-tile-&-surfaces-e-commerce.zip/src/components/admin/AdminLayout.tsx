import { useState, useEffect } from 'react';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { AdminLockScreen } from './AdminLockScreen';
import { AdminBrightnessController } from './AdminBrightnessController';
import { 
  LayoutDashboard, 
  Package, 
  Boxes, 
  ShoppingCart, 
  Users, 
  Palette, 
  ShieldAlert, 
  Settings, 
  FileText, 
  Tags, 
  History, 
  Store, 
  Layers, 
  ChevronRight, 
  LogOut,
  AlertTriangle,
  ExternalLink,
  Lock,
  Building2,
  Globe,
  Download,
  Video,
  Sun,
  CreditCard,
  Sliders,
  ShieldCheck,
  BarChart3
} from 'lucide-react';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { ConnectionStatusBadge } from '../common/ConnectionStatusBadge';

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export function AdminLayout({ children, title, subtitle, actions }: AdminLayoutProps) {
  const { currentPath, navigate } = useRouter();
  const { 
    currentUser, 
    currentRole, 
    hasPermission, 
    availableRoles, 
    switchRole,
    isAdminConsoleUnlocked,
    lockAdminConsole
  } = useAuth();
  const { activeTheme } = useTheme();
  const { activeCompany, setIsSwitcherOpen } = useCompany();
  const settings = storeService.getStoreSettings();

  // Panel Brightness & Illumination State
  const [brightnessConfig, setBrightnessConfig] = useState(() => storeService.getPanelBrightness(activeCompany.id));
  const [isBrightnessModalOpen, setIsBrightnessModalOpen] = useState(false);

  useEffect(() => {
    setBrightnessConfig(storeService.getPanelBrightness(activeCompany.id));
  }, [activeCompany.id]);

  // If the admin console is locked, require password authentication
  if (!isAdminConsoleUnlocked) {
    return <AdminLockScreen targetPath={currentPath} />;
  }

  // Navigation Items with module permission mapping
  const navItems = [
    { label: 'Overview', href: '/admin', icon: LayoutDashboard, module: 'dashboard' as const, action: 'view' as const },
    { label: 'POS Terminal (Showroom)', href: '/admin/pos', icon: CreditCard, module: 'orders' as const, action: 'view' as const },
    { label: 'POS Features & Settings', href: '/admin/pos/settings', icon: Sliders, module: 'store_settings' as const, action: 'view' as const },
    { label: 'Company Workspaces', href: '/admin/companies', icon: Building2, module: 'store_settings' as const, action: 'view' as const },
    { label: 'Products & Slabs', href: '/admin/products', icon: Package, module: 'products' as const, action: 'view' as const },
    { label: 'Surface Categories', href: '/admin/categories', icon: Layers, module: 'categories' as const, action: 'view' as const },
    { label: 'Live Inventory', href: '/admin/inventory', icon: Boxes, module: 'inventory' as const, action: 'view' as const },
    { label: 'Orders & Receipts', href: '/admin/orders', icon: ShoppingCart, module: 'orders' as const, action: 'view' as const },
    { label: 'EcomSpine Logistics & Pay', href: '/admin/ecomspine', icon: ShieldCheck, module: 'store_settings' as const, action: 'view' as const },
    { label: 'Customer Directory', href: '/admin/customers', icon: Users, module: 'customers' as const, action: 'view' as const },
    { label: 'Discounts & Trade', href: '/admin/discounts', icon: Tags, module: 'discounts' as const, action: 'view' as const },
    { label: 'Commercial Analytics', href: '/admin/analytics', icon: BarChart3, module: 'reports' as const, action: 'view' as const },
    { label: 'Business Reports', href: '/admin/reports', icon: FileText, module: 'reports' as const, action: 'view' as const },
    { label: 'Staff & Users', href: '/admin/users', icon: Users, module: 'user_management' as const, action: 'view' as const },
    { label: 'Theme Studio (64+)', href: '/admin/settings/appearance', icon: Palette, module: 'theme_management' as const, action: 'view' as const },
    { label: 'Panel Brightness & Display', href: '/admin/settings/brightness', icon: Sun, module: 'theme_management' as const, action: 'view' as const },
    { label: 'Role & Permissions Matrix', href: '/admin/settings/roles', icon: ShieldAlert, module: 'role_management' as const, action: 'view' as const },
    { label: 'Store & Region', href: '/admin/settings/store', icon: Settings, module: 'store_settings' as const, action: 'view' as const },
    { label: 'Audit Trail', href: '/admin/audit-logs', icon: History, module: 'audit_logs' as const, action: 'view' as const },
    { label: 'Video Calls & Showroom Lock', href: '/admin/video-consultations', icon: Video, module: 'store_settings' as const, action: 'view' as const },
    { label: 'Download SaaS App', href: '/install', icon: Download, module: 'dashboard' as const, action: 'view' as const }
  ];

  // Access check: If user cannot view dashboard or admin
  const canAccessAdmin = currentRole?.id === 'super-admin' || navItems.some(item => hasPermission(item.module, item.action));

  if (!canAccessAdmin) {
    return (
      <div className="min-h-screen bg-[var(--theme-bg)] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-[var(--theme-surface)] border border-[var(--theme-border)] p-8 text-center space-y-4 shadow-xl">
          <div className="w-14 h-14 mx-auto rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <h2 className="font-serif-luxury text-2xl font-bold text-[var(--theme-text)]">
            Restricted Administration Access
          </h2>
          <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
            Your current role (<strong className="text-[var(--theme-text)]">{currentRole?.name || 'Customer'}</strong>) does not have authorization to view internal administrative consoles.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => switchRole('super-admin')}
              className="w-full py-2.5 bg-[var(--theme-accent)] text-white text-xs font-semibold uppercase tracking-wider hover:opacity-90"
            >
              Switch to Super Admin for Testing
            </button>
            <Link
              href="/"
              className="w-full py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider text-[var(--theme-text)]"
            >
              Return to Storefront
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--theme-bg)] flex text-[var(--theme-text)]">
      
      {/* Persistent Sidebar */}
      <aside 
        aria-label="Admin Navigation"
        style={{
          filter: `brightness(${brightnessConfig.sidebarBrightness}%) contrast(${brightnessConfig.sidebarContrast}%)`
        }}
        className="w-64 bg-[var(--theme-sidebar-bg)] text-[var(--theme-sidebar-text)] border-r border-[var(--theme-sidebar-border)] flex flex-col shrink-0 min-h-screen sticky top-0 h-screen transition-all duration-150 z-20"
      >
        {/* Brand header */}
        <div className="p-6 border-b border-[var(--theme-sidebar-border)] flex items-center justify-between">
          <div>
            <Link
              href="/admin"
              className="font-serif-luxury text-lg font-semibold tracking-widest uppercase text-white block hover:opacity-90"
            >
              {settings.brandName}
            </Link>
            <span className="text-[10px] text-[var(--theme-sidebar-muted)] tracking-wider uppercase block mt-0.5">
              Control Console · {currentRole?.name}
            </span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-1 text-xs">
          {navItems.map(item => {
            const permitted = currentRole?.id === 'super-admin' || hasPermission(item.module, item.action);
            if (!permitted) return null;

            const isActive = currentPath === item.href || (item.href !== '/admin' && currentPath.startsWith(item.href));
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xs transition-colors ${
                  isActive
                    ? 'bg-[var(--theme-sidebar-active)] text-white font-semibold shadow-xs'
                    : 'text-[var(--theme-sidebar-muted)] hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Sidebar Footer with Active Global Theme Info, Storefront Link & Lock Action */}
        <div className="p-4 border-t border-[var(--theme-sidebar-border)] bg-black/20 text-xs space-y-2.5">
          <div className="flex items-center justify-between text-[11px] text-[var(--theme-sidebar-muted)]">
            <span>Global Theme:</span>
            <span className="text-[var(--theme-sidebar-active)] font-medium truncate max-w-[120px]" title={activeTheme.name}>
              {activeTheme.name}
            </span>
          </div>

          <PWAInstallButton variant="sidebar" />

          <Link
            href="/"
            className="w-full py-2 bg-white/10 hover:bg-white/20 text-white text-[11px] font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors border border-white/10"
          >
            <span>View Public Storefront</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>

          <button
            type="button"
            onClick={() => {
              lockAdminConsole();
              navigate('/');
            }}
            className="w-full py-2 bg-red-950/60 hover:bg-red-900/80 text-red-200 text-[11px] font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors border border-red-800/60 cursor-pointer shadow-xs"
            title="Lock admin console and return to public website"
          >
            <Lock className="w-3.5 h-3.5 text-red-400" />
            <span>Lock Admin Console</span>
          </button>
        </div>
      </aside>

      {/* Main Administrative Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Navbar */}
        <header 
          style={{
            filter: `brightness(${brightnessConfig.headerBrightness}%) contrast(${brightnessConfig.headerContrast}%)`
          }}
          className="h-16 bg-[var(--theme-surface)] border-b border-[var(--theme-border)] px-6 flex items-center justify-between gap-4 sticky top-0 z-10 transition-all duration-150"
        >
          <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)]">
            <Link href="/admin" className="hover:text-[var(--theme-text)]">Admin Console</Link>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-[var(--theme-text)] font-semibold">{title}</span>
          </div>

          <div className="flex items-center gap-2.5 sm:gap-3 text-xs">
            {/* Quick POS Terminal Button */}
            <Link
              href="/admin/pos"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 text-xs font-semibold rounded-xs transition-colors shadow-xs"
              title="Launch Showroom POS Terminal"
            >
              <CreditCard className="w-3.5 h-3.5 text-emerald-500" />
              <span>POS</span>
            </Link>

            {/* Panel Brightness & Lock Adjuster Button */}
            <button
              type="button"
              onClick={() => setIsBrightnessModalOpen(true)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 border text-xs font-semibold rounded-xs transition-colors cursor-pointer shadow-xs ${
                brightnessConfig.isLocked
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-600 dark:text-amber-400'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
              title={`Adjust & Lock Panel Brightness (Sidebar: ${brightnessConfig.sidebarBrightness}%, Header: ${brightnessConfig.headerBrightness}%, Workspace: ${brightnessConfig.workspaceBrightness}%)`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span className="hidden md:inline">Panels</span>
              <span className="text-[10px] font-mono font-bold bg-amber-500/20 px-1 py-0.2 rounded-xs">
                {brightnessConfig.workspaceBrightness}%
              </span>
              {brightnessConfig.isLocked && (
                <Lock className="w-3 h-3 text-amber-500 ml-0.5" />
              )}
            </button>

            {/* Active Company Workspace Switcher */}
            <button
              type="button"
              onClick={() => setIsSwitcherOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] transition-colors cursor-pointer shadow-xs"
              title="Switch or deploy company workspace"
            >
              <Building2 className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span className="max-w-[120px] truncate">{activeCompany.name}</span>
              <span className="text-[10px] px-1 py-0.2 bg-[var(--theme-accent)] text-white font-mono uppercase font-bold">
                {activeCompany.currency}
              </span>
            </button>

            <span className="text-[var(--theme-border)] hidden sm:inline">|</span>

            {/* Quick Testing Role Switcher */}
            <div className="hidden md:flex items-center gap-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] px-2.5 py-1">
              <span className="text-[var(--theme-text-muted)] font-semibold">Testing Role:</span>
              <select
                value={currentRole?.id || 'super-admin'}
                onChange={e => switchRole(e.target.value)}
                className="bg-transparent font-bold text-[var(--theme-accent)] focus:outline-none cursor-pointer"
              >
                {availableRoles.map(r => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center text-[var(--theme-accent)] font-bold text-xs">
                {currentUser?.name.charAt(0) || 'A'}
              </div>
              <span className="font-semibold hidden sm:inline">{currentUser?.name}</span>
            </div>

            <span className="text-[var(--theme-border)]">|</span>

            {/* Quick Video Call & Showroom Status Chip */}
            <Link
              href="/admin/video-consultations"
              className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold rounded-xs border transition cursor-pointer ${
                settings.videoConsultationLocked
                  ? 'bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-400 hover:bg-red-500/20'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20'
              }`}
              title="Click to edit, add, save, and lock Face-to-Face Video Calls & Showroom Coordinates"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Calls: {settings.videoConsultationLocked ? 'LOCKED' : 'ONLINE'}</span>
              <span className="text-[var(--theme-border)]">·</span>
              <span className="text-[10px] font-mono text-[var(--theme-text-muted)]">
                {settings.ghanaPostGps || 'GA-110-3849'}
              </span>
            </Link>

            <span className="text-[var(--theme-border)] hidden lg:inline">|</span>

            {/* Hybrid Online/Offline Status Hub */}
            <ConnectionStatusBadge />

            <span className="text-[var(--theme-border)]">|</span>

            {/* SaaS Desktop App Install Button */}
            <PWAInstallButton variant="admin" />

            <span className="text-[var(--theme-border)]">|</span>

            {/* Prominent Lock Admin Console Action */}
            <button
              type="button"
              onClick={() => {
                lockAdminConsole();
                navigate('/');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-950/20 hover:bg-red-900/40 text-red-600 dark:text-red-300 border border-red-800/40 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs"
              title="Lock and protect admin console"
            >
              <Lock className="w-3.5 h-3.5 text-red-500" />
              <span>Lock Console</span>
            </button>
          </div>
        </header>

        {/* Content Container */}
        <main 
          style={{
            filter: `brightness(${brightnessConfig.workspaceBrightness}%) contrast(${brightnessConfig.workspaceContrast}%)`
          }}
          className="flex-1 p-6 sm:p-8 max-w-7xl w-full mx-auto space-y-6 transition-all duration-150"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--theme-border)]">
            <div>
              <h1 className="font-serif-luxury text-3xl font-semibold text-[var(--theme-text)]">
                {title}
              </h1>
              {subtitle && (
                <p className="text-xs text-[var(--theme-text-muted)] mt-1">
                  {subtitle}
                </p>
              )}
            </div>
            {actions && <div className="flex items-center gap-3 shrink-0">{actions}</div>}
          </div>

          {children}
        </main>
      </div>

      {/* Admin Panel Brightness & Contrast Calibration / Lock Modal */}
      <AdminBrightnessController
        isOpen={isBrightnessModalOpen}
        onClose={() => setIsBrightnessModalOpen(false)}
        onUpdate={(newConfig) => setBrightnessConfig(newConfig)}
      />
    </div>
  );
}
