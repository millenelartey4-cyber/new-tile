import React, { useState, useRef, useMemo } from 'react';
import { storeService } from '../../services/store';
import { realtimeSyncService } from '../../services/realtimeSync';
import { useAuth } from '../../context/AuthContext';
import { Product, ProductVariant } from '../../types';
import { 
  X, 
  UploadCloud, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Check, 
  CheckCircle2, 
  Layers, 
  DollarSign, 
  Boxes, 
  Sparkles, 
  Globe, 
  Eye, 
  Link as LinkIcon, 
  AlertCircle,
  HelpCircle,
  Tag
} from 'lucide-react';

interface ManualProductUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newProduct: Product) => void;
  companyId: string;
}

const PRESET_SAMPLE_IMAGES = [
  { name: 'Calacatta Gold Porcelain', url: '/assets/images/category_porcelain_floors_1792523066985.jpg' },
  { name: 'Nero Marquina Velvet Slab', url: '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg' },
  { name: 'French Limestone Beige', url: '/assets/images/category_stone_bathroom_1792523067646.jpg' },
  { name: 'Roman Travertine Navona', url: '/assets/images/category_marble_slabs_1792523067297.jpg' },
  { name: 'Terrazzo Moderno Grigio', url: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1600&q=85' }
];

const APPLICATION_OPTIONS = [
  'Floor',
  'Wall',
  'Kitchen Countertop',
  'Bathroom & Wet Room',
  'Exterior Facade',
  'Swimming Pool Deck',
  'Fireplace Surround',
  'Commercial High Traffic'
];

export function ManualProductUploadModal({
  isOpen,
  onClose,
  onSuccess,
  companyId
}: ManualProductUploadModalProps) {
  const { currentUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const categories = useMemo(() => storeService.getCategories(companyId), [companyId]);

  // Form State
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || 'porcelain-slabs');
  const [material, setMaterial] = useState<Product['material']>('Porcelain');
  const [finish, setFinish] = useState<Product['finish']>('Polished');
  const [size, setSize] = useState('120x278 cm (Large Format Slab)');
  const [thickness, setThickness] = useState('9 mm');
  const [description, setDescription] = useState('');

  // Pricing & Inventory
  const [price, setPrice] = useState<number>(495);
  const [compareAtPrice, setCompareAtPrice] = useState<number>(550);
  const [stock, setStock] = useState<number>(200);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(25);
  const [boxCoverage, setBoxCoverage] = useState<number>(3.34);

  // Primary Color Variant
  const [colorName, setColorName] = useState('Statuario Oro');
  const [colorHex, setColorHex] = useState('#EFECE6');
  const [sku, setSku] = useState('');

  // Applications
  const [selectedApplications, setSelectedApplications] = useState<string[]>([
    'Floor',
    'Wall',
    'Kitchen Countertop'
  ]);

  // Specifications
  const [origin, setOrigin] = useState('Sassuolo, Italy');
  const [waterAbsorption, setWaterAbsorption] = useState('< 0.05% (Impervious)');
  const [slipResistance, setSlipResistance] = useState('R10 Interior');
  const [rectified, setRectified] = useState(true);

  // Publishing Flags
  const [active, setActive] = useState(true);
  const [featured, setFeatured] = useState(false);

  // Image Upload State
  const [images, setImages] = useState<string[]>([
    '/assets/images/category_porcelain_floors_1792523066985.jpg'
  ]);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  // Action status
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showPresets, setShowPresets] = useState(false);

  // Auto-generate slug and SKU when name changes
  const handleNameChange = (val: string) => {
    setName(val);
    const generatedSlug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
    setSlug(generatedSlug);

    const prefix = val.substring(0, 3).toUpperCase().replace(/[^A-Z]/g, '') || 'SLB';
    const num = Math.floor(100 + Math.random() * 900);
    setSku(`AS-${prefix}-${num}`);
  };

  // Handle local image file upload & convert to Data URL
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setErrorMessage('');

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) {
        setErrorMessage('Please upload image files only (PNG, JPG, WebP).');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setErrorMessage('Image size exceeds 10MB limit.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          setImages(prev => {
            // If the only image is the placeholder default, replace it
            if (prev.length === 1 && prev[0].includes('category_porcelain_floors')) {
              return [result];
            }
            return [...prev, result];
          });
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleAddImageUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrlInput.trim()) return;
    const url = imageUrlInput.trim();
    setImages(prev => [...prev, url]);
    setImageUrlInput('');
  };

  const handleRemoveImage = (indexToRemove: number) => {
    if (images.length <= 1) {
      setErrorMessage('Every product slab must maintain at least one specimen photograph.');
      return;
    }
    setImages(images.filter((_, idx) => idx !== indexToRemove));
  };

  const handleSetPrimaryImage = (index: number) => {
    if (index === 0) return;
    const reordered = [...images];
    const [selected] = reordered.splice(index, 1);
    reordered.unshift(selected);
    setImages(reordered);
  };

  const handleToggleApplication = (app: string) => {
    setSelectedApplications(prev => 
      prev.includes(app) ? prev.filter(a => a !== app) : [...prev, app]
    );
  };

  // APPLY AND SAVE HANDLER
  const handleApplyAndSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Product name is required.');
      return;
    }
    if (!slug.trim()) {
      setErrorMessage('Product slug identifier is required.');
      return;
    }
    if (images.length === 0) {
      setErrorMessage('Please upload at least one image of the slab or tile.');
      return;
    }
    if (price <= 0) {
      setErrorMessage('Unit price must be greater than zero.');
      return;
    }

    setIsSubmitting(true);

    try {
      const selectedCat = categories.find(c => c.id === categoryId) || categories[0] || {
        id: 'porcelain-slabs',
        name: 'Porcelain Slabs'
      };

      const finalSku = sku.trim() || `AS-${slug.substring(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

      const primaryVariant: ProductVariant = {
        id: `var-${Date.now()}-1`,
        colorName: colorName.trim() || 'Primary Specimen',
        colorHex: colorHex || '#EFECE6',
        sku: finalSku,
        images: images,
        price: Number(price),
        compareAtPrice: compareAtPrice > 0 ? Number(compareAtPrice) : undefined,
        stock: Number(stock),
        lowStockThreshold: Number(lowStockThreshold),
        unit: 'm²',
        boxCoverage: Number(boxCoverage) || 1.44,
        active: true
      };

      const newProductPayload: Product = {
        id: `prod-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        name: name.trim(),
        slug: slug.trim().toLowerCase(),
        description: description.trim() || `Architectural grade ${material.toLowerCase()} surface calibrated for luxury commercial and residential installations. Featuring pristine ${finish.toLowerCase()} finish and authentic European mineral characteristics.`,
        categoryId: selectedCat.id,
        categoryName: selectedCat.name,
        material,
        size: size.trim(),
        thickness: thickness.trim(),
        finish,
        applications: selectedApplications.length > 0 ? selectedApplications : ['Floor', 'Wall'],
        specifications: {
          waterAbsorption,
          slipResistance,
          origin,
          rectified
        },
        featured,
        active,
        variants: [primaryVariant],
        rating: 5.0,
        reviewCount: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // 1. Save product into tenant-scoped database in storeService
      const saved = storeService.saveProduct(newProductPayload, currentUser?.name || 'Administrator', companyId);

      // 2. Broadcast real-time inventory and pricing update so storefront reflects immediately
      try {
        await realtimeSyncService.publishEvent('INVENTORY_ADJUSTED', {
          productId: saved.id,
          variantId: primaryVariant.id,
          newStock: primaryVariant.stock,
          adjustment: primaryVariant.stock,
          reason: 'Received shipment',
          productName: saved.name,
          colorName: primaryVariant.colorName
        }, companyId, currentUser?.name || 'Showroom Administrator');

        await realtimeSyncService.publishEvent('PRICE_UPDATED', {
          productId: saved.id,
          variantId: primaryVariant.id,
          newPrice: primaryVariant.price
        }, companyId, currentUser?.name || 'Showroom Administrator');
      } catch (err) {
        console.warn('Real-time event push warning:', err);
      }

      // 3. Dispatch browser-level event for immediate local UI sync
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('pos_inventory_synced', {
          detail: { 
            productId: saved.id, 
            variantId: primaryVariant.id, 
            newStock: primaryVariant.stock,
            productName: saved.name
          }
        }));
        window.dispatchEvent(new CustomEvent('pos_price_synced', {
          detail: { productId: saved.id, variantId: primaryVariant.id, newPrice: primaryVariant.price }
        }));
        window.dispatchEvent(new Event('storage'));
      }

      setIsSubmitting(false);
      onSuccess(saved);
      onClose();
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage(err.message || 'Failed to apply and save product.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in">
      <div 
        className="w-full max-w-4xl bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-2xl rounded-xs overflow-hidden flex flex-col max-h-[92vh] my-auto"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xs bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                  Manual Product & Slab Upload
                </h3>
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 bg-emerald-950/80 text-emerald-400 border border-emerald-700/60 rounded-full flex items-center gap-1">
                  <Globe className="w-3 h-3" /> Live Storefront Sync
                </span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Upload photography, define pricing, and click <strong>Apply & Save</strong> to instantly publish to the storefront catalog.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] hover:bg-[var(--theme-surface)] rounded-xs transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Scrollable Form */}
        <form onSubmit={handleApplyAndSave} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          
          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-red-950/30 border border-red-500/50 text-red-300 rounded-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* SECTION 1: PRODUCT IMAGE UPLOAD (DRAG & DROP / FILE SELECTOR / PRESETS) */}
          <div className="space-y-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-4 rounded-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                  Step 1 · High-Fidelity Slab Photography
                </span>
                <h4 className="font-serif-luxury text-sm font-bold text-[var(--theme-text)]">
                  Upload Product Image *
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowPresets(!showPresets)}
                className="text-[11px] font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{showPresets ? 'Hide Sample Presets' : 'Choose Architectural Preset'}</span>
              </button>
            </div>

            {/* Presets Grid */}
            {showPresets && (
              <div className="p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs space-y-2">
                <span className="text-[10px] text-[var(--theme-text-muted)] uppercase font-mono block">
                  Click to add sample luxury quarry specimen:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {PRESET_SAMPLE_IMAGES.map((preset, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        setImages(prev => [...prev, preset.url]);
                        setShowPresets(false);
                      }}
                      className="p-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-left group bg-[var(--theme-surface-subtle)] transition"
                    >
                      <img src={preset.url} alt={preset.name} className="w-full aspect-[4/3] object-cover mb-1" />
                      <span className="text-[10px] text-[var(--theme-text)] font-medium line-clamp-1 group-hover:text-[var(--theme-accent)]">
                        {preset.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Drag & Drop Zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xs p-6 flex flex-col items-center justify-center text-center cursor-pointer transition ${
                isDragging 
                  ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)]/10 scale-[1.01]' 
                  : 'border-[var(--theme-border)] hover:border-[var(--theme-accent)] bg-[var(--theme-surface)]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*"
                className="hidden"
                onChange={e => handleFileUpload(e.target.files)}
              />
              <div className="w-12 h-12 rounded-full bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center text-[var(--theme-accent)] mb-3">
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="font-semibold text-xs text-[var(--theme-text)] mb-1">
                Drag and drop your slab image here, or <span className="text-[var(--theme-accent)] underline">browse files</span>
              </p>
              <p className="text-[10px] text-[var(--theme-text-muted)]">
                Supports PNG, JPG, JPEG, WEBP up to 10MB. High-resolution photos are calibrated for storefront lighting simulations.
              </p>
            </div>

            {/* Or Paste Direct Image URL */}
            <div className="flex gap-2">
              <input
                type="url"
                value={imageUrlInput}
                onChange={e => setImageUrlInput(e.target.value)}
                placeholder="Or paste external image URL (e.g. https://images.unsplash.com/...)"
                className="flex-1 px-3 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
              <button
                type="button"
                onClick={handleAddImageUrl}
                className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold hover:border-[var(--theme-text)] text-[var(--theme-text)]"
              >
                Add URL
              </button>
            </div>

            {/* Uploaded Images Preview Strip */}
            {images.length > 0 && (
              <div className="space-y-1.5 pt-2">
                <span className="text-[10px] text-[var(--theme-text-muted)] uppercase font-mono block">
                  Gallery Images ({images.length}) · First image is Primary Cover
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                  {images.map((img, idx) => (
                    <div 
                      key={idx}
                      className={`relative aspect-[4/3] rounded-xs overflow-hidden border group bg-stone-900 ${
                        idx === 0 ? 'border-[var(--theme-accent)] ring-2 ring-[var(--theme-accent)]/30' : 'border-[var(--theme-border)]'
                      }`}
                    >
                      <img src={img} alt={`Uploaded ${idx + 1}`} className="w-full h-full object-cover" />
                      
                      {idx === 0 && (
                        <span className="absolute top-1 left-1 bg-[var(--theme-accent)] text-white text-[9px] font-bold px-1.5 py-0.2 uppercase rounded-xs">
                          Primary
                        </span>
                      )}

                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-1">
                        {idx !== 0 && (
                          <button
                            type="button"
                            onClick={() => handleSetPrimaryImage(idx)}
                            className="px-1.5 py-0.5 bg-stone-800 text-stone-100 text-[10px] rounded hover:bg-stone-700"
                            title="Set as Primary Cover"
                          >
                            Set Cover
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(idx)}
                          className="p-1 bg-red-600 text-white rounded hover:bg-red-700"
                          title="Remove image"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* SECTION 2: BASIC PRODUCT & SLAB METADATA */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Product Title / Slab Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => handleNameChange(e.target.value)}
                placeholder="e.g. Calacatta Macchia Vecchia Bookmatch Porcelain Slab"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Storefront Slug Identifier *
              </label>
              <input
                type="text"
                required
                value={slug}
                onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-'))}
                placeholder="calacatta-macchia-vecchia-slab"
                className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Surface Category *
              </label>
              <select
                value={categoryId}
                onChange={e => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
              >
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Material Geology *
              </label>
              <select
                value={material}
                onChange={e => setMaterial(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
              >
                <option value="Porcelain">Ultra-Compact Porcelain (&lt; 0.05% absorption)</option>
                <option value="Marble">Natural Marble (Italian & Spanish)</option>
                <option value="Limestone">Natural French Limestone</option>
                <option value="Travertine">Roman Cross-Cut Travertine</option>
                <option value="Granite">Natural Granite</option>
                <option value="Terrazzo">Architectural Terrazzo</option>
                <option value="Ceramic">Bespoke Wall Ceramic</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Surface Sheen / Finish *
              </label>
              <select
                value={finish}
                onChange={e => setFinish(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
              >
                <option value="Polished">Polished Mirror Reflective (High Sheen)</option>
                <option value="Honed">Honed Smooth Matte (Glare-Free)</option>
                <option value="Velvet">Velvet Satin Touch (Soft Sheen)</option>
                <option value="Textured">Textured Architectural (R10/R11 Anti-Slip)</option>
                <option value="Flamed">Flamed & Brushed (Outdoor Grip)</option>
                <option value="Bush-hammered">Bush-hammered Cleft</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Dimensions / Slab Size *
              </label>
              <input
                type="text"
                required
                value={size}
                onChange={e => setSize(e.target.value)}
                placeholder="160x320 cm or 120x278 cm"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Thickness *
              </label>
              <input
                type="text"
                required
                value={thickness}
                onChange={e => setThickness(e.target.value)}
                placeholder="9 mm or 12 mm or 20 mm"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium text-[var(--theme-text)]"
              />
            </div>
          </div>

          {/* SECTION 3: PRICING & INVENTORY */}
          <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-4 rounded-xs space-y-3">
            <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
              Step 2 · Pricing & Showroom Inventory
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Unit Price (GH₵ / m²) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  step="1"
                  value={price}
                  onChange={e => setPrice(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 font-mono font-bold text-sm bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Regular Price (GH₵ / m²)
                </label>
                <input
                  type="number"
                  min="0"
                  value={compareAtPrice || ''}
                  onChange={e => setCompareAtPrice(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 550"
                  className="w-full px-3 py-2 font-mono text-xs bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Stock Available (m²) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={stock}
                  onChange={e => setStock(parseInt(e.target.value, 10) || 0)}
                  className="w-full px-3 py-2 font-mono font-bold text-sm bg-[var(--theme-surface)] border border-[var(--theme-border)] text-emerald-400"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Coverage / Slab Area (m²)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={boxCoverage}
                  onChange={e => setBoxCoverage(parseFloat(e.target.value) || 1.44)}
                  className="w-full px-3 py-2 font-mono text-xs bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)]"
                />
              </div>
            </div>
          </div>

          {/* SECTION 4: COLOR VARIANT & SKU */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Color Variant Name *
              </label>
              <input
                type="text"
                required
                value={colorName}
                onChange={e => setColorName(e.target.value)}
                placeholder="e.g. Statuario Oro / Imperial Gold"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Color Swatch Hex *
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={colorHex}
                  onChange={e => setColorHex(e.target.value)}
                  className="w-8 h-8 rounded border border-black/20 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={colorHex}
                  onChange={e => setColorHex(e.target.value)}
                  placeholder="#EFECE6"
                  className="w-full px-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Unique SKU Identifier *
              </label>
              <input
                type="text"
                required
                value={sku}
                onChange={e => setSku(e.target.value.toUpperCase())}
                placeholder="AS-CAL-ORO-120278"
                className="w-full px-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>
          </div>

          {/* SECTION 5: RECOMMENDED APPLICATIONS */}
          <div className="space-y-2">
            <label className="block uppercase font-bold text-[var(--theme-text-muted)]">
              Recommended Architectural Applications
            </label>
            <div className="flex flex-wrap gap-2">
              {APPLICATION_OPTIONS.map(app => {
                const isSelected = selectedApplications.includes(app);
                return (
                  <button
                    key={app}
                    type="button"
                    onClick={() => handleToggleApplication(app)}
                    className={`px-3 py-1.5 rounded-xs border text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)] shadow-xs'
                        : 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    <span>{app}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 6: ARCHITECTURAL SPECIFICATIONS */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Quarry / Factory Origin
              </label>
              <input
                type="text"
                value={origin}
                onChange={e => setOrigin(e.target.value)}
                placeholder="Sassuolo, Italy"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Water Absorption Rating
              </label>
              <input
                type="text"
                value={waterAbsorption}
                onChange={e => setWaterAbsorption(e.target.value)}
                placeholder="< 0.05%"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Slip Resistance
              </label>
              <input
                type="text"
                value={slipResistance}
                onChange={e => setSlipResistance(e.target.value)}
                placeholder="R10 Interior or R11 Outdoor"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>
          </div>

          {/* SECTION 7: DESCRIPTION */}
          <div>
            <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
              Stone Description & Architectural Character
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe veining patterns, mineral reflections, recommended lighting temperatures, and edge treatment..."
              className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
            />
          </div>

          {/* SECTION 8: STOREFRONT PUBLISHING FLAGS */}
          <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={e => setActive(e.target.checked)}
                  className="accent-emerald-500 w-4 h-4"
                />
                <span className="text-[var(--theme-text)]">Published to Storefront Catalog</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer font-semibold text-xs">
                <input
                  type="checkbox"
                  checked={featured}
                  onChange={e => setFeatured(e.target.checked)}
                  className="accent-[var(--theme-accent)] w-4 h-4"
                />
                <span className="text-[var(--theme-text)]">Featured in Showroom Spotlight</span>
              </label>
            </div>

            <span className="text-[11px] text-[var(--theme-text-muted)]">
              {active ? '● Will appear immediately on /shop and product detail' : '○ Saved as Draft'}
            </span>
          </div>

          {/* MODAL FOOTER ACTIONS */}
          <div className="pt-4 border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 sticky bottom-0 bg-[var(--theme-surface)] py-2">
            <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Applying and saving pushes this slab directly into storefront catalog and physical POS search.</span>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] rounded-xs cursor-pointer transition"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-2 transition shadow-lg shadow-emerald-950/40 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Applying & Saving...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Apply & Save to Storefront</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
