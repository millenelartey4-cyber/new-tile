import React, { useState } from 'react';
import { 
  AlertTriangle, 
  TrendingUp, 
  Video, 
  ArrowRight, 
  Package, 
  Layers, 
  CreditCard, 
  ExternalLink, 
  RefreshCw, 
  Lock, 
  Unlock, 
  UserCheck, 
  Smartphone, 
  Banknote, 
  CheckCircle2, 
  ShieldAlert,
  Clock,
  Sparkles
} from 'lucide-react';
import { Link } from '../../router/Router';
import { ConsultationRoom, Order, POSTransaction } from '../../types';

export interface QuickStatsLowStockItem {
  productId: string;
  productName: string;
  productSlug: string;
  categoryName: string;
  material: string;
  variantId: string;
  variantColor: string;
  colorHex: string;
  sku: string;
  stock: number;
  threshold: number;
  unit: string;
  image?: string;
  price: number;
  isOutOfStock: boolean;
  isCritical: boolean;
  percentRemaining: number;
}

interface QuickStatsWidgetProps {
  lowStockItems: QuickStatsLowStockItem[];
  orders: Order[];
  posTransactions: POSTransaction[];
  rooms: ConsultationRoom[];
  currencySymbol: string;
  className?: string;
  style?: React.CSSProperties;
}

export const QuickStatsWidget: React.FC<QuickStatsWidgetProps> = ({
  lowStockItems,
  orders,
  posTransactions,
  rooms,
  currencySymbol,
  className = '',
  style
}) => {
  const [lastRefreshed, setLastRefreshed] = useState<string>('Just now');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setLastRefreshed(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setIsRefreshing(false);
    }, 400);
  };

  // -------------------------------------------------------------
  // 1. INVENTORY ALERTS METRICS
  // -------------------------------------------------------------
  const outOfStockItems = lowStockItems.filter(i => i.isOutOfStock);
  const criticalItems = lowStockItems.filter(i => i.isCritical);
  const warningItems = lowStockItems.filter(i => !i.isOutOfStock && !i.isCritical);

  const outOfStockCount = outOfStockItems.length;
  const criticalCount = criticalItems.length;
  const warningCount = warningItems.length;
  const totalAlertsCount = lowStockItems.length;

  // Top critical slab specimens to display (up to 3)
  const topCriticalItems = lowStockItems.slice(0, 3);

  // -------------------------------------------------------------
  // 2. DAILY SALES VOLUME METRICS (TODAY'S ORDERS + POS COUNTER)
  // -------------------------------------------------------------
  const todayDateStr = new Date().toDateString();

  // Filter POS transactions made today
  const todayPOSTx = posTransactions.filter(tx => {
    try {
      return new Date(tx.timestamp).toDateString() === todayDateStr;
    } catch {
      return false;
    }
  });

  // Filter Online Orders made today (or confirmed paid today)
  const todayOrders = orders.filter(o => {
    try {
      const matchDate = new Date(o.createdAt).toDateString() === todayDateStr;
      return matchDate && o.paymentStatus === 'paid';
    } catch {
      return false;
    }
  });

  // Calculate today's totals
  const todayPOSTotal = todayPOSTx.reduce((sum, tx) => sum + (tx.total || 0), 0);
  const todayOnlineTotal = todayOrders.reduce((sum, o) => sum + (o.total || 0), 0);
  const todayCombinedTotal = todayPOSTotal + todayOnlineTotal;
  const todayCombinedTxCount = todayPOSTx.length + todayOrders.length;

  // Calculate square meters (m²) invoiced today across both channels
  const todayPOSAreaSqM = todayPOSTx.reduce((sum, tx) => {
    return sum + (tx.items || []).reduce((itemSum, item) => {
      // If unit is m² or tile slabs
      return itemSum + (item.quantity || 0);
    }, 0);
  }, 0);

  const todayOnlineAreaSqM = todayOrders.reduce((sum, o) => {
    return sum + (o.itemsSnapshot || []).reduce((itemSum, item) => {
      return itemSum + (item.quantity || 0);
    }, 0);
  }, 0);

  const todayTotalSqM = todayPOSAreaSqM + todayOnlineAreaSqM;
  const averageTicketValue = todayCombinedTxCount > 0 ? todayCombinedTotal / todayCombinedTxCount : 0;

  // Tender breakdown for today
  let cashTotal = 0;
  let cardTotal = 0;
  let momoTotal = 0;
  let bankOrPaystackTotal = todayOnlineTotal; // Online orders typically Paystack/Bank

  todayPOSTx.forEach(tx => {
    if (tx.paymentMethod === 'cash') cashTotal += tx.total;
    else if (tx.paymentMethod === 'card') cardTotal += tx.total;
    else if (tx.paymentMethod === 'momo') momoTotal += tx.total;
    else if (tx.paymentMethod === 'bank_transfer') bankOrPaystackTotal += tx.total;
    else if (tx.paymentMethod === 'split' && tx.paymentDetails?.splitBreakdown) {
      cashTotal += tx.paymentDetails.splitBreakdown.cash || 0;
      cardTotal += tx.paymentDetails.splitBreakdown.card || 0;
      momoTotal += tx.paymentDetails.splitBreakdown.momo || 0;
    } else {
      cardTotal += tx.total;
    }
  });

  // -------------------------------------------------------------
  // 3. PENDING & LIVE VIDEO CONSULTATIONS METRICS
  // -------------------------------------------------------------
  const activeRooms = rooms || [];
  const liveParticipantsCount = activeRooms.reduce((sum, r) => sum + (r.activeParticipantsCount || 0), 0);
  const liveRooms = activeRooms.filter(r => (r.activeParticipantsCount || 0) > 0);
  const lockedRooms = activeRooms.filter(r => r.isLocked);
  const availableRooms = activeRooms.filter(r => !r.isLocked);
  const firstAvailableRoomId = availableRooms[0]?.id || activeRooms[0]?.id || 'atelier-flagship-lounge';

  return (
    <section 
      aria-label="Admin Quick Stats Widget"
      style={style}
      className={`bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-xs transition-all duration-150 overflow-hidden ${className}`}
    >
      {/* Widget Header Strip */}
      <div className="px-5 py-3.5 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--theme-accent)]">
            Command Center
          </span>
          <span className="text-zinc-400 dark:text-zinc-600">·</span>
          <h2 className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text)]">
            Quick Stats &amp; Operational Oversight
          </h2>
          <span className="hidden sm:inline-flex px-1.5 py-0.5 text-[10px] font-mono bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]">
            Ridge West Flagship + E-Commerce
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-[11px] text-[var(--theme-text-muted)] flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Live Stream</span>
            <span className="text-[10px] opacity-70">({lastRefreshed})</span>
          </div>
          <button
            type="button"
            onClick={handleManualRefresh}
            title="Refresh Quick Stats telemetry"
            disabled={isRefreshing}
            className="p-1 hover:bg-[var(--theme-surface)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition rounded-xs cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[var(--theme-accent)]' : ''}`} />
          </button>
        </div>
      </div>

      {/* 3-Column Oversight Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 divide-y lg:divide-y-0 lg:divide-x divide-[var(--theme-border)]">
        
        {/* ========================================================= */}
        {/* CARD 1: REAL-TIME INVENTORY ALERTS */}
        {/* ========================================================= */}
        <div className="p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            {/* Header row */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-xs ${
                  outOfStockCount > 0 
                    ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30' 
                    : criticalCount > 0 
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30' 
                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                }`}>
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text)]">
                    Inventory Alerts
                  </h3>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">
                    Safety stock &amp; depleted variants
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              {outOfStockCount > 0 ? (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-rose-500/15 border border-rose-500/40 text-rose-700 dark:text-rose-300 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
                  {outOfStockCount} Depleted
                </span>
              ) : criticalCount > 0 ? (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 border border-amber-500/40 text-amber-700 dark:text-amber-300">
                  {criticalCount} Critical
                </span>
              ) : (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/15 border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Optimal
                </span>
              )}
            </div>

            {/* Core Metric Display */}
            <div className="flex items-baseline justify-between pt-1">
              <div>
                <div className="text-2xl font-bold font-serif-luxury tabular-nums text-[var(--theme-text)]">
                  {totalAlertsCount}
                  <span className="text-xs font-sans font-normal text-[var(--theme-text-muted)] ml-1.5">
                    variants flagged
                  </span>
                </div>
                <div className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                  Across warehouse catalog pallets
                </div>
              </div>

              {/* Mini Pill Breakdown */}
              <div className="flex items-center gap-1.5 text-[10px] font-mono">
                <span className="px-1.5 py-0.5 bg-rose-500/10 text-rose-700 dark:text-rose-400 border border-rose-500/20 font-bold" title="Zero units in stock">
                  0 stock: {outOfStockCount}
                </span>
                <span className="px-1.5 py-0.5 bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 font-bold" title="Less than 40% safety stock">
                  &lt;40%: {criticalCount}
                </span>
                <span className="px-1.5 py-0.5 bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] border border-[var(--theme-border)]" title="Below reorder threshold">
                  low: {warningCount}
                </span>
              </div>
            </div>

            {/* Specimen Mini Feed: Top Depleted Slabs */}
            <div className="space-y-2 pt-1 border-t border-[var(--theme-border)]">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)] block">
                Most Depleted Surface Slabs:
              </span>
              
              {topCriticalItems.length === 0 ? (
                <div className="p-3 bg-[var(--theme-surface-subtle)] text-[11px] text-[var(--theme-text-muted)] text-center">
                  All porcelain, marble, and quartz slab lines meet safe reorder buffers.
                </div>
              ) : (
                topCriticalItems.map(item => {
                  const isZero = item.stock <= 0;
                  const isCrit = item.isCritical;
                  return (
                    <div 
                      key={`${item.productId}-${item.variantId}`}
                      className="p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-colors space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          {item.image ? (
                            <img 
                              src={item.image} 
                              alt={item.productName} 
                              className="w-7 h-7 object-cover rounded-xs border border-[var(--theme-border)] shrink-0" 
                            />
                          ) : (
                            <div className="w-7 h-7 bg-zinc-800 flex items-center justify-center shrink-0">
                              <Package className="w-3.5 h-3.5 text-zinc-400" />
                            </div>
                          )}
                          <div className="truncate">
                            <span className="text-xs font-semibold text-[var(--theme-text)] truncate block">
                              {item.productName}
                            </span>
                            <span className="text-[10px] text-[var(--theme-text-muted)] truncate block font-mono">
                              {item.variantColor} · SKU: {item.sku}
                            </span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className={`text-xs font-bold font-mono ${
                            isZero ? 'text-rose-600 dark:text-rose-400' : isCrit ? 'text-amber-600 dark:text-amber-400' : 'text-[var(--theme-text)]'
                          }`}>
                            {item.stock} {item.unit}
                          </span>
                          <span className="text-[9px] text-[var(--theme-text-muted)] block">
                            min: {item.threshold} {item.unit}
                          </span>
                        </div>
                      </div>

                      {/* Visual Stock Bar */}
                      <div className="w-full bg-zinc-200 dark:bg-zinc-800 h-1 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-300 ${
                            isZero ? 'w-0' : isCrit ? 'bg-rose-500' : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.max(4, Math.min(100, item.percentRemaining))}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Action Link */}
          <Link
            href="/admin/inventory?lowStock=true"
            className="pt-2 text-xs font-bold uppercase tracking-wider text-[var(--theme-accent)] hover:underline flex items-center justify-between border-t border-[var(--theme-border)]"
          >
            <span>Open Warehouse Stock Desk</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* ========================================================= */}
        {/* CARD 2: DAILY SALES VOLUME (COMBINED POS + ONLINE) */}
        {/* ========================================================= */}
        <div className="p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            {/* Header row */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xs bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text)]">
                    Daily Sales Volume
                  </h3>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">
                    Invoiced today (Showroom POS &amp; Web)
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/15 border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Today's Ledger
              </span>
            </div>

            {/* Core Metric Display */}
            <div className="flex items-baseline justify-between pt-1">
              <div>
                <div className="text-2xl font-bold font-serif-luxury tabular-nums text-[var(--theme-text)]">
                  {currencySymbol}{todayCombinedTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                  {todayCombinedTxCount} transactions ({todayPOSTx.length} POS · {todayOrders.length} Online)
                </div>
              </div>

              {/* Surface Area Invoiced */}
              <div className="text-right">
                <div className="flex items-center gap-1 text-xs font-bold font-mono text-[var(--theme-accent)]">
                  <Layers className="w-3.5 h-3.5" />
                  <span>{todayTotalSqM.toFixed(1)} m²</span>
                </div>
                <span className="text-[10px] text-[var(--theme-text-muted)]">
                  specimens sold
                </span>
              </div>
            </div>

            {/* Channel Breakdown Cards */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[var(--theme-border)]">
              {/* Showroom POS Terminal */}
              <div className="p-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
                <div className="flex items-center justify-between text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <CreditCard className="w-3 h-3 text-emerald-500" />
                    Showroom POS
                  </span>
                  <span className="font-mono">{todayPOSTx.length} tickets</span>
                </div>
                <div className="text-sm font-bold font-mono text-[var(--theme-text)]">
                  {currencySymbol}{todayPOSTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <span className="text-[9px] text-[var(--theme-text-muted)] block truncate">
                  Terminal #1 (Ridge West)
                </span>
              </div>

              {/* Online Architecture Store */}
              <div className="p-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
                <div className="flex items-center justify-between text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-[var(--theme-accent)]" />
                    Online Store
                  </span>
                  <span className="font-mono">{todayOrders.length} orders</span>
                </div>
                <div className="text-sm font-bold font-mono text-[var(--theme-text)]">
                  {currencySymbol}{todayOnlineTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <span className="text-[9px] text-[var(--theme-text-muted)] block truncate">
                  Paystack &amp; Bank Direct
                </span>
              </div>
            </div>

            {/* Tender Distribution */}
            <div className="space-y-1 pt-1">
              <div className="flex items-center justify-between text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider">
                <span>Tender Distribution:</span>
                <span className="font-mono">ATV: {currencySymbol}{averageTicketValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap text-[10px] font-mono">
                {cardTotal > 0 && (
                  <span className="px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] flex items-center gap-1">
                    <CreditCard className="w-3 h-3 text-blue-500" />
                    Card: {currencySymbol}{cardTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                )}
                {momoTotal > 0 && (
                  <span className="px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] flex items-center gap-1">
                    <Smartphone className="w-3 h-3 text-amber-500" />
                    MoMo: {currencySymbol}{momoTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                )}
                {cashTotal > 0 && (
                  <span className="px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] flex items-center gap-1">
                    <Banknote className="w-3 h-3 text-emerald-500" />
                    Cash: {currencySymbol}{cashTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                )}
                {bankOrPaystackTotal > 0 && (
                  <span className="px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] flex items-center gap-1">
                    <Layers className="w-3 h-3 text-purple-500" />
                    Web/Bank: {currencySymbol}{bankOrPaystackTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Links */}
          <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)]">
            <Link
              href="/admin/pos"
              className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Open POS Terminal</span>
            </Link>
            <Link
              href="/admin/orders"
              className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] flex items-center gap-1"
            >
              <span>All Orders</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* ========================================================= */}
        {/* CARD 3: PENDING & LIVE VIDEO CONSULTATIONS */}
        {/* ========================================================= */}
        <div className="p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            {/* Header row */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xs bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30">
                  <Video className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text)]">
                    Video Consultations
                  </h3>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">
                    Face-to-face concierge &amp; slab match
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              {liveParticipantsCount > 0 ? (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/15 border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  {liveParticipantsCount} In Live Session
                </span>
              ) : (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]">
                  {availableRooms.length} Desks Ready
                </span>
              )}
            </div>

            {/* Core Metric Display */}
            <div className="flex items-baseline justify-between pt-1">
              <div>
                <div className="text-2xl font-bold font-serif-luxury tabular-nums text-[var(--theme-text)]">
                  {activeRooms.length}
                  <span className="text-xs font-sans font-normal text-[var(--theme-text-muted)] ml-1.5">
                    consultation rooms
                  </span>
                </div>
                <div className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                  Ridge West showroom concierge desk
                </div>
              </div>

              {/* Mini Pill Breakdown */}
              <div className="flex items-center gap-1.5 text-[10px] font-mono">
                <span className={`px-1.5 py-0.5 border font-bold ${
                  liveParticipantsCount > 0 
                    ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20' 
                    : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] border-[var(--theme-border)]'
                }`}>
                  live: {liveRooms.length}
                </span>
                <span className="px-1.5 py-0.5 bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] border border-[var(--theme-border)]">
                  locked: {lockedRooms.length}
                </span>
              </div>
            </div>

            {/* Room Stream: Top 2 Rooms */}
            <div className="space-y-2 pt-1 border-t border-[var(--theme-border)]">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)] block">
                Active Client Consultation Rooms:
              </span>

              {activeRooms.length === 0 ? (
                <div className="p-3 bg-[var(--theme-surface-subtle)] text-[11px] text-[var(--theme-text-muted)] text-center">
                  No consultation rooms currently registered.
                </div>
              ) : (
                activeRooms.slice(0, 2).map(room => {
                  const isLive = (room.activeParticipantsCount || 0) > 0;
                  return (
                    <div
                      key={room.id}
                      className="p-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-colors space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="truncate">
                          <span className="text-xs font-semibold text-[var(--theme-text)] truncate block">
                            {room.name}
                          </span>
                          <span className="text-[10px] text-[var(--theme-text-muted)] truncate flex items-center gap-1">
                            <UserCheck className="w-3 h-3 text-[var(--theme-accent)]" />
                            {room.clientName || 'General Client'} 
                            {room.clientRole && ` · ${room.clientRole}`}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {room.isLocked ? (
                            <span className="p-1 text-amber-600 bg-amber-500/10 rounded-xs" title="Locked by Admin">
                              <Lock className="w-3 h-3" />
                            </span>
                          ) : (
                            <span className="p-1 text-emerald-600 bg-emerald-500/10 rounded-xs" title="Unlocked & Available">
                              <Unlock className="w-3 h-3" />
                            </span>
                          )}

                          {isLive ? (
                            <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                              {room.activeParticipantsCount} ONLINE
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 text-[9px] font-mono bg-zinc-200 dark:bg-zinc-800 text-[var(--theme-text-muted)]">
                              STANDBY
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Presenting Slab Banner if assigned */}
                      {room.presentingSlab && (
                        <div className="text-[10px] font-mono bg-[var(--theme-surface)] px-2 py-0.5 border border-[var(--theme-border)] text-[var(--theme-accent)] flex items-center justify-between">
                          <span className="truncate">Specimen: {room.presentingSlab.name}</span>
                          <span className="shrink-0">{room.scheduledTime || 'Live On-Demand'}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Action Links */}
          <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)]">
            <Link
              href="/admin/video-consultations"
              className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Open Call Desk &amp; Rooms</span>
            </Link>
            <Link
              href={`/video-consultation?room=${firstAvailableRoomId}`}
              className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] flex items-center gap-1"
            >
              <span>Join Active Room</span>
              <ExternalLink className="w-3 h-3" />
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
};
