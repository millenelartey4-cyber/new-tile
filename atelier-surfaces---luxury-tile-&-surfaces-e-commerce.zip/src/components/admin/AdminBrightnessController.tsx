import React, { useState, useEffect } from 'react';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { PanelBrightnessConfig } from '../../types';
import { Link } from '../../router/Router';
import { 
  Sun, 
  Lock, 
  Unlock, 
  Save, 
  CheckCircle2, 
  Sliders, 
  RotateCcw, 
  Sparkles, 
  Layers, 
  Layout, 
  CreditCard, 
  X,
  Globe,
  ExternalLink
} from 'lucide-react';

interface AdminBrightnessControllerProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigChange?: (config: PanelBrightnessConfig) => void;
  onUpdate?: (config: PanelBrightnessConfig) => void;
}

export function AdminBrightnessController({ isOpen, onClose, onConfigChange, onUpdate }: AdminBrightnessControllerProps) {
  const { currentUser } = useAuth();
  const { activeCompany } = useCompany();

  const [config, setConfig] = useState<PanelBrightnessConfig>(() => storeService.getPanelBrightness(activeCompany.id));
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [modalTab, setModalTab] = useState<'storefront' | 'admin'>('storefront');

  const notifyChange = (cfg: PanelBrightnessConfig) => {
    if (onConfigChange) onConfigChange(cfg);
    if (onUpdate) onUpdate(cfg);
  };

  useEffect(() => {
    const loaded = storeService.getPanelBrightness(activeCompany.id);
    setConfig(loaded);
  }, [activeCompany.id, isOpen]);

  if (!isOpen) return null;

  const handleSliderChange = (panel: keyof PanelBrightnessConfig, value: number) => {
    if (config.isLocked) return;
    const next = { ...config, [panel]: value };
    setConfig(next);
    notifyChange(next);
  };

  const handleApplyPreset = (brightnessLevel: number, contrastLevel: number = 100) => {
    if (config.isLocked) return;
    const next: PanelBrightnessConfig = {
      ...config,
      sidebarBrightness: brightnessLevel,
      sidebarContrast: contrastLevel,
      headerBrightness: brightnessLevel,
      headerContrast: contrastLevel,
      workspaceBrightness: brightnessLevel,
      workspaceContrast: contrastLevel,
      cardsBrightness: brightnessLevel,
      cardsContrast: contrastLevel,
      posBrightness: brightnessLevel,
      posContrast: contrastLevel,
      storefrontHeaderBrightness: brightnessLevel,
      storefrontHeaderContrast: contrastLevel,
      storefrontHeroBrightness: brightnessLevel,
      storefrontHeroContrast: contrastLevel,
      storefrontCatalogBrightness: brightnessLevel,
      storefrontCatalogContrast: contrastLevel,
      storefrontSpecimenBrightness: brightnessLevel,
      storefrontSpecimenContrast: contrastLevel,
      storefrontFooterBrightness: brightnessLevel,
      storefrontFooterContrast: contrastLevel,
    };
    setConfig(next);
    notifyChange(next);
  };

  const handleToggleLock = () => {
    const nextLocked = !config.isLocked;
    const updated = storeService.togglePanelBrightnessLock(nextLocked, currentUser?.name, activeCompany.id);
    const newConfig = {
      ...config,
      isLocked: updated,
      lockedBy: updated ? currentUser?.name : undefined,
      lockedAt: updated ? new Date().toISOString() : undefined,
    };
    setConfig(newConfig);
    notifyChange(newConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    storeService.updatePanelBrightness(config, currentUser?.name, activeCompany.id);
    notifyChange(config);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    if (config.isLocked) return;
    const defaults: PanelBrightnessConfig = {
      sidebarBrightness: 100,
      sidebarContrast: 100,
      headerBrightness: 100,
      headerContrast: 100,
      workspaceBrightness: 100,
      workspaceContrast: 100,
      cardsBrightness: 100,
      cardsContrast: 100,
      posBrightness: 100,
      posContrast: 100,
      storefrontHeaderBrightness: 100,
      storefrontHeaderContrast: 100,
      storefrontHeroBrightness: 100,
      storefrontHeroContrast: 100,
      storefrontCatalogBrightness: 100,
      storefrontCatalogContrast: 100,
      storefrontSpecimenBrightness: 100,
      storefrontSpecimenContrast: 100,
      storefrontFooterBrightness: 100,
      storefrontFooterContrast: 100,
      isLocked: false,
    };
    setConfig(defaults);
    notifyChange(defaults);
  };

  const storefrontPanels = [
    {
      id: 'storefrontHeader',
      label: 'Storefront Navigation & Top Header',
      description: 'Controls public navbar illumination and brand wordmark reflectivity.',
      icon: Layout,
      brightnessKey: 'storefrontHeaderBrightness' as const,
      contrastKey: 'storefrontHeaderContrast' as const,
    },
    {
      id: 'storefrontHero',
      label: 'Storefront Hero Showcase & Billboard',
      description: 'Controls luminance of the flagship hero banner image and typography.',
      icon: Sparkles,
      brightnessKey: 'storefrontHeroBrightness' as const,
      contrastKey: 'storefrontHeroContrast' as const,
    },
    {
      id: 'storefrontCatalog',
      label: 'Product Catalog & Slabs Gallery Grid',
      description: 'Adjusts illumination of category cards, product slab specimens, and swatches.',
      icon: Layers,
      brightnessKey: 'storefrontCatalogBrightness' as const,
      contrastKey: 'storefrontCatalogContrast' as const,
    },
    {
      id: 'storefrontSpecimen',
      label: 'Slab Specimen Inspection & Zoom Canvas',
      description: 'Controls slab veining clarity, 2D photometry lighting simulator, and 3D studio.',
      icon: Sun,
      brightnessKey: 'storefrontSpecimenBrightness' as const,
      contrastKey: 'storefrontSpecimenContrast' as const,
    },
    {
      id: 'storefrontFooter',
      label: 'Public Storefront Footer & Showroom Depot',
      description: 'Controls footer contrast, showroom address (GA-110-3849), and contact phone.',
      icon: CreditCard,
      brightnessKey: 'storefrontFooterBrightness' as const,
      contrastKey: 'storefrontFooterContrast' as const,
    },
  ];

  const adminPanels = [
    {
      id: 'sidebar',
      label: 'Sidebar Navigation Panel',
      description: 'Controls contrast and illumination of the left admin navigation dock.',
      icon: Layout,
      brightnessKey: 'sidebarBrightness' as const,
      contrastKey: 'sidebarContrast' as const,
    },
    {
      id: 'header',
      label: 'Top Header & App Bar Panel',
      description: 'Controls luminance of breadcrumbs, company switcher, and utility actions.',
      icon: Sun,
      brightnessKey: 'headerBrightness' as const,
      contrastKey: 'headerContrast' as const,
    },
    {
      id: 'workspace',
      label: 'Main Content & Tables Workspace',
      description: 'Controls canvas illumination for product lists, orders, and reports.',
      icon: Layers,
      brightnessKey: 'workspaceBrightness' as const,
      contrastKey: 'workspaceContrast' as const,
    },
    {
      id: 'cards',
      label: 'Dashboard KPI Cards & Modals',
      description: 'Controls background radiance and surface contrast of statistical cards.',
      icon: Sparkles,
      brightnessKey: 'cardsBrightness' as const,
      contrastKey: 'cardsContrast' as const,
    },
    {
      id: 'pos',
      label: 'POS Register & Cashier Panel',
      description: 'Adjusts showroom Point of Sale screen brightness for daylight vs indoor glare.',
      icon: CreditCard,
      brightnessKey: 'posBrightness' as const,
      contrastKey: 'posContrast' as const,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div 
        className="bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] max-w-3xl w-full shadow-2xl rounded-xs overflow-hidden my-8"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-6 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xs bg-[var(--theme-accent)]/15 text-[var(--theme-accent)] flex items-center justify-center">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif-luxury text-xl font-bold text-[var(--theme-text)]">
                  Panel Luminance & Brightness Calibration
                </h2>
                <span className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded-xs ${
                  config.isLocked
                    ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}>
                  {config.isLocked ? 'LOCKED BY ADMIN' : 'UNLOCKED (EDITABLE)'}
                </span>
              </div>
              <p className="text-xs text-[var(--theme-text-muted)] mt-0.5">
                Adjust each panel's individual brightness and contrast, save configurations, and lock settings across administrative consoles.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] rounded-xs transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert */}
        {saveSuccess && (
          <div className="mx-6 mt-4 p-3 bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 rounded-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="font-semibold">
              Panel brightness configuration and security lock saved successfully!
            </span>
          </div>
        )}

        {/* Lock Banner if Locked */}
        {config.isLocked && (
          <div className="mx-6 mt-4 p-3.5 bg-red-950/20 border border-red-500/40 rounded-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-red-400 font-semibold">
              <Lock className="w-4 h-4 shrink-0" />
              <span>
                Panel brightness adjustments are currently locked by {config.lockedBy || 'Super Admin'}. Unlock to adjust sliders.
              </span>
            </div>

            <button
              type="button"
              onClick={handleToggleLock}
              className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] uppercase rounded-xs transition cursor-pointer self-start sm:self-auto flex items-center gap-1"
            >
              <Unlock className="w-3 h-3" />
              <span>Unlock Panels</span>
            </button>
          </div>
        )}

        {/* Quick Presets Bar */}
        <div className="px-6 pt-5 pb-2 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--theme-border)]">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider">
              Quick Presets:
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                disabled={config.isLocked}
                onClick={() => handleApplyPreset(75, 95)}
                className="px-2.5 py-1 text-[11px] font-semibold bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs disabled:opacity-50 cursor-pointer"
              >
                Dim (75%)
              </button>
              <button
                type="button"
                disabled={config.isLocked}
                onClick={() => handleApplyPreset(100, 100)}
                className="px-2.5 py-1 text-[11px] font-semibold bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs disabled:opacity-50 cursor-pointer"
              >
                Standard (100%)
              </button>
              <button
                type="button"
                disabled={config.isLocked}
                onClick={() => handleApplyPreset(120, 105)}
                className="px-2.5 py-1 text-[11px] font-semibold bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs disabled:opacity-50 cursor-pointer"
              >
                Vivid (120%)
              </button>
              <button
                type="button"
                disabled={config.isLocked}
                onClick={() => handleApplyPreset(135, 110)}
                className="px-2.5 py-1 text-[11px] font-semibold bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs disabled:opacity-50 cursor-pointer"
              >
                High-Contrast (135%)
              </button>
            </div>
          </div>

          <button
            type="button"
            disabled={config.isLocked}
            onClick={handleResetDefaults}
            className="text-[11px] text-[var(--theme-accent)] hover:underline font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-50"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset All to 100%</span>
          </button>
        </div>

        {/* Tab Switcher: Public Storefront Panels vs Admin Console Panels */}
        <div className="px-6 pt-3 flex items-center justify-between border-b border-[var(--theme-border)] text-xs">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setModalTab('storefront')}
              className={`pb-2 font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-colors ${
                modalTab === 'storefront'
                  ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                  : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Public Storefront Panels ({storefrontPanels.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setModalTab('admin')}
              className={`pb-2 font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-colors ${
                modalTab === 'admin'
                  ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                  : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
              }`}
            >
              <Layout className="w-3.5 h-3.5" />
              <span>Admin & POS Panels ({adminPanels.length})</span>
            </button>
          </div>

          <Link
            href="/admin/settings/brightness"
            onClick={onClose}
            className="text-[11px] text-[var(--theme-accent)] hover:underline font-semibold flex items-center gap-1 pb-2"
          >
            <span>Full Studio</span>
            <ExternalLink className="w-3 h-3" />
          </Link>
        </div>

        {/* Panel Sliders List */}
        <div className="p-6 space-y-5 max-h-[55vh] overflow-y-auto divide-y divide-[var(--theme-border)]">
          {(modalTab === 'storefront' ? storefrontPanels : adminPanels).map((p, idx) => {
            const Icon = p.icon;
            const currentBrightness = (config as any)[p.brightnessKey] || 100;
            const currentContrast = (config as any)[p.contrastKey] || 100;

            return (
              <div key={p.id} className={`space-y-3 ${idx > 0 ? 'pt-5' : ''}`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xs bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center text-[var(--theme-accent)]">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xs uppercase text-[var(--theme-text)]">
                        {p.label}
                      </h3>
                      <p className="text-[11px] text-[var(--theme-text-muted)]">
                        {p.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-auto">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)]">
                      {currentBrightness}%
                    </span>
                    <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                      (Contrast: {currentContrast}%)
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  {/* Brightness Slider */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-bold uppercase text-[var(--theme-text-muted)]">
                      <span>Brightness (50% – 150%)</span>
                      <span className="tabular-nums">{currentBrightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="150"
                      step="1"
                      disabled={config.isLocked}
                      value={currentBrightness}
                      onChange={e => handleSliderChange(p.brightnessKey, parseInt(e.target.value, 10))}
                      className="w-full accent-[var(--theme-accent)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    />
                  </div>

                  {/* Contrast Slider */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-bold uppercase text-[var(--theme-text-muted)]">
                      <span>Contrast (80% – 125%)</span>
                      <span className="tabular-nums">{currentContrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="80"
                      max="125"
                      step="1"
                      disabled={config.isLocked}
                      value={currentContrast}
                      onChange={e => handleSliderChange(p.contrastKey, parseInt(e.target.value, 10))}
                      className="w-full accent-[var(--theme-accent)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-6 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleToggleLock}
            className={`px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              config.isLocked
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
            }`}
          >
            {config.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            <span>{config.isLocked ? 'Unlock Panel Brightness' : 'Lock Brightness Settings'}</span>
          </button>

          <div className="flex items-center gap-2 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:bg-[var(--theme-surface)] transition cursor-pointer"
            >
              Close
            </button>

            <button
              type="button"
              onClick={() => handleSave()}
              className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Apply Brightness</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
