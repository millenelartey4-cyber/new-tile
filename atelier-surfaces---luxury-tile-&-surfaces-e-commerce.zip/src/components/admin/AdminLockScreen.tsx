import React, { useState, useRef, useEffect } from 'react';
import { useRouter } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { storeService } from '../../services/store';
import { 
  Lock, 
  Unlock, 
  ShieldCheck, 
  AlertTriangle, 
  Eye, 
  EyeOff, 
  ArrowLeft, 
  Sparkles,
  KeyRound,
  CheckCircle2
} from 'lucide-react';

interface AdminLockScreenProps {
  targetPath?: string;
  onUnlockSuccess?: () => void;
}

export function AdminLockScreen({ targetPath = '/admin', onUnlockSuccess }: AdminLockScreenProps) {
  const { navigate } = useRouter();
  const { unlockAdminConsole } = useAuth();
  const settings = storeService.getStoreSettings();

  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [shake, setShake] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Auto focus password input on load
    inputRef.current?.focus();
  }, []);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || isVerifying || isSuccess) return;

    setError(null);
    setIsVerifying(true);

    setTimeout(() => {
      const result = unlockAdminConsole(password);
      if (result.success) {
        setIsSuccess(true);
        setIsVerifying(false);
        // Brief success feedback before transitioning
        setTimeout(() => {
          if (onUnlockSuccess) {
            onUnlockSuccess();
          } else {
            navigate(targetPath);
          }
        }, 400);
      } else {
        setIsVerifying(false);
        setError(result.error || 'Incorrect admin password. Access denied.');
        setShake(true);
        setTimeout(() => setShake(false), 600);
        inputRef.current?.select();
      }
    }, 250);
  };

  return (
    <div className="min-h-screen bg-[#111110] text-[#EDE8DF] flex flex-col justify-between selection:bg-[#B3874B] selection:text-white relative overflow-hidden font-sans">
      
      {/* Background Architectural Geometry Grid */}
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #B3874B 1px, transparent 0)`,
          backgroundSize: '36px 36px'
        }}
      />

      {/* Subtle Ambient Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-[#B3874B]/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Bar with Brand & Back Link */}
      <header className="p-6 sm:p-8 flex items-center justify-between relative z-10">
        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#9E988E] hover:text-white transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
          <span>Return to Storefront</span>
        </button>

        <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-widest text-[#B3874B]">
          <span className="w-2 h-2 rounded-full bg-[#B3874B] animate-pulse" />
          <span>Protected Gate</span>
        </div>
      </header>

      {/* Center Lock Authentication Card */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 relative z-10">
        <div className={`max-w-md w-full bg-[#181816] border border-[#2B2925] p-8 sm:p-10 shadow-2xl space-y-6 transition-transform duration-200 ${shake ? 'animate-bounce' : ''}`}>
          
          {/* Lock Icon & Brand Header */}
          <div className="text-center space-y-3">
            <div className="relative mx-auto w-16 h-16 rounded-full bg-[#201F1B] border border-[#B3874B]/40 flex items-center justify-center shadow-inner">
              {isSuccess ? (
                <CheckCircle2 className="w-8 h-8 text-emerald-400 animate-in zoom-in-75 duration-200" />
              ) : (
                <Lock className="w-8 h-8 text-[#B3874B]" />
              )}
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-[#B3874B] block">
                {settings.brandName || 'ATELIER SURFACES'}
              </span>
              <h1 className="font-serif-luxury text-2xl sm:text-3xl font-semibold text-white mt-1">
                Admin Console
              </h1>
              <p className="text-xs text-[#9E988E] mt-2 leading-relaxed">
                Protected system area. Please enter your administrator password to access catalog controls, inventory, orders, and studio settings.
              </p>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3.5 bg-red-950/40 border border-red-800/60 text-red-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-semibold">Access Denied</strong>
                <span className="text-[11px] opacity-90">{error}</span>
              </div>
            </div>
          )}

          {/* Success Notification */}
          {isSuccess && (
            <div className="p-3.5 bg-emerald-950/40 border border-emerald-800/60 text-emerald-200 text-xs flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Password verified. Opening Control Console...</span>
            </div>
          )}

          {/* Password Form */}
          <form onSubmit={handleUnlock} className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label 
                  htmlFor="admin-password-input" 
                  className="font-bold uppercase tracking-wider text-[11px] text-[#CFC9BD]"
                >
                  Admin Password
                </label>
                <span className="text-[10px] text-[#9E988E] font-mono">
                  Master Security Key
                </span>
              </div>

              <div className="relative">
                <input
                  id="admin-password-input"
                  ref={inputRef}
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  disabled={isVerifying || isSuccess}
                  placeholder="••••••••••••"
                  autoComplete="current-password"
                  className="w-full pl-10 pr-11 py-3 bg-[#111110] border border-[#2B2925] text-white text-xs placeholder:text-[#5E5A54] focus:outline-none focus:border-[#B3874B] focus:ring-1 focus:ring-[#B3874B] transition-colors tracking-widest"
                />
                
                <KeyRound className="w-4 h-4 text-[#9E988E] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1.5 text-[#9E988E] hover:text-white absolute right-3 top-1/2 -translate-y-1/2 transition-colors cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                  tabIndex={-1}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4 text-[#B3874B]" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={!password.trim() || isVerifying || isSuccess}
              className="w-full py-3.5 bg-[#B3874B] hover:bg-[#C2965A] active:bg-[#9E733B] disabled:opacity-50 text-white text-xs font-bold uppercase tracking-widest transition-all cursor-pointer shadow-lg shadow-[#B3874B]/20 flex items-center justify-center gap-2"
            >
              {isVerifying ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : isSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Unlocked</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>Unlock Admin Console</span>
                </>
              )}
            </button>
          </form>

          {/* Confidential Notice */}
          <div className="pt-4 border-t border-[#2B2925] space-y-2 text-center">
            <div className="flex items-center justify-center gap-1.5 text-xs text-[#9E988E]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#B3874B]" />
              <span className="text-[11px] font-semibold uppercase tracking-wider">Confidential Administrator Terminal</span>
            </div>
            <p className="text-[10px] text-[#6E6A63] leading-relaxed">
              Authorized personnel only. When finished making catalog, inventory, or theme modifications, click <strong>"Lock Console"</strong> to secure access.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="p-6 text-center text-[11px] text-[#6E6A63] relative z-10 border-t border-[#1C1B19]">
        <span>Encrypted Management Gate · {settings.brandName || 'Atelier Surfaces'} · Accra, Ghana</span>
      </footer>
    </div>
  );
}
