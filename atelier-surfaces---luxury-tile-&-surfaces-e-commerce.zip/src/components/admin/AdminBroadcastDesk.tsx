import { useState, useEffect, useMemo } from 'react';
import { storeService } from '../../services/store';
import { 
  AdminBroadcast, 
  BroadcastAudience, 
  BroadcastUrgency, 
  BroadcastPlacement 
} from '../../types';
import { useCompany } from '../../context/CompanyContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Radio, 
  Megaphone, 
  Lock, 
  Unlock, 
  Save, 
  Edit3, 
  Trash2, 
  Plus, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Info, 
  Bell, 
  Users, 
  UserCheck, 
  Eye, 
  Volume2, 
  ExternalLink, 
  KeyRound, 
  X, 
  Clock, 
  Sparkles,
  RefreshCw,
  Search,
  Filter,
  AlertCircle
} from 'lucide-react';

export function AdminBroadcastDesk() {
  const { activeCompany } = useCompany();
  const { currentUser } = useAuth();
  const [dataVersion, setDataVersion] = useState(0);

  // Filter state
  const [audienceFilter, setAudienceFilter] = useState<'all' | 'staff' | 'customers' | 'active' | 'locked'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Composer / Editor modal state
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [editingBroadcast, setEditingBroadcast] = useState<AdminBroadcast | null>(null);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formMessage, setFormMessage] = useState('');
  const [formAudience, setFormAudience] = useState<BroadcastAudience>('all');
  const [formUrgency, setFormUrgency] = useState<BroadcastUrgency>('critical');
  const [formPlacement, setFormPlacement] = useState<BroadcastPlacement>('top_banner');
  const [formActionLabel, setFormActionLabel] = useState('');
  const [formActionUrl, setFormActionUrl] = useState('');
  const [formSoundAlert, setFormSoundAlert] = useState(true);
  const [formLockOnSave, setFormLockOnSave] = useState(false);
  const [formError, setFormError] = useState('');

  // Admin authentication / unlock modal
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [unlockTargetId, setUnlockTargetId] = useState<string | null>(null);
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockError, setUnlockError] = useState('');
  const [unlockPurpose, setUnlockPurpose] = useState<'unlock_broadcast' | 'edit_locked' | 'delete_locked'>('unlock_broadcast');

  // Preview modal
  const [previewBroadcast, setPreviewBroadcast] = useState<AdminBroadcast | null>(null);

  // Toast feedback
  const [feedbackToast, setFeedbackToast] = useState<{ title: string; message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Listen to storage and real-time broadcast events
  useEffect(() => {
    const handleSync = () => setDataVersion(v => v + 1);
    window.addEventListener('atelier_broadcast_updated', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('atelier_broadcast_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Fetch broadcasts
  const broadcasts = useMemo(() => {
    return storeService.getBroadcasts(activeCompany.id);
  }, [activeCompany.id, dataVersion]);

  // Statistics
  const activeCount = broadcasts.filter(b => b.active).length;
  const lockedCount = broadcasts.filter(b => b.isLocked).length;
  const criticalCount = broadcasts.filter(b => b.urgency === 'critical' && b.active).length;
  const staffOnlyCount = broadcasts.filter(b => b.audience === 'staff').length;
  const customerCount = broadcasts.filter(b => b.audience === 'customers').length;

  // Filtered broadcasts
  const filteredBroadcasts = useMemo(() => {
    return broadcasts.filter(b => {
      if (audienceFilter === 'active' && !b.active) return false;
      if (audienceFilter === 'locked' && !b.isLocked) return false;
      if (audienceFilter === 'staff' && b.audience !== 'staff') return false;
      if (audienceFilter === 'customers' && b.audience !== 'customers') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return b.title.toLowerCase().includes(q) || b.message.toLowerCase().includes(q);
      }
      return true;
    });
  }, [broadcasts, audienceFilter, searchQuery]);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setFeedbackToast({ title, message, type });
    setTimeout(() => setFeedbackToast(null), 4000);
  };

  // Open composer for creating new broadcast
  const handleOpenCreate = () => {
    setEditingBroadcast(null);
    setFormTitle('');
    setFormMessage('');
    setFormAudience('all');
    setFormUrgency('critical');
    setFormPlacement('top_banner');
    setFormActionLabel('');
    setFormActionUrl('');
    setFormSoundAlert(true);
    setFormLockOnSave(false);
    setFormError('');
    setIsComposerOpen(true);
  };

  // Open composer for editing existing broadcast
  const handleOpenEdit = (broadcast: AdminBroadcast) => {
    if (broadcast.isLocked) {
      setUnlockTargetId(broadcast.id);
      setUnlockPurpose('edit_locked');
      setUnlockPassword('');
      setUnlockError('');
      setIsUnlockModalOpen(true);
      return;
    }

    setEditingBroadcast(broadcast);
    setFormTitle(broadcast.title);
    setFormMessage(broadcast.message);
    setFormAudience(broadcast.audience);
    setFormUrgency(broadcast.urgency);
    setFormPlacement(broadcast.placement);
    setFormActionLabel(broadcast.actionLabel || '');
    setFormActionUrl(broadcast.actionUrl || '');
    setFormSoundAlert(!!broadcast.soundAlert);
    setFormLockOnSave(broadcast.isLocked);
    setFormError('');
    setIsComposerOpen(true);
  };

  // Handle save & broadcast
  const handleSaveBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formMessage.trim()) {
      setFormError('Please enter both announcement title and message body.');
      return;
    }

    try {
      const saved = storeService.saveBroadcast({
        id: editingBroadcast?.id,
        tenantId: activeCompany.id,
        title: formTitle.trim(),
        message: formMessage.trim(),
        audience: formAudience,
        urgency: formUrgency,
        placement: formPlacement,
        actionLabel: formActionLabel.trim() || undefined,
        actionUrl: formActionUrl.trim() || undefined,
        active: true,
        isLocked: formLockOnSave,
        soundAlert: formSoundAlert
      }, currentUser?.name || 'Administrator', activeCompany.id);

      setIsComposerOpen(false);
      setDataVersion(v => v + 1);
      showToast(
        editingBroadcast ? 'Broadcast Updated & Dispatched' : 'Urgent Broadcast Published',
        `Announcement "${saved.title}" sent to ${saved.audience.toUpperCase()} and synced live.`,
        'success'
      );
    } catch (err: any) {
      setFormError(err.message || 'Failed to save broadcast announcement.');
    }
  };

  // Handle Lock / Unlock click
  const handleToggleLockClick = (broadcast: AdminBroadcast) => {
    if (broadcast.isLocked) {
      // Prompt for admin authentication
      setUnlockTargetId(broadcast.id);
      setUnlockPurpose('unlock_broadcast');
      setUnlockPassword('');
      setUnlockError('');
      setIsUnlockModalOpen(true);
    } else {
      // Lock immediately
      storeService.toggleBroadcastLock(broadcast.id, true, currentUser?.name, activeCompany.id);
      setDataVersion(v => v + 1);
      showToast(
        'Broadcast Message Locked',
        `"${broadcast.title}" is locked against modification or dismissal.`,
        'info'
      );
    }
  };

  // Confirm Unlock with Admin Password
  const handleConfirmUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const input = unlockPassword.trim();
    const valid = activeCompany.adminPassword || 'admin123';

    if (input === valid || input === 'admin123' || currentUser?.roleId === 'super-admin') {
      if (unlockTargetId) {
        if (unlockPurpose === 'unlock_broadcast') {
          storeService.toggleBroadcastLock(unlockTargetId, false, currentUser?.name, activeCompany.id);
          setIsUnlockModalOpen(false);
          setDataVersion(v => v + 1);
          showToast('Broadcast Unlocked', 'Administrator credentials verified. Message controls unlocked.', 'success');
        } else if (unlockPurpose === 'edit_locked') {
          const target = broadcasts.find(b => b.id === unlockTargetId);
          setIsUnlockModalOpen(false);
          if (target) {
            setEditingBroadcast(target);
            setFormTitle(target.title);
            setFormMessage(target.message);
            setFormAudience(target.audience);
            setFormUrgency(target.urgency);
            setFormPlacement(target.placement);
            setFormActionLabel(target.actionLabel || '');
            setFormActionUrl(target.actionUrl || '');
            setFormSoundAlert(!!target.soundAlert);
            setFormLockOnSave(false);
            setFormError('');
            setIsComposerOpen(true);
          }
        }
      }
    } else {
      setUnlockError('Invalid administrator password. Default is "admin123" or company credentials.');
    }
  };

  // Toggle active/inactive
  const handleToggleActive = (broadcast: AdminBroadcast) => {
    try {
      const nextActive = !broadcast.active;
      storeService.toggleBroadcastActive(broadcast.id, nextActive, currentUser?.name, activeCompany.id);
      setDataVersion(v => v + 1);
      showToast(
        nextActive ? 'Broadcast Activated' : 'Broadcast Paused',
        `Message is ${nextActive ? 'now live across in-app banners' : 'hidden from users'}.`,
        'info'
      );
    } catch (err: any) {
      showToast('Action Blocked', err.message, 'error');
    }
  };

  // Delete broadcast
  const handleDelete = (broadcast: AdminBroadcast) => {
    if (broadcast.isLocked) {
      showToast('Cannot Delete', 'This broadcast is locked. Unlock before deleting.', 'error');
      return;
    }
    if (confirm(`Permanently delete broadcast announcement "${broadcast.title}"?`)) {
      storeService.deleteBroadcast(broadcast.id, currentUser?.name, activeCompany.id);
      setDataVersion(v => v + 1);
      showToast('Broadcast Removed', 'The message has been permanently deleted.', 'info');
    }
  };

  return (
    <section 
      aria-label="Admin Broadcast System"
      className="bg-stone-900 border-2 border-stone-800 text-stone-100 shadow-xl p-5 space-y-4"
    >
      {/* Toast Feedback */}
      {feedbackToast && (
        <div 
          className={`p-3.5 border text-xs flex items-center justify-between gap-3 shadow-lg transition-all animate-in fade-in duration-200 ${
            feedbackToast.type === 'success' 
              ? 'bg-emerald-950 border-emerald-500/70 text-emerald-200' 
              : feedbackToast.type === 'error'
              ? 'bg-red-950 border-red-500/70 text-red-200'
              : 'bg-stone-950 border-cyan-500/70 text-cyan-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {feedbackToast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : feedbackToast.type === 'error' ? (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-cyan-400 shrink-0" />
            )}
            <div>
              <strong className="font-bold uppercase tracking-wider block text-[11px]">{feedbackToast.title}</strong>
              <span className="text-[12px] opacity-90">{feedbackToast.message}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setFeedbackToast(null)}
            className="text-stone-400 hover:text-stone-100 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Control Desk Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-stone-800 pb-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 bg-red-950/80 text-red-300 border border-red-800 font-bold flex items-center gap-1.5">
              <Megaphone className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              <span>Admin Broadcast System</span>
            </span>
            <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 bg-stone-800 text-stone-300 border border-stone-700">
              Workspace: <strong className="text-stone-100">{activeCompany.name}</strong>
            </span>
            <span className="text-[10px] font-mono text-stone-400">
              Operator: <strong className="text-stone-200">{currentUser?.name || 'Administrator'}</strong>
            </span>
          </div>
          <h2 className="text-base font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
            <span>Urgent Notifications, Store Banners & Staff Advisories</span>
          </h2>
          <p className="text-[11px] text-stone-400">
            Publish real-time banners and pop-up notifications to Showroom Staff (POS), online Trade Architects, or storefront customers. Edit, save, and lock messages after administrator authentication.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 flex-wrap shrink-0">
          <button
            type="button"
            onClick={handleOpenCreate}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-md font-mono"
          >
            <Plus className="w-4 h-4" />
            <span>Send Urgent Broadcast</span>
          </button>
        </div>
      </div>

      {/* Quick Status KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
        <div className="bg-stone-950 border border-stone-800 p-3 space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-[10px] uppercase font-mono">
            <span>Total Broadcasts</span>
            <Megaphone className="w-3.5 h-3.5 text-stone-500" />
          </div>
          <div className="text-lg font-bold font-mono text-stone-100">{broadcasts.length}</div>
        </div>

        <div className="bg-stone-950 border border-stone-800 p-3 space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-[10px] uppercase font-mono">
            <span>Live Active</span>
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          </div>
          <div className="text-lg font-bold font-mono text-emerald-400">{activeCount} Active</div>
        </div>

        <div className="bg-stone-950 border border-stone-800 p-3 space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-[10px] uppercase font-mono">
            <span>Admin Locked</span>
            <Lock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-400">{lockedCount} Locked</div>
        </div>

        <div className="bg-stone-950 border border-stone-800 p-3 space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-[10px] uppercase font-mono">
            <span>Critical Alerts</span>
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
          </div>
          <div className="text-lg font-bold font-mono text-red-400">{criticalCount} Critical</div>
        </div>

        <div className="bg-stone-950 border border-stone-800 p-3 space-y-1 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-stone-400 text-[10px] uppercase font-mono">
            <span>Audience Scope</span>
            <Users className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xs font-mono text-stone-300">
            {staffOnlyCount} Staff · {customerCount} Cust
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
        <div className="flex items-center gap-1.5 flex-wrap overflow-x-auto text-[11px] font-mono">
          <button
            type="button"
            onClick={() => setAudienceFilter('all')}
            className={`px-3 py-1.5 border uppercase font-bold tracking-wider cursor-pointer transition-colors ${
              audienceFilter === 'all'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
            }`}
          >
            All Broadcasts ({broadcasts.length})
          </button>
          <button
            type="button"
            onClick={() => setAudienceFilter('active')}
            className={`px-3 py-1.5 border uppercase font-bold tracking-wider cursor-pointer transition-colors ${
              audienceFilter === 'active'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60'
                : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
            }`}
          >
            Active ({activeCount})
          </button>
          <button
            type="button"
            onClick={() => setAudienceFilter('locked')}
            className={`px-3 py-1.5 border uppercase font-bold tracking-wider cursor-pointer transition-colors ${
              audienceFilter === 'locked'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
            }`}
          >
            Locked ({lockedCount})
          </button>
          <button
            type="button"
            onClick={() => setAudienceFilter('staff')}
            className={`px-3 py-1.5 border uppercase font-bold tracking-wider cursor-pointer transition-colors ${
              audienceFilter === 'staff'
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60'
                : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
            }`}
          >
            Staff Only ({staffOnlyCount})
          </button>
          <button
            type="button"
            onClick={() => setAudienceFilter('customers')}
            className={`px-3 py-1.5 border uppercase font-bold tracking-wider cursor-pointer transition-colors ${
              audienceFilter === 'customers'
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/60'
                : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
            }`}
          >
            Customers Only ({customerCount})
          </button>
        </div>

        <div className="relative shrink-0 sm:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search announcement text..."
            className="w-full pl-8 pr-3 py-1.5 bg-stone-950 border border-stone-800 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
          />
          <Search className="w-3.5 h-3.5 text-stone-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      {/* Broadcast Cards Grid */}
      <div className="space-y-3">
        {filteredBroadcasts.length === 0 ? (
          <div className="bg-stone-950/60 border border-stone-800 p-8 text-center text-stone-400 text-xs space-y-2">
            <Megaphone className="w-8 h-8 text-stone-600 mx-auto" />
            <p className="font-bold text-stone-300">No broadcasts found matching your filter criteria.</p>
            <p className="text-[11px] text-stone-500">Click "Send Urgent Broadcast" above to dispatch a new in-app announcement.</p>
          </div>
        ) : (
          filteredBroadcasts.map(bc => {
            const isCritical = bc.urgency === 'critical';
            const isWarning = bc.urgency === 'warning';
            const isSuccess = bc.urgency === 'success';

            return (
              <div
                key={bc.id}
                className={`border p-4 transition-all duration-150 space-y-3 ${
                  bc.active 
                    ? isCritical 
                      ? 'bg-red-950/20 border-red-800/80 shadow-md' 
                      : isWarning
                      ? 'bg-amber-950/20 border-amber-800/80'
                      : 'bg-stone-950 border-stone-800'
                    : 'bg-stone-950/40 border-stone-800/60 opacity-60'
                }`}
              >
                {/* Card Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Urgency Badge */}
                    <span className={`text-[10px] font-mono uppercase px-2 py-0.5 border font-bold ${
                      isCritical 
                        ? 'bg-red-950 text-red-300 border-red-700' 
                        : isWarning
                        ? 'bg-amber-950 text-amber-300 border-amber-700'
                        : isSuccess
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                        : 'bg-cyan-950 text-cyan-300 border-cyan-700'
                    }`}>
                      {bc.urgency.toUpperCase()}
                    </span>

                    {/* Audience Badge */}
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 bg-stone-800 text-stone-300 border border-stone-700 flex items-center gap-1">
                      <Users className="w-3 h-3 text-stone-400" />
                      <span>{bc.audience === 'all' ? 'Storewide (All)' : bc.audience === 'staff' ? 'Staff Only (POS/Warehouse)' : 'Storefront Customers'}</span>
                    </span>

                    {/* Placement Badge */}
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 bg-stone-900 text-stone-400 border border-stone-800">
                      {bc.placement === 'top_banner' ? 'Top Sticky Banner' : bc.placement === 'modal' ? 'Priority Modal' : 'Toast'}
                    </span>

                    {/* Active / Inactive Badge */}
                    {bc.active ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>BROADCASTING LIVE</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono text-stone-500 bg-stone-900 border border-stone-800 px-2 py-0.5">
                        PAUSED / INACTIVE
                      </span>
                    )}

                    {/* Lock Status Pill */}
                    {bc.isLocked ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-mono text-amber-400 bg-amber-950/70 border border-amber-800 px-2 py-0.5 font-bold">
                        <Lock className="w-3 h-3" />
                        <span>ADMIN LOCKED</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-mono text-stone-400 bg-stone-900 border border-stone-800 px-1.5 py-0.5">
                        <Unlock className="w-3 h-3" />
                        <span>Unlocked</span>
                      </span>
                    )}
                  </div>

                  {/* Metadata */}
                  <div className="text-[10px] font-mono text-stone-500 flex items-center gap-2">
                    <Clock className="w-3 h-3 text-stone-500" />
                    <span>Updated: {new Date(bc.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} by {bc.createdBy}</span>
                  </div>
                </div>

                {/* Message Body */}
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-stone-100 flex items-center gap-2">
                    <span>{bc.title}</span>
                  </h3>
                  <p className="text-xs text-stone-300 leading-relaxed font-sans">
                    {bc.message}
                  </p>
                </div>

                {/* Card Action Controls & Buttons */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-stone-900 text-xs">
                  <div className="flex items-center gap-2 flex-wrap text-[11px] text-stone-400">
                    {bc.actionLabel && bc.actionUrl && (
                      <span className="inline-flex items-center gap-1 text-cyan-400 bg-cyan-950/40 border border-cyan-800/80 px-2 py-0.5 font-mono">
                        <ExternalLink className="w-3 h-3" />
                        <span>CTA: {bc.actionLabel} &rarr; {bc.actionUrl}</span>
                      </span>
                    )}
                    {bc.soundAlert && (
                      <span className="inline-flex items-center gap-1 text-amber-400 bg-amber-950/40 border border-amber-800/80 px-2 py-0.5 font-mono">
                        <Volume2 className="w-3 h-3" />
                        <span>Chime Active</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Live Preview Button */}
                    <button
                      type="button"
                      onClick={() => setPreviewBroadcast(bc)}
                      className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-stone-300 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 border border-stone-700 cursor-pointer"
                      title="Preview how this appears in banner"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Preview</span>
                    </button>

                    {/* Active / Inactive Toggle */}
                    <button
                      type="button"
                      onClick={() => handleToggleActive(bc)}
                      className={`px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 border cursor-pointer transition-colors ${
                        bc.active 
                          ? 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-800' 
                          : 'bg-stone-900 hover:bg-stone-800 text-stone-400 border-stone-700'
                      }`}
                      title={bc.active ? 'Pause this broadcast' : 'Activate live broadcast'}
                    >
                      <Radio className="w-3 h-3" />
                      <span>{bc.active ? 'Active' : 'Paused'}</span>
                    </button>

                    {/* Lock / Unlock Toggle Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleLockClick(bc)}
                      className={`px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 border cursor-pointer transition-colors ${
                        bc.isLocked 
                          ? 'bg-amber-950/80 hover:bg-amber-900 text-amber-300 border-amber-700' 
                          : 'bg-stone-900 hover:bg-stone-800 text-stone-300 border-stone-700'
                      }`}
                      title={bc.isLocked ? 'Authenticate with admin credentials to unlock' : 'Lock to prevent accidental modification or dismissal'}
                    >
                      {bc.isLocked ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3 text-stone-400" />}
                      <span>{bc.isLocked ? 'Unlock Message' : 'Lock Message'}</span>
                    </button>

                    {/* Edit Message Button */}
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(bc)}
                      className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 border border-stone-700 cursor-pointer"
                      title={bc.isLocked ? 'Unlock message to edit' : 'Edit broadcast details'}
                    >
                      <Edit3 className="w-3 h-3 text-cyan-400" />
                      <span>Edit</span>
                    </button>

                    {/* Delete Button */}
                    <button
                      type="button"
                      onClick={() => handleDelete(bc)}
                      disabled={bc.isLocked}
                      className={`px-2 py-1 text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 border transition-colors ${
                        bc.isLocked
                          ? 'bg-stone-900 text-stone-600 border-stone-800 cursor-not-allowed'
                          : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border-red-800 cursor-pointer'
                      }`}
                      title={bc.isLocked ? 'Cannot delete locked broadcast' : 'Delete broadcast'}
                    >
                      <Trash2 className="w-3 h-3 text-red-400" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ========================================================= */}
      {/* COMPOSER / EDIT MODAL                                     */}
      {/* ========================================================= */}
      {isComposerOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border-2 border-stone-700 w-full max-w-2xl p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-500/20 border border-red-500/40 text-red-400">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-100 uppercase tracking-wide">
                    {editingBroadcast ? 'Edit In-App Broadcast Message' : 'Author Urgent Admin Broadcast'}
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Workspace: <strong className="text-stone-200">{activeCompany.name}</strong> · Dispatches in real time to connected users
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsComposerOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-red-950/80 border border-red-500/60 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveBroadcast} className="space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                  Announcement Headline *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="e.g. Urgent Freight Clearance: Calacatta Statuario Shipments Arrived"
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500 font-sans"
                />
              </div>

              {/* Message Body */}
              <div>
                <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                  Broadcast Message Body *
                </label>
                <textarea
                  required
                  rows={3}
                  value={formMessage}
                  onChange={e => setFormMessage(e.target.value)}
                  placeholder="Enter the full announcement or urgent instructions for staff and customers..."
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500 font-sans leading-relaxed"
                />
              </div>

              {/* Target Audience & Urgency Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Target Audience */}
                <div>
                  <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                    Target Audience
                  </label>
                  <select
                    value={formAudience}
                    onChange={e => setFormAudience(e.target.value as BroadcastAudience)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-200 focus:outline-none focus:border-red-500 font-mono"
                  >
                    <option value="all">Storewide (Everyone: Staff & Customers)</option>
                    <option value="staff">Staff Only (POS Terminal & Warehouse)</option>
                    <option value="customers">Customers Only (Storefront & Trade Portals)</option>
                  </select>
                  <p className="text-[10px] text-stone-500 mt-1">
                    Controls whether this banner appears in administrative tools, public catalog, or both.
                  </p>
                </div>

                {/* Urgency Level */}
                <div>
                  <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                    Urgency Priority Level
                  </label>
                  <select
                    value={formUrgency}
                    onChange={e => setFormUrgency(e.target.value as BroadcastUrgency)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-200 focus:outline-none focus:border-red-500 font-mono"
                  >
                    <option value="critical">Critical (High-priority emergency / vessel arrival)</option>
                    <option value="warning">Warning (Operational notice / stock recount)</option>
                    <option value="info">Showroom Info (Quarry news / event invitation)</option>
                    <option value="success">Dispatch Success (Restocked / promotion active)</option>
                  </select>
                </div>
              </div>

              {/* Placement & Call to Action */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Placement */}
                <div>
                  <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                    In-App Placement
                  </label>
                  <select
                    value={formPlacement}
                    onChange={e => setFormPlacement(e.target.value as BroadcastPlacement)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-200 focus:outline-none focus:border-red-500 font-mono"
                  >
                    <option value="top_banner">Top Sticky Banner</option>
                    <option value="modal">Priority Modal Pop-up</option>
                  </select>
                </div>

                {/* Action Label */}
                <div>
                  <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                    Action CTA Label (Optional)
                  </label>
                  <input
                    type="text"
                    value={formActionLabel}
                    onChange={e => setFormActionLabel(e.target.value)}
                    placeholder="e.g. Inspect Allocations"
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500"
                  />
                </div>

                {/* Action URL */}
                <div>
                  <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                    Action Target URL (Optional)
                  </label>
                  <input
                    type="text"
                    value={formActionUrl}
                    onChange={e => setFormActionUrl(e.target.value)}
                    placeholder="e.g. /admin/inventory or /shop"
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Checkboxes: Audio alert & Master Lock protection */}
              <div className="p-3 bg-stone-950 border border-stone-800 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formSoundAlert}
                    onChange={e => setFormSoundAlert(e.target.checked)}
                    className="rounded-xs border-stone-700 text-red-600 focus:ring-0"
                  />
                  <span className="text-stone-200 font-semibold flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Trigger Attention Audio Chime on Client Display</span>
                  </span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer pt-1 border-t border-stone-900">
                  <input
                    type="checkbox"
                    checked={formLockOnSave}
                    onChange={e => setFormLockOnSave(e.target.checked)}
                    className="rounded-xs border-stone-700 text-amber-600 focus:ring-0"
                  />
                  <span className="text-amber-300 font-semibold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Lock Message upon Save (Prevents unauthorized editing and disables user dismissal)</span>
                  </span>
                </label>
              </div>

              {/* Form Buttons */}
              <div className="flex justify-end gap-2.5 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsComposerOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white uppercase font-bold tracking-wider text-xs flex items-center gap-2 cursor-pointer shadow-md font-mono"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save & Apply Live Broadcast</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ADMIN AUTHENTICATION / UNLOCK PIN MODAL                   */}
      {/* ========================================================= */}
      {isUnlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border-2 border-amber-600/70 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/20 border border-amber-500/40 text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-100 uppercase tracking-wide">
                    Administrator Authentication
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Unlock Protected Broadcast Message
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUnlockModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {unlockError && (
              <div className="p-3 bg-red-950/80 border border-red-500/60 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{unlockError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmUnlock} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                  Administrator Master Password
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={unlockPassword}
                  onChange={e => setUnlockPassword(e.target.value)}
                  placeholder="Enter administrator password..."
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[10px] text-stone-500 mt-1">
                  Default credentials: <code className="text-amber-400">admin123</code> or active company admin credentials.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsUnlockModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md font-mono"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Authenticate & Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* BANNER PREVIEW MODAL                                      */}
      {/* ========================================================= */}
      {previewBroadcast && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-2xl p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-cyan-400" />
                <h3 className="font-serif text-base font-bold text-stone-100 uppercase tracking-wide">
                  Live Banner Preview Simulation
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewBroadcast(null)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-400">
              This is how the broadcast renders to recipients targeting <strong>{previewBroadcast.audience.toUpperCase()}</strong>:
            </p>

            {/* Simulated Banner Container */}
            <div className={`p-3.5 border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              previewBroadcast.urgency === 'critical'
                ? 'bg-red-950 border-red-600 text-red-100'
                : previewBroadcast.urgency === 'warning'
                ? 'bg-amber-950 border-amber-600 text-amber-100'
                : 'bg-stone-950 border-stone-700 text-stone-100'
            }`}>
              <div className="flex items-start sm:items-center gap-2.5 flex-1 min-w-0">
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-black/50 border border-white/20">
                      {previewBroadcast.urgency.toUpperCase()}
                    </span>
                    <strong className="text-xs">{previewBroadcast.title}</strong>
                  </div>
                  <p className="text-[11px] opacity-90">{previewBroadcast.message}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {previewBroadcast.actionLabel && (
                  <span className="px-3 py-1 bg-white text-stone-950 text-[11px] font-bold uppercase tracking-wider">
                    {previewBroadcast.actionLabel}
                  </span>
                )}
                {previewBroadcast.isLocked ? (
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-black/60 text-amber-400 border border-amber-500/40 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>Locked</span>
                  </span>
                ) : (
                  <span className="text-stone-400 p-1">
                    <X className="w-4 h-4" />
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setPreviewBroadcast(null)}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 uppercase font-bold text-xs cursor-pointer font-mono"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
