import React, { useRef, useEffect, useState } from 'react';
import { useVideoCall } from '../../context/VideoCallContext';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  PhoneOff, 
  MessageSquare, 
  Sparkles, 
  Share2, 
  Copy, 
  Check, 
  Layers, 
  Maximize2, 
  Minimize2, 
  Sun, 
  Flame, 
  Lamp,
  ShieldCheck,
  User,
  Radio,
  X,
  Camera,
  RefreshCw
} from 'lucide-react';
import { ThreeDTextureStudio } from '../product/ThreeDTextureStudio';
import { SurfaceLightingSimulator } from '../product/SurfaceLightingSimulator';
import { storeService } from '../../services/store';
import { useCompany } from '../../context/CompanyContext';
import { Product, ProductVariant } from '../../types';
import { ShowroomLiveVideoFeed } from './ShowroomLiveVideoFeed';

export const VideoCallStage: React.FC = () => {
  const {
    localStream,
    isCameraMuted,
    isMicMuted,
    isChatOpen,
    feedMode,
    participants,
    presentingSlab,
    callDuration,
    toggleCamera,
    toggleMic,
    toggleChat,
    switchVideoFeed,
    endCall,
    presentSlab,
    stopPresenting,
    activeRoomId,
  } = useVideoCall();

  const { activeCompany } = useCompany();
  const catalogProducts = storeService.getProducts(activeCompany.id);
  const matchedProduct = catalogProducts.find(
    p => p.name.toLowerCase() === (presentingSlab?.name || '').toLowerCase()
  ) || catalogProducts[0];
  const fallbackProduct = catalogProducts[0];
  const presentationProduct: Product = matchedProduct ? {
    ...matchedProduct,
    name: presentingSlab?.name || matchedProduct.name,
  } : fallbackProduct;

  const presentationVariant: ProductVariant = presentationProduct?.variants?.[0] || {
    id: 'var-pres-def',
    colorName: 'Calacatta Gold',
    colorHex: '#D4AF37',
    sku: 'CAL-01',
    images: [presentingSlab?.image || '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'],
    price: presentingSlab?.price || 485,
    stock: 100,
    lowStockThreshold: 10,
    unit: 'm²',
    boxCoverage: 2.88,
    active: true,
  };

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [swappedPiP, setSwappedPiP] = useState(false);
  const [presentationLight, setPresentationLight] = useState<'daylight' | 'warm' | 'cool'>('daylight');

  // Attach local media stream to video element
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
      localVideoRef.current.play().catch(err => {
        console.warn('Local video auto-playback deferred by browser:', err);
      });
    }
  }, [localStream, isCameraMuted]);

  // Format call duration
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopyLink = () => {
    const callUrl = `${window.location.origin}/video-consultation?room=${activeRoomId}`;
    navigator.clipboard.writeText(callUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const consultant = participants.find(p => p.role === 'consultant') || {
    id: 'consultant-kwame',
    name: 'Kwame Mensah',
    role: 'consultant',
    cameraOn: true,
    micOn: true,
  };

  return (
    <div className="flex-1 bg-stone-950 flex flex-col relative overflow-hidden min-h-[500px]">
      
      {/* Top Floating Utility Bar */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2.5 pointer-events-auto">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-black/60 backdrop-blur-md border border-white/10 text-white rounded-full text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="font-bold">{formatTime(callDuration)}</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-black/60 backdrop-blur-md border border-white/10 text-stone-300 rounded-full text-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span className="font-medium">Atelier Private Showroom Tunnel</span>
          </div>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={handleCopyLink}
            className="px-3 py-1.5 bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/15 text-white text-xs font-semibold rounded-full flex items-center gap-1.5 transition cursor-pointer shadow-lg"
            title="Invite client or colleague to this video call"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />}
            <span>{copiedLink ? 'Link Copied!' : 'Copy Invite Link'}</span>
          </button>
        </div>
      </div>

      {/* Main Video & Presentation Workspace */}
      <div className="flex-1 relative flex items-center justify-center p-4">
        
        {presentingSlab ? (
          /* Presentation Mode: 3D Slab Center Stage + Video bubbles */
          <div className="w-full h-full flex flex-col rounded-sm overflow-hidden bg-stone-900 border border-stone-800 relative animate-in fade-in duration-300">
            {/* Header info bar */}
            <div className="p-3 bg-stone-950/80 border-b border-stone-800 flex items-center justify-between text-xs text-white">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[var(--theme-accent)] animate-pulse" />
                <span className="font-serif-luxury font-bold text-sm tracking-wide">
                  Shared Specimen Presentation: {presentingSlab.name || 'Calacatta Statuario'}
                </span>
              </div>
              <button
                onClick={stopPresenting}
                className="px-2.5 py-1 bg-red-950/60 hover:bg-red-900/80 border border-red-700/60 text-red-200 text-[11px] font-bold uppercase tracking-wider rounded-xs transition flex items-center gap-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Stop Presenting</span>
              </button>
            </div>

            {/* Presentation Stage Content */}
            <div className="flex-1 relative bg-stone-950 flex items-center justify-center p-6">
              <div className="max-w-2xl w-full h-[400px]">
                <ThreeDTextureStudio
                  product={presentationProduct}
                  variant={presentationVariant}
                  onClose={stopPresenting}
                />
              </div>
            </div>

            {/* Floating Dual Video Bubbles in Presentation Mode */}
            <div className="absolute bottom-20 right-6 flex items-center gap-3 z-30">
              {/* Consultant Bubble (Active Video) */}
              <div className="w-40 h-28 bg-stone-900 rounded-sm border-2 border-[var(--theme-accent)] overflow-hidden relative shadow-2xl">
                <ShowroomLiveVideoFeed
                  consultantName={consultant.name}
                  showOverlay={false}
                  className="w-full h-full"
                  aspectRatio="aspect-auto"
                />
                <div className="absolute bottom-1 left-1 right-1 bg-black/80 px-2 py-0.5 rounded-xs flex items-center justify-between text-[9px] text-white">
                  <span className="font-bold truncate">{consultant.name}</span>
                  <span className="text-emerald-400 font-mono">LIVE ●</span>
                </div>
              </div>

              {/* Local User Bubble (Active Video) */}
              <div className="w-40 h-28 bg-stone-900 rounded-sm border-2 border-emerald-500 overflow-hidden relative shadow-2xl">
                {!isCameraMuted && localStream ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                ) : (
                  <div className="w-full h-full bg-stone-900 flex flex-col items-center justify-center p-2 text-center text-stone-400">
                    <User className="w-8 h-8 text-stone-500 mb-1" />
                    <span className="text-[10px] font-bold text-white">You</span>
                    <span className="text-[8px] text-amber-400">Camera Off</span>
                  </div>
                )}
                <div className="absolute bottom-1 left-1 right-1 bg-black/80 px-2 py-0.5 rounded-xs flex items-center justify-between text-[9px] text-white">
                  <span className="font-bold">You</span>
                  <span className="text-emerald-400 font-mono">ACTIVE ●</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Face-to-Face Dual Video Stage */
          <div className="w-full h-full grid grid-cols-1 md:grid-cols-2 gap-4 max-w-6xl">
            
            {/* Participant 1: Remote Consultant View (Active 1080p Video Stream) */}
            <div className="bg-stone-900 border border-stone-800 rounded-sm overflow-hidden relative flex flex-col items-center justify-center group shadow-2xl min-h-[340px]">
              <ShowroomLiveVideoFeed
                consultantName={consultant.name}
                consultantTitle="Lead Architectural Consultant"
                showroomLocation="Accra Flagship Showroom · Ridge West"
                className="w-full h-full"
                aspectRatio="aspect-auto"
                showOverlay={true}
              />
            </div>

            {/* Participant 2: Local User View (Active Video Stream with WebRTC / Canvas Feed) */}
            <div className="bg-stone-900 border border-stone-800 rounded-sm overflow-hidden relative flex flex-col items-center justify-center shadow-2xl min-h-[340px]">
              
              {!isCameraMuted && localStream ? (
                <div className="w-full h-full relative group">
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />

                  {/* Top Feed Source Selector HUD */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs text-white z-10">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-black/75 backdrop-blur-md border border-white/10 rounded-full font-mono text-[10px]">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="font-bold tracking-wider">
                        {feedMode === 'webcam' ? 'PHYSICAL WEBCAM · 1080p' : 'VIRTUAL STUDIO CAMERA · 1080p'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => switchVideoFeed(feedMode === 'webcam' ? 'virtual' : 'webcam')}
                      className="px-2.5 py-1 bg-black/70 hover:bg-black/90 backdrop-blur-md border border-[var(--theme-accent)]/50 text-[10px] uppercase font-bold text-[var(--theme-accent)] rounded-full transition cursor-pointer flex items-center gap-1.5 shadow-md"
                      title="Switch between physical webcam and simulated studio camera feed"
                    >
                      <Camera className="w-3 h-3 text-[var(--theme-accent)]" />
                      <span>{feedMode === 'webcam' ? 'Use Studio Stream' : 'Use Physical Webcam'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center space-y-4">
                  <div className="w-20 h-20 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center text-stone-400">
                    <User className="w-10 h-10" />
                  </div>
                  <div>
                    <h4 className="font-serif-luxury text-lg font-bold text-white">
                      Your Video Feed Is Off
                    </h4>
                    <p className="text-xs text-stone-400 mt-1 max-w-xs">
                      Click below to activate your video stream for face-to-face consultation.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={toggleCamera}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs transition flex items-center gap-2 cursor-pointer shadow-lg"
                  >
                    <Video className="w-4 h-4" />
                    <span>Turn On Video Stream</span>
                  </button>
                </div>
              )}

              {/* Local User Bottom Nameplate */}
              <div className="absolute bottom-3 left-3 right-3 z-20 flex items-center justify-between text-xs text-white bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xs border border-white/10">
                <div className="flex items-center gap-2 truncate">
                  <span className={`w-2 h-2 rounded-full ${isCameraMuted ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                  <span className="font-semibold truncate">You (Client / Architect)</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.2 bg-white/10 text-stone-300 uppercase rounded-xs">
                    {feedMode}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {isMicMuted ? (
                    <span className="flex items-center gap-1 text-[10px] text-red-400">
                      <MicOff className="w-3 h-3" /> Muted
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                      <Mic className="w-3 h-3" /> Mic Active
                    </span>
                  )}
                </div>
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Persistent Bottom Control Bar */}
      <div className="p-4 bg-stone-900/95 border-t border-stone-800 flex items-center justify-between gap-4 z-20">
        
        {/* Left Side: Room Tag */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-stone-400">
          <Radio className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span className="font-mono text-stone-300">Room: {activeRoomId}</span>
        </div>

        {/* Center: Main Call Action Buttons */}
        <div className="flex items-center gap-3 mx-auto sm:mx-0">
          
          {/* Mic Toggle */}
          <button
            onClick={toggleMic}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition cursor-pointer shadow-lg ${
              isMicMuted
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-white border border-stone-700'
            }`}
            title={isMicMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Camera Toggle */}
          <button
            onClick={toggleCamera}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition cursor-pointer shadow-lg ${
              isCameraMuted
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-white border border-stone-700'
            }`}
            title={isCameraMuted ? 'Turn video on' : 'Turn video off'}
          >
            {isCameraMuted ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          {/* Feed Mode Switcher */}
          <button
            type="button"
            onClick={() => switchVideoFeed(feedMode === 'webcam' ? 'virtual' : 'webcam')}
            className="hidden md:flex items-center gap-1.5 px-3.5 h-11 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 rounded-full text-xs font-semibold transition cursor-pointer"
            title={`Current: ${feedMode}. Click to switch between physical webcam and virtual studio camera feed`}
          >
            <Camera className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span className="font-mono text-[11px]">{feedMode === 'webcam' ? 'Webcam Feed' : 'Studio Cam'}</span>
          </button>

          {/* Toggle Chat */}
          <button
            onClick={toggleChat}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition cursor-pointer shadow-lg ${
              isChatOpen
                ? 'bg-[var(--theme-accent)] text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-white border border-stone-700'
            }`}
            title="Toggle Live Consultation Chat"
          >
            <MessageSquare className="w-5 h-5" />
          </button>

          {/* End Call Button */}
          <button
            onClick={endCall}
            className="px-5 h-11 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider rounded-full flex items-center gap-2 transition cursor-pointer shadow-lg"
            title="End Video Consultation"
          >
            <PhoneOff className="w-4 h-4" />
            <span className="hidden sm:inline">Leave Call</span>
          </button>
        </div>

        {/* Right Side: Quick Specimen Present Button */}
        <div className="hidden sm:flex items-center gap-2">
          {!presentingSlab && (
            <button
              onClick={() => {
                // Present default Calacatta specimen
                const defaultSlab = {
                  name: 'Calacatta Statuario Imperiale',
                  material: 'Italian Sintered Porcelain Slab',
                  price: 485,
                  image: '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'
                };
                presentSlab(defaultSlab);
              }}
              className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xs border border-stone-700 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Present 3D Slab</span>
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
