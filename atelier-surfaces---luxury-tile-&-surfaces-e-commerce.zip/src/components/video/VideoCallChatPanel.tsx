import React, { useState, useRef, useEffect } from 'react';
import { useVideoCall, VideoMessage } from '../../context/VideoCallContext';
import { storeService } from '../../services/store';
import { useCompany } from '../../context/CompanyContext';
import { 
  Send, 
  MessageSquare, 
  Layers, 
  Sparkles, 
  X, 
  Check, 
  DollarSign, 
  ExternalLink,
  ChevronDown,
  Info
} from 'lucide-react';

export const VideoCallChatPanel: React.FC = () => {
  const { messages, sendMessage, presentSlab } = useVideoCall();
  const { activeCompany } = useCompany();
  const products = storeService.getProducts(activeCompany.id);

  const [inputVal, setInputVal] = useState('');
  const [showSlabPicker, setShowSlabPicker] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    const text = inputVal;
    setInputVal('');
    await sendMessage(text);
  };

  const handleShareProduct = async (prod: any) => {
    const variant = prod.variants?.[0] || {};
    const price = variant.price || prod.price || 0;
    const currency = activeCompany.currency || 'GHS';

    await sendMessage(`Shared Material Specimen: ${prod.name}`, {
      type: 'slab',
      title: prod.name,
      image: variant.images?.[0] || prod.thumbnail || '/assets/images/category_porcelain_floors_1792523066985.jpg',
      price,
      currency,
      sku: variant.sku || prod.sku,
      details: `${prod.material || 'Porcelain'} · ${variant.finish || 'Honed'} · ${variant.dimensions || '60x120 cm'}`
    });

    setShowSlabPicker(false);
  };

  return (
    <div className="w-full lg:w-96 bg-[var(--theme-surface)] border-l border-[var(--theme-border)] flex flex-col h-full text-[var(--theme-text)]">
      
      {/* Header */}
      <div className="p-4 border-b border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-[var(--theme-accent)]" />
          <h3 className="font-serif-luxury font-bold text-sm tracking-wide">
            Live Consultation Chat
          </h3>
        </div>
        <span className="text-[10px] font-mono uppercase px-2 py-0.5 bg-emerald-500/20 text-emerald-400 font-bold rounded-xs">
          Encrypted
        </span>
      </div>

      {/* Message Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
        {messages.map(msg => {
          const isConsultant = msg.role === 'consultant';
          const isSystem = msg.senderId === 'sys-concierge';

          return (
            <div 
              key={msg.id} 
              className={`space-y-1.5 ${isSystem ? 'opacity-90' : ''}`}
            >
              <div className="flex items-center justify-between text-[10px] text-[var(--theme-text-muted)]">
                <span className={`font-bold ${isConsultant ? 'text-[var(--theme-accent)]' : 'text-[var(--theme-text)]'}`}>
                  {msg.sender}
                </span>
                <span className="tabular-nums">{msg.timestamp}</span>
              </div>

              <div className={`p-3 rounded-xs leading-relaxed ${
                isSystem
                  ? 'bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] italic text-[11px]'
                  : isConsultant
                  ? 'bg-[var(--theme-accent)]/10 border border-[var(--theme-accent)]/30 text-[var(--theme-text)]'
                  : 'bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}>
                <p>{msg.content}</p>

                {/* Shared Slab Attachment */}
                {msg.attachment && (
                  <div className="mt-2.5 p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs space-y-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-12 h-12 bg-stone-900 border border-[var(--theme-border)] rounded-xs overflow-hidden shrink-0">
                        <img 
                          src={msg.attachment.image?.startsWith('/src/assets/') ? msg.attachment.image.replace('/src/assets/', '/assets/') : msg.attachment.image} 
                          alt={msg.attachment.title} 
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                          }}
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="font-serif-luxury font-bold text-xs truncate block text-[var(--theme-text)]">
                          {msg.attachment.title}
                        </span>
                        <span className="text-[10px] text-[var(--theme-text-muted)] block">
                          {msg.attachment.details}
                        </span>
                        <span className="text-[11px] font-bold text-[var(--theme-accent)]">
                          {msg.attachment.currency} {msg.attachment.price} / m²
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => presentSlab({
                        name: msg.attachment?.title,
                        material: 'Luxury Surface Slab',
                        price: msg.attachment?.price,
                        image: msg.attachment?.image
                      })}
                      className="w-full py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-[10px] uppercase tracking-wider hover:opacity-90 transition flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-[var(--theme-accent)]" />
                      <span>Inspect 3D Slab Together</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Specimen Picker Tray */}
      {showSlabPicker && (
        <div className="p-3 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] max-h-48 overflow-y-auto space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-[var(--theme-text)] mb-1">
            <span>Select Material to Share:</span>
            <button 
              onClick={() => setShowSlabPicker(false)}
              className="text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-1 gap-1.5">
            {products.slice(0, 5).map(p => (
              <button
                key={p.id}
                onClick={() => handleShareProduct(p)}
                className="p-2 bg-[var(--theme-surface)] hover:bg-white/5 border border-[var(--theme-border)] text-left flex items-center justify-between gap-2 text-xs transition cursor-pointer"
              >
                <div className="truncate">
                  <span className="font-semibold block truncate">{p.name}</span>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">{p.material}</span>
                </div>
                <span className="font-mono text-[10px] font-bold text-[var(--theme-accent)] shrink-0">
                  + Share
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chat Input & Fast Prompts */}
      <div className="p-3 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] space-y-2">
        
        {/* Quick Question Chips */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px]">
          <button
            onClick={() => setShowSlabPicker(!showSlabPicker)}
            className="px-2.5 py-1 bg-[var(--theme-surface)] border border-[var(--theme-accent)]/40 hover:border-[var(--theme-accent)] text-[var(--theme-accent)] font-semibold whitespace-nowrap flex items-center gap-1 cursor-pointer"
          >
            <Layers className="w-3 h-3" />
            <span>Share Slab Specimen</span>
          </button>
          <button
            onClick={() => setInputVal('What is the water absorption rate for this porcelain?')}
            className="px-2 py-1 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] whitespace-nowrap cursor-pointer"
          >
            Water Absorption?
          </button>
          <button
            onClick={() => setInputVal('Can we get trade pricing for 150m² delivery to Ridge West?')}
            className="px-2 py-1 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] whitespace-nowrap cursor-pointer"
          >
            Trade Pricing?
          </button>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="flex gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            placeholder="Type message to consultant..."
            className="flex-1 px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <button
            type="submit"
            disabled={!inputVal.trim()}
            className="px-3.5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 disabled:opacity-40 transition flex items-center justify-center cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

    </div>
  );
};
