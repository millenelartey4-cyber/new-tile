import React, { useRef, useEffect, useState } from 'react';
import { Video, ShieldCheck, Sparkles, Volume2, VolumeX, Maximize2, Radio } from 'lucide-react';
import { createVirtualMediaStream } from '../../utils/videoStreamGenerator';

interface ShowroomLiveVideoFeedProps {
  consultantName?: string;
  consultantTitle?: string;
  showroomLocation?: string;
  className?: string;
  showOverlay?: boolean;
  isInteractive?: boolean;
  aspectRatio?: string;
  onJoinClick?: () => void;
}

export const ShowroomLiveVideoFeed: React.FC<ShowroomLiveVideoFeedProps> = ({
  consultantName = 'Kwame Mensah',
  consultantTitle = 'Lead Architectural Consultant',
  showroomLocation = '14 Independence Avenue, Ridge West, Accra',
  className = '',
  showOverlay = true,
  isInteractive = true,
  aspectRatio = 'aspect-[16/9]',
  onJoinClick,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isAudioMuted, setIsAudioMuted] = useState(true);
  const [feedMode, setFeedMode] = useState<'showroom' | 'slab-inspection' | 'architectural'>('showroom');
  const [timeElapsed, setTimeElapsed] = useState(0);

  // Initialize synthesized live showroom stream
  useEffect(() => {
    try {
      const stream = createVirtualMediaStream({
        participantName: consultantName,
        role: 'consultant',
        isConsultant: true,
        width: 1280,
        height: 720,
        fps: 30,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(err => {
          console.warn('Video autoPlay prevented, user interaction required:', err);
        });
      }
    } catch (err) {
      console.warn('Could not initialize video stream:', err);
    }

    const timer = setInterval(() => {
      setTimeElapsed(prev => prev + 1);
    }, 1000);

    return () => {
      clearInterval(timer);
      if (streamRef.current) {
        (streamRef.current as any).stopVirtualStream?.();
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, [consultantName]);

  const formatTimecode = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`relative bg-stone-950 overflow-hidden border border-stone-800 rounded-sm shadow-2xl group ${aspectRatio} ${className}`}>
      
      {/* Active HTML5 Video Player displaying synthesized live stream */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted={isAudioMuted}
        loop
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.02]"
      />

      {/* Fallback Animated Canvas in case <video> srcObject is delayed */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Visual Ambient Scanline / Grade Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-transparent to-stone-950/40 pointer-events-none" />

      {/* Top Stream Status HUD */}
      {showOverlay && (
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs text-white z-10 pointer-events-none">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-black/70 backdrop-blur-md border border-white/10 rounded-full font-mono text-[11px]">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="font-bold tracking-wider">LIVE HD · 1080p</span>
            </div>
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-black/60 backdrop-blur-md border border-white/10 rounded-full text-stone-300 font-mono text-[10px]">
              <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>{formatTimecode(timeElapsed)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={() => setIsAudioMuted(!isAudioMuted)}
              className="p-1.5 bg-black/60 hover:bg-black/90 backdrop-blur-md border border-white/15 rounded-full text-stone-300 hover:text-white transition cursor-pointer"
              title={isAudioMuted ? 'Unmute Showroom Audio' : 'Mute Showroom Audio'}
            >
              {isAudioMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            </button>
          </div>
        </div>
      )}

      {/* Bottom Consultant Card & Controls */}
      {showOverlay && (
        <div className="absolute bottom-3 left-3 right-3 z-10">
          <div className="bg-black/75 backdrop-blur-md border border-white/15 p-3 rounded-xs flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative shrink-0">
                <div className="w-9 h-9 rounded-full bg-[var(--theme-accent)]/20 border border-[var(--theme-accent)] flex items-center justify-center font-bold text-xs text-[var(--theme-accent)]">
                  KM
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-stone-900" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-serif-luxury font-bold text-xs text-white truncate block">
                    {consultantName}
                  </span>
                  <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xs font-bold">
                    Connected
                  </span>
                </div>
                <span className="text-[10px] text-stone-300 truncate block">
                  {consultantTitle} · {showroomLocation}
                </span>
              </div>
            </div>

            {onJoinClick && (
              <button
                type="button"
                onClick={onJoinClick}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold uppercase tracking-wider rounded-xs transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer shadow-lg"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Join Call</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
