import React from 'react';
import { useVideoCall } from '../../context/VideoCallContext';
import { useRouter } from '../../router/Router';
import { 
  Video, 
  Mic, 
  MicOff, 
  PhoneOff, 
  Maximize2, 
  Sparkles, 
  User 
} from 'lucide-react';

export const FloatingVideoCallPill: React.FC = () => {
  const { 
    isCallActive, 
    callDuration, 
    isMicMuted, 
    toggleMic, 
    endCall, 
    localStream, 
    isCameraMuted,
    presentingSlab 
  } = useVideoCall();
  const { currentPath, navigate } = useRouter();

  // If call is not active, or if user is currently on the full video consultation page, don't show floating pill
  if (!isCallActive || currentPath === '/video-consultation' || currentPath === '/consultation') {
    return null;
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <aside 
      aria-label="Active Video Call Floating Window"
      className="fixed bottom-6 right-6 z-50 w-72 bg-stone-950 border-2 border-[var(--theme-accent)] shadow-2xl rounded-xs overflow-hidden text-white animate-in slide-in-from-bottom-3 duration-300"
    >
      {/* Header */}
      <div className="p-2.5 bg-black/60 border-b border-white/10 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 font-bold">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="font-mono text-[11px]">{formatTime(callDuration)}</span>
          <span className="text-[10px] text-[var(--theme-accent)] font-semibold truncate max-w-[90px]">
            {presentingSlab ? 'Presenting 3D' : 'Showroom Call'}
          </span>
        </div>

        <button
          onClick={() => navigate('/video-consultation')}
          className="p-1 hover:text-[var(--theme-accent)] transition cursor-pointer"
          title="Return to fullscreen call"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Mini Video Feed */}
      <div className="h-32 bg-stone-900 relative flex items-center justify-center overflow-hidden">
        {!isCameraMuted && localStream ? (
          <video
            ref={(video) => {
              if (video && localStream) {
                video.srcObject = localStream;
                video.play().catch(e => console.warn('Pill video play warning:', e));
              }
            }}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover transform -scale-x-100"
          />
        ) : (
          <div className="flex flex-col items-center justify-center p-2 text-stone-400 text-center">
            <User className="w-6 h-6 text-stone-500 mb-1" />
            <span className="text-[10px] font-bold text-white">Call Active · Video Muted</span>
          </div>
        )}

        <div className="absolute bottom-2 left-2 px-1.5 py-0.5 bg-black/60 rounded text-[9px] font-bold">
          Kwame (Consultant) & You
        </div>
      </div>

      {/* Mini Control Bar */}
      <div className="p-2 bg-stone-900 border-t border-white/10 flex items-center justify-between gap-2">
        <button
          onClick={toggleMic}
          className={`flex-1 py-1.5 rounded-xs flex items-center justify-center gap-1 text-xs font-semibold cursor-pointer transition ${
            isMicMuted ? 'bg-red-600 text-white' : 'bg-stone-800 hover:bg-stone-700 text-stone-200'
          }`}
        >
          {isMicMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          <span className="text-[10px]">{isMicMuted ? 'Muted' : 'Mute'}</span>
        </button>

        <button
          onClick={() => navigate('/video-consultation')}
          className="flex-1 py-1.5 bg-[var(--theme-accent)] hover:opacity-90 text-white text-[10px] font-bold uppercase rounded-xs transition flex items-center justify-center gap-1 cursor-pointer"
        >
          <span>Open Call</span>
        </button>

        <button
          onClick={endCall}
          className="p-1.5 bg-red-600/80 hover:bg-red-600 text-white rounded-xs transition cursor-pointer"
          title="End Call"
        >
          <PhoneOff className="w-3.5 h-3.5" />
        </button>
      </div>
    </aside>
  );
};
