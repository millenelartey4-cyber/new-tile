import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { 
  Download, 
  X, 
  Monitor, 
  Smartphone, 
  CheckCircle2, 
  WifiOff, 
  Layers, 
  ShieldCheck, 
  Share, 
  PlusSquare, 
  Sparkles, 
  Laptop, 
  FolderDown, 
  Check, 
  Copy,
  FileCode2,
  AlertCircle
} from 'lucide-react';
import { downloadDesktopShortcut, downloadStandaloneWebApp, getAppBaseUrl } from '../../utils/desktopAppLauncher';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstalled, isStandalone, isIOS, platform, install, hasNativePrompt } = usePWAInstall();
  const [installStatus, setInstallStatus] = useState<'idle' | 'installing' | 'success'>('idle');
  const [downloadedShortcut, setDownloadedShortcut] = useState(false);
  const [downloadedApp, setDownloadedApp] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (hasNativePrompt) {
      setInstallStatus('installing');
      const outcome = await install();
      if (outcome === 'accepted') {
        setInstallStatus('success');
        setTimeout(() => onClose(), 1800);
      } else {
        setInstallStatus('idle');
      }
    } else {
      // Direct offline app download when browser doesn't provide prompt
      downloadStandaloneWebApp('Atelier-Surfaces-SaaS-App');
      setDownloadedApp(true);
      setTimeout(() => setDownloadedApp(false), 3500);
    }
  };

  const handleDownloadApp = () => {
    downloadStandaloneWebApp('Atelier-Surfaces-SaaS-App');
    setDownloadedApp(true);
    setTimeout(() => setDownloadedApp(false), 3500);
  };

  const handleDownloadShortcut = () => {
    downloadDesktopShortcut('ATELIER-Surfaces-SaaS');
    setDownloadedShortcut(true);
    setTimeout(() => setDownloadedShortcut(false), 3000);
  };

  const handleCopyDirectLink = () => {
    navigator.clipboard.writeText(getAppBaseUrl());
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Top Header Banner */}
        <div className="p-6 bg-gradient-to-r from-[var(--theme-surface-subtle)] via-[var(--theme-surface)] to-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-start justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-xs bg-stone-900 border border-[var(--theme-border)] flex items-center justify-center p-1.5 text-[var(--theme-accent)] shadow-lg shrink-0">
              <img 
                src="/pwa-192x192.png" 
                alt="ATELIER App Icon" 
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }} 
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)] px-2 py-0.5 bg-[var(--theme-accent)]/15 border border-[var(--theme-accent)]/30">
                  Official SaaS Web Application
                </span>
                {isStandalone && (
                  <span className="text-[10px] font-bold text-emerald-500 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Standalone Active
                  </span>
                )}
              </div>
              <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold mt-1 text-[var(--theme-text)]">
                Download ATELIER Surfaces SaaS Web App
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)] mt-0.5">
                Download the official standalone application directly to your computer or mobile device.
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          
          {/* Main Download Options Card */}
          <div className="p-5 bg-gradient-to-br from-[var(--theme-surface-subtle)] to-[var(--theme-surface)] border-2 border-[var(--theme-accent)]/50 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--theme-border)] pb-3">
              <div>
                <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--theme-accent)]">
                  Direct Download Package
                </span>
                <h4 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                  Download & Save to Your Computer
                </h4>
              </div>
              <span className="text-xs font-mono font-semibold px-2 py-0.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-accent)]">
                {platform.toUpperCase()} READY
              </span>
            </div>

            <p className="text-xs text-[var(--theme-text)] leading-relaxed">
              Click below to download the official standalone app package directly into your computer's <strong>Downloads</strong> folder. You can double-click and run it offline anytime with zero dependencies:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Option A: Download Standalone Offline App (.html) */}
              <button
                onClick={handleDownloadApp}
                className="p-4 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-lg text-center"
              >
                <div className="flex items-center gap-1.5">
                  {downloadedApp ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <FileCode2 className="w-4 h-4" />
                  )}
                  <span>{downloadedApp ? 'App Downloaded!' : 'Download Standalone App (.html)'}</span>
                </div>
                <span className="text-[10px] font-normal opacity-85 lowercase">
                  (runs locally on Mac, Windows, Linux, or iPad)
                </span>
              </button>

              {/* Option B: Download Desktop Shortcut File */}
              <button
                onClick={handleDownloadShortcut}
                className="p-4 bg-[var(--theme-surface)] border-2 border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text)] font-bold text-xs uppercase tracking-wider transition flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-sm text-center"
              >
                <div className="flex items-center gap-1.5">
                  {downloadedShortcut ? (
                    <Check className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <FolderDown className="w-4 h-4 text-[var(--theme-accent)]" />
                  )}
                  <span>{downloadedShortcut ? 'Shortcut Downloaded!' : 'Download Desktop Shortcut'}</span>
                </div>
                <span className="text-[10px] font-normal text-[var(--theme-text-muted)] lowercase">
                  (saves .url / .webloc to desktop or dock)
                </span>
              </button>
            </div>

            {hasNativePrompt && (
              <div className="pt-1">
                <button
                  onClick={handleInstallClick}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>Install via Browser App Prompt</span>
                </button>
              </div>
            )}
          </div>

          {/* Platform Specific Step Guide */}
          <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[var(--theme-text-muted)]">
              <span>Platform-Specific Instructions</span>
              <button
                onClick={handleCopyDirectLink}
                className="text-[var(--theme-accent)] hover:underline flex items-center gap-1 lowercase font-mono font-normal text-xs cursor-pointer"
              >
                {copiedLink ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                <span>{copiedLink ? 'copied!' : 'copy app link'}</span>
              </button>
            </div>

            {isIOS ? (
              <div className="space-y-2 text-xs text-[var(--theme-text)]">
                <p className="font-semibold text-[var(--theme-text)] flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-[var(--theme-accent)]" />
                  <span>Installing on Apple iOS (iPhone & iPad Safari):</span>
                </p>
                <ol className="list-decimal list-inside space-y-1.5 text-[var(--theme-text-muted)] text-[11px]">
                  <li className="flex items-start gap-2">
                    <Share className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
                    <span>Tap the <strong>Share</strong> button at the bottom of your Safari screen.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <PlusSquare className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
                    <span>Scroll down the menu and tap <strong>Add to Home Screen</strong>.</span>
                  </li>
                  <li>
                    <span>Tap <strong>Add</strong> in the top right. An official app icon will be pinned to your home screen!</span>
                  </li>
                </ol>
              </div>
            ) : (
              <div className="space-y-2.5 text-xs text-[var(--theme-text)]">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] text-[var(--theme-text-muted)]">
                  <div className="p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                    <strong className="text-[var(--theme-text)] block flex items-center gap-1">
                      <Laptop className="w-3.5 h-3.5 text-[var(--theme-accent)]" /> Mac (macOS)
                    </strong>
                    <span>Double-click the downloaded <strong>Atelier-Surfaces-SaaS-App.html</strong> file to run full-screen, or move it to your Applications folder.</span>
                  </div>
                  <div className="p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                    <strong className="text-[var(--theme-text)] block flex items-center gap-1">
                      <Monitor className="w-3.5 h-3.5 text-[var(--theme-accent)]" /> Windows PC & ChromeOS
                    </strong>
                    <span>Double-click the downloaded app file or shortcut to launch into a clean, dedicated surfaces catalog.</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-[var(--theme-text)]">
                <Monitor className="w-4 h-4 text-[var(--theme-accent)]" />
                <span>Dedicated Standalone Window</span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Opens in its own native desktop window with no browser tabs or address bar distractions.
              </p>
            </div>

            <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-[var(--theme-text)]">
                <WifiOff className="w-4 h-4 text-[var(--theme-accent)]" />
                <span>100% Offline Specifier</span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Present tile finishes, calculate m² wastage, and draft orders on construction sites without internet.
              </p>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-[11px] text-[var(--theme-text-muted)] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>PWA v2.0 Standard · Workbox Precached · Multi-Tenant Isolated</span>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={handleDownloadApp}
              className="px-4 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] hover:border-[var(--theme-accent)] transition cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Download App</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
