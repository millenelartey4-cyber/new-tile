import React from 'react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';
import { WifiOff, HardDrive } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <aside 
      aria-label="Offline Status Notification"
      className="fixed bottom-6 left-6 z-50 flex items-center gap-3 bg-[var(--theme-surface)] border border-amber-500/40 text-[var(--theme-text)] px-4 py-2.5 shadow-2xl rounded-xs animate-in fade-in slide-in-from-bottom-2 duration-300"
    >
      <div className="w-7 h-7 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
        <WifiOff className="w-4 h-4" />
      </div>
      <div>
        <div className="flex items-center gap-1.5 text-xs font-semibold">
          <span>Offline Standalone Mode</span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
        </div>
        <p className="text-[11px] text-[var(--theme-text-muted)] flex items-center gap-1">
          <HardDrive className="w-3 h-3 text-[var(--theme-accent)]" />
          Using cached catalogue, products, and offline database.
        </p>
      </div>
    </aside>
  );
};
