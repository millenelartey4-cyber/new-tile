import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallModal } from './PWAInstallModal';
import { Download, Monitor, CheckCircle2, Sparkles, X, Smartphone } from 'lucide-react';

interface PWAInstallButtonProps {
  variant?: 'header' | 'admin' | 'banner' | 'page' | 'sidebar';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  className = '',
}) => {
  const { isInstalled, isStandalone, isInstallable, install, hasNativePrompt, isIOS } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBannerDismissed, setIsBannerDismissed] = useState(() => {
    try {
      return sessionStorage.getItem('atelier_pwa_banner_dismissed') === 'true';
    } catch {
      return false;
    }
  });

  const handleClick = async () => {
    // If native prompt is available, we can trigger direct install, or open modal for clear instructions
    if (hasNativePrompt) {
      const outcome = await install();
      if (outcome === 'manual_required' || outcome === 'dismissed') {
        setIsModalOpen(true);
      }
    } else {
      setIsModalOpen(true);
    }
  };

  // If already running inside installed standalone window, don't show prompt banner
  if (isStandalone && (variant === 'banner')) {
    return null;
  }

  // Variant: Banner (permanently disabled per user request)
  if (variant === 'banner') {
    return null;
  }

  // Variant: Admin Topbar
  if (variant === 'admin') {
    return (
      <>
        <button
          type="button"
          onClick={handleClick}
          className={`flex items-center gap-1.5 px-3 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] transition-colors cursor-pointer shadow-xs ${className}`}
          title="Install ATELIER as a standalone SaaS desktop application"
        >
          {isStandalone ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span className="hidden lg:inline text-emerald-600 dark:text-emerald-400 font-bold">App Active</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span className="font-bold">Install SaaS App</span>
            </>
          )}
        </button>

        <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </>
    );
  }

  // Variant: Sidebar
  if (variant === 'sidebar') {
    return (
      <>
        <button
          type="button"
          onClick={handleClick}
          className={`w-full py-2 bg-white/5 hover:bg-white/10 text-[var(--theme-sidebar-text)] text-[11px] font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors border border-[var(--theme-sidebar-border)] cursor-pointer ${className}`}
          title="Download desktop SaaS application"
        >
          {isStandalone ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Standalone App Mode</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Download Desktop App</span>
            </>
          )}
        </button>

        <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </>
    );
  }

  // Variant: Page
  if (variant === 'page') {
    return (
      <>
        <button
          type="button"
          onClick={handleClick}
          className={`px-8 py-3.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-sm font-bold uppercase tracking-wider hover:opacity-90 transition flex items-center justify-center gap-2 cursor-pointer shadow-lg ${className}`}
        >
          <Download className="w-5 h-5" />
          <span>{isStandalone ? 'App Already Installed (Open Standalone)' : 'Install SaaS Application Now'}</span>
        </button>

        <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </>
    );
  }

  // Default: Header utility bar button
  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-xs border transition-colors cursor-pointer ${
          isStandalone 
            ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-600 dark:text-emerald-400' 
            : 'bg-[var(--theme-accent)]/10 hover:bg-[var(--theme-accent)]/20 border-[var(--theme-accent)]/30 text-[var(--theme-text)]'
        } ${className}`}
        title="Download or install ATELIER webapp on your device"
      >
        {isStandalone ? (
          <>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span className="hidden sm:inline">Installed App</span>
          </>
        ) : (
          <>
            <Download className="w-3.5 h-3.5 text-[var(--theme-accent)] shrink-0" />
            <span className="font-bold">Install App</span>
          </>
        )}
      </button>

      <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
