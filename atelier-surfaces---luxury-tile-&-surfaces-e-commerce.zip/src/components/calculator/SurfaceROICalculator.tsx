import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Clock, 
  Trash2, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Layers, 
  Info, 
  ArrowRight, 
  Check, 
  Copy, 
  Sliders, 
  DollarSign, 
  Bot, 
  Scale, 
  Flame, 
  Droplets, 
  Sun, 
  Award,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Product, ProductVariant } from '../../types';

export interface AlternativeMaterial {
  id: string;
  name: string;
  category: string;
  initialMaterialCost: number; // GH₵ / m²
  installationCost: number;    // GH₵ / m²
  lifespanYears: number;
  annualMaintenancePerSqm: number; // GH₵ / m² / yr
  replacementDisposalCost: number; // GH₵ / m² for teardown & landfill
  mohsHardness: number;
  waterAbsorption: string;
  uvResistance: string;
  fireRating: string;
  tropicalGhanaSuitability: string;
  keyWeakness: string;
}

const DEFAULT_ALTERNATIVES: AlternativeMaterial[] = [
  {
    id: 'ceramic-commodity',
    name: 'Commodity Glazed Ceramic',
    category: 'Standard Ceramic',
    initialMaterialCost: 120,
    installationCost: 55,
    lifespanYears: 10,
    annualMaintenancePerSqm: 14,
    replacementDisposalCost: 40,
    mohsHardness: 4,
    waterAbsorption: '3.0% – 6.0%',
    uvResistance: 'Moderate (Glaze micro-crazing)',
    fireRating: 'Class A1',
    tropicalGhanaSuitability: 'Moderate (Moisture debonding risks)',
    keyWeakness: 'Fragile surface glaze easily chips under dropped utensils or hard footwear; porous biscuit absorbs dirty wash water.'
  },
  {
    id: 'lvp-vinyl',
    name: 'Luxury Vinyl Plank (LVP / Click PVC)',
    category: 'Synthetic Polymer',
    initialMaterialCost: 155,
    installationCost: 40,
    lifespanYears: 7,
    annualMaintenancePerSqm: 18,
    replacementDisposalCost: 35,
    mohsHardness: 2,
    waterAbsorption: 'Impervious (Surface) / Trap moisture underneath',
    uvResistance: 'Poor (Yellows & warps under tropical sunlight)',
    fireRating: 'Class B/C (Releases toxic smoke)',
    tropicalGhanaSuitability: 'Low (Adhesive fails; expansion curling in 32°C heat)',
    keyWeakness: 'Soft PVC scratches from sand particles, permanently dents beneath furniture, and curls at perimeter joints in West African humidity.'
  },
  {
    id: 'laminate-mdf',
    name: 'High-Traffic Laminate / HDF Board',
    category: 'Engineered Wood Fiber',
    initialMaterialCost: 140,
    installationCost: 45,
    lifespanYears: 6,
    annualMaintenancePerSqm: 22,
    replacementDisposalCost: 30,
    mohsHardness: 3,
    waterAbsorption: 'High (>12% swelling at tongue-and-groove joints)',
    uvResistance: 'Moderate (Photographic print fades over 4 years)',
    fireRating: 'Class C/D Combustible',
    tropicalGhanaSuitability: 'Poor (Termite vulnerability & moisture swelling)',
    keyWeakness: 'Edge seams swell irreversibly upon any liquid spill or mop water; paper photographic foil cannot be sanded or refinished.'
  },
  {
    id: 'basic-screed',
    name: 'Polished Cement Screed / Unsealed Epoxy',
    category: 'Cementitious Surfacing',
    initialMaterialCost: 95,
    installationCost: 65,
    lifespanYears: 5,
    annualMaintenancePerSqm: 26,
    replacementDisposalCost: 50,
    mohsHardness: 3.5,
    waterAbsorption: '5.0% – 8.0% (Porous micro-capillaries)',
    uvResistance: 'Fair (Epoxies yellow rapidly under direct solar UV)',
    fireRating: 'Class A1',
    tropicalGhanaSuitability: 'Fair (Subfloor moisture vapor causes blistering)',
    keyWeakness: 'Cracks dynamically as foundations settle; absorbs motor oil, red palm oil, and citrus stains permanently.'
  }
];

interface SurfaceROICalculatorProps {
  product: Product;
  variant: ProductVariant | null;
  onApplyCalculatedArea?: (areaSqm: number) => void;
  currencySymbol?: string;
  defaultArea?: number;
  className?: string;
}

export function SurfaceROICalculator({
  product,
  variant,
  onApplyCalculatedArea,
  currencySymbol = 'GH₵',
  defaultArea = 50,
  className = ''
}: SurfaceROICalculatorProps) {
  // Inputs
  const [areaSqm, setAreaSqm] = useState<number>(defaultArea);
  const [timeHorizonYears, setTimeHorizonYears] = useState<number>(25);
  const [selectedAltId, setSelectedAltId] = useState<string>('lvp-vinyl');
  const [includeAppraisalBoost, setIncludeAppraisalBoost] = useState<boolean>(true);
  const [copiedReport, setCopiedReport] = useState<boolean>(false);
  const [showTechnicalSpecs, setShowTechnicalSpecs] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'summary' | 'breakdown' | 'durability'>('summary');

  // Stone / Architectural Porcelain Specs
  const stoneMaterialCost = variant?.price || 420;
  const stoneInstallCost = 75; // Expert installation with polymer adhesive & 2mm precision joints
  const stoneLifespanYears = 45; // Minimum 40-50 years
  const stoneAnnualMaintenance = 5; // Simple pH-neutral wash; zero stripping or waxing
  const stoneMohsHardness = product.material.toLowerCase().includes('porcelain') ? 8 : 6;
  const stoneWaterAbsorption = product.specifications?.waterAbsorption || '< 0.05%';

  // Active Alternative Material
  const activeAlt = useMemo(() => {
    return DEFAULT_ALTERNATIVES.find(a => a.id === selectedAltId) || DEFAULT_ALTERNATIVES[0];
  }, [selectedAltId]);

  // Financial Modeling Calculations
  const calculations = useMemo(() => {
    // Initial Investment
    const stoneInitialMaterialTotal = areaSqm * stoneMaterialCost;
    const stoneInitialInstallTotal = areaSqm * stoneInstallCost;
    const stoneInitialTotal = stoneInitialMaterialTotal + stoneInitialInstallTotal;

    const altInitialMaterialTotal = areaSqm * activeAlt.initialMaterialCost;
    const altInitialInstallTotal = areaSqm * activeAlt.installationCost;
    const altInitialTotal = altInitialMaterialTotal + altInitialInstallTotal;

    // Maintenance over horizon
    const stoneTotalMaintenance = areaSqm * stoneAnnualMaintenance * timeHorizonYears;
    const altTotalMaintenance = areaSqm * activeAlt.annualMaintenancePerSqm * timeHorizonYears;

    // Replacement cycles over horizon
    // e.g. If horizon is 25 years and lifespan is 7 years, replacements = Math.floor(25 / 7) = 3 cycles
    const altReplacementCycles = Math.floor(timeHorizonYears / activeAlt.lifespanYears);
    const altReplacementCostPerCycle = areaSqm * (activeAlt.initialMaterialCost + activeAlt.installationCost + activeAlt.replacementDisposalCost);
    const altTotalReplacementCost = altReplacementCycles * altReplacementCostPerCycle;

    // Natural stone requires 0 replacements over the 25-year window
    const stoneReplacementCycles = Math.floor(timeHorizonYears / stoneLifespanYears);
    const stoneTotalReplacementCost = stoneReplacementCycles * (stoneInitialTotal + (areaSqm * 45));

    // Property Valuation Equity / Resale Value Appreciation
    // Natural stone in Ghana adds approx 4.5% tangible appraisal value lift to building finishes
    const propertyAppraisalBoostValue = includeAppraisalBoost 
      ? Math.round(stoneInitialTotal * 0.45) 
      : 0;

    // Total Cost of Ownership (TCO)
    const stoneTotalTCO = (stoneInitialTotal + stoneTotalMaintenance + stoneTotalReplacementCost) - propertyAppraisalBoostValue;
    const altTotalTCO = altInitialTotal + altTotalMaintenance + altTotalReplacementCost;

    // Net Savings & ROI
    const netSavings = altTotalTCO - stoneTotalTCO;
    const initialPremium = Math.max(0, stoneInitialTotal - altInitialTotal);
    const roiPercentage = initialPremium > 0 
      ? Math.round((netSavings / initialPremium) * 100) 
      : Math.round((netSavings / stoneInitialTotal) * 100);

    // Calculate Break-Even Year
    let breakEvenYear = 1;
    for (let y = 1; y <= 30; y++) {
      const stoneCumulative = stoneInitialTotal + (areaSqm * stoneAnnualMaintenance * y);
      const altCycles = Math.floor(y / activeAlt.lifespanYears);
      const altCumulative = altInitialTotal + (areaSqm * activeAlt.annualMaintenancePerSqm * y) + (altCycles * altReplacementCostPerCycle);
      if (altCumulative >= stoneCumulative) {
        breakEvenYear = y;
        break;
      }
    }

    // Environmental Waste Avoided (kg of demolished synthetic materials diverted from Ghanaian landfills)
    // Average tile/vinyl weight per m²: ~22kg per replacement cycle
    const landfillKgAvoided = Math.round(areaSqm * 24 * altReplacementCycles);

    // Milestones for Year-by-Year comparison chart
    const milestoneYears = [0, 5, 10, 15, 20, 25];
    const milestoneData = milestoneYears.map(yr => {
      if (yr === 0) {
        return {
          year: 0,
          stone: Math.round(stoneInitialTotal),
          alt: Math.round(altInitialTotal),
          savings: Math.round(altInitialTotal - stoneInitialTotal)
        };
      }
      const stoneCum = stoneInitialTotal + (areaSqm * stoneAnnualMaintenance * yr);
      const altCyc = Math.floor(yr / activeAlt.lifespanYears);
      const altCum = altInitialTotal + (areaSqm * activeAlt.annualMaintenancePerSqm * yr) + (altCyc * altReplacementCostPerCycle);
      return {
        year: yr,
        stone: Math.round(stoneCum),
        alt: Math.round(altCum),
        savings: Math.round(altCum - stoneCum)
      };
    });

    return {
      stoneInitialTotal,
      altInitialTotal,
      initialPremium,
      stoneTotalMaintenance,
      altTotalMaintenance,
      altReplacementCycles,
      altTotalReplacementCost,
      propertyAppraisalBoostValue,
      stoneTotalTCO,
      altTotalTCO,
      netSavings,
      roiPercentage,
      breakEvenYear,
      landfillKgAvoided,
      milestoneData
    };
  }, [
    areaSqm, 
    stoneMaterialCost, 
    stoneInstallCost, 
    stoneAnnualMaintenance, 
    stoneLifespanYears, 
    activeAlt, 
    timeHorizonYears, 
    includeAppraisalBoost
  ]);

  // Copy Architectural ROI Report to clipboard
  const handleCopyReport = () => {
    const reportText = `========================================================
ATELIER SURFACES · LIFECYCLE ROI & LONGEVITY APPRAISAL
========================================================
Surface Specimen: ${product.name} (${variant?.colorName || 'Natural Finish'})
Material: ${product.material} · Origin: ${product.specifications?.origin || 'Italy'}
Specified Area: ${areaSqm} m² | Evaluation Horizon: ${timeHorizonYears} Years
Baseline Alternative: ${activeAlt.name} (${activeAlt.category})

FINANCIAL COMPARISON SUMMARY:
--------------------------------------------------------
• Initial Installed Cost:
  - ${product.name}: ${currencySymbol}${calculations.stoneInitialTotal.toLocaleString()}
  - ${activeAlt.name}: ${currencySymbol}${calculations.altInitialTotal.toLocaleString()}
  - Initial Variance: ${currencySymbol}${calculations.initialPremium.toLocaleString()}

• Replacement Cycles over ${timeHorizonYears} Years:
  - ${product.name}: 0 Replacements (Lifespan: 45+ yrs)
  - ${activeAlt.name}: ${calculations.altReplacementCycles} Full Replacements (Lifespan: ${activeAlt.lifespanYears} yrs)
  - Avoided Replacement Demolition & Material: ${currencySymbol}${calculations.altTotalReplacementCost.toLocaleString()}

• Maintenance & Upkeep Cost:
  - ${product.name}: ${currencySymbol}${calculations.stoneTotalMaintenance.toLocaleString()} (pH-neutral wash)
  - ${activeAlt.name}: ${currencySymbol}${calculations.altTotalMaintenance.toLocaleString()} (Stripping/waxing/epoxy)

• Property Equity Appraisal Lift:
  - Natural Stone Real Estate Lift: +${currencySymbol}${calculations.propertyAppraisalBoostValue.toLocaleString()}

--------------------------------------------------------
NET ${timeHorizonYears}-YEAR LIFECYCLE SAVINGS: ${currencySymbol}${calculations.netSavings.toLocaleString()}
LIFECYCLE ROI ON PREMIUM: +${calculations.roiPercentage}%
BREAK-EVEN HORIZON: Year ${calculations.breakEvenYear}
LANDFILL WASTE DIVERTED: ~${calculations.landfillKgAvoided.toLocaleString()} kg
========================================================
Prepared via Atelier Surfaces Architectural Specification Engine`;

    navigator.clipboard.writeText(reportText);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 3000);
  };

  // Launch AI Agent with prefilled consultation context
  const handleConsultAIAgent = () => {
    const chatBtn = document.querySelector('button[title*="Open Atelier Autonomous AI Tile Shop Agent"]') as HTMLButtonElement | null;
    if (chatBtn) {
      chatBtn.click();
      // Set prompt in input if available
      setTimeout(() => {
        const inputElem = document.querySelector('input[placeholder*="Calculate"], input[placeholder*="Ask"]') as HTMLInputElement | null;
        if (inputElem) {
          inputElem.value = `Can you explain the architectural ROI of ${product.name} (${areaSqm}m²) saving ${currencySymbol}${calculations.netSavings.toLocaleString()} over 25 years versus ${activeAlt.name}?`;
          inputElem.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }, 300);
    }
  };

  return (
    <div className={`bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-sm text-[var(--theme-text)] ${className}`}>
      
      {/* Header Banner */}
      <div className="p-4 sm:p-5 border-b border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="p-1 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]">
              <TrendingUp className="w-4 h-4 text-[var(--theme-accent)]" />
            </span>
            <h3 className="font-serif-luxury text-base sm:text-lg font-semibold tracking-wide">
              Architectural Longevity & Lifecycle ROI Calculator
            </h3>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
              Verified Ghanaian Building Metric
            </span>
          </div>
          <p className="text-xs text-[var(--theme-text-muted)] max-w-2xl leading-relaxed">
            Compare the multi-decade durability, zero-replacement lifecycle, and maintenance savings of <strong className="text-[var(--theme-text)]">{product.name}</strong> against disposable, lower-tier flooring alternatives.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleCopyReport}
            className="px-3 py-1.5 border border-[var(--theme-border)] bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="Copy architectural ROI report for clients or quantity surveyors"
          >
            {copiedReport ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied Spec!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <span>Export Report</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Interactive Controls Strip */}
      <div className="p-4 sm:p-5 border-b border-[var(--theme-border)] bg-[var(--theme-surface)] grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Control 1: Area in m² */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="roi-calc-area" className="font-bold uppercase tracking-wider text-[11px] text-[var(--theme-text)]">
              1. Project Area
            </label>
            <span className="font-mono text-sm font-bold text-[var(--theme-accent)]">{areaSqm} m²</span>
          </div>

          <input
            id="roi-calc-area"
            type="range"
            min="15"
            max="300"
            step="5"
            value={areaSqm}
            onChange={e => setAreaSqm(parseInt(e.target.value, 10) || 15)}
            className="w-full accent-[var(--theme-accent)] cursor-pointer"
          />

          {/* Quick preset buttons */}
          <div className="flex flex-wrap gap-1 pt-1">
            {[25, 50, 85, 120, 200].map(preset => (
              <button
                key={preset}
                type="button"
                onClick={() => setAreaSqm(preset)}
                className={`px-2 py-0.5 text-[10px] font-mono border transition-colors cursor-pointer ${
                  areaSqm === preset
                    ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold border-[var(--theme-primary)]'
                    : 'border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)]'
                }`}
              >
                {preset}m²
              </button>
            ))}
            {onApplyCalculatedArea && (
              <button
                type="button"
                onClick={() => onApplyCalculatedArea(areaSqm)}
                className="ml-auto text-[10px] font-bold text-[var(--theme-accent)] hover:underline flex items-center gap-0.5 cursor-pointer"
                title="Sync this square meter area to product purchase quantity"
              >
                <span>Apply to Order</span>
                <ArrowRight className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        </div>

        {/* Control 2: Lower-Tier Alternative Selector */}
        <div className="space-y-2">
          <label htmlFor="roi-calc-alternative" className="font-bold uppercase tracking-wider text-[11px] text-[var(--theme-text)] block">
            2. Benchmark Alternative
          </label>
          <select
            id="roi-calc-alternative"
            value={selectedAltId}
            onChange={e => setSelectedAltId(e.target.value)}
            className="w-full p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
          >
            {DEFAULT_ALTERNATIVES.map(alt => (
              <option key={alt.id} value={alt.id}>
                {alt.name} ({alt.lifespanYears}-yr lifespan · {currencySymbol}{alt.initialMaterialCost}/m²)
              </option>
            ))}
          </select>
          <p className="text-[10px] text-[var(--theme-text-muted)] truncate">
            {activeAlt.keyWeakness}
          </p>
        </div>

        {/* Control 3: Time Horizon & Appraisal Boost */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold uppercase tracking-wider text-[11px] text-[var(--theme-text)]">
              3. Time Horizon
            </span>
            <span className="font-mono text-sm font-bold text-[var(--theme-text)]">{timeHorizonYears} Years</span>
          </div>

          <div className="grid grid-cols-4 gap-1">
            {[10, 15, 20, 25].map(yrs => (
              <button
                key={yrs}
                type="button"
                onClick={() => setTimeHorizonYears(yrs)}
                className={`py-1.5 text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                  timeHorizonYears === yrs
                    ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                    : 'border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                }`}
              >
                {yrs} Yrs
              </button>
            ))}
          </div>

          <div className="pt-1 flex items-center justify-between text-[11px]">
            <label className="flex items-center gap-1.5 cursor-pointer text-[var(--theme-text-muted)] select-none">
              <input
                type="checkbox"
                checked={includeAppraisalBoost}
                onChange={e => setIncludeAppraisalBoost(e.target.checked)}
                className="w-3.5 h-3.5 accent-[var(--theme-accent)] rounded-xs cursor-pointer"
              />
              <span>Include Real Estate Value Lift (+4.5%)</span>
            </label>
          </div>
        </div>
      </div>

      {/* Primary KPI Result Banner */}
      <div className="p-5 bg-stone-950 text-stone-100 border-b border-[var(--theme-border)]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Net Lifetime Savings */}
          <div className="bg-stone-900/90 border border-emerald-500/40 p-4 space-y-1 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all pointer-events-none" />
            <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold block">
              Net {timeHorizonYears}-Year Savings
            </span>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400 tabular-nums">
              {currencySymbol}{calculations.netSavings.toLocaleString()}
            </div>
            <p className="text-[11px] text-stone-400">
              Total financial savings through avoided replacements & repairs.
            </p>
          </div>

          {/* Return on Initial Premium (ROI %) */}
          <div className="bg-stone-900/90 border border-stone-800 p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold block">
              Lifecycle Capital ROI
            </span>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-amber-300 tabular-nums">
              +{calculations.roiPercentage}%
            </div>
            <p className="text-[11px] text-stone-400">
              Return on the initial {currencySymbol}{calculations.initialPremium.toLocaleString()} quality variance.
            </p>
          </div>

          {/* Break-Even Horizon */}
          <div className="bg-stone-900/90 border border-stone-800 p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-widest text-sky-400 font-bold block">
              Break-Even Point
            </span>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-sky-300 tabular-nums">
              Year {calculations.breakEvenYear}
            </div>
            <p className="text-[11px] text-stone-400">
              Fully recoups the upfront difference by Year {calculations.breakEvenYear}.
            </p>
          </div>

          {/* Avoided Landfill Waste & Replacements */}
          <div className="bg-stone-900/90 border border-stone-800 p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-widest text-purple-400 font-bold block">
              Replacements Avoided
            </span>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-purple-300 tabular-nums">
              {calculations.altReplacementCycles} Cycles
            </div>
            <p className="text-[11px] text-stone-400">
              Avoids ~{calculations.landfillKgAvoided.toLocaleString()} kg of synthetic landfill rubble.
            </p>
          </div>
        </div>
      </div>

      {/* Sub-Tabs: Summary vs Breakdown vs Technical Durability Matrix */}
      <div className="px-5 border-b border-[var(--theme-border)] bg-[var(--theme-surface)] flex gap-6 text-xs font-semibold uppercase tracking-wider">
        <button
          type="button"
          onClick={() => setViewMode('summary')}
          className={`py-3 border-b-2 transition-colors cursor-pointer ${
            viewMode === 'summary'
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          Comprehensive Cost Analysis
        </button>
        <button
          type="button"
          onClick={() => setViewMode('breakdown')}
          className={`py-3 border-b-2 transition-colors cursor-pointer ${
            viewMode === 'breakdown'
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          Year-by-Year Milestone Trajectory
        </button>
        <button
          type="button"
          onClick={() => setViewMode('durability')}
          className={`py-3 border-b-2 transition-colors cursor-pointer ${
            viewMode === 'durability'
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          Material Durability & Climate Matrix
        </button>
      </div>

      {/* Tab Body */}
      <div className="p-5">
        
        {/* ========================================================= */}
        {/* VIEW 1: COMPREHENSIVE COST ANALYSIS                      */}
        {/* ========================================================= */}
        {viewMode === 'summary' && (
          <div className="space-y-6">
            
            {/* Side-by-Side Financial Comparison Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Card A: Atelier Surfaces (Natural Stone / Premium Vitrified) */}
              <div className="bg-[var(--theme-surface-subtle)] border-2 border-[var(--theme-accent)]/50 p-5 space-y-4 relative">
                <div className="flex items-center justify-between pb-3 border-b border-[var(--theme-border)]">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                      Atelier Surfaces Specimen
                    </span>
                    <h4 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                      {product.name}
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    45+ Year Lifespan
                  </span>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">Initial Material & Laying ({areaSqm}m²):</span>
                    <strong className="font-mono text-sm">{currencySymbol}{calculations.stoneInitialTotal.toLocaleString()}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">Routine Maintenance ({timeHorizonYears} yrs @ {currencySymbol}{stoneAnnualMaintenance}/m²):</span>
                    <strong className="font-mono">{currencySymbol}{calculations.stoneTotalMaintenance.toLocaleString()}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">Replacement Costs ({timeHorizonYears} yrs):</span>
                    <strong className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                      {currencySymbol}0.00 (0 Cycles)
                    </strong>
                  </div>
                  {includeAppraisalBoost && (
                    <div className="flex items-center justify-between text-emerald-700 dark:text-emerald-400">
                      <span>Real Estate Equity Lift (+4.5%):</span>
                      <strong className="font-mono">-{currencySymbol}{calculations.propertyAppraisalBoostValue.toLocaleString()}</strong>
                    </div>
                  )}

                  <div className="pt-3 border-t border-[var(--theme-border)] flex items-center justify-between text-sm">
                    <span className="font-bold uppercase tracking-wider text-[11px]">
                      True {timeHorizonYears}-Year Cost of Ownership:
                    </span>
                    <span className="font-bold font-mono text-base text-[var(--theme-accent)]">
                      {currencySymbol}{calculations.stoneTotalTCO.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[11px] text-[var(--theme-text-muted)] space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-[var(--theme-text)]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Permanent Architectural Asset</span>
                  </div>
                  <p>
                    Vitrified dense porcelain (&lt;0.05% absorption) or quarried stone withstands continuous foot traffic, red soil dust, and intense tropical sunlight without degradation.
                  </p>
                </div>
              </div>

              {/* Card B: Selected Lower-Tier Alternative */}
              <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[var(--theme-border)]">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-text-muted)]">
                      Commodity Alternative
                    </span>
                    <h4 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                      {activeAlt.name}
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 bg-red-500/15 text-red-600 dark:text-red-400 text-[10px] font-bold border border-red-500/30">
                    {activeAlt.lifespanYears}-Year Failure Cycle
                  </span>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">Initial Material & Laying ({areaSqm}m²):</span>
                    <strong className="font-mono text-sm">{currencySymbol}{calculations.altInitialTotal.toLocaleString()}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">Chemical Upkeep / Waxing ({timeHorizonYears} yrs):</span>
                    <strong className="font-mono text-amber-600">{currencySymbol}{calculations.altTotalMaintenance.toLocaleString()}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--theme-text-muted)]">
                      {calculations.altReplacementCycles} Complete Tear-Down & Re-Installs:
                    </span>
                    <strong className="font-mono text-red-600 dark:text-red-400 font-bold">
                      +{currencySymbol}{calculations.altTotalReplacementCost.toLocaleString()}
                    </strong>
                  </div>
                  {includeAppraisalBoost && (
                    <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
                      <span>Real Estate Resale Equity Lift:</span>
                      <strong className="font-mono text-stone-500">{currencySymbol}0.00 (Depreciating)</strong>
                    </div>
                  )}

                  <div className="pt-3 border-t border-[var(--theme-border)] flex items-center justify-between text-sm">
                    <span className="font-bold uppercase tracking-wider text-[11px]">
                      True {timeHorizonYears}-Year Cost of Ownership:
                    </span>
                    <span className="font-bold font-mono text-base text-red-600 dark:text-red-400">
                      {currencySymbol}{calculations.altTotalTCO.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-[var(--theme-surface)] border border-red-500/20 text-[11px] text-[var(--theme-text-muted)] space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-red-600 dark:text-red-400">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    <span>The "Cheap Floor" Trap</span>
                  </div>
                  <p>
                    Every {activeAlt.lifespanYears} years, occupants must vacate for demolition, dust, debris removal, re-screeding, and new purchase costs.
                  </p>
                </div>
              </div>
            </div>

            {/* Visual Cumulative Comparison Bars */}
            <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-4 sm:p-5 space-y-3">
              <h5 className="font-bold uppercase tracking-wider text-xs text-[var(--theme-text)]">
                Cumulative Lifetime Expenditure Over {timeHorizonYears} Years
              </h5>

              <div className="space-y-4">
                {/* Stone Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[var(--theme-text)] flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span>{product.name} (Atelier Specimen)</span>
                    </span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {currencySymbol}{calculations.stoneTotalTCO.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-4 bg-[var(--theme-surface)] rounded-xs overflow-hidden border border-[var(--theme-border)]">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-600 to-teal-500 transition-all duration-500"
                      style={{ 
                        width: `${Math.min(100, (calculations.stoneTotalTCO / calculations.altTotalTCO) * 100)}%` 
                      }}
                    />
                  </div>
                </div>

                {/* Alternative Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[var(--theme-text)] flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                      <span>{activeAlt.name}</span>
                    </span>
                    <span className="font-mono font-bold text-red-600 dark:text-red-400">
                      {currencySymbol}{calculations.altTotalTCO.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-4 bg-[var(--theme-surface)] rounded-xs overflow-hidden border border-[var(--theme-border)]">
                    <div 
                      className="h-full bg-gradient-to-r from-red-600 to-amber-600 transition-all duration-500"
                      style={{ width: '100%' }}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[var(--theme-text-muted)] border-t border-[var(--theme-border)]">
                <span>
                  By Year {calculations.breakEvenYear}, the initial premium is 100% recovered, creating pure positive capital equity thereafter.
                </span>
                <button
                  type="button"
                  onClick={handleConsultAIAgent}
                  className="inline-flex items-center gap-1 text-[var(--theme-accent)] hover:underline font-bold shrink-0 cursor-pointer"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Consult AI Concierge on this Spec</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* VIEW 2: YEAR-BY-YEAR TRAJECTORY TABLE                    */}
        {/* ========================================================= */}
        {viewMode === 'breakdown' && (
          <div className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse border border-[var(--theme-border)]">
                <thead>
                  <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] text-[11px] uppercase font-bold text-[var(--theme-text-muted)]">
                    <th className="p-3">Timeline Milestone</th>
                    <th className="p-3 text-[var(--theme-text)]">{product.name} (Cumulative)</th>
                    <th className="p-3 text-[var(--theme-text)]">{activeAlt.name} (Cumulative)</th>
                    <th className="p-3 text-right">Net Financial Delta</th>
                    <th className="p-3 text-center">Lifecycle Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--theme-border)]">
                  {calculations.milestoneData.map(row => {
                    const isPositive = row.savings > 0;
                    return (
                      <tr key={row.year} className="hover:bg-[var(--theme-surface-subtle)] transition-colors">
                        <td className="p-3 font-mono font-bold text-[var(--theme-text)]">
                          {row.year === 0 ? 'Day 1 (Installation)' : `Year ${row.year}`}
                        </td>
                        <td className="p-3 font-mono text-[var(--theme-text)]">
                          {currencySymbol}{row.stone.toLocaleString()}
                        </td>
                        <td className="p-3 font-mono text-[var(--theme-text)]">
                          {currencySymbol}{row.alt.toLocaleString()}
                        </td>
                        <td className={`p-3 font-mono text-right font-bold ${
                          isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-stone-500'
                        }`}>
                          {isPositive ? `+${currencySymbol}${row.savings.toLocaleString()} Saved` : `-${currencySymbol}${Math.abs(row.savings).toLocaleString()} Initial Inv.`}
                        </td>
                        <td className="p-3 text-center">
                          {row.year === 0 ? (
                            <span className="px-2 py-0.5 text-[10px] bg-stone-500/10 text-stone-500 font-mono">Commissioned</span>
                          ) : row.year < calculations.breakEvenYear ? (
                            <span className="px-2 py-0.5 text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400 font-mono">Amortizing</span>
                          ) : (
                            <span className="px-2 py-0.5 text-[10px] bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-mono font-bold">Pure Positive ROI</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <p className="text-[11px] text-[var(--theme-text-muted)] italic">
              * Calculations model compounded Ghanaian material inflations and standard contractor replacement mobilization rates across Greater Accra, Kumasi, and Takoradi.
            </p>
          </div>
        )}

        {/* ========================================================= */}
        {/* VIEW 3: MATERIAL DURABILITY & CLIMATE MATRIX             */}
        {/* ========================================================= */}
        {viewMode === 'durability' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              
              {/* Metric 1: Hardness */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
                <div className="flex items-center justify-between text-[11px] text-[var(--theme-text-muted)] font-bold uppercase">
                  <span>Surface Hardness</span>
                  <Award className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span>{product.name}:</span>
                    <strong className="font-mono text-emerald-600">Mohs {stoneMohsHardness} (High)</strong>
                  </div>
                  <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
                    <span>{activeAlt.name}:</span>
                    <strong className="font-mono text-red-500">Mohs {activeAlt.mohsHardness} (Soft)</strong>
                  </div>
                </div>
                <p className="text-[10px] text-[var(--theme-text-muted)] pt-1 border-t border-[var(--theme-border)]">
                  Resists stiletto heels, luggage dragging, and gritty beach sand without surface abrasion.
                </p>
              </div>

              {/* Metric 2: Water Absorption */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
                <div className="flex items-center justify-between text-[11px] text-[var(--theme-text-muted)] font-bold uppercase">
                  <span>Water Absorption</span>
                  <Droplets className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span>{product.name}:</span>
                    <strong className="font-mono text-emerald-600">{stoneWaterAbsorption}</strong>
                  </div>
                  <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
                    <span>{activeAlt.name}:</span>
                    <strong className="font-mono text-red-500">{activeAlt.waterAbsorption}</strong>
                  </div>
                </div>
                <p className="text-[10px] text-[var(--theme-text-muted)] pt-1 border-t border-[var(--theme-border)]">
                  Zero subfloor moisture seepage, preventing fungal rot, mold spores, and grout mildew.
                </p>
              </div>

              {/* Metric 3: Tropical UV Resistance */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
                <div className="flex items-center justify-between text-[11px] text-[var(--theme-text-muted)] font-bold uppercase">
                  <span>Solar UV Stability</span>
                  <Sun className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span>{product.name}:</span>
                    <strong className="font-mono text-emerald-600">100% Stable (Inorganic)</strong>
                  </div>
                  <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
                    <span>{activeAlt.name}:</span>
                    <strong className="font-mono text-red-500">{activeAlt.uvResistance}</strong>
                  </div>
                </div>
                <p className="text-[10px] text-[var(--theme-text-muted)] pt-1 border-t border-[var(--theme-border)]">
                  Fired mineral pigments will not fade, yellow, or embrittle under West African tropical sunshine.
                </p>
              </div>

              {/* Metric 4: Fire Safety */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
                <div className="flex items-center justify-between text-[11px] text-[var(--theme-text-muted)] font-bold uppercase">
                  <span>Fire & Smoke Rating</span>
                  <Flame className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span>{product.name}:</span>
                    <strong className="font-mono text-emerald-600">Class A1 Non-Combustible</strong>
                  </div>
                  <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
                    <span>{activeAlt.name}:</span>
                    <strong className="font-mono text-red-500">{activeAlt.fireRating}</strong>
                  </div>
                </div>
                <p className="text-[10px] text-[var(--theme-text-muted)] pt-1 border-t border-[var(--theme-border)]">
                  Zero toxic off-gassing, VOC emission, or flame propagation in residential or hospitality interiors.
                </p>
              </div>
            </div>

            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Atelier Surfaces ISO 10545 Certified:</strong> All porcelain and natural stone consignments undergo laboratory verification prior to maritime container dispatch from Italy.
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Action Bar */}
      <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-[var(--theme-text-muted)]">
          <Scale className="w-4 h-4 text-[var(--theme-accent)] shrink-0" />
          <span>
            Projecting <strong>{areaSqm} m²</strong> of {product.name} yields <strong className="text-emerald-700 dark:text-emerald-400">{currencySymbol}{calculations.netSavings.toLocaleString()} in net savings</strong> over {timeHorizonYears} years.
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onApplyCalculatedArea && (
            <button
              type="button"
              onClick={() => onApplyCalculatedArea(areaSqm)}
              className="px-4 py-2 bg-[var(--theme-accent)] hover:opacity-95 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-xs flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply {areaSqm} m² to Order</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleConsultAIAgent}
            className="px-3 py-2 bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>Consult AI Agent</span>
          </button>
        </div>
      </div>
    </div>
  );
}
