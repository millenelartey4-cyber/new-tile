import { useState } from 'react';
import { ProductVariant } from '../../types';
import { Calculator, Info, Check } from 'lucide-react';

interface TileAreaCalculatorProps {
  variant: ProductVariant;
  onApplyCalculatedQuantity: (boxesOrM2: number) => void;
}

export function TileAreaCalculator({ variant, onApplyCalculatedQuantity }: TileAreaCalculatorProps) {
  const [unit, setUnit] = useState<'metres' | 'feet'>('metres');
  const [length, setLength] = useState<string>('5.0');
  const [width, setWidth] = useState<string>('4.0');
  const [wastePercent, setWastePercent] = useState<number>(10);
  const [applied, setApplied] = useState(false);

  const numLength = parseFloat(length) || 0;
  const numWidth = parseFloat(width) || 0;

  // Calculate base area in m²
  let baseAreaM2 = 0;
  if (unit === 'metres') {
    baseAreaM2 = Math.max(0, numLength * numWidth);
  } else {
    // 1 sq foot = 0.092903 sq metres
    baseAreaM2 = Math.max(0, (numLength * numWidth) * 0.092903);
  }

  // Add waste percentage
  const wasteAreaM2 = baseAreaM2 * (wastePercent / 100);
  const totalRequiredM2 = baseAreaM2 + wasteAreaM2;

  // Box coverage
  const boxCoverage = variant.boxCoverage || 1.44;
  const requiredBoxes = Math.ceil(totalRequiredM2 / boxCoverage);
  const totalBoxAreaM2 = requiredBoxes * boxCoverage;

  // Total price estimate
  const estimatedCost = variant.unit === 'm²'
    ? totalBoxAreaM2 * variant.price
    : requiredBoxes * variant.price;

  const handleApply = () => {
    // For per m² products, pass the covered m² or boxes
    onApplyCalculatedQuantity(Math.round(totalBoxAreaM2));
    setApplied(true);
    setTimeout(() => setApplied(false), 3000);
  };

  return (
    <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-5 text-[var(--theme-text)]">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-[var(--theme-border)]">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-[var(--theme-accent)]" />
          <h3 className="text-xs uppercase font-bold tracking-wider">
            Tile & Area Estimation Calculator
          </h3>
        </div>
        <div className="flex items-center gap-1 p-0.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[11px]">
          <button
            type="button"
            onClick={() => setUnit('metres')}
            className={`px-2 py-0.5 font-medium transition-colors ${
              unit === 'metres' ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]' : 'text-[var(--theme-text-muted)]'
            }`}
          >
            Metres (m)
          </button>
          <button
            type="button"
            onClick={() => setUnit('feet')}
            className={`px-2 py-0.5 font-medium transition-colors ${
              unit === 'feet' ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]' : 'text-[var(--theme-text-muted)]'
            }`}
          >
            Feet (ft)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <div>
          <label className="block text-[11px] uppercase font-semibold text-[var(--theme-text-muted)] mb-1">
            Room Length ({unit === 'metres' ? 'm' : 'ft'})
          </label>
          <input
            type="number"
            min="0.1"
            step="0.1"
            value={length}
            onChange={e => setLength(e.target.value)}
            className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-sm tabular-nums focus:outline-none focus:border-[var(--theme-accent)]"
          />
        </div>

        <div>
          <label className="block text-[11px] uppercase font-semibold text-[var(--theme-text-muted)] mb-1">
            Room Width ({unit === 'metres' ? 'm' : 'ft'})
          </label>
          <input
            type="number"
            min="0.1"
            step="0.1"
            value={width}
            onChange={e => setWidth(e.target.value)}
            className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-sm tabular-nums focus:outline-none focus:border-[var(--theme-accent)]"
          />
        </div>

        <div>
          <label className="block text-[11px] uppercase font-semibold text-[var(--theme-text-muted)] mb-1">
            Cut & Waste Allowance
          </label>
          <select
            value={wastePercent}
            onChange={e => setWastePercent(parseInt(e.target.value, 10))}
            className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-sm focus:outline-none focus:border-[var(--theme-accent)]"
          >
            <option value={10}>10% (Standard rectangular)</option>
            <option value={15}>15% (Diagonal / Herringbone)</option>
            <option value={20}>20% (Complex niches & pillars)</option>
            <option value={5}>5% (Exact straight run)</option>
          </select>
        </div>
      </div>

      {/* Output Summary */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 mb-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center divide-y sm:divide-y-0 sm:divide-x divide-[var(--theme-border)]">
          <div className="p-1">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block mb-1">Net Room Area</span>
            <span className="text-base font-semibold tabular-nums">{baseAreaM2.toFixed(2)} m²</span>
          </div>

          <div className="p-1">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block mb-1">With {wastePercent}% Waste</span>
            <span className="text-base font-semibold tabular-nums text-[var(--theme-accent)]">{totalRequiredM2.toFixed(2)} m²</span>
          </div>

          <div className="p-1">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block mb-1">Required Boxes</span>
            <span className="text-base font-semibold tabular-nums">{requiredBoxes} boxes</span>
            <span className="text-[10px] text-[var(--theme-text-muted)] block">({boxCoverage} m²/box)</span>
          </div>

          <div className="p-1">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block mb-1">Estimated Cost</span>
            <span className="text-base font-semibold tabular-nums text-[var(--theme-text)]">
              GH₵{estimatedCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-start gap-1.5 text-xs text-[var(--theme-text-muted)]">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <span>We recommend ordering full boxes to ensure batch shade consistency across your installation.</span>
        </div>

        <button
          type="button"
          onClick={handleApply}
          className="w-full sm:w-auto px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-1.5 shrink-0"
        >
          {applied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Applied {Math.round(totalBoxAreaM2)} m²</span>
            </>
          ) : (
            <span>Apply {Math.round(totalBoxAreaM2)} m² to Quantity</span>
          )}
        </button>
      </div>
    </div>
  );
}
