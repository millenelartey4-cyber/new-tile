import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  Search, 
  MapPin, 
  Bot, 
  User, 
  ExternalLink,
  Trash2,
  Calculator,
  ShoppingBag,
  Megaphone,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Video,
  Layers,
  ChevronRight,
  ChevronDown,
  Check,
  Info,
  Sliders,
  DollarSign,
  PackageCheck,
  ScanLine,
  Camera,
  Paperclip,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Brain,
  TrendingUp,
  FileText,
  RefreshCw,
  Printer,
  Compass,
  Image as ImageIcon,
  ZoomIn,
  ZoomOut,
  Download,
  Copy,
  Maximize2,
  Eye
} from 'lucide-react';
import { 
  Product, 
  ProductVariant, 
  AdminBroadcast, 
  BroadcastAudience, 
  BroadcastUrgency, 
  BroadcastPlacement 
} from '../../types';
import { storeService } from '../../services/store';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useRouter } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { INITIAL_PRODUCTS } from '../../data/products';
import { SurfaceTextureScannerModal } from '../scanner/SurfaceTextureScannerModal';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  agentThought?: string | null;
  image?: {
    base64: string;
    name?: string;
  };
  agentAction?: {
    type: 'tile_calculation' | 'durability_roi_comparison' | 'architectural_quote' | 'recommend_products' | 'sample_kit' | 'draft_broadcast' | 'video_consult' | 'display_image' | 'image_gallery';
    // Tile Calculation
    productSlug?: string;
    productName?: string;
    areaSqm?: number;
    wastePct?: number;
    layoutPattern?: 'straight' | 'herringbone' | 'diagonal' | 'chevron' | string;
    totalSqm?: number;
    boxes?: number;
    boxCoverage?: number;
    unitPrice?: number;
    estimatedCost?: number;
    // ROI Durability Comparison
    stoneTileSlug?: string;
    stoneTileName?: string;
    alternativeMaterial?: string;
    alternativeMaterialName?: string;
    timeHorizonYears?: number;
    stoneInitialCost?: number;
    stoneTotal25YrCost?: number;
    altInitialCost?: number;
    altTotal25YrCost?: number;
    totalLifetimeSavings?: number;
    breakEvenYear?: number;
    durabilityInsights?: string[];
    // Architectural Quote
    quoteNumber?: string;
    clientName?: string;
    projectType?: string;
    items?: Array<{
      productName: string;
      quantityBoxes: number;
      areaCoveredSqm: number;
      unitPrice: number;
      totalPrice: number;
    }>;
    deliveryCost?: number;
    taxAmount?: number;
    grandTotal?: number;
    validDays?: number;
    notes?: string;
    // Recommendations
    products?: Array<{
      slug: string;
      name: string;
      material: string;
      finish: string;
      price: number;
      unit: string;
      boxCoverage: number;
      imageUrl?: string;
      rRating?: string;
      highlight?: string;
    }>;
    // Sample Kit
    sampleNames?: string[];
    courierFee?: number;
    dispatchEta?: string;
    deliveryAddress?: string;
    // Broadcast
    title?: string;
    message?: string;
    urgency?: 'info' | 'warning' | 'critical' | 'success';
    audience?: 'all' | 'staff' | 'customers';
    placement?: 'top_banner' | 'modal' | 'toast';
    // Architectural Image & Visualizer
    imageUrl?: string;
    thumbnailUrl?: string;
    imageTitle?: string;
    imageCaption?: string;
    aspectRatio?: string;
    material?: string;
    finish?: string;
    rRating?: string;
    dimensions?: string;
    roomType?: string;
    source?: string;
    altViews?: Array<{
      url: string;
      title: string;
      caption: string;
      viewType: 'room' | 'slab' | 'detail' | 'pattern';
    }>;
    images?: Array<{
      url: string;
      title: string;
      caption?: string;
      tag?: string;
    }>;
  };
  groundingMetadata?: {
    webSearchQueries?: string[];
    searchEntryPoint?: { renderedContent: string };
    groundingChunks?: Array<{
      web?: { uri: string; title: string };
      maps?: { uri?: string; title?: string };
    }>;
  };
}

interface ArchitecturalChatbotProps {
  currentProduct?: Product;
  currentVariant?: ProductVariant;
}

export function ArchitecturalChatbot({ currentProduct, currentVariant }: ArchitecturalChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'calculator'>('chat');
  const [agentRole, setAgentRole] = useState<'concierge' | 'admin'>('concierge');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [isThinkingMode, setIsThinkingMode] = useState(true);
  const [useSearchGrounding, setUseSearchGrounding] = useState(false);
  const [useMapsGrounding, setUseMapsGrounding] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [isScannerModalOpen, setIsScannerModalOpen] = useState(false);
  
  // Multimodal Image Attachment state
  const [attachedImage, setAttachedImage] = useState<{ base64: string; name: string; mimeType: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Voice Interaction (STT / TTS) state
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Accordion state for chain-of-thought traces
  const [expandedThoughts, setExpandedThoughts] = useState<Record<string, boolean>>({});

  // Quick Tile Calculator state
  const [calcArea, setCalcArea] = useState<number>(35);
  const [calcWastePct, setCalcWastePct] = useState<number>(10);
  const [calcSelectedTileSlug, setCalcSelectedTileSlug] = useState<string>('calacatta-statuario-porcelain');

  // Architectural Visualizer Image & Lightbox state
  const [activeAltViewMap, setActiveAltViewMap] = useState<Record<string, number>>({});
  const [lightboxImage, setLightboxImage] = useState<{
    url: string;
    title: string;
    caption?: string;
    material?: string;
    finish?: string;
    rRating?: string;
    dimensions?: string;
    roomType?: string;
    productSlug?: string;
  } | null>(null);
  const [lightboxZoom, setLightboxZoom] = useState<number>(1);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const { addToCart, setIsCartOpen } = useCartWishlist();
  const { navigate } = useRouter();
  const { currentUser } = useAuth();
  const { activeCompany } = useCompany();

  // All catalog products from store or fallback
  const catalogProducts: Product[] = React.useMemo(() => {
    try {
      const prods = storeService.getProducts();
      return prods && prods.length > 0 ? prods : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  }, []);

  // Initial welcome message
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome-1',
      role: 'model',
      content: `Welcome to Atelier Surfaces. I am your Autonomous AI Tile Shop Agent & Architectural Consultant.

I operate with state-of-the-art computational reasoning and quarry-direct material intelligence:
• **Area & Quantity Surveying**: Calculate exact box counts, m² totals, and pattern wastage (Straight 10% vs Herringbone 15%).
• **25-Year Durability & ROI Comparison**: Project long-term savings of Italian vitrified stone vs low-tier alternatives.
• **Official Architectural Trade Quotes**: Generate itemized quotation sheets with hydraulic freight offloading.
• **Multimodal Surface Vision**: Snap or upload any floor/countertop photo using the camera tool for instant vein matching.
• **Tactile Swatch Kits**: Dispatch 3-piece physical sample boxes across Ghana within 24 hours.`,
      agentThought: 'Initialized Autonomous Tile Shop Agent. Ready to compute quantity surveys, compare 25-yr lifecycle durability, analyze attached surface photos, and generate trade quotations.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      if (activeTab === 'chat') {
        inputRef.current?.focus();
      }
    }
  }, [messages, isOpen, activeTab]);

  // Clear notice after 4 seconds
  useEffect(() => {
    if (actionNotice) {
      const timer = setTimeout(() => setActionNotice(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [actionNotice]);

  // Cleanup speech & audio on unmount
  useEffect(() => {
    return () => {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch {}
      }
    };
  }, []);

  // Handle Maps/Search toggle mutual exclusivity per SDK guidelines
  const toggleSearch = () => {
    if (!useSearchGrounding) {
      setUseSearchGrounding(true);
      setUseMapsGrounding(false);
    } else {
      setUseSearchGrounding(false);
    }
  };

  const toggleMaps = () => {
    if (!useMapsGrounding) {
      setUseMapsGrounding(true);
      setUseSearchGrounding(false);
    } else {
      setUseMapsGrounding(false);
    }
  };

  // Toggle thought accordion
  const toggleThought = (msgId: string) => {
    setExpandedThoughts(prev => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  // Image Upload Handler
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setActionNotice('Please select an image file (JPEG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setAttachedImage({
        base64,
        name: file.name,
        mimeType: file.type || 'image/jpeg'
      });
      setActionNotice(`Attached photo: ${file.name}`);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Voice Input (Speech-to-Text)
  const toggleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setActionNotice('Speech recognition is not supported in this browser. Please type your query.');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch {}
      }
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setActionNotice('Listening to your architectural request...');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0]?.[0]?.transcript;
        if (transcript) {
          setInput(prev => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = (err: any) => {
        console.warn('Voice input error:', err);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.warn('Could not start speech recognition:', err);
      setIsListening(false);
    }
  };

  // Text-to-Speech (Audio Voice Output)
  const handleSpeakMessage = async (msgId: string, textContent: string) => {
    if (speakingMsgId === msgId) {
      // Stop current playback
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setSpeakingMsgId(null);
      return;
    }

    // Stop any existing playback
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    setSpeakingMsgId(msgId);

    try {
      // 1. Try server-side Gemini 3.8 Flash Lite TTS endpoint
      const res = await fetch('/api/agent/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textContent, voiceName: 'Kore' })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audioData) {
          const audio = new Audio(data.audioData);
          audioPlayerRef.current = audio;
          audio.onended = () => setSpeakingMsgId(null);
          audio.onerror = () => fallbackBrowserSpeak(msgId, textContent);
          await audio.play();
          return;
        }
      }
    } catch {
      // Fallback to browser synthesis
    }

    fallbackBrowserSpeak(msgId, textContent);
  };

  const fallbackBrowserSpeak = (msgId: string, text: string) => {
    if ('speechSynthesis' in window) {
      const clean = text.replace(/[*_#`[\]()]/g, '').slice(0, 350);
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.onend = () => setSpeakingMsgId(null);
      utterance.onerror = () => setSpeakingMsgId(null);
      window.speechSynthesis.speak(utterance);
    } else {
      setSpeakingMsgId(null);
      setActionNotice('Audio playback not supported in this browser environment.');
    }
  };

  // Send Message Handler
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if ((!text && !attachedImage) || isLoading) return;

    const currentImg = attachedImage;
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text || (currentImg ? 'Please analyze this surface sample and match against the catalog.' : ''),
      image: currentImg ? { base64: currentImg.base64, name: currentImg.name } : undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setAttachedImage(null);
    setIsLoading(true);

    try {
      const productContext = currentProduct && currentVariant ? {
        name: currentProduct.name,
        slug: currentProduct.slug,
        material: currentProduct.material,
        finish: currentProduct.finish,
        colorName: currentVariant.colorName,
        price: currentVariant.price,
        unit: currentVariant.unit,
        coverage: currentVariant.boxCoverage
      } : undefined;

      const orders = storeService.getOrders();
      const verifiedRev = orders
        .filter(o => o.paymentStatus === 'paid')
        .reduce((sum, o) => sum + (o.total || 0), 0);
      const lowStockCount = catalogProducts.filter(p => p.variants.some(v => v.stock < 25)).length;

      const storeMetrics = {
        totalOrders: orders.length,
        totalRevenue: Math.round(verifiedRev),
        productCount: catalogProducts.length,
        lowStockCount
      };

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ 
            role: m.role, 
            content: m.content,
            image: m.image
          })),
          model: selectedModel,
          thinkingLevel: isThinkingMode ? 'HIGH' : undefined,
          useSearchGrounding,
          useMapsGrounding,
          productContext,
          agentRole,
          storeMetrics,
          attachedImage: currentImg ? { base64: currentImg.base64, mimeType: currentImg.mimeType } : undefined
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Server returned an error');
      }

      const data = await response.json();

      const assistantMessage: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        content: data.text,
        agentThought: data.agentThought,
        agentAction: data.agentAction,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        groundingMetadata: data.groundingMetadata
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        content: `I encountered an issue processing your request (${err.message}). The tile shop catalog and quantity calculator remain fully operational.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'model',
        content: `Conversation history refreshed. Atelier Surfaces Autonomous Tile Shop Agent is online. How can I assist your architectural project today?`,
        agentThought: 'Session memory reset. Operational and ready for quantity surveying, ROI modeling, and catalog specification.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // 1-Click Action: Add Calculated Boxes to Cart
  const handleAddCalculatedBoxesToCart = (
    slug?: string, 
    boxesCount?: number, 
    fallbackName?: string
  ) => {
    const targetSlug = slug || calcSelectedTileSlug;
    const count = boxesCount || Math.ceil((calcArea * (1 + calcWastePct / 100)) / 1.44);

    const product = catalogProducts.find(p => p.slug === targetSlug) || catalogProducts[0];
    if (!product || !product.variants[0]) {
      setActionNotice(`Could not locate product specifications for ${fallbackName || targetSlug}.`);
      return;
    }

    addToCart(product, product.variants[0], count);
    setIsCartOpen(true);
    setActionNotice(`Added ${count} boxes of ${product.name} to your cart.`);
  };

  // 1-Click Action: Add All Quote Items to Cart
  const handleAddQuoteToCart = (items?: Array<{ productName: string; quantityBoxes: number }>) => {
    if (!items || items.length === 0) return;
    let addedCount = 0;

    items.forEach(item => {
      const matched = catalogProducts.find(p => 
        p.name.toLowerCase().includes(item.productName.toLowerCase()) || 
        item.productName.toLowerCase().includes(p.name.toLowerCase())
      );
      if (matched && matched.variants[0]) {
        addToCart(matched, matched.variants[0], item.quantityBoxes);
        addedCount++;
      }
    });

    setIsCartOpen(true);
    setActionNotice(`Added ${addedCount} quotation line items to your cart.`);
  };

  // 1-Click Action: Order 3-Swatch Sample Kit
  const handleOrderSampleKit = (sampleNames?: string[]) => {
    const defaultProduct = catalogProducts[0];
    if (defaultProduct && defaultProduct.variants[0]) {
      addToCart(defaultProduct, defaultProduct.variants[0], 1);
      setIsCartOpen(true);
      setActionNotice(`Sample tactile swatches (${(sampleNames || ['Calacatta Statuario', 'Roman Travertine', 'Charente Limestone']).join(', ')}) registered. Dispatched within 24h.`);
    }
  };

  // 1-Click Action: Dispatch AI-Drafted Broadcast to Admin System
  const handlePublishBroadcast = async (broadcastDraft: NonNullable<ChatMessage['agentAction']>) => {
    try {
      const urgencyMap: Record<string, BroadcastUrgency> = {
        critical: 'critical',
        warning: 'warning',
        info: 'info',
        success: 'success',
        urgent: 'critical'
      };
      const placementMap: Record<string, BroadcastPlacement> = {
        top_banner: 'top_banner',
        modal: 'modal',
        toast: 'toast'
      };

      const newBroadcast: AdminBroadcast = {
        id: `bcast-${Date.now()}`,
        title: broadcastDraft.title || 'Architectural Tile Advisory',
        message: broadcastDraft.message || '',
        urgency: (broadcastDraft.urgency && urgencyMap[broadcastDraft.urgency]) ? urgencyMap[broadcastDraft.urgency] : 'warning',
        audience: (broadcastDraft.audience as BroadcastAudience) || 'all',
        placement: (broadcastDraft.placement && placementMap[broadcastDraft.placement]) ? placementMap[broadcastDraft.placement] : 'top_banner',
        active: true,
        isLocked: false,
        dismissible: true,
        createdBy: currentUser?.name ? `${currentUser.name} (via AI Agent)` : 'AI Tile Shop Agent',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      storeService.saveBroadcast(newBroadcast);
      setActionNotice(`Broadcast "${newBroadcast.title}" published storewide.`);
    } catch (err: any) {
      setActionNotice(`Failed to publish broadcast: ${err.message}`);
    }
  };

  // Calculation for the embedded calculator tab
  const selectedTileObj = catalogProducts.find(p => p.slug === calcSelectedTileSlug) || catalogProducts[0];
  const coveragePerBox = selectedTileObj?.variants[0]?.boxCoverage || 1.44;
  const tileUnitPrice = selectedTileObj?.variants[0]?.price || 420;
  const computedTotalSqm = Math.round(calcArea * (1 + calcWastePct / 100) * 100) / 100;
  const computedBoxes = Math.ceil(computedTotalSqm / coveragePerBox);
  const computedTotalCost = computedBoxes * tileUnitPrice;

  // Prompt suggestions with instant picture and visual display triggers
  const conciergePrompts = [
    '📸 Show picture of Calacatta Statuario luxury foyer',
    '📸 Show French Limestone pool terrace & patio picture',
    '📸 Display picture of Nero Marquina black marble bathroom',
    '📸 Show picture of herringbone pattern wood porcelain floor',
    '📸 Display picture of Milano Terrazzo kitchen floor',
    '📸 Show picture of 3D Fluted Wall Relief panels',
    '📐 Calculate 55m² herringbone living room with 15% waste',
    '💰 Compare Calacatta marble vs ceramic tile 25-yr ROI',
    '📑 Generate formal trade quote for 85m² villa project',
    '📦 Request 3-swatch tactile sample box for Accra site'
  ];

  const adminPrompts = [
    '📊 Analyze current low-stock tiles and restock priorities',
    '📢 Draft urgent weekend 15% flash trade discount broadcast',
    '📑 Generate executive revenue and order performance briefing',
    '⚠️ Draft urgent showroom maintenance notice for all staff'
  ];

  return (
    <>
      {/* Floating Action Launcher Pill */}
      {!isOpen && (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] p-3.5 sm:px-4 sm:py-3 border border-[var(--theme-border)] shadow-2xl flex items-center gap-2.5 hover:opacity-95 transition-all cursor-pointer group"
          title="Open Atelier Autonomous AI Tile Shop Agent"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-[var(--theme-accent)]" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div className="text-left hidden sm:block">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold uppercase tracking-wider">AI Tile Shop Agent</span>
              <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1 py-0.2 uppercase font-bold">
                Online
              </span>
            </div>
            <span className="block text-[10px] opacity-75">Autonomous Concierge · ROI & Vision</span>
          </div>
        </button>
      )}

      {/* Main Agent Drawer / Dialog */}
      {isOpen && (
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-[95vw] sm:w-[490px] h-[670px] max-h-[88vh] bg-[var(--theme-surface)] border-2 border-[var(--theme-border)] shadow-2xl flex flex-col overflow-hidden text-[var(--theme-text)]">
          
          {/* Action Notification Toast Bar */}
          {actionNotice && (
            <div className="bg-emerald-600 text-white text-[11px] font-semibold px-3 py-1.5 flex items-center justify-between animate-fadeIn z-10">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>{actionNotice}</span>
              </span>
              <button 
                type="button"
                onClick={() => setActionNotice(null)}
                className="hover:opacity-75 cursor-pointer ml-2"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Header */}
          <div className="p-3 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="p-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] relative">
                <Bot className="w-4 h-4 text-[var(--theme-accent)]" />
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </span>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-serif-luxury text-sm font-semibold">Atelier Autonomous Agent</h3>
                  <span className="text-[9px] uppercase px-1.5 py-0.2 bg-[var(--theme-accent)] text-white font-bold">
                    OpenAI / Gemini Hybrid
                  </span>
                </div>
                <p className="text-[10px] text-[var(--theme-text-muted)] flex items-center gap-1">
                  <span>Ridge West Flagship</span>
                  <span>·</span>
                  <span className="text-emerald-500 font-bold">Multi-Tool Reasoning Engine</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleClearHistory}
                className="p-1.5 hover:bg-black/5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors cursor-pointer"
                title="Refresh conversation"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-black/5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors cursor-pointer"
                title="Close Agent"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Dual Navigation Sub-Bar: Chat vs Tile Calculator */}
          <div className="grid grid-cols-2 bg-[var(--theme-surface)] border-b border-[var(--theme-border)] text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('chat')}
              className={`py-2 px-3 flex items-center justify-center gap-1.5 transition-colors cursor-pointer border-r border-[var(--theme-border)] ${
                activeTab === 'chat'
                  ? 'bg-[var(--theme-surface-subtle)] text-[var(--theme-accent)] border-b-2 border-b-[var(--theme-accent)]'
                  : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Autonomous Chat</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('calculator')}
              className={`py-2 px-3 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'calculator'
                  ? 'bg-[var(--theme-surface-subtle)] text-[var(--theme-accent)] border-b-2 border-b-[var(--theme-accent)]'
                  : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Tile Box Calculator</span>
            </button>
          </div>

          {/* Agent Persona, Thinking & Tool Strip (Chat Tab Only) */}
          {activeTab === 'chat' && (
            <div className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between gap-1.5 text-xs flex-wrap">
              {/* Role Toggle */}
              <div className="flex items-center gap-1 bg-[var(--theme-surface)] p-0.5 border border-[var(--theme-border)]">
                <button
                  type="button"
                  onClick={() => setAgentRole('concierge')}
                  className={`px-2 py-0.5 text-[10px] font-bold cursor-pointer transition-colors ${
                    agentRole === 'concierge'
                      ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]'
                      : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                  title="Client Architectural Concierge & Tile Specifier"
                >
                  Client Mode
                </button>
                <button
                  type="button"
                  onClick={() => setAgentRole('admin')}
                  className={`px-2 py-0.5 text-[10px] font-bold cursor-pointer transition-colors ${
                    agentRole === 'admin'
                      ? 'bg-amber-600 text-white'
                      : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                  title="Store Manager Operations & Broadcast Drafter"
                >
                  Admin Ops
                </button>
              </div>

              {/* Extended Reasoning / Thinking Mode Toggle */}
              <button
                type="button"
                onClick={() => setIsThinkingMode(!isThinkingMode)}
                className={`px-2 py-0.5 border text-[10px] font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                  isThinkingMode
                    ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400 font-bold'
                    : 'border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                }`}
                title="Toggle Deep Quantity Surveying & Extended Reasoning"
              >
                <Brain className="w-2.5 h-2.5" />
                <span>{isThinkingMode ? 'Thinking ON' : 'Fast Mode'}</span>
              </button>

              {/* Grounding and Camera Tools */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={toggleSearch}
                  className={`px-2 py-0.5 border text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                    useSearchGrounding
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                  title="Enable Google Search Grounding for Live International Quarry Indices"
                >
                  <Search className="w-2.5 h-2.5" />
                  <span>Search</span>
                </button>

                <button
                  type="button"
                  onClick={toggleMaps}
                  className={`px-2 py-0.5 border text-[10px] font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                    useMapsGrounding
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                  title="Enable Google Maps Grounding for Ridge West Flagship & GPS Routing"
                >
                  <MapPin className="w-2.5 h-2.5" />
                  <span>Maps</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsScannerModalOpen(true)}
                  className="px-2 py-0.5 border border-[var(--theme-accent)] bg-[var(--theme-accent)]/10 text-[var(--theme-accent)] hover:bg-[var(--theme-accent)] hover:text-white font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                  title="Open Camera Texture Scanner"
                >
                  <ScanLine className="w-2.5 h-2.5" />
                  <span>Scan</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Product Context Banner (if viewing a PDP) */}
          {currentProduct && currentVariant && activeTab === 'chat' && (
            <div className="px-3 py-1 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between text-[10px] text-[var(--theme-text-muted)]">
              <span>Specimen: <strong>{currentProduct.name}</strong> ({currentVariant.colorName})</span>
              <span className="font-semibold text-[var(--theme-accent)]">GH₵{currentVariant.price}/{currentVariant.unit}</span>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 1: INTERACTIVE TILE BOX CALCULATOR                   */}
          {/* ======================================================== */}
          {activeTab === 'calculator' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs bg-[var(--theme-surface)]">
              <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-3.5 space-y-3">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-[var(--theme-accent)]" />
                  <h4 className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                    Autonomous Tile Estimator
                  </h4>
                </div>
                <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                  Enter your room area and layout pattern. The agent computes precise box counts, accounting for cuts and packaging.
                </p>
              </div>

              {/* Area Input & Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <label htmlFor="agent-calc-area" className="font-semibold text-[var(--theme-text)]">Net Floor / Wall Area (m²)</label>
                  <span className="font-bold font-mono text-[var(--theme-accent)] text-sm">{calcArea} m²</span>
                </div>
                <input
                  id="agent-calc-area"
                  type="range"
                  min="5"
                  max="200"
                  step="1"
                  value={calcArea}
                  onChange={e => setCalcArea(parseFloat(e.target.value) || 5)}
                  className="w-full accent-[var(--theme-accent)] cursor-pointer"
                />
                <div className="flex gap-1.5">
                  {[15, 25, 35, 50, 75, 100].map(val => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setCalcArea(val)}
                      className={`px-2 py-0.5 text-[10px] border cursor-pointer font-mono ${
                        calcArea === val
                          ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)] font-bold'
                          : 'border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)]'
                      }`}
                    >
                      {val}m²
                    </button>
                  ))}
                </div>
              </div>

              {/* Laying Pattern & Waste Margin */}
              <div className="space-y-1.5">
                <label className="font-semibold text-[var(--theme-text)] block">Layout Pattern & Waste Allowance</label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setCalcWastePct(10)}
                    className={`p-2.5 border text-left cursor-pointer transition-colors ${
                      calcWastePct === 10
                        ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)]/10 font-bold'
                        : 'border-[var(--theme-border)] bg-[var(--theme-surface-subtle)]'
                    }`}
                  >
                    <div className="font-bold text-[11px] text-[var(--theme-text)]">+10% Straight Pattern</div>
                    <span className="text-[10px] text-[var(--theme-text-muted)]">Standard grid layout</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCalcWastePct(15)}
                    className={`p-2.5 border text-left cursor-pointer transition-colors ${
                      calcWastePct === 15
                        ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)]/10 font-bold'
                        : 'border-[var(--theme-border)] bg-[var(--theme-surface-subtle)]'
                    }`}
                  >
                    <div className="font-bold text-[11px] text-[var(--theme-text)]">+15% Herringbone / Diagonal</div>
                    <span className="text-[10px] text-[var(--theme-text-muted)]">Angle cuts & complex corners</span>
                  </button>
                </div>
              </div>

              {/* Specimen Picker */}
              <div className="space-y-1.5">
                <label htmlFor="agent-calc-tile-select" className="font-semibold text-[var(--theme-text)] block">Select Architectural Specimen</label>
                <select
                  id="agent-calc-tile-select"
                  value={calcSelectedTileSlug}
                  onChange={e => setCalcSelectedTileSlug(e.target.value)}
                  className="w-full p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium focus:outline-none focus:border-[var(--theme-accent)]"
                >
                  {catalogProducts.map(p => (
                    <option key={p.slug} value={p.slug}>
                      {p.name} — GH₵{p.variants[0]?.price || 420}/{p.variants[0]?.unit || 'm²'} ({p.variants[0]?.boxCoverage || 1.44} m²/box)
                    </option>
                  ))}
                </select>
              </div>

              {/* Calculated Results Summary Card */}
              <div className="bg-[var(--theme-surface-subtle)] border-2 border-[var(--theme-accent)] p-4 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[var(--theme-border)]">
                  <span className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                    Specification Breakdown
                  </span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold text-xs">
                    {computedBoxes} Boxes Required
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Net Area:</span>
                    <strong>{calcArea} m²</strong>
                  </div>
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Waste Margin:</span>
                    <strong>+{calcWastePct}% ({Math.round(calcArea * (calcWastePct / 100) * 10) / 10} m²)</strong>
                  </div>
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Total Delivered Area:</span>
                    <strong>{computedTotalSqm} m²</strong>
                  </div>
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Box Coverage:</span>
                    <strong>{coveragePerBox} m² / box</strong>
                  </div>
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Unit Price:</span>
                    <strong>GH₵{tileUnitPrice}.00 / box</strong>
                  </div>
                  <div>
                    <span className="text-[var(--theme-text-muted)] block">Estimated Total:</span>
                    <strong className="text-[var(--theme-accent)] font-mono text-xs">
                      GH₵{computedTotalCost.toLocaleString()}.00
                    </strong>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleAddCalculatedBoxesToCart()}
                  className="w-full py-2.5 bg-[var(--theme-accent)] hover:opacity-95 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md transition-opacity"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Add {computedBoxes} Boxes to Cart (GH₵{computedTotalCost.toLocaleString()})</span>
                </button>
              </div>

              {/* Quick AI Consultant Prompt Handover */}
              <button
                type="button"
                onClick={() => {
                  setActiveTab('chat');
                  handleSendMessage(`Can you review my tile calculation for ${calcArea}m² of ${selectedTileObj.name} with ${calcWastePct}% waste margin and suggest installation primers and grout width?`);
                }}
                className="w-full py-2 border border-[var(--theme-border)] bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <span>Ask AI Agent to Verify Subfloor & Primer</span>
              </button>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 2: AUTONOMOUS MULTI-TOOL CONVERSATION & AGENT TRACE  */}
          {/* ======================================================== */}
          {activeTab === 'chat' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs bg-[var(--theme-surface)]">
              {messages.map((msg) => {
                const isModel = msg.role === 'model';
                const hasThought = !!msg.agentThought;
                const isThoughtExpanded = !!expandedThoughts[msg.id];
                const isSpeakingThis = speakingMsgId === msg.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex gap-2.5 ${isModel ? 'items-start' : 'items-start flex-row-reverse'}`}
                  >
                    <div
                      className={`w-7 h-7 rounded-xs shrink-0 flex items-center justify-center text-xs font-bold ${
                        isModel
                          ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]'
                          : 'bg-[var(--theme-accent)] text-white'
                      }`}
                    >
                      {isModel ? <Bot className="w-4 h-4 text-[var(--theme-accent)]" /> : <User className="w-4 h-4" />}
                    </div>

                    <div
                      className={`max-w-[85%] rounded-xs p-3.5 space-y-2 border ${
                        isModel
                          ? 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)] text-[var(--theme-text)]'
                          : 'bg-[var(--theme-primary)] border-[var(--theme-border)] text-[var(--theme-primary-contrast)]'
                      }`}
                    >
                      {/* Attached User Image preview */}
                      {msg.image && (
                        <div className="mb-2 rounded-xs overflow-hidden border border-[var(--theme-border)] max-w-[200px]">
                          <img src={msg.image.base64} alt={msg.image.name || 'Surface sample'} className="w-full h-auto object-cover max-h-36" />
                          {msg.image.name && (
                            <div className="bg-black/60 text-white text-[9px] px-1.5 py-0.5 truncate font-mono">
                              📷 {msg.image.name}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Chain-of-Thought (Reasoning Trace) Accordion */}
                      {isModel && hasThought && (
                        <div className="mb-2 bg-[var(--theme-surface)] border border-indigo-500/30 rounded-xs overflow-hidden">
                          <button
                            type="button"
                            onClick={() => toggleThought(msg.id)}
                            className="w-full px-2.5 py-1.5 flex items-center justify-between text-[10px] font-semibold text-indigo-400 bg-indigo-500/5 hover:bg-indigo-500/10 transition cursor-pointer"
                          >
                            <span className="flex items-center gap-1.5">
                              <Brain className="w-3 h-3 text-indigo-400 animate-pulse" />
                              <span>Agent Reasoning & Quantity Survey</span>
                            </span>
                            <span className="flex items-center gap-1 text-[9px] text-[var(--theme-text-muted)] font-mono">
                              {isThoughtExpanded ? 'Hide' : 'Trace'}
                              {isThoughtExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                            </span>
                          </button>
                          {isThoughtExpanded && (
                            <div className="p-2.5 text-[10px] text-[var(--theme-text-muted)] border-t border-indigo-500/20 font-mono leading-relaxed bg-[var(--theme-surface)] whitespace-pre-wrap">
                              {msg.agentThought}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Message Text */}
                      <div className="leading-relaxed whitespace-pre-wrap font-sans text-xs">
                        {msg.content}
                      </div>

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: TILE CALCULATION       */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'tile_calculation' && (
                        <div className="mt-3 p-3 bg-[var(--theme-surface)] border-2 border-[var(--theme-accent)]/60 text-[var(--theme-text)] space-y-2.5">
                          <div className="flex items-center justify-between text-[11px] font-bold border-b border-[var(--theme-border)] pb-1.5">
                            <span className="flex items-center gap-1.5 text-[var(--theme-accent)]">
                              <Calculator className="w-3.5 h-3.5" />
                              <span>Calculated Material Specification</span>
                            </span>
                            <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                              {msg.agentAction.boxes} Boxes
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[10px]">
                            <div>
                              <span className="text-[var(--theme-text-muted)] block">Net Area / Waste:</span>
                              <strong>{msg.agentAction.areaSqm} m² (+{msg.agentAction.wastePct}%)</strong>
                            </div>
                            <div>
                              <span className="text-[var(--theme-text-muted)] block">Layout Pattern:</span>
                              <strong className="capitalize font-mono">{msg.agentAction.layoutPattern || 'Straight'}</strong>
                            </div>
                            <div>
                              <span className="text-[var(--theme-text-muted)] block">Delivered Area:</span>
                              <strong>{msg.agentAction.totalSqm} m²</strong>
                            </div>
                            <div>
                              <span className="text-[var(--theme-text-muted)] block">Unit Price:</span>
                              <strong>GH₵{msg.agentAction.unitPrice}/box</strong>
                            </div>
                            <div className="col-span-2 pt-1 border-t border-[var(--theme-border)] flex items-center justify-between">
                              <span className="text-[var(--theme-text-muted)]">Estimated Total:</span>
                              <strong className="text-emerald-600 dark:text-emerald-400 font-mono text-xs">
                                GH₵{msg.agentAction.estimatedCost?.toLocaleString()}.00
                              </strong>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-1.5 pt-1">
                            <button
                              type="button"
                              onClick={() => handleAddCalculatedBoxesToCart(
                                msg.agentAction?.productSlug, 
                                msg.agentAction?.boxes, 
                                msg.agentAction?.productName
                              )}
                              className="py-2 bg-[var(--theme-accent)] hover:opacity-90 text-white font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                            >
                              <ShoppingBag className="w-3 h-3" />
                              <span>Add {msg.agentAction.boxes} Boxes</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOrderSampleKit([msg.agentAction?.productName || 'Calacatta Statuario'])}
                              className="py-2 border border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] text-[var(--theme-text)] font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <PackageCheck className="w-3 h-3 text-[var(--theme-accent)]" />
                              <span>Order Swatch</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: 25-YEAR DURABILITY ROI */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'durability_roi_comparison' && (
                        <div className="mt-3 p-3.5 bg-[var(--theme-surface)] border-2 border-emerald-500/60 text-[var(--theme-text)] space-y-3">
                          <div className="flex items-center justify-between text-[11px] font-bold border-b border-[var(--theme-border)] pb-1.5">
                            <span className="flex items-center gap-1.5 text-emerald-500">
                              <TrendingUp className="w-3.5 h-3.5" />
                              <span>25-Year Lifecycle ROI Comparison</span>
                            </span>
                            <span className="font-mono text-emerald-400 font-bold bg-emerald-500/20 px-1.5 py-0.5 border border-emerald-500/40 text-[9px] uppercase">
                              Break-Even Yr {msg.agentAction.breakEvenYear || 6}
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between text-[10px]">
                              <span>{msg.agentAction.stoneTileName || 'Italian Vitrified Stone'}</span>
                              <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                GH₵{msg.agentAction.stoneTotal25YrCost?.toLocaleString()}
                              </span>
                            </div>
                            <div className="w-full bg-[var(--theme-surface-subtle)] h-2 rounded-xs overflow-hidden border border-[var(--theme-border)]">
                              <div className="bg-emerald-500 h-full" style={{ width: '38%' }} />
                            </div>

                            <div className="flex items-center justify-between text-[10px] pt-1">
                              <span>{msg.agentAction.alternativeMaterialName || 'Budget Ceramic Alternative'}</span>
                              <span className="font-mono font-bold text-amber-600">
                                GH₵{msg.agentAction.altTotal25YrCost?.toLocaleString()}
                              </span>
                            </div>
                            <div className="w-full bg-[var(--theme-surface-subtle)] h-2 rounded-xs overflow-hidden border border-[var(--theme-border)]">
                              <div className="bg-amber-500 h-full" style={{ width: '85%' }} />
                            </div>
                          </div>

                          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 text-[11px] flex items-center justify-between">
                            <span className="text-[var(--theme-text)] font-semibold">Net 25-Year Material Savings:</span>
                            <strong className="text-emerald-600 dark:text-emerald-400 font-mono text-xs">
                              GH₵{msg.agentAction.totalLifetimeSavings?.toLocaleString()}.00
                            </strong>
                          </div>

                          {msg.agentAction.durabilityInsights && msg.agentAction.durabilityInsights.length > 0 && (
                            <ul className="space-y-1 text-[10px] text-[var(--theme-text-muted)] border-t border-[var(--theme-border)] pt-2">
                              {msg.agentAction.durabilityInsights.map((insight, idx) => (
                                <li key={idx} className="flex items-start gap-1.5">
                                  <ShieldCheck className="w-3 h-3 text-emerald-500 shrink-0 mt-0.5" />
                                  <span>{insight}</span>
                                </li>
                              ))}
                            </ul>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              navigate('/product/calacatta-statuario-porcelain#roi-calculator');
                              setIsOpen(false);
                            }}
                            className="w-full py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer hover:opacity-90"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Launch Full Interactive Surface ROI Calculator</span>
                          </button>
                        </div>
                      )}

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: ARCHITECTURAL QUOTE    */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'architectural_quote' && (
                        <div className="mt-3 p-3.5 bg-[var(--theme-surface)] border-2 border-[var(--theme-primary)] text-[var(--theme-text)] space-y-3 font-sans">
                          <div className="flex items-center justify-between text-[11px] font-bold border-b border-[var(--theme-border)] pb-2">
                            <span className="flex items-center gap-1.5 text-[var(--theme-text)] font-serif-luxury text-xs">
                              <FileText className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                              <span>Trade Quotation #{msg.agentAction.quoteNumber || 'AT-2026-914'}</span>
                            </span>
                            <span className="font-mono text-[9px] bg-stone-800 text-stone-200 px-1.5 py-0.5">
                              30-Day Guarantee
                            </span>
                          </div>

                          <div className="text-[10px] text-[var(--theme-text-muted)] space-y-0.5">
                            <div>Project: <strong>{msg.agentAction.projectType || 'Luxury Residence Specification'}</strong></div>
                            <div>Client: <strong>{msg.agentAction.clientName || 'Architectural Partner'}</strong></div>
                          </div>

                          {msg.agentAction.items && (
                            <div className="border border-[var(--theme-border)] divide-y divide-[var(--theme-border)] text-[10px]">
                              {msg.agentAction.items.map((item, idx) => (
                                <div key={idx} className="p-2 flex items-center justify-between">
                                  <div className="min-w-0 pr-2">
                                    <div className="font-semibold text-[var(--theme-text)] truncate">{item.productName}</div>
                                    <div className="text-[9px] text-[var(--theme-text-muted)]">{item.quantityBoxes} boxes ({item.areaCoveredSqm} m²)</div>
                                  </div>
                                  <div className="font-mono font-bold shrink-0">GH₵{item.totalPrice.toLocaleString()}</div>
                                </div>
                              ))}
                            </div>
                          )}

                          <div className="space-y-1 text-[10px] border-t border-[var(--theme-border)] pt-2">
                            <div className="flex justify-between text-[var(--theme-text-muted)]">
                              <span>Hydraulic Tailgate Delivery (Accra):</span>
                              <span className="font-mono">GH₵{(msg.agentAction.deliveryCost || 150).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between text-[var(--theme-text-muted)]">
                              <span>Estimated VAT/NHIL:</span>
                              <span className="font-mono">GH₵{(msg.agentAction.taxAmount || 0).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between font-bold text-xs pt-1 border-t border-[var(--theme-border)]">
                              <span>Grand Total:</span>
                              <span className="font-mono text-emerald-600 dark:text-emerald-400">
                                GH₵{msg.agentAction.grandTotal?.toLocaleString()}.00
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-1.5 pt-1">
                            <button
                              type="button"
                              onClick={() => handleAddQuoteToCart(msg.agentAction?.items)}
                              className="py-2 bg-[var(--theme-accent)] hover:opacity-90 text-white font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                            >
                              <ShoppingBag className="w-3 h-3" />
                              <span>Add Items to Cart</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                window.print();
                              }}
                              className="py-2 border border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] text-[var(--theme-text)] font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Printer className="w-3 h-3 text-[var(--theme-accent)]" />
                              <span>Print Spec Sheet</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: RECOMMENDED PRODUCTS   */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'recommend_products' && msg.agentAction.products && (
                        <div className="mt-3 space-y-2">
                          {msg.agentAction.products.map((item, idx) => (
                            <div 
                              key={idx}
                              className="p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] flex items-center justify-between gap-3 text-xs"
                            >
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <h5 className="font-bold truncate text-[var(--theme-text)]">{item.name}</h5>
                                  {item.rRating && (
                                    <span className="text-[9px] px-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono font-bold">
                                      {item.rRating}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[10px] text-[var(--theme-text-muted)]">
                                  {item.material} · {item.finish}
                                </p>
                                <span className="text-[11px] font-bold text-[var(--theme-accent)]">
                                  GH₵{item.price}/{item.unit}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => navigate(`/product/${item.slug}`)}
                                  className="px-2 py-1 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-border)] text-[10px] font-semibold text-[var(--theme-text)] cursor-pointer"
                                >
                                  Specs
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleAddCalculatedBoxesToCart(item.slug, 1, item.name)}
                                  className="px-2.5 py-1 bg-[var(--theme-accent)] text-white text-[10px] font-bold cursor-pointer hover:opacity-90"
                                >
                                  + Cart
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: TACTILE SAMPLE KIT     */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'sample_kit' && (
                        <div className="mt-3 p-3 bg-[var(--theme-surface)] border border-[var(--theme-accent)]/50 text-[var(--theme-text)] space-y-2.5">
                          <div className="flex items-center justify-between text-[11px] font-bold border-b border-[var(--theme-border)] pb-1.5">
                            <span className="flex items-center gap-1.5 text-[var(--theme-accent)]">
                              <PackageCheck className="w-3.5 h-3.5" />
                              <span>Architectural Tactile Swatch Kit</span>
                            </span>
                            <span className="font-mono text-emerald-500 text-[10px]">
                              GH₵{msg.agentAction.courierFee || 80} Express
                            </span>
                          </div>

                          <p className="text-[10px] text-[var(--theme-text-muted)]">
                            Includes 3 nominal precision-cut stone/porcelain swatches for physical touch, gloss reflection, and water testing:
                          </p>

                          <div className="space-y-1 text-[10px] font-semibold">
                            {(msg.agentAction.sampleNames || ['Calacatta Statuario', 'Roman Travertine Navona', 'French Charente Limestone']).map((name, i) => (
                              <div key={i} className="flex items-center gap-1.5 text-[var(--theme-text)]">
                                <span className="w-1.5 h-1.5 rounded-full bg-[var(--theme-accent)]" />
                                <span>{name}</span>
                              </div>
                            ))}
                          </div>

                          <div className="p-2 bg-[var(--theme-surface-subtle)] text-[10px] flex items-center justify-between">
                            <span className="text-[var(--theme-text-muted)]">Dispatch Time:</span>
                            <span className="font-semibold text-emerald-500">{msg.agentAction.dispatchEta || 'Within 24 Hours in Greater Accra'}</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleOrderSampleKit(msg.agentAction?.sampleNames)}
                            className="w-full py-2 bg-[var(--theme-accent)] text-white font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer hover:opacity-90 shadow-xs"
                          >
                            <PackageCheck className="w-3.5 h-3.5" />
                            <span>Confirm Sample Dispatch (GH₵{msg.agentAction.courierFee || 80})</span>
                          </button>
                        </div>
                      )}

                      {/* ============================================== */}
                      {/* STRUCTURED ACTION CARD: DRAFT BROADCAST (ADMIN) */}
                      {/* ============================================== */}
                      {msg.agentAction?.type === 'draft_broadcast' && (
                        <div className="mt-3 p-3 bg-amber-500/10 border border-amber-500/40 text-[var(--theme-text)] space-y-2">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-bold flex items-center gap-1.5 text-amber-500">
                              <Megaphone className="w-3.5 h-3.5" />
                              <span>AI Broadcast Draft Prepared</span>
                            </span>
                            <span className="uppercase text-[9px] px-1.5 py-0.5 bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                              {msg.agentAction.urgency || 'urgent'}
                            </span>
                          </div>

                          <div className="text-[11px]">
                            <strong>Title:</strong> {msg.agentAction.title}
                          </div>
                          <p className="text-[10px] text-[var(--theme-text-muted)] bg-[var(--theme-surface)] p-2 border border-[var(--theme-border)]">
                            {msg.agentAction.message}
                          </p>

                          <button
                            type="button"
                            onClick={() => handlePublishBroadcast(msg.agentAction!)}
                            className="w-full py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Publish via Admin Broadcast System</span>
                          </button>
                        </div>
                      )}

                      {/* ============================================================== */}
                      {/* STRUCTURED ACTION CARD: DISPLAY IMAGE & ARCHITECTURAL VISUAL   */}
                      {/* ============================================================== */}
                      {msg.agentAction?.type === 'display_image' && msg.agentAction.imageUrl && (() => {
                        const allViews = [
                          {
                            url: msg.agentAction.imageUrl!,
                            title: msg.agentAction.imageTitle || 'Architectural Space',
                            caption: msg.agentAction.imageCaption || '',
                            viewType: 'room' as const
                          },
                          ...(msg.agentAction.altViews || [])
                        ];
                        // Deduplicate views by URL
                        const uniqueViews = allViews.filter((v, idx, arr) => arr.findIndex(x => x.url === v.url) === idx);
                        const activeIdx = (activeAltViewMap[msg.id] ?? 0) % (uniqueViews.length || 1);
                        const activeView = uniqueViews[activeIdx] || uniqueViews[0];

                        return (
                          <div className="mt-3 overflow-hidden border border-[var(--theme-border)] bg-[var(--theme-surface)] rounded-xs shadow-md">
                            {/* Header bar */}
                            <div className="px-3 py-2 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <ImageIcon className="w-3.5 h-3.5 text-[var(--theme-accent)] shrink-0" />
                                <span className="text-[11px] font-bold truncate text-[var(--theme-text)]">
                                  {msg.agentAction.imageTitle || 'Architectural Specification Visual'}
                                </span>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                {msg.agentAction.rRating && (
                                  <span className="text-[9px] px-1.5 py-0.5 bg-emerald-500/15 text-emerald-400 font-mono font-semibold border border-emerald-500/30">
                                    {msg.agentAction.rRating}
                                  </span>
                                )}
                                <button
                                  type="button"
                                  onClick={() => setLightboxImage({
                                    url: activeView.url,
                                    title: activeView.title || msg.agentAction?.imageTitle || '',
                                    caption: activeView.caption || msg.agentAction?.imageCaption || '',
                                    material: msg.agentAction?.material,
                                    finish: msg.agentAction?.finish,
                                    rRating: msg.agentAction?.rRating,
                                    dimensions: msg.agentAction?.dimensions,
                                    roomType: msg.agentAction?.roomType,
                                    productSlug: msg.agentAction?.productSlug
                                  })}
                                  className="p-1 hover:text-[var(--theme-accent)] text-[var(--theme-text-muted)] transition-colors cursor-pointer"
                                  title="Expand full-screen lightbox"
                                >
                                  <Maximize2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            {/* Main Image Container */}
                            <div 
                              className="relative group cursor-pointer overflow-hidden bg-black/40 aspect-video max-h-60"
                              onClick={() => setLightboxImage({
                                url: activeView.url,
                                title: activeView.title || msg.agentAction?.imageTitle || '',
                                caption: activeView.caption || msg.agentAction?.imageCaption || '',
                                material: msg.agentAction?.material,
                                finish: msg.agentAction?.finish,
                                rRating: msg.agentAction?.rRating,
                                dimensions: msg.agentAction?.dimensions,
                                roomType: msg.agentAction?.roomType,
                                productSlug: msg.agentAction?.productSlug
                              })}
                            >
                              <img 
                                src={activeView.url.startsWith('/src/assets/') ? activeView.url.replace('/src/assets/', '/assets/') : activeView.url} 
                                alt={activeView.title}
                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                loading="lazy"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg';
                                }}
                              />

                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80 group-hover:opacity-95 transition-opacity pointer-events-none" />

                              {/* Hover Zoom Badge */}
                              <div className="absolute top-2 right-2 px-2 py-1 bg-black/60 backdrop-blur-xs text-white text-[9px] font-mono flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <ZoomIn className="w-3 h-3 text-amber-400" />
                                <span>Click to Enlarge</span>
                              </div>

                              {/* Bottom Overlay Label */}
                              <div className="absolute bottom-2 left-3 right-3 text-white pointer-events-none">
                                <div className="text-[10px] font-semibold flex items-center gap-1.5 drop-shadow-md">
                                  <span>{activeView.title}</span>
                                </div>
                                {activeView.caption && (
                                  <p className="text-[9px] text-white/80 line-clamp-1 font-light drop-shadow-xs mt-0.5">
                                    {activeView.caption}
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Multi-Angle Viewport Switcher */}
                            {uniqueViews.length > 1 && (
                              <div className="p-1.5 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex items-center gap-1 overflow-x-auto text-[9px]">
                                <span className="text-[var(--theme-text-muted)] font-mono pl-1 uppercase tracking-wider text-[8px] shrink-0">
                                  Angles:
                                </span>
                                {uniqueViews.map((view, vIdx) => {
                                  const isActive = vIdx === activeIdx;
                                  const label = view.viewType === 'room' ? '🏛️ Room View' :
                                                view.viewType === 'slab' ? '💎 Slab Vein' :
                                                view.viewType === 'pattern' ? '📐 Lay Pattern' : '🔬 Detail';
                                  return (
                                    <button
                                      key={vIdx}
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setActiveAltViewMap(prev => ({ ...prev, [msg.id]: vIdx }));
                                      }}
                                      className={`px-2 py-1 text-[9px] font-medium border transition-colors cursor-pointer shrink-0 ${
                                        isActive 
                                          ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white shadow-xs' 
                                          : 'border-[var(--theme-border)] bg-[var(--theme-surface)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                                      }`}
                                    >
                                      {label}
                                    </button>
                                  );
                                })}
                              </div>
                            )}

                            {/* Specification Strip */}
                            <div className="p-2.5 text-[10px] space-y-2 border-t border-[var(--theme-border)]">
                              <div className="grid grid-cols-2 gap-2 text-[10px]">
                                {msg.agentAction.material && (
                                  <div>
                                    <span className="text-[var(--theme-text-muted)] block text-[9px]">Material & Sheen:</span>
                                    <strong className="text-[var(--theme-text)]">{msg.agentAction.material}</strong>
                                    {msg.agentAction.finish && <span className="text-[var(--theme-text-muted)]"> ({msg.agentAction.finish})</span>}
                                  </div>
                                )}
                                {msg.agentAction.dimensions && (
                                  <div>
                                    <span className="text-[var(--theme-text-muted)] block text-[9px]">Dimensions:</span>
                                    <strong className="font-mono text-[var(--theme-text)]">{msg.agentAction.dimensions}</strong>
                                  </div>
                                )}
                                {msg.agentAction.roomType && (
                                  <div className="col-span-2">
                                    <span className="text-[var(--theme-text-muted)] block text-[9px]">Architectural Space:</span>
                                    <span className="text-[var(--theme-text)] font-medium">{msg.agentAction.roomType}</span>
                                  </div>
                                )}
                              </div>

                              {/* Interactive Actions on Image */}
                              <div className="pt-2 border-t border-[var(--theme-border)] flex flex-wrap gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (msg.agentAction?.productSlug) {
                                      setCalcSelectedTileSlug(msg.agentAction.productSlug);
                                    }
                                    setActiveTab('calculator');
                                  }}
                                  className="flex-1 min-w-[130px] py-1.5 px-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text)] font-semibold text-[10px] flex items-center justify-center gap-1 cursor-pointer transition-colors"
                                >
                                  <Calculator className="w-3 h-3 text-[var(--theme-accent)]" />
                                  <span>Calculate Requirements</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleOrderSampleKit([msg.agentAction?.imageTitle || 'Architectural Specimen'])}
                                  className="flex-1 min-w-[120px] py-1.5 px-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text)] font-semibold text-[10px] flex items-center justify-center gap-1 cursor-pointer transition-colors"
                                >
                                  <PackageCheck className="w-3 h-3 text-emerald-500" />
                                  <span>Order 3-Swatch Kit</span>
                                </button>

                                {msg.agentAction.productSlug && (
                                  <button
                                    type="button"
                                    onClick={() => handleAddCalculatedBoxesToCart(msg.agentAction?.productSlug, 1, msg.agentAction?.imageTitle)}
                                    className="py-1.5 px-3 bg-[var(--theme-accent)] hover:opacity-90 text-white font-bold text-[10px] flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                                  >
                                    <ShoppingBag className="w-3 h-3" />
                                    <span>Add 1 Box</span>
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })()}

                      {/* Grounding Attribution */}
                      {msg.groundingMetadata?.groundingChunks && msg.groundingMetadata.groundingChunks.length > 0 && (
                        <div className="mt-2.5 pt-2 border-t border-[var(--theme-border)] text-[10px]">
                          <span className="font-semibold block text-[var(--theme-text-muted)] mb-1">
                            Verified Grounding:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {msg.groundingMetadata.groundingChunks.map((chunk, i) => {
                              if (chunk.web?.uri) {
                                return (
                                  <a
                                    key={i}
                                    href={chunk.web.uri}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-accent)] hover:underline truncate max-w-[200px]"
                                  >
                                    <ExternalLink className="w-2.5 h-2.5" />
                                    <span>{chunk.web.title || 'Source'}</span>
                                  </a>
                                );
                              }
                              if (chunk.maps?.title) {
                                return (
                                  <span
                                    key={i}
                                    className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)]"
                                  >
                                    <MapPin className="w-2.5 h-2.5 text-red-500" />
                                    <span>{chunk.maps.title}</span>
                                  </span>
                                );
                              }
                              return null;
                            })}
                          </div>
                        </div>
                      )}

                      {/* Footer Info: Timestamp & Voice TTS Read Button */}
                      <div className="mt-1 flex items-center justify-between text-[9px] opacity-75 pt-1">
                        {isModel && (
                          <button
                            type="button"
                            onClick={() => handleSpeakMessage(msg.id, msg.content)}
                            className={`flex items-center gap-1 hover:opacity-100 transition cursor-pointer font-medium ${
                              isSpeakingThis ? 'text-emerald-500 font-bold animate-pulse' : 'text-[var(--theme-text-muted)]'
                            }`}
                            title="Listen to agent audio response"
                          >
                            {isSpeakingThis ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                            <span>{isSpeakingThis ? 'Mute Audio' : 'Listen'}</span>
                          </button>
                        )}
                        <span className="ml-auto font-mono">{msg.timestamp}</span>
                      </div>
                    </div>
                  </div>
                );
              })}

              {isLoading && (
                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs space-y-1.5 animate-pulse">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[var(--theme-accent)]">
                    <Brain className="w-4 h-4 animate-spin" />
                    <span>Autonomous Agent is analyzing requirements & calculating specs...</span>
                  </div>
                  <div className="text-[10px] text-[var(--theme-text-muted)] font-mono pl-6">
                    {isThinkingMode 
                      ? 'Applying dimensional quantity surveying, material wear indices, and Accra freight logistics...' 
                      : 'Retrieving catalog specifications...'}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Quick Actions Strip (Chat Tab) */}
          {activeTab === 'chat' && (
            <div className="px-3 py-1.5 bg-[var(--theme-surface)] border-t border-[var(--theme-border)] flex gap-1.5 overflow-x-auto text-[10px]">
              {(agentRole === 'concierge' ? conciergePrompts : adminPrompts).map((prompt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    handleSendMessage(prompt);
                  }}
                  className="px-2.5 py-1 border border-[var(--theme-border)] hover:border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] shrink-0 transition-colors cursor-pointer max-w-[240px] truncate text-left"
                >
                  {prompt}
                </button>
              ))}
            </div>
          )}

          {/* Quick Video Consultation & Samples Footer Pill */}
          <div className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex items-center justify-between text-[10px] text-[var(--theme-text-muted)]">
            <button
              type="button"
              onClick={() => {
                navigate('/video-consultation');
                setIsOpen(false);
              }}
              className="flex items-center gap-1 text-[var(--theme-accent)] hover:underline font-semibold cursor-pointer"
            >
              <Video className="w-3 h-3" />
              <span>Book 1-on-1 Video Consultation</span>
            </button>
            <span className="font-mono text-[9px]">Ridge West · Ghana (0542443125/0596334488)</span>
          </div>

          {/* Input Box & Multimodal Attachment Bar (Chat Tab Only) */}
          {activeTab === 'chat' && (
            <div className="p-3 bg-[var(--theme-surface)] border-t border-[var(--theme-border)] space-y-2">
              
              {/* Attached Image Thumbnail Chip */}
              {attachedImage && (
                <div className="flex items-center justify-between p-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <img src={attachedImage.base64} alt="Attached" className="w-6 h-6 object-cover border border-[var(--theme-border)]" />
                    <span className="text-[11px] font-mono truncate">{attachedImage.name}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setAttachedImage(null)}
                    className="p-1 hover:text-red-500 cursor-pointer"
                    title="Remove attached photo"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageSelect}
              />

              <form
                onSubmit={e => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center gap-1.5"
              >
                {/* Photo / Texture Upload Button */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 border border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] hover:border-[var(--theme-accent)] transition cursor-pointer"
                  title="Upload floor or stone photo for multimodal inspection"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {/* Camera Texture Scanner Launch Button */}
                <button
                  type="button"
                  onClick={() => setIsScannerModalOpen(true)}
                  className="p-2 border border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] hover:border-[var(--theme-accent)] transition cursor-pointer"
                  title="Capture floor sample via live camera"
                >
                  <Camera className="w-4 h-4" />
                </button>

                {/* Voice Input (Speech-to-Text) Button */}
                <button
                  type="button"
                  onClick={toggleVoiceInput}
                  className={`p-2 border transition cursor-pointer ${
                    isListening
                      ? 'border-red-500 bg-red-500/20 text-red-500 animate-pulse'
                      : 'border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                  title={isListening ? 'Stop listening' : 'Speak your architectural inquiry'}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>

                {/* Text input */}
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  placeholder={
                    agentRole === 'concierge'
                      ? "Calculate 50m² tiles, 25-yr ROI, quote, R11 outdoor..."
                      : "Analyze low stock, draft emergency broadcast, sales report..."
                  }
                  disabled={isLoading}
                  className="flex-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] px-3 py-2 text-xs text-[var(--theme-text)] placeholder-[var(--theme-text-muted)] focus:outline-none focus:border-[var(--theme-accent)]"
                />

                {/* Send Button */}
                <button
                  type="submit"
                  disabled={(!input.trim() && !attachedImage) || isLoading}
                  className="p-2 bg-[var(--theme-accent)] text-white hover:opacity-90 disabled:opacity-50 transition-opacity cursor-pointer shrink-0 shadow-xs"
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </div>
      )}

      {/* Surface Texture Scanner Modal Handover */}
      <SurfaceTextureScannerModal
        isOpen={isScannerModalOpen}
        onClose={() => setIsScannerModalOpen(false)}
        onSendToAIAgent={prompt => {
          setActiveTab('chat');
          handleSendMessage(prompt);
        }}
      />

      {/* ============================================================== */}
      {/* FULLSCREEN ARCHITECTURAL LIGHTBOX MODAL WITH ZOOM & SPEC SHEET */}
      {/* ============================================================== */}
      {lightboxImage && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex flex-col animate-in fade-in duration-200"
          onClick={() => {
            setLightboxImage(null);
            setLightboxZoom(1);
          }}
        >
          {/* Top Bar Controls */}
          <div 
            className="p-3 md:p-4 bg-black/60 border-b border-white/10 flex items-center justify-between gap-3 text-white shrink-0"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 min-w-0">
              <ImageIcon className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="truncate">
                <h3 className="text-sm font-bold truncate">{lightboxImage.title}</h3>
                {lightboxImage.material && (
                  <p className="text-[11px] text-white/60 font-mono truncate">
                    {lightboxImage.material} {lightboxImage.finish ? `· ${lightboxImage.finish}` : ''} {lightboxImage.dimensions ? `· ${lightboxImage.dimensions}` : ''}
                  </p>
                )}
              </div>
            </div>

            {/* Action Tools */}
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Zoom Out */}
              <button
                type="button"
                onClick={() => setLightboxZoom(prev => Math.max(0.75, prev - 0.25))}
                className="p-2 hover:bg-white/10 rounded-xs transition-colors cursor-pointer text-white/80 hover:text-white"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              <span className="text-[11px] font-mono px-2 py-0.5 bg-white/10 rounded-xs text-white/90 min-w-[48px] text-center">
                {Math.round(lightboxZoom * 100)}%
              </span>

              {/* Zoom In */}
              <button
                type="button"
                onClick={() => setLightboxZoom(prev => Math.min(2.5, prev + 0.25))}
                className="p-2 hover:bg-white/10 rounded-xs transition-colors cursor-pointer text-white/80 hover:text-white"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              {/* Reset Zoom */}
              {lightboxZoom !== 1 && (
                <button
                  type="button"
                  onClick={() => setLightboxZoom(1)}
                  className="px-2 py-1 text-[10px] font-mono bg-white/10 hover:bg-white/20 rounded-xs transition-colors cursor-pointer text-white"
                >
                  Reset
                </button>
              )}

              {/* Copy Link */}
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(lightboxImage.url);
                  setCopiedLink(true);
                  setTimeout(() => setCopiedLink(false), 2000);
                }}
                className="p-2 hover:bg-white/10 rounded-xs transition-colors cursor-pointer text-white/80 hover:text-white flex items-center gap-1"
                title="Copy high-res image link"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>

              {/* Direct Download */}
              <a
                href={lightboxImage.url}
                download={`${lightboxImage.title.toLowerCase().replace(/\s+/g, '_')}.jpg`}
                target="_blank"
                rel="noreferrer"
                className="p-2 hover:bg-white/10 rounded-xs transition-colors cursor-pointer text-white/80 hover:text-white"
                title="Download full resolution photo"
              >
                <Download className="w-4 h-4" />
              </a>

              {/* Close Button */}
              <button
                type="button"
                onClick={() => {
                  setLightboxImage(null);
                  setLightboxZoom(1);
                }}
                className="p-2 ml-2 hover:bg-red-500/20 text-white/80 hover:text-red-400 rounded-xs transition-colors cursor-pointer"
                title="Close Lightbox (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body: Image Canvas & Info Drawer */}
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Viewport Canvas */}
            <div 
              className="flex-1 overflow-auto flex items-center justify-center p-4 relative"
              onClick={e => e.stopPropagation()}
            >
              <div 
                className="transition-transform duration-200 ease-out origin-center select-none"
                style={{ transform: `scale(${lightboxZoom})` }}
              >
                <img
                  src={lightboxImage.url.startsWith('/src/assets/') ? lightboxImage.url.replace('/src/assets/', '/assets/') : lightboxImage.url}
                  alt={lightboxImage.title}
                  className="max-h-[75vh] max-w-[85vw] object-contain shadow-2xl rounded-xs border border-white/10"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg';
                  }}
                />
              </div>
            </div>

            {/* Sidebar Architectural Spec Panel */}
            <div 
              className="w-full lg:w-80 bg-stone-900/90 border-t lg:border-t-0 lg:border-l border-white/10 p-4 text-white overflow-y-auto space-y-4 shrink-0"
              onClick={e => e.stopPropagation()}
            >
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 block mb-1">
                  Architectural Specification
                </span>
                <h4 className="text-base font-bold leading-tight">{lightboxImage.title}</h4>
                {lightboxImage.caption && (
                  <p className="text-xs text-white/70 mt-2 font-light leading-relaxed">
                    {lightboxImage.caption}
                  </p>
                )}
              </div>

              {/* Specs Grid */}
              <div className="space-y-2 pt-3 border-t border-white/10 text-xs">
                {lightboxImage.material && (
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-white/50">Material:</span>
                    <span className="font-semibold">{lightboxImage.material}</span>
                  </div>
                )}
                {lightboxImage.finish && (
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-white/50">Sheen & Finish:</span>
                    <span className="font-semibold">{lightboxImage.finish}</span>
                  </div>
                )}
                {lightboxImage.rRating && (
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-white/50">Slip Resistance:</span>
                    <span className="font-mono text-emerald-400 font-bold">{lightboxImage.rRating}</span>
                  </div>
                )}
                {lightboxImage.dimensions && (
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-white/50">Dimensions:</span>
                    <span className="font-mono">{lightboxImage.dimensions}</span>
                  </div>
                )}
                {lightboxImage.roomType && (
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-white/50">Application:</span>
                    <span>{lightboxImage.roomType}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons inside Lightbox */}
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    if (lightboxImage.productSlug) {
                      setCalcSelectedTileSlug(lightboxImage.productSlug);
                    }
                    setLightboxImage(null);
                    setIsOpen(true);
                    setActiveTab('calculator');
                  }}
                  className="w-full py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-colors border border-white/20"
                >
                  <Calculator className="w-3.5 h-3.5 text-amber-400" />
                  <span>Calculate m² Requirements</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleOrderSampleKit([lightboxImage.title]);
                    setLightboxImage(null);
                  }}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
                >
                  <PackageCheck className="w-3.5 h-3.5" />
                  <span>Request 3-Swatch Kit</span>
                </button>

                {lightboxImage.productSlug && (
                  <button
                    type="button"
                    onClick={() => {
                      handleAddCalculatedBoxesToCart(lightboxImage.productSlug, 1, lightboxImage.title);
                      setLightboxImage(null);
                    }}
                    className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Add Box to Cart</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
