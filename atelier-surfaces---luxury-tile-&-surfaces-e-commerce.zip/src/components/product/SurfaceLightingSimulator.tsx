import React, { useState, useRef, useEffect } from 'react';
import { Product, ProductVariant } from '../../types';
import { 
  Sun, 
  Lamp, 
  Sparkles, 
  Sunset, 
  Moon, 
  Sliders, 
  Split, 
  ZoomIn, 
  Maximize2, 
  Info, 
  Lightbulb,
  Compass,
  Layers,
  RotateCcw,
  Eye,
  Check
} from 'lucide-react';

export type LightingConditionId = 'daylight' | 'warm_indoor' | 'cool_studio' | 'golden_hour' | 'evening_cove';

export interface LightingCondition {
  id: LightingConditionId;
  name: string;
  shortName: string;
  kelvin: string;
  kelvinValue: number;
  cri: string;
  description: string;
  architecturalApplication: string;
  icon: React.ComponentType<{ className?: string }>;
  colorFilter: string;
  overlayGradient: string;
  specularIntensity: number; // 0 to 1
  shadowSoftness: number;
  ambientBrightness: number; // multiplier
}

export const LIGHTING_CONDITIONS: LightingCondition[] = [
  {
    id: 'daylight',
    name: 'Natural Daylight',
    shortName: 'Daylight (5500K)',
    kelvin: '5500K – 6000K',
    kelvinValue: 5500,
    cri: '98+ CRI',
    description: 'Crisp morning & afternoon sunlit neutral ambient light. Reveals authentic mineral undertones, true pigments, and pure crystalline alabaster veining without artificial warm or blue casting.',
    architecturalApplication: 'Open-plan living spaces with floor-to-ceiling fenestration, sunrooms, atrium foyers, and exterior patios.',
    icon: Sun,
    colorFilter: 'brightness(1.02) contrast(1.04) saturate(1.02) hue-rotate(0deg)',
    overlayGradient: 'radial-gradient(circle at var(--light-x, 40%) var(--light-y, 30%), rgba(255, 255, 255, 0.45) 0%, rgba(240, 248, 255, 0.15) 45%, rgba(0, 0, 0, 0.05) 100%)',
    specularIntensity: 0.75,
    shadowSoftness: 12,
    ambientBrightness: 1.0
  },
  {
    id: 'warm_indoor',
    name: 'Warm Indoor',
    shortName: 'Warm Indoor (2700K)',
    kelvin: '2700K – 3000K',
    kelvinValue: 2700,
    cri: '95 CRI',
    description: 'Tungsten and 2700K recessed architectural LEDs, cove lighting, and decorative chandeliers. Enriches golden veins, warm travertine hues, and casts cozy, intimate specular depth.',
    architecturalApplication: 'Master bedroom suites, private dining salons, residential living areas, and luxury hospitality lounges.',
    icon: Lamp,
    colorFilter: 'sepia(0.24) saturate(1.25) brightness(0.98) contrast(1.05) hue-rotate(-12deg)',
    overlayGradient: 'radial-gradient(circle at var(--light-x, 50%) var(--light-y, 35%), rgba(255, 218, 160, 0.55) 0%, rgba(245, 185, 110, 0.22) 50%, rgba(45, 25, 5, 0.18) 100%)',
    specularIntensity: 0.85,
    shadowSoftness: 18,
    ambientBrightness: 0.95
  },
  {
    id: 'cool_studio',
    name: 'Cool Studio',
    shortName: 'Cool Studio (6500K)',
    kelvin: '6000K – 6500K',
    kelvinValue: 6500,
    cri: '99 CRI',
    description: 'Crisp commercial studio and art gallery spotlighting. Sharp architectural grazing with high contrast, bringing out micro-texture relief, slate cleaving, and sharp specular glints.',
    architecturalApplication: 'Commercial foyers, corporate boardrooms, luxury retail boutiques, modern minimalist kitchens, and architectural showrooms.',
    icon: Sparkles,
    colorFilter: 'contrast(1.12) saturate(0.92) brightness(1.06) hue-rotate(5deg)',
    overlayGradient: 'radial-gradient(circle at var(--light-x, 50%) var(--light-y, 40%), rgba(255, 255, 255, 0.6) 0%, rgba(215, 235, 255, 0.22) 55%, rgba(10, 25, 45, 0.08) 100%)',
    specularIntensity: 0.95,
    shadowSoftness: 8,
    ambientBrightness: 1.05
  },
  {
    id: 'golden_hour',
    name: 'Golden Hour Sunset',
    shortName: 'Golden Hour (2200K)',
    kelvin: '2200K – 2400K',
    kelvinValue: 2200,
    cri: '90 CRI',
    description: 'Low-angle raking sunlight casting dramatic elongated micro-shadows across the tile face. Emphasizes tactile stone clefts, honed grain, and sculpted reliefs.',
    architecturalApplication: 'West-facing balconies, penthouse terraces, outdoor pools, and textured feature stone accent walls.',
    icon: Sunset,
    colorFilter: 'sepia(0.44) saturate(1.48) brightness(0.93) contrast(1.16) hue-rotate(-18deg)',
    overlayGradient: 'linear-gradient(var(--light-angle, 125deg), rgba(255, 170, 70, 0.68) 0%, rgba(240, 130, 40, 0.28) 45%, rgba(40, 15, 5, 0.38) 100%)',
    specularIntensity: 0.70,
    shadowSoftness: 24,
    ambientBrightness: 0.90
  },
  {
    id: 'evening_cove',
    name: 'Dimmable Evening & Spa Cove',
    shortName: 'Evening Spa (2000K)',
    kelvin: '2000K – 2200K',
    kelvinValue: 2000,
    cri: '92 CRI',
    description: 'Intimate perimeter cove lighting and low-lumen sconces. Produces velvety deep contrast, muted specular reflection, and tranquil hotel-spa ambiance.',
    architecturalApplication: 'Primary wet-room showers, freestanding bathtub niches, wine cellars, and home cinema rooms.',
    icon: Moon,
    colorFilter: 'brightness(0.76) contrast(1.24) saturate(1.15) sepia(0.32)',
    overlayGradient: 'radial-gradient(circle at var(--light-x, 50%) var(--light-y, 80%), rgba(255, 195, 130, 0.48) 0%, rgba(120, 70, 30, 0.32) 50%, rgba(5, 5, 10, 0.58) 100%)',
    specularIntensity: 0.45,
    shadowSoftness: 30,
    ambientBrightness: 0.75
  }
];

export type SimulatedFinish = 'Polished' | 'Honed' | 'Matte' | 'Textured';

interface SurfaceLightingSimulatorProps {
  product: Product;
  variant: ProductVariant;
  currentImage: string;
  onClose?: () => void;
  isCompact?: boolean;
}

export function SurfaceLightingSimulator({
  product,
  variant,
  currentImage,
  onClose,
  isCompact = false
}: SurfaceLightingSimulatorProps) {
  // Active lighting condition
  const [selectedConditionId, setSelectedConditionId] = useState<LightingConditionId>('daylight');
  const [compareConditionId, setCompareConditionId] = useState<LightingConditionId>('warm_indoor');
  
  // Interactive Controls
  const [isSplitMode, setIsSplitMode] = useState(false);
  const [splitPosition, setSplitPosition] = useState(50); // percentage 0-100
  const [lightX, setLightX] = useState(45); // percentage across container
  const [lightY, setLightY] = useState(30);
  const [isDraggingLight, setIsDraggingLight] = useState(false);
  
  // Light intensity slider (Lux simulation: 200 - 1200 Lux)
  const [luxLevel, setLuxLevel] = useState<number>(650);
  
  // Finish simulation override (allow testing how the same tile behaves in Polished vs Honed vs Matte vs Textured)
  const defaultFinish = (['Polished', 'Honed', 'Matte', 'Textured'].includes(product.finish) 
    ? product.finish 
    : 'Polished') as SimulatedFinish;
  const [activeFinish, setActiveFinish] = useState<SimulatedFinish>(defaultFinish);

  // Grout line contrast preview
  const [groutColor, setGroutColor] = useState<'none' | 'white' | 'silver' | 'charcoal'>('none');

  // Texture Zoom Loupe
  const [isZoomActive, setIsZoomActive] = useState(false);
  const [zoomCoords, setZoomCoords] = useState({ x: 50, y: 50 });

  const containerRef = useRef<HTMLDivElement>(null);

  const activeCondition = LIGHTING_CONDITIONS.find(c => c.id === selectedConditionId) || LIGHTING_CONDITIONS[0];
  const compareCondition = LIGHTING_CONDITIONS.find(c => c.id === compareConditionId) || LIGHTING_CONDITIONS[1];

  // Sync active finish if product changes
  useEffect(() => {
    const fin = (['Polished', 'Honed', 'Matte', 'Textured'].includes(product.finish) 
      ? product.finish 
      : 'Polished') as SimulatedFinish;
    setActiveFinish(fin);
  }, [product.finish]);

  // Finish physical response characteristics
  const isPolished = activeFinish === 'Polished';
  const isHoned = activeFinish === 'Honed';
  const isMatte = activeFinish === 'Matte';
  const isTextured = activeFinish === 'Textured';

  // Lux brightness scaling
  const luxFactor = luxLevel / 650; // 1.0 at standard 650 lux

  // Dynamic finish-based specular highlight styling
  let glossClass = '';
  let specularOpacity = 0.5;
  let specularSize = 260; // px
  let surfaceBlur = 0; // px

  if (isPolished) {
    glossClass = 'mix-blend-overlay';
    specularOpacity = Math.min(1, activeCondition.specularIntensity * luxFactor * 1.15);
    specularSize = 220;
  } else if (isHoned) {
    glossClass = 'mix-blend-soft-light';
    specularOpacity = Math.min(0.85, activeCondition.specularIntensity * 0.7 * luxFactor);
    specularSize = 340;
  } else if (isTextured) {
    glossClass = 'mix-blend-hard-light';
    specularOpacity = Math.min(0.7, activeCondition.specularIntensity * 0.55 * luxFactor);
    specularSize = 280;
  } else {
    // Matte
    glossClass = 'mix-blend-screen opacity-20';
    specularOpacity = Math.min(0.4, activeCondition.specularIntensity * 0.3 * luxFactor);
    specularSize = 420;
  }

  // Handle pointer tracking across surface to dynamically aim the architectural light
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(5, Math.min(95, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(5, Math.min(95, ((e.clientY - rect.top) / rect.height) * 100));

    if (isDraggingLight) {
      setLightX(x);
      setLightY(y);
    }

    if (isZoomActive) {
      setZoomCoords({ x, y });
    }
  };

  // Quick light direction angle presets
  const setLightPreset = (preset: 'overhead' | 'grazing_left' | 'grazing_right' | 'frontal') => {
    switch (preset) {
      case 'overhead':
        setLightX(50);
        setLightY(15);
        break;
      case 'grazing_left':
        setLightX(15);
        setLightY(50);
        break;
      case 'grazing_right':
        setLightX(85);
        setLightY(50);
        break;
      case 'frontal':
        setLightX(50);
        setLightY(50);
        break;
    }
  };

  // Touch/drag split divider
  const handleSplitDrag = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const newPos = Math.max(10, Math.min(90, ((clientX - rect.left) / rect.width) * 100));
    setSplitPosition(newPos);
  };

  // Calculated Light Reflectance Value (LRV %) estimate based on variant color & finish
  const calculateLRV = () => {
    if (activeFinish === 'Polished') return '62% LRV (High Gloss)';
    if (activeFinish === 'Honed') return '48% LRV (Satin Diffuse)';
    if (activeFinish === 'Textured') return '38% LRV (Raking Shadow)';
    return '42% LRV (Diffuse Matte)';
  };

  return (
    <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] space-y-4 shadow-sm">
      
      {/* Header Bar */}
      <div className="p-4 border-b border-[var(--theme-border)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[var(--theme-surface-subtle)]">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)]">
              <Lightbulb className="w-4 h-4" />
            </span>
            <h3 className="font-serif-luxury text-base sm:text-lg font-semibold tracking-wide">
              Architectural Lighting & Sheen Simulator
            </h3>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-[var(--theme-accent)] text-white">
              Interactive 3D Photometry
            </span>
          </div>
          <p className="text-xs text-[var(--theme-text-muted)] mt-1">
            Toggle color temperatures (Natural Daylight, Warm Indoor, Cool Studio) and drag the light position to observe how specular sheen and micro-textures respond.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Split Mode Toggle */}
          <button
            type="button"
            onClick={() => setIsSplitMode(!isSplitMode)}
            className={`px-3 py-1.5 border text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              isSplitMode 
                ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white shadow-xs' 
                : 'border-[var(--theme-border)] bg-[var(--theme-surface)] hover:border-[var(--theme-text)] text-[var(--theme-text)]'
            }`}
            title="Compare two lighting environments side-by-side"
          >
            <Split className="w-3.5 h-3.5" />
            <span>{isSplitMode ? 'Exit Comparison' : 'A/B Split View'}</span>
          </button>

          {/* Texture Loupe */}
          <button
            type="button"
            onClick={() => setIsZoomActive(!isZoomActive)}
            className={`px-3 py-1.5 border text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              isZoomActive
                ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white shadow-xs'
                : 'border-[var(--theme-border)] bg-[var(--theme-surface)] hover:border-[var(--theme-text)] text-[var(--theme-text)]'
            }`}
            title="Inspect surface micro-texture, bevels and relief under light"
          >
            <ZoomIn className="w-3.5 h-3.5" />
            <span>{isZoomActive ? 'Loupe On' : 'Micro-Texture Loupe'}</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 border border-[var(--theme-border)] text-xs text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
            >
              Close Studio
            </button>
          )}
        </div>
      </div>

      {/* Main Lighting Condition Buttons (Explicit: Natural Daylight, Warm Indoor, Cool Studio + Extras) */}
      <div className="px-4 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold uppercase tracking-wider text-[var(--theme-text)] flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            Select Lighting Condition:
          </span>
          <span className="text-[11px] text-[var(--theme-text-muted)]">
            Active: <strong className="text-[var(--theme-text)] font-semibold">{activeCondition.name} ({activeCondition.kelvin})</strong>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {LIGHTING_CONDITIONS.map(cond => {
            const Icon = cond.icon;
            const isSelected = selectedConditionId === cond.id;
            return (
              <button
                key={cond.id}
                type="button"
                onClick={() => setSelectedConditionId(cond.id)}
                className={`p-3 text-left border transition-all cursor-pointer flex flex-col justify-between relative ${
                  isSelected
                    ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] shadow-xs ring-1 ring-[var(--theme-accent)]'
                    : 'border-[var(--theme-border)] hover:border-[var(--theme-text)]/40 bg-[var(--theme-surface)]'
                }`}
              >
                {isSelected && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[var(--theme-accent)]" />
                )}
                <div className="flex items-center justify-between mb-2">
                  <span className={`p-1 border ${isSelected ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' : 'border-[var(--theme-border)] text-[var(--theme-text-muted)]'}`}>
                    <Icon className="w-4 h-4" />
                  </span>
                  <span className="text-[10px] font-mono tabular-nums text-[var(--theme-text-muted)] font-semibold">
                    {cond.kelvin.split(' ')[0]}
                  </span>
                </div>
                <div>
                  <span className={`block text-xs font-semibold ${isSelected ? 'text-[var(--theme-text)]' : 'text-[var(--theme-text)]/80'}`}>
                    {cond.name}
                  </span>
                  <span className="text-[10px] text-[var(--theme-text-muted)] block mt-0.5">
                    {cond.cri} · {cond.kelvin.split('–')[0]}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Split Comparison Sub-Selector */}
      {isSplitMode && (
        <div className="mx-4 p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold uppercase tracking-wider text-[10px] text-[var(--theme-text)]">Comparison:</span>
            <span className="font-semibold px-2 py-0.5 bg-[var(--theme-surface)] border border-[var(--theme-border)]">
              {activeCondition.name} (Left)
            </span>
            <span className="text-[var(--theme-text-muted)] font-bold">VS</span>
            <select
              value={compareConditionId}
              onChange={e => setCompareConditionId(e.target.value as LightingConditionId)}
              className="px-2.5 py-1 bg-[var(--theme-surface)] border border-[var(--theme-accent)] font-semibold text-xs focus:outline-none cursor-pointer"
            >
              {LIGHTING_CONDITIONS.filter(c => c.id !== selectedConditionId).map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.kelvin}) (Right)</option>
              ))}
            </select>
          </div>
          <span className="text-[11px] text-[var(--theme-text-muted)]">
            Drag the center divider left/right to compare transitions.
          </span>
        </div>
      )}

      {/* Interactive Lighting Surface Viewport */}
      <div className="px-4">
        <div
          ref={containerRef}
          onPointerMove={handlePointerMove}
          onPointerDown={() => setIsDraggingLight(true)}
          onPointerUp={() => setIsDraggingLight(false)}
          className="relative aspect-[16/10] sm:aspect-[16/9] w-full overflow-hidden border border-[var(--theme-border)] bg-stone-900 select-none cursor-crosshair group shadow-inner"
          style={{
            ['--light-x' as any]: `${lightX}%`,
            ['--light-y' as any]: `${lightY}%`,
            ['--light-angle' as any]: `${Math.atan2(lightY - 50, lightX - 50) * (180 / Math.PI) + 90}deg`
          }}
        >
          {/* Base Layer: Selected Lighting Condition */}
          <div className="absolute inset-0 w-full h-full overflow-hidden">
            {/* Tile Image */}
            <img
              src={currentImage}
              alt={`${product.name} under ${activeCondition.name}`}
              className="w-full h-full object-cover transition-all duration-300"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg';
              }}
              style={{
                filter: `${activeCondition.colorFilter} brightness(${luxFactor * activeCondition.ambientBrightness})`
              }}
            />

            {/* Ambient Lighting Gradient Overlay */}
            <div
              className="absolute inset-0 pointer-events-none transition-all duration-300"
              style={{
                background: activeCondition.overlayGradient
              }}
            />

            {/* Dynamic Specular Sheen (Moves with light cursor position) */}
            <div
              className={`absolute inset-0 pointer-events-none transition-opacity duration-200 ${glossClass}`}
              style={{
                background: `radial-gradient(circle ${specularSize}px at ${lightX}% ${lightY}%, rgba(255, 255, 255, ${specularOpacity}) 0%, rgba(255, 255, 255, ${specularOpacity * 0.35}) 40%, transparent 80%)`
              }}
            />

            {/* Grazing Shadow and Cleft Relief (for Textured and Bush-hammered finishes) */}
            {isTextured && (
              <div
                className="absolute inset-0 pointer-events-none mix-blend-multiply opacity-50 transition-all duration-200"
                style={{
                  background: `linear-gradient(${lightX * 3.6}deg, rgba(0,0,0,0.45) 0%, transparent 45%, rgba(255,255,255,0.2) 100%)`
                }}
              />
            )}

            {/* Honed Satin Sheen Diffuse Wash */}
            {isHoned && (
              <div
                className="absolute inset-0 pointer-events-none mix-blend-screen opacity-25"
                style={{
                  background: `radial-gradient(ellipse at ${lightX}% ${lightY}%, rgba(255, 250, 240, 0.45) 0%, transparent 70%)`
                }}
              />
            )}

            {/* Polished Mirror Glint Hotspot */}
            {isPolished && (
              <div
                className="absolute pointer-events-none -translate-x-1/2 -translate-y-1/2 transition-all duration-100 ease-out"
                style={{
                  left: `${lightX}%`,
                  top: `${lightY}%`,
                  width: `${60 * luxFactor}px`,
                  height: `${60 * luxFactor}px`,
                  background: 'radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.4) 40%, transparent 80%)',
                  filter: 'blur(2px)'
                }}
              />
            )}

            {/* Optional Grout Simulation Grid */}
            {groutColor !== 'none' && (
              <div 
                className="absolute inset-0 pointer-events-none opacity-40 mix-blend-multiply"
                style={{
                  backgroundImage: `linear-gradient(to right, ${groutColor === 'white' ? '#fff' : groutColor === 'silver' ? '#999' : '#222'} 2px, transparent 2px), linear-gradient(to bottom, ${groutColor === 'white' ? '#fff' : groutColor === 'silver' ? '#999' : '#222'} 2px, transparent 2px)`,
                  backgroundSize: '180px 180px'
                }}
              />
            )}
          </div>

          {/* Split Mode Comparison Pane (Right Side) */}
          {isSplitMode && (
            <div
              className="absolute inset-y-0 right-0 overflow-hidden border-l-2 border-white shadow-2xl pointer-events-none"
              style={{
                width: `${100 - splitPosition}%`
              }}
            >
              <div
                className="absolute inset-y-0 right-0"
                style={{
                  width: `${containerRef.current ? containerRef.current.clientWidth : 800}px`
                }}
              >
                <img
                  src={currentImage}
                  alt={`${product.name} under ${compareCondition.name}`}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg';
                  }}
                  style={{
                    filter: `${compareCondition.colorFilter} brightness(${luxFactor * compareCondition.ambientBrightness})`
                  }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background: compareCondition.overlayGradient
                  }}
                />
                <div
                  className={`absolute inset-0 ${glossClass}`}
                  style={{
                    background: `radial-gradient(circle ${specularSize}px at ${lightX}% ${lightY}%, rgba(255, 255, 255, ${specularOpacity * 0.8}) 0%, transparent 80%)`
                  }}
                />
              </div>

              {/* Tag on right comparison pane */}
              <div className="absolute top-4 right-4 bg-black/80 text-white text-[10px] font-bold px-3 py-1.5 uppercase tracking-wider backdrop-blur-xs border border-white/20">
                {compareCondition.name} ({compareCondition.kelvin})
              </div>
            </div>
          )}

          {/* Split Divider Draggable Handle */}
          {isSplitMode && (
            <div
              onMouseDown={e => {
                const handleMove = (ev: MouseEvent) => {
                  if (!containerRef.current) return;
                  const rect = containerRef.current.getBoundingClientRect();
                  const newPos = Math.max(10, Math.min(90, ((ev.clientX - rect.left) / rect.width) * 100));
                  setSplitPosition(newPos);
                };
                const handleUp = () => {
                  window.removeEventListener('mousemove', handleMove);
                  window.removeEventListener('mouseup', handleUp);
                };
                window.addEventListener('mousemove', handleMove);
                window.addEventListener('mouseup', handleUp);
              }}
              onTouchMove={handleSplitDrag}
              style={{ left: `${splitPosition}%` }}
              className="absolute inset-y-0 -ml-4 w-8 flex items-center justify-center cursor-ew-resize z-20"
            >
              <div className="w-0.5 h-full bg-white shadow-xl relative flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-white text-stone-900 border border-stone-300 shadow-xl flex items-center justify-center text-xs font-bold hover:scale-110 transition-transform">
                  ↔
                </div>
              </div>
            </div>
          )}

          {/* Dynamic Light Source Origin Marker */}
          <div
            style={{ left: `${lightX}%`, top: `${lightY}%` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10 transition-transform duration-75"
          >
            <div className="w-12 h-12 rounded-full border border-white/70 bg-white/20 backdrop-blur-xs flex items-center justify-center animate-pulse shadow-lg">
              <div className="w-4 h-4 rounded-full bg-white shadow-md border border-amber-200" />
            </div>
          </div>

          {/* Active Preset Overlay Tag (Left Pane) */}
          <div className="absolute top-4 left-4 bg-black/80 text-white text-[10px] font-bold px-3 py-1.5 uppercase tracking-wider backdrop-blur-xs border border-white/20 z-10">
            {activeCondition.name} ({activeCondition.kelvin}) · {activeFinish} Finish
          </div>

          {/* Interactive Light Mover Prompt Banner */}
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] text-white/90 backdrop-blur-md bg-black/60 px-3.5 py-2 z-10 border border-white/10">
            <span className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-300 animate-spin-slow" />
              <span><strong>Drag on the surface</strong> to guide the architectural light source across {variant.colorName}.</span>
            </span>
            <span className="font-mono tabular-nums text-white/70 hidden sm:inline">
              Spotlight: X {Math.round(lightX)}% · Y {Math.round(lightY)}% · Angle {Math.round(lightX * 3.6)}°
            </span>
          </div>

          {/* Texture Loupe Magnifier Bubble */}
          {isZoomActive && (
            <div
              style={{
                left: `${Math.min(80, Math.max(20, zoomCoords.x))}%`,
                top: `${Math.min(75, Math.max(25, zoomCoords.y))}%`
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 w-52 h-52 rounded-full border-4 border-white shadow-2xl overflow-hidden pointer-events-none z-30 ring-4 ring-black/30"
            >
              <div
                className="w-full h-full relative"
                style={{
                  backgroundImage: `url(${currentImage})`,
                  backgroundPosition: `${zoomCoords.x}% ${zoomCoords.y}%`,
                  backgroundSize: '400%',
                  filter: `${activeCondition.colorFilter} brightness(${luxFactor})`
                }}
              >
                <div
                  className="absolute inset-0"
                  style={{ background: activeCondition.overlayGradient }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-4 h-4 border border-white/80 rounded-full" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Raking Angle & Finish Response Controls */}
      <div className="px-4 py-2 grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-[var(--theme-border)] text-xs">
        
        {/* Light Angle Presets */}
        <div className="space-y-1.5">
          <label className="font-bold uppercase tracking-wider text-[10px] text-[var(--theme-text-muted)] block">
            Raking Light Direction:
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            <button
              type="button"
              onClick={() => setLightPreset('overhead')}
              className="px-2 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-text)] bg-[var(--theme-surface)] text-[10px] font-semibold uppercase text-center transition-colors"
            >
              Overhead
            </button>
            <button
              type="button"
              onClick={() => setLightPreset('grazing_left')}
              className="px-2 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-text)] bg-[var(--theme-surface)] text-[10px] font-semibold uppercase text-center transition-colors"
            >
              Left 45°
            </button>
            <button
              type="button"
              onClick={() => setLightPreset('grazing_right')}
              className="px-2 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-text)] bg-[var(--theme-surface)] text-[10px] font-semibold uppercase text-center transition-colors"
            >
              Right 45°
            </button>
            <button
              type="button"
              onClick={() => setLightPreset('frontal')}
              className="px-2 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-text)] bg-[var(--theme-surface)] text-[10px] font-semibold uppercase text-center transition-colors"
            >
              Diffuse
            </button>
          </div>
        </div>

        {/* Tile Finish Response Simulator */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="font-bold uppercase tracking-wider text-[10px] text-[var(--theme-text-muted)]">
              Simulate Texture & Finish:
            </label>
            <span className="text-[10px] text-[var(--theme-accent)] font-semibold">
              {calculateLRV()}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {(['Polished', 'Honed', 'Matte', 'Textured'] as SimulatedFinish[]).map(finishOption => {
              const isActive = activeFinish === finishOption;
              const isDefault = product.finish === finishOption;
              return (
                <button
                  key={finishOption}
                  type="button"
                  onClick={() => setActiveFinish(finishOption)}
                  className={`px-2 py-1.5 border text-[10px] font-semibold uppercase text-center transition-colors cursor-pointer ${
                    isActive
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] text-[var(--theme-accent)] font-bold'
                      : 'border-[var(--theme-border)] bg-[var(--theme-surface)] hover:border-[var(--theme-text)] text-[var(--theme-text)]'
                  }`}
                >
                  {finishOption}
                  {isDefault && <span className="block text-[8px] opacity-60">Orig</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Lux Intensity & Grout Simulation */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="font-bold uppercase tracking-wider text-[10px] text-[var(--theme-text-muted)]">
              Luminous Intensity:
            </label>
            <span className="font-mono text-[11px] font-bold text-[var(--theme-text)]">
              {luxLevel} Lux
            </span>
          </div>
          <input
            type="range"
            min="200"
            max="1200"
            step="50"
            value={luxLevel}
            onChange={e => setLuxLevel(parseInt(e.target.value, 10))}
            className="w-full accent-[var(--theme-accent)] cursor-pointer"
          />
          <div className="flex items-center justify-between text-[10px] text-[var(--theme-text-muted)]">
            <span>200 Lux (Moody)</span>
            <span>650 Lux (Standard)</span>
            <span>1200 Lux (Bright Sun)</span>
          </div>
        </div>
      </div>

      {/* Architectural Light Interaction Insights */}
      <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider block">
              1. Photometric Spectrum & Kelvin
            </span>
            <strong className="text-sm text-[var(--theme-text)] block">
              {activeCondition.name} ({activeCondition.kelvin})
            </strong>
            <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
              {activeCondition.description}
            </p>
          </div>

          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider block">
              2. Surface Sheen & Texture Response
            </span>
            <strong className="text-sm text-[var(--theme-text)] block">
              {activeFinish} Finish on {product.material}
            </strong>
            <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
              {isPolished && 'Polished specular highlights create sharp mirror reflections and crystalline depth. Best paired with indirect architectural perimeter coves to prevent point glare.'}
              {isHoned && 'Honed satin absorbs direct light into a velvety diffuse spread without harsh hot-spots. Ideal for sun-drenched coastal rooms and high-glare living spaces.'}
              {isMatte && 'Matte finish completely diffuses incident light, maintaining uniform base tonality regardless of angle. Zero glare, high tactile slip resistance.'}
              {isTextured && 'Low-angle raking illumination emphasizes the dramatic organic relief and cleft depth of the stone, casting tactile micro-shadows.'}
            </p>
          </div>

          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider block">
              3. Architectural Lighting Spec Note
            </span>
            <strong className="text-sm text-[var(--theme-accent)] block">
              Recommended Fixtures
            </strong>
            <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
              {activeCondition.architecturalApplication}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
