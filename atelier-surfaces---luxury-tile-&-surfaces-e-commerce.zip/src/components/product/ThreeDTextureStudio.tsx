import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Product, ProductVariant } from '../../types';
import { 
  Sun, 
  Lamp, 
  Sparkles, 
  Sunset, 
  Layers, 
  RotateCcw, 
  ChevronDown, 
  ChevronUp, 
  Compass, 
  Maximize2, 
  Minimize2,
  Check,
  Lightbulb
} from 'lucide-react';

export type ThreeDLightingCondition = 'daylight' | 'warm_indoor' | 'cool_studio' | 'golden_hour';
export type ThreeDFinish = 'Polished' | 'Honed' | 'Matte' | 'Textured';

interface ThreeDTextureStudioProps {
  product: Product;
  variant: ProductVariant;
  onClose?: () => void;
  isFullScreenDefault?: boolean;
}

export function ThreeDTextureStudio({
  product,
  variant,
  onClose,
  isFullScreenDefault = false
}: ThreeDTextureStudioProps) {
  const mountRef = useRef<HTMLDivElement>(null);

  // UI state for bottom dock
  const [activeLighting, setActiveLighting] = useState<ThreeDLightingCondition>('daylight');
  const [activeFinish, setActiveFinish] = useState<ThreeDFinish>(() => {
    if (['Polished', 'Honed', 'Matte', 'Textured'].includes(product.finish)) {
      return product.finish as ThreeDFinish;
    }
    return 'Polished';
  });
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [explodedRatio, setExplodedRatio] = useState<number>(0); // 0 to 1
  const [isFullScreen, setIsFullScreen] = useState(isFullScreenDefault);
  const [lightRotationDeg, setLightRotationDeg] = useState<number>(45);

  // Mutable refs for Three.js state to avoid teardown on re-renders
  const stateRef = useRef({
    activeLighting: 'daylight' as ThreeDLightingCondition,
    activeFinish: 'Polished' as ThreeDFinish,
    explodedRatio: 0,
    lightRotationDeg: 45,
    requestRender: () => {},
  });

  // Sync state to ref
  useEffect(() => {
    stateRef.current.activeLighting = activeLighting;
    stateRef.current.activeFinish = activeFinish;
    stateRef.current.explodedRatio = explodedRatio;
    stateRef.current.lightRotationDeg = lightRotationDeg;
    stateRef.current.requestRender();
  }, [activeLighting, activeFinish, explodedRatio, lightRotationDeg]);

  // Main Three.js Scene Setup
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect Software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer Setup
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true
    });
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 3. Scene & Camera Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x181816);
    scene.fog = new THREE.FogExp2(0x181816, 0.08);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 50);
    camera.position.set(0, 1.3, 2.5);

    // 4. OrbitControls with Damping
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.02; // Don't clip through floor
    controls.minDistance = 1.2;
    controls.maxDistance = 5.0;
    controls.target.set(0, 0.45, 0);

    // 5. Studio Environment Map (PMREMGenerator + RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 6. Studio Lighting Rig
    // Warm key light
    const keyLight = new THREE.DirectionalLight(0xfff5ea, 2.2);
    keyLight.position.set(2, 3, 2);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 10;
    keyLight.shadow.camera.left = -1.5;
    keyLight.shadow.camera.right = 1.5;
    keyLight.shadow.camera.top = 1.5;
    keyLight.shadow.camera.bottom = -1.5;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    // Cool Hemisphere Fill
    const hemiLight = new THREE.HemisphereLight(0xdce8f5, 0x222220, 0.85);
    scene.add(hemiLight);

    // Ambient Bounce
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.25);
    scene.add(ambientLight);

    // 7. Procedural Procedural Textures (Albedo, Bump, Roughness)
    // Generates an architectural marble/stone texture based on the variant's hex color
    function createProceduralTileTextures(hexColor: string, isTexturedFinish: boolean) {
      const size = 1024;
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d')!;

      // Base background tone
      ctx.fillStyle = hexColor;
      ctx.fillRect(0, 0, size, size);

      // Procedural organic veining & micro-crystallites
      const baseRgb = new THREE.Color(hexColor);
      const isDark = (baseRgb.r * 0.299 + baseRgb.g * 0.587 + baseRgb.b * 0.114) < 0.5;
      const veinColor = isDark ? 'rgba(255, 250, 240, 0.35)' : 'rgba(90, 80, 70, 0.22)';
      const goldVein = 'rgba(212, 175, 55, 0.28)';

      // Organic flowing veins
      ctx.lineWidth = 4;
      for (let v = 0; v < 7; v++) {
        ctx.beginPath();
        let startX = Math.random() * size * 0.3;
        let startY = Math.random() * size;
        ctx.moveTo(startX, startY);

        let currX = startX;
        let currY = startY;
        for (let seg = 0; seg < 8; seg++) {
          currX += (Math.random() - 0.2) * 160;
          currY += (Math.random() - 0.5) * 120;
          ctx.bezierCurveTo(
            currX - 40, currY + (Math.random() - 0.5) * 50,
            currX + 20, currY - (Math.random() - 0.5) * 40,
            currX, currY
          );
        }
        ctx.strokeStyle = v % 2 === 0 ? goldVein : veinColor;
        ctx.stroke();
      }

      // Micro-texture noise specks
      const imgData = ctx.getImageData(0, 0, size, size);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * (isTexturedFinish ? 28 : 12);
        data[i] = Math.min(255, Math.max(0, data[i] + noise));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise));
      }
      ctx.putImageData(imgData, 0, 0);

      const albedoTex = new THREE.CanvasTexture(canvas);
      albedoTex.colorSpace = THREE.SRGBColorSpace;
      albedoTex.anisotropy = renderer.capabilities.getMaxAnisotropy();

      // Bump Texture
      const bumpCanvas = document.createElement('canvas');
      bumpCanvas.width = 512;
      bumpCanvas.height = 512;
      const bCtx = bumpCanvas.getContext('2d')!;
      bCtx.drawImage(canvas, 0, 0, 512, 512);
      const bumpData = bCtx.getImageData(0, 0, 512, 512);
      for (let i = 0; i < bumpData.data.length; i += 4) {
        const avg = (bumpData.data[i] + bumpData.data[i + 1] + bumpData.data[i + 2]) / 3;
        bumpData.data[i] = avg;
        bumpData.data[i + 1] = avg;
        bumpData.data[i + 2] = avg;
      }
      bCtx.putImageData(bumpData, 0, 0);
      const bumpTex = new THREE.CanvasTexture(bumpCanvas);
      bumpTex.wrapS = THREE.RepeatWrapping;
      bumpTex.wrapT = THREE.RepeatWrapping;

      return { albedoTex, bumpTex };
    }

    const { albedoTex, bumpTex } = createProceduralTileTextures(variant.colorHex, product.finish === 'Textured');

    // 8. Composite 3-12 Part Procedural Model (THREE.Group)
    // Structure:
    // - Tile Model Group
    //   - Part 1: Front Ceramic/Stone Slab Face (with beveled edges)
    //   - Part 2: Calibration Adhesive / Cushioning Mortar Interlayer
    //   - Part 3: Vitrified Porcelain / Stone Backing Substrate
    //   - Part 4: Brushed Brass Perimeter Framing Trim
    // - Display Pedestal Group
    //   - Part 5: Honed Charcoal Stone Base Pedestal
    //   - Part 6: Brass Mounting Bracket & Support Pins
    //   - Part 7: Contact Shadow Grounding Disc

    const showcaseGroup = new THREE.Group();
    scene.add(showcaseGroup);

    // Materials
    const tileFaceMaterial = new THREE.MeshPhysicalMaterial({
      map: albedoTex,
      bumpMap: bumpTex,
      bumpScale: 0.015,
      roughness: 0.1,
      metalness: 0.02,
      clearcoat: 1.0,
      clearcoatRoughness: 0.06,
      reflectivity: 0.8
    });

    const mortarMaterial = new THREE.MeshStandardMaterial({
      color: 0x99948c,
      roughness: 0.95,
      metalness: 0.0
    });

    const substrateMaterial = new THREE.MeshStandardMaterial({
      color: 0xb5a898,
      roughness: 0.85,
      metalness: 0.0
    });

    const brassTrimMaterial = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.92,
      roughness: 0.18
    });

    const pedestalMaterial = new THREE.MeshStandardMaterial({
      color: 0x222220,
      roughness: 0.65,
      metalness: 0.1
    });

    // Part 1: Front Ceramic/Stone Slab Face (ExtrudeGeometry with bevel)
    const slabShape = new THREE.Shape();
    const halfW = 0.45;
    const halfH = 0.45;
    slabShape.moveTo(-halfW, -halfH);
    slabShape.lineTo(halfW, -halfH);
    slabShape.lineTo(halfW, halfH);
    slabShape.lineTo(-halfW, halfH);
    slabShape.closePath();

    const slabGeo = new THREE.ExtrudeGeometry(slabShape, {
      depth: 0.012,
      bevelEnabled: true,
      bevelThickness: 0.004,
      bevelSize: 0.004,
      bevelSegments: 3
    });
    slabGeo.center();

    const slabMesh = new THREE.Mesh(slabGeo, tileFaceMaterial);
    slabMesh.castShadow = !isSoftwareGl;
    slabMesh.receiveShadow = !isSoftwareGl;

    // Part 2: Mortar / Adhesive Layer (Exploded component)
    const mortarGeo = new THREE.BoxGeometry(halfW * 1.95, halfH * 1.95, 0.004);
    const mortarMesh = new THREE.Mesh(mortarGeo, mortarMaterial);
    mortarMesh.position.z = -0.01;

    // Part 3: Backing Porcelain Substrate
    const substrateGeo = new THREE.BoxGeometry(halfW * 2, halfH * 2, 0.01);
    const substrateMesh = new THREE.Mesh(substrateGeo, substrateMaterial);
    substrateMesh.position.z = -0.02;
    substrateMesh.castShadow = !isSoftwareGl;

    // Part 4: Brushed Brass Perimeter Trim
    const trimShape = new THREE.Shape();
    trimShape.moveTo(-halfW - 0.008, -halfH - 0.008);
    trimShape.lineTo(halfW + 0.008, -halfH - 0.008);
    trimShape.lineTo(halfW + 0.008, halfH + 0.008);
    trimShape.lineTo(-halfW - 0.008, halfH + 0.008);
    trimShape.closePath();

    const trimHole = new THREE.Path();
    trimHole.moveTo(-halfW, -halfH);
    trimHole.lineTo(halfW, -halfH);
    trimHole.lineTo(halfW, halfH);
    trimHole.lineTo(-halfW, halfH);
    trimHole.closePath();
    trimShape.holes.push(trimHole);

    const trimGeo = new THREE.ExtrudeGeometry(trimShape, {
      depth: 0.03,
      bevelEnabled: true,
      bevelThickness: 0.002,
      bevelSize: 0.002,
      bevelSegments: 2
    });
    trimGeo.center();
    const trimMesh = new THREE.Mesh(trimGeo, brassTrimMaterial);
    trimMesh.position.z = -0.008;
    trimMesh.castShadow = !isSoftwareGl;

    // Assemble Tile Sandwich in tilted display group
    const tileAssemblyGroup = new THREE.Group();
    tileAssemblyGroup.add(slabMesh);
    tileAssemblyGroup.add(mortarMesh);
    tileAssemblyGroup.add(substrateMesh);
    tileAssemblyGroup.add(trimMesh);

    // Position tile at elegant 35° architectural display tilt
    tileAssemblyGroup.rotation.x = -0.35;
    tileAssemblyGroup.position.set(0, 0.52, 0);
    showcaseGroup.add(tileAssemblyGroup);

    // Part 5: Showcase Pedestal Plinth Base
    const plinthGeo = new THREE.CylinderGeometry(0.55, 0.62, 0.16, 32);
    const plinthMesh = new THREE.Mesh(plinthGeo, pedestalMaterial);
    plinthMesh.position.set(0, 0.08, 0); // Bottom-center pivot flush with ground
    plinthMesh.receiveShadow = !isSoftwareGl;
    plinthMesh.castShadow = !isSoftwareGl;
    showcaseGroup.add(plinthMesh);

    // Part 6: Brass Mounting Bracket & Pins
    const pinGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.45, 16);
    const pin1 = new THREE.Mesh(pinGeo, brassTrimMaterial);
    pin1.position.set(-0.25, 0.35, -0.05);
    pin1.rotation.x = 0.4;
    const pin2 = pin1.clone();
    pin2.position.x = 0.25;
    showcaseGroup.add(pin1);
    showcaseGroup.add(pin2);

    // Part 7: Contact Shadow Grounding Disc
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d')!;
    const grad = sCtx.createRadialGradient(128, 128, 20, 128, 128, 120);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.25)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 256, 256);

    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const shadowGeo = new THREE.PlaneGeometry(1.6, 1.6);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.6
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.002; // Offset above ground to prevent z-fighting
    showcaseGroup.add(shadowMesh);

    // Ground Floor Grid for Showroom Depth
    const floorGeo = new THREE.PlaneGeometry(12, 12);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x141412,
      roughness: 0.85,
      metalness: 0.1
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    // Animation & State Update Helpers
    const _vec3 = new THREE.Vector3();
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;

    function applyLightingAndFinish(delta: number) {
      const { activeLighting, activeFinish, explodedRatio, lightRotationDeg } = stateRef.current;

      // 1. Lighting Presets Configuration
      const rad = (lightRotationDeg * Math.PI) / 180;
      const lightDistance = 3.5;

      if (activeLighting === 'daylight') {
        // Natural Daylight: 5500K neutral sunlight
        keyLight.color.setHex(0xfff6ed);
        keyLight.intensity = 2.4;
        hemiLight.color.setHex(0xdce8f5);
        hemiLight.groundColor.setHex(0x333330);
        hemiLight.intensity = 0.9;
        keyLight.position.set(Math.cos(rad) * lightDistance, 3.2, Math.sin(rad) * lightDistance);
      } else if (activeLighting === 'warm_indoor') {
        // Warm Indoor: 2700K cozy residential tungsten
        keyLight.color.setHex(0xffb86c);
        keyLight.intensity = 2.6;
        hemiLight.color.setHex(0xffe0b2);
        hemiLight.groundColor.setHex(0x4a2c11);
        hemiLight.intensity = 0.75;
        keyLight.position.set(Math.cos(rad) * lightDistance, 2.8, Math.sin(rad) * lightDistance);
      } else if (activeLighting === 'cool_studio') {
        // Cool Studio: 6500K high-CRI gallery spot
        keyLight.color.setHex(0xe8f1ff);
        keyLight.intensity = 3.0;
        hemiLight.color.setHex(0xf0f4f8);
        hemiLight.groundColor.setHex(0x1a222c);
        hemiLight.intensity = 1.0;
        keyLight.position.set(Math.cos(rad) * lightDistance, 3.5, Math.sin(rad) * lightDistance);
      } else if (activeLighting === 'golden_hour') {
        // Sunset Golden Hour: 2200K low raking angle
        keyLight.color.setHex(0xff7b25);
        keyLight.intensity = 3.2;
        hemiLight.color.setHex(0xffc58d);
        hemiLight.groundColor.setHex(0x2a1005);
        hemiLight.intensity = 0.6;
        keyLight.position.set(Math.cos(rad) * lightDistance, 1.2, Math.sin(rad) * lightDistance);
      }

      // 2. Finish PBR Response
      if (activeFinish === 'Polished') {
        tileFaceMaterial.roughness = THREE.MathUtils.damp(tileFaceMaterial.roughness, 0.08, 8, delta);
        tileFaceMaterial.clearcoat = THREE.MathUtils.damp(tileFaceMaterial.clearcoat, 1.0, 8, delta);
        tileFaceMaterial.clearcoatRoughness = THREE.MathUtils.damp(tileFaceMaterial.clearcoatRoughness, 0.05, 8, delta);
        tileFaceMaterial.bumpScale = THREE.MathUtils.damp(tileFaceMaterial.bumpScale, 0.008, 8, delta);
      } else if (activeFinish === 'Honed') {
        tileFaceMaterial.roughness = THREE.MathUtils.damp(tileFaceMaterial.roughness, 0.38, 8, delta);
        tileFaceMaterial.clearcoat = THREE.MathUtils.damp(tileFaceMaterial.clearcoat, 0.25, 8, delta);
        tileFaceMaterial.clearcoatRoughness = THREE.MathUtils.damp(tileFaceMaterial.clearcoatRoughness, 0.35, 8, delta);
        tileFaceMaterial.bumpScale = THREE.MathUtils.damp(tileFaceMaterial.bumpScale, 0.018, 8, delta);
      } else if (activeFinish === 'Matte') {
        tileFaceMaterial.roughness = THREE.MathUtils.damp(tileFaceMaterial.roughness, 0.88, 8, delta);
        tileFaceMaterial.clearcoat = THREE.MathUtils.damp(tileFaceMaterial.clearcoat, 0.0, 8, delta);
        tileFaceMaterial.clearcoatRoughness = THREE.MathUtils.damp(tileFaceMaterial.clearcoatRoughness, 1.0, 8, delta);
        tileFaceMaterial.bumpScale = THREE.MathUtils.damp(tileFaceMaterial.bumpScale, 0.025, 8, delta);
      } else if (activeFinish === 'Textured') {
        tileFaceMaterial.roughness = THREE.MathUtils.damp(tileFaceMaterial.roughness, 0.72, 8, delta);
        tileFaceMaterial.clearcoat = THREE.MathUtils.damp(tileFaceMaterial.clearcoat, 0.05, 8, delta);
        tileFaceMaterial.clearcoatRoughness = THREE.MathUtils.damp(tileFaceMaterial.clearcoatRoughness, 0.6, 8, delta);
        tileFaceMaterial.bumpScale = THREE.MathUtils.damp(tileFaceMaterial.bumpScale, 0.055, 8, delta);
      }

      // 3. Exploded Layer Separation
      const targetSlabZ = explodedRatio * 0.12;
      const targetMortarZ = -0.01 + explodedRatio * 0.04;
      const targetSubstrateZ = -0.02 - explodedRatio * 0.06;
      const targetTrimZ = -0.008 - explodedRatio * 0.10;

      slabMesh.position.z = THREE.MathUtils.damp(slabMesh.position.z, targetSlabZ, 10, delta);
      mortarMesh.position.z = THREE.MathUtils.damp(mortarMesh.position.z, targetMortarZ, 10, delta);
      substrateMesh.position.z = THREE.MathUtils.damp(substrateMesh.position.z, targetSubstrateZ, 10, delta);
      trimMesh.position.z = THREE.MathUtils.damp(trimMesh.position.z, targetTrimZ, 10, delta);
    }

    // Software WebGL pacing
    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    // 60fps Loop with clock
    const clock = new THREE.Clock();

    function tick() {
      const delta = Math.min(clock.getDelta(), 0.1);
      controls.update();
      applyLightingAndFinish(delta);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    // Trigger loop
    tick();

    stateRef.current.requestRender = () => {
      // Loop is continuous
    };

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup on unmount
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);

      controls.dispose();
      slabGeo.dispose();
      mortarGeo.dispose();
      substrateGeo.dispose();
      trimGeo.dispose();
      plinthGeo.dispose();
      pinGeo.dispose();
      shadowGeo.dispose();
      floorGeo.dispose();

      tileFaceMaterial.dispose();
      mortarMaterial.dispose();
      substrateMaterial.dispose();
      brassTrimMaterial.dispose();
      pedestalMaterial.dispose();
      shadowMat.dispose();
      floorMat.dispose();

      albedoTex.dispose();
      bumpTex.dispose();
      shadowTex.dispose();

      if (scene.environment) {
        scene.environment.dispose();
      }

      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, [variant.colorHex, product.finish]);

  return (
    <div className={`relative w-full overflow-hidden bg-[#181816] text-white border border-[var(--theme-border)] select-none ${isFullScreen ? 'fixed inset-0 z-50 h-screen' : 'aspect-[16/10] sm:aspect-[16/9] min-h-[460px]'}`}>
      
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Header Floating Badge (Zero Occlusion, Top-Left) */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 pointer-events-none">
        <div className="bg-[#242421]/90 border border-white/10 px-3 py-1.5 flex items-center gap-2 pointer-events-auto shadow-xl">
          <Lightbulb className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider">
            Three.js Studio: {variant.colorName}
          </span>
          <span className="text-[10px] text-white/50 border-l border-white/20 pl-2">
            Orbit 360° · Tilt & Inspect
          </span>
        </div>
      </div>

      {/* Top Right Actions (Full Screen & Close) */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setIsFullScreen(!isFullScreen)}
          className="p-2 bg-[#242421]/90 border border-white/10 text-white/80 hover:text-white transition-colors cursor-pointer shadow-lg"
          title={isFullScreen ? 'Exit Full Screen' : 'Full Screen View'}
        >
          {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 bg-[#242421]/90 border border-white/10 text-xs text-white/80 hover:text-white transition-colors cursor-pointer shadow-lg"
          >
            Close
          </button>
        )}
      </div>

      {/* Unified Bottom Control Dock (Strictly pinned to bottom center, <= 15% viewport footprint) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-[840px] pointer-events-auto transition-transform duration-300">
        
        {/* Collapse / Expand Toggle Button on Dock Header */}
        <div className="flex justify-center -mb-px">
          <button
            type="button"
            onClick={() => setIsDockCollapsed(!isDockCollapsed)}
            className="px-4 py-1 bg-[#242421] border-t border-x border-white/15 text-[11px] font-semibold uppercase tracking-wider text-white/80 hover:text-white flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            {isDockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <span>Show Architectural Dock</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>Hide Controls (Zen View)</span>
              </>
            )}
          </button>
        </div>

        {/* Dock Controls Body */}
        {!isDockCollapsed && (
          <div className="bg-[#242421] border border-white/15 p-3.5 space-y-3 shadow-2xl">
            
            {/* Row 1: Lighting Condition Toggles (Natural Daylight, Warm Indoor, Cool Studio, Golden Hour) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-2.5">
              <span className="text-[10px] uppercase font-bold tracking-widest text-white/60">
                Studio Photometry:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
                
                <button
                  type="button"
                  onClick={() => setActiveLighting('daylight')}
                  className={`px-2.5 py-1.5 border text-[11px] font-semibold uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeLighting === 'daylight'
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-white/15 bg-white/5 hover:border-white/40 text-white/80'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Daylight 5500K</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLighting('warm_indoor')}
                  className={`px-2.5 py-1.5 border text-[11px] font-semibold uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeLighting === 'warm_indoor'
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-white/15 bg-white/5 hover:border-white/40 text-white/80'
                  }`}
                >
                  <Lamp className="w-3.5 h-3.5 text-amber-500" />
                  <span>Warm 2700K</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLighting('cool_studio')}
                  className={`px-2.5 py-1.5 border text-[11px] font-semibold uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeLighting === 'cool_studio'
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-white/15 bg-white/5 hover:border-white/40 text-white/80'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                  <span>Studio 6500K</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveLighting('golden_hour')}
                  className={`px-2.5 py-1.5 border text-[11px] font-semibold uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeLighting === 'golden_hour'
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white font-bold'
                      : 'border-white/15 bg-white/5 hover:border-white/40 text-white/80'
                  }`}
                >
                  <Sunset className="w-3.5 h-3.5 text-orange-400" />
                  <span>Sunset 2200K</span>
                </button>
              </div>
            </div>

            {/* Row 2: Finish Response Selector + Light Angle Slider + Exploded Layer Slider */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              
              {/* Finish Simulator */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-white/60">Surface Finish:</span>
                  <span className="text-[10px] text-[var(--theme-accent)] font-semibold">{activeFinish} PBR</span>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  {(['Polished', 'Honed', 'Matte', 'Textured'] as ThreeDFinish[]).map(fin => (
                    <button
                      key={fin}
                      type="button"
                      onClick={() => setActiveFinish(fin)}
                      className={`py-1 border text-[10px] font-semibold uppercase text-center transition-colors cursor-pointer ${
                        activeFinish === fin
                          ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)]/20 text-[var(--theme-accent)] font-bold'
                          : 'border-white/15 hover:border-white/40 text-white/70'
                      }`}
                    >
                      {fin}
                    </button>
                  ))}
                </div>
              </div>

              {/* Raking Light Direction Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-white/60 flex items-center gap-1">
                    <Compass className="w-3 h-3 text-[var(--theme-accent)]" />
                    Light Orbit Angle:
                  </span>
                  <span className="font-mono text-[10px] text-white/80">{lightRotationDeg}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="360"
                  step="5"
                  value={lightRotationDeg}
                  onChange={e => setLightRotationDeg(parseInt(e.target.value, 10))}
                  className="w-full accent-[var(--theme-accent)] cursor-pointer"
                />
              </div>

              {/* Exploded View Slider */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-white/60 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-[var(--theme-accent)]" />
                    Exploded Specimen Layers:
                  </span>
                  <span className="font-mono text-[10px] text-white/80">{Math.round(explodedRatio * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={explodedRatio}
                  onChange={e => setExplodedRatio(parseFloat(e.target.value))}
                  className="w-full accent-[var(--theme-accent)] cursor-pointer"
                />
              </div>

            </div>
          </div>
        )}
      </div>
    </div>
  );
}
