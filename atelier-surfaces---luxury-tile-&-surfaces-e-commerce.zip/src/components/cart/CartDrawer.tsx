import { useRouter, Link } from '../../router/Router';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingBag, Truck } from 'lucide-react';

export function CartDrawer() {
  const { navigate } = useRouter();
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    bulkDiscount,
    appliedBulkTiers,
    total,
    freeShippingThreshold,
    freeShippingProgress,
    itemCount
  } = useCartWishlist();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <aside 
          aria-label="Shopping bag"
          className="w-screen max-w-md bg-[var(--theme-surface)] border-l border-[var(--theme-border)] text-[var(--theme-text)] flex flex-col shadow-2xl"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-[var(--theme-border)] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[var(--theme-accent)]" />
              <h2 className="font-serif-luxury text-xl font-semibold tracking-wide">
                Architectural Bag ({itemCount})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Freight Progress Bar */}
          <div className="bg-[var(--theme-surface-subtle)] px-6 py-3 border-b border-[var(--theme-border)] text-xs">
            <div className="flex items-center justify-between mb-1.5 font-medium">
              <span className="flex items-center gap-1.5 text-[var(--theme-text)]">
                <Truck className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                {subtotal >= freeShippingThreshold ? (
                  <span className="text-[var(--theme-success)] font-semibold">Complimentary Site Freight Unlocked!</span>
                ) : (
                  <span>Add GH₵{(freeShippingThreshold - subtotal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} for Free Delivery</span>
                )}
              </span>
              <span className="tabular-nums text-[var(--theme-text-muted)]">{Math.round(freeShippingProgress)}%</span>
            </div>
            <div className="w-full h-1.5 bg-[var(--theme-border)] overflow-hidden">
              <div 
                className="h-full bg-[var(--theme-accent)] transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto px-6 py-6 divide-y divide-[var(--theme-border-subtle)]">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-[var(--theme-surface-subtle)] flex items-center justify-center text-[var(--theme-text-muted)]">
                  <ShoppingBag className="w-8 h-8 opacity-40" />
                </div>
                <h3 className="font-serif-luxury text-lg font-medium">Your specification bag is empty</h3>
                <p className="text-xs text-[var(--theme-text-muted)] max-w-xs mx-auto">
                  Explore our curated collections of architectural marble slabs, porcelain tiles, and natural stone surfaces.
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigate('/shop');
                  }}
                  className="mt-4 px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="py-4 flex gap-4">
                  <img
                    src={item.image.startsWith('/src/assets/') ? item.image.replace('/src/assets/', '/assets/') : item.image}
                    alt={item.productName}
                    className="w-20 h-20 object-cover bg-stone-100 shrink-0 border border-[var(--theme-border-subtle)]"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                    }}
                  />

                  {/* Details */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          href={`/product/${item.productSlug}`}
                          onClick={() => setIsCartOpen(false)}
                          className="font-medium text-sm hover:text-[var(--theme-accent)] transition-colors line-clamp-1"
                        >
                          {item.productName}
                        </Link>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-[var(--theme-text-muted)] hover:text-red-600 transition-colors p-0.5"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Color variant & SKU (Zero-pill text format) */}
                      <div className="flex items-center gap-2 mt-1 text-xs text-[var(--theme-text-muted)]">
                        <span 
                          className="w-2.5 h-2.5 rounded-full shrink-0 border border-black/10" 
                          style={{ backgroundColor: item.colorHex }}
                        />
                        <span className="font-medium text-[var(--theme-text)]">{item.colorName}</span>
                        <span>·</span>
                        <span className="font-mono text-[11px]">{item.sku}</span>
                      </div>

                      {/* Sample Specimen Badge & 100% Rebate Callout */}
                      {item.isSample && (
                        <div className="mt-1.5 space-y-0.5">
                          <span className="inline-block px-1.5 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 text-[10px] uppercase font-bold tracking-wider">
                            4" × 4" Sample Specimen
                          </span>
                          <span className="block text-[10px] text-[var(--theme-success)] font-medium">
                            Nominal fee · 100% credited toward full box order
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Quantity Stepper & Price */}
                    <div className="flex items-center justify-between mt-3 pt-2">
                      <div className="flex items-center border border-[var(--theme-border)] bg-[var(--theme-surface)]">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)]"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-3 text-xs font-semibold tabular-nums">
                          {item.quantity} {item.unit}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          disabled={item.quantity >= item.maxStock}
                          className="p-1 hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] disabled:opacity-40"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-semibold tabular-nums block text-[var(--theme-text)]">
                          GH₵{(item.unitPrice * item.quantity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-[10px] text-[var(--theme-text-muted)]">
                          GH₵{item.unitPrice}/{item.unit}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer actions */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-[var(--theme-border)] bg-[var(--theme-surface-subtle)] space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[var(--theme-text-muted)]">Subtotal</span>
                <span className="text-base font-semibold tabular-nums text-[var(--theme-text)]">
                  GH₵{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              {bulkDiscount > 0 && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xs space-y-1">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="flex items-center gap-1">
                      <span>🏷️ Bulk Tier Volume Savings:</span>
                    </span>
                    <span className="tabular-nums font-mono text-emerald-700">
                      -GH₵{bulkDiscount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  {appliedBulkTiers.map((tier, idx) => (
                    <div key={idx} className="text-[10px] text-emerald-800 flex justify-between">
                      <span>{tier.collectionName} ({tier.qualifyingSqm} m²): {tier.tierLabel}</span>
                      <span className="font-semibold">{tier.discountType === 'percentage' ? `${tier.discountValue}% OFF` : `GH₵${tier.discountValue}/m²`}</span>
                    </div>
                  ))}
                </div>
              )}

              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Taxes, Ghana VAT (15%), and site freight calculated at final step.
              </p>

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigate('/checkout');
                  }}
                  className="w-full py-3.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 flex items-center justify-center gap-2 transition-opacity"
                >
                  <span>Proceed to Site Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      navigate('/cart');
                    }}
                    className="text-xs text-[var(--theme-text)] hover:underline font-medium"
                  >
                    View Full Cart Summary
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Clear all items from your bag?')) {
                        clearCart();
                      }
                    }}
                    className="text-xs text-red-600 hover:underline"
                  >
                    Clear All
                  </button>
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
