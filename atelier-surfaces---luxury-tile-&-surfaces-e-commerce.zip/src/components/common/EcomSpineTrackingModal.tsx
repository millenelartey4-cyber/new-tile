import React from 'react';
import { 
  ShieldCheck, 
  Truck, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  Phone, 
  Package, 
  ExternalLink, 
  X, 
  Lock,
  Layers,
  ArrowRight
} from 'lucide-react';
import { EcomSpineWaybill, EcomSpineMilestone } from '../../types/ecomspine';

interface EcomSpineTrackingModalProps {
  waybill: EcomSpineWaybill;
  onClose: () => void;
  isOpen: boolean;
}

const MILESTONE_STEPS: { key: EcomSpineMilestone; label: string; desc: string }[] = [
  { key: 'crated_at_hub', label: 'Crated & Shock-Wrapped', desc: 'Central Hub Spintex' },
  { key: 'tailgate_loaded', label: 'Hydraulic Tailgate Loaded', desc: 'Secure Bay Loading' },
  { key: 'in_transit', label: 'In Fleet Transit', desc: 'Live Telemetry & GPS' },
  { key: 'arrived_on_site', label: 'Arrived On Destination Site', desc: 'Perimeter Staging' },
  { key: 'tailgate_offload', label: 'Hydraulic Tailgate Offload', desc: 'Heavy Precision Rigging' },
  { key: 'client_inspected_and_delivered', label: 'Client PIN Handover', desc: 'Verified & Delivered' }
];

export const EcomSpineTrackingModal: React.FC<EcomSpineTrackingModalProps> = ({
  waybill,
  onClose,
  isOpen
}) => {
  if (!isOpen) return null;

  const currentStepIndex = MILESTONE_STEPS.findIndex(s => s.key === waybill.currentMilestone);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header with EcomSpine Brand & Security Badge */}
        <div className="px-6 py-5 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-900/30">
              <Truck className="w-5 h-5 text-stone-950" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-500 font-mono">EcomSpine Logistics Engine</span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/60">
                  <ShieldCheck className="w-3 h-3 mr-1" />
                  Fleet Safe Protected
                </span>
              </div>
              <h2 className="text-lg font-serif font-medium text-stone-100 flex items-center gap-2">
                Waybill: <span className="font-mono text-amber-400 font-semibold">{waybill.waybillNumber}</span>
                <span className="text-xs text-stone-400 font-sans font-normal">(Order #{waybill.orderNumber})</span>
              </h2>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs text-stone-400">Security Delivery PIN</span>
              <span className="font-mono text-sm font-bold text-amber-400 tracking-widest bg-stone-900 px-2 py-1 rounded border border-amber-500/30">
                {waybill.verificationPin}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Key Metrics Banner */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-stone-950/60 border border-stone-800/80 rounded-xl p-4">
            <div>
              <div className="text-xs text-stone-400">Current Status</div>
              <div className="text-sm font-medium text-amber-400 capitalize flex items-center gap-1.5 mt-1">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                {waybill.currentMilestone.replace(/_/g, ' ')}
              </div>
            </div>
            <div>
              <div className="text-xs text-stone-400">ETA / Schedule</div>
              <div className="text-sm font-medium text-stone-200 mt-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-stone-400" />
                {waybill.estimatedDeliveryTime}
              </div>
            </div>
            <div>
              <div className="text-xs text-stone-400">Allocated Fleet</div>
              <div className="text-sm font-medium text-stone-200 mt-1 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-stone-400" />
                {waybill.vehiclePlate} ({waybill.vehicleType.split(' ')[0]})
              </div>
            </div>
            <div>
              <div className="text-xs text-stone-400">Handling Type</div>
              <div className="text-sm font-medium text-stone-200 mt-1 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-stone-400" />
                {waybill.packageDetails.totalPallets} Pallets ({waybill.packageDetails.totalWeightKg} kg)
              </div>
            </div>
          </div>

          {/* Stepper Progress Bar */}
          <div>
            <h3 className="text-xs uppercase tracking-wider text-stone-400 font-semibold mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              Heavy Architectural Delivery Milestones
            </h3>
            <div className="relative">
              {/* Stepper Grid */}
              <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
                {MILESTONE_STEPS.map((step, idx) => {
                  const isCompleted = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex;
                  return (
                    <div 
                      key={step.key} 
                      className={`p-3 rounded-xl border transition-all ${
                        isCurrent 
                          ? 'bg-amber-500/10 border-amber-500/50 shadow-sm shadow-amber-950'
                          : isCompleted 
                            ? 'bg-stone-950/80 border-emerald-900/40 text-stone-300' 
                            : 'bg-stone-950/40 border-stone-800 text-stone-500 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          isCurrent ? 'bg-amber-500 text-stone-950' : isCompleted ? 'bg-emerald-950 text-emerald-400' : 'bg-stone-800 text-stone-400'
                        }`}>
                          0{idx + 1}
                        </span>
                        {isCompleted ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Clock className="w-4 h-4 text-stone-600" />
                        )}
                      </div>
                      <div className={`text-xs font-semibold leading-snug ${isCurrent ? 'text-amber-300' : isCompleted ? 'text-stone-200' : 'text-stone-400'}`}>
                        {step.label}
                      </div>
                      <div className="text-[10px] text-stone-400 mt-1">
                        {step.desc}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Logistics & Driver Details + Waypoint Timeline */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Driver and Destination */}
            <div className="lg:col-span-5 space-y-4">
              {/* Assigned Heavy Transport Team */}
              <div className="bg-stone-950/70 border border-stone-800 rounded-xl p-4">
                <div className="text-xs uppercase font-mono tracking-wider text-stone-400 mb-3 flex items-center justify-between">
                  <span>Assigned Fleet Logistics Team</span>
                  <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20">
                    Certified Rigger
                  </span>
                </div>
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-12 h-12 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center text-stone-200 font-bold font-serif text-lg">
                    {waybill.driverName.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-stone-100">{waybill.driverName}</h4>
                    <p className="text-xs text-stone-400">Heavy Slabs Transit Master ({waybill.vehiclePlate})</p>
                  </div>
                </div>
                <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between">
                  <span className="text-xs text-stone-400">Direct Comms</span>
                  <a
                    href={`tel:${waybill.driverPhone}`}
                    className="inline-flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 font-mono"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    {waybill.driverPhone}
                  </a>
                </div>
              </div>

              {/* Delivery Site Destination Card */}
              <div className="bg-stone-950/70 border border-stone-800 rounded-xl p-4">
                <div className="text-xs uppercase font-mono tracking-wider text-stone-400 mb-3">
                  Delivery Site Destination
                </div>
                <div className="space-y-2">
                  <div className="flex items-start gap-2 text-xs">
                    <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-stone-200">{waybill.clientName}</div>
                      <div className="text-stone-400">{waybill.destinationAddress}</div>
                      <div className="text-stone-400">{waybill.destinationCity}</div>
                      <div className="font-mono text-amber-400/90 text-[11px] mt-1">{waybill.destinationGps}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Security & Verification Box */}
              <div className="bg-gradient-to-br from-amber-950/20 via-stone-900 to-stone-950 border border-amber-900/40 rounded-xl p-4">
                <div className="flex items-center space-x-2 text-amber-400 text-xs font-semibold mb-2">
                  <Lock className="w-4 h-4" />
                  <span>EcomSpine Anti-Theft Handover</span>
                </div>
                <p className="text-xs text-stone-300 leading-relaxed">
                  Upon arrival, our hydraulic offload team will inspect all quartz and marble surfaces with you. Hand the secure 4-digit PIN <span className="font-mono text-amber-400 font-bold">({waybill.verificationPin})</span> only when you have inspected and accepted the crated cargo.
                </p>
              </div>
            </div>

            {/* Right: Waypoint Log Timeline */}
            <div className="lg:col-span-7 bg-stone-950/70 border border-stone-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="text-xs uppercase font-mono tracking-wider text-stone-400 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  Live Fleet Telemetry & Waypoints
                </div>
                <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  GPS ACTIVE
                </span>
              </div>

              <div className="space-y-4">
                {waybill.waypoints.map((wp, index) => (
                  <div key={wp.id} className="relative pl-6 pb-2 group">
                    {/* Vertical line connecting waypoints */}
                    {index < waybill.waypoints.length - 1 && (
                      <div className={`absolute left-2.5 top-5 bottom-0 w-0.5 ${wp.completed ? 'bg-amber-500/40' : 'bg-stone-800'}`} />
                    )}
                    {/* Circle icon */}
                    <div className={`absolute left-0 top-1 w-5 h-5 rounded-full border flex items-center justify-center ${
                      wp.completed 
                        ? 'bg-amber-500 text-stone-950 border-amber-400' 
                        : 'bg-stone-900 text-stone-600 border-stone-700'
                    }`}>
                      {wp.completed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
                      ) : (
                        <div className="w-1.5 h-1.5 rounded-full bg-stone-600" />
                      )}
                    </div>
                    <div className="bg-stone-900/60 border border-stone-800/80 rounded-lg p-3 hover:border-stone-700 transition-colors">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className={`font-semibold ${wp.completed ? 'text-stone-200' : 'text-stone-400'}`}>
                          {wp.title}
                        </span>
                        <span className="font-mono text-[10px] text-stone-400">
                          {wp.timestamp}
                        </span>
                      </div>
                      <p className="text-xs text-stone-400 leading-relaxed">
                        {wp.description}
                      </p>
                      {wp.gpsCoordinates && (
                        <div className="mt-2 text-[10px] font-mono text-amber-500/80 flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          Telemetric Coordinates: {wp.gpsCoordinates}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-stone-950 border-t border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs text-stone-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Encrypted Fleet Waybill • Atelier Ghana Logistics</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-700 transition-colors flex items-center gap-1.5"
            >
              Print Official Waybill
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
