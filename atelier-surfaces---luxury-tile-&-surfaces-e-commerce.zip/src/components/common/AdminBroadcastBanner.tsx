import { useState, useEffect, useMemo } from 'react';
import { storeService } from '../../services/store';
import { AdminBroadcast, BroadcastAudience } from '../../types';
import { useRouter, Link } from '../../router/Router';
import { useCompany } from '../../context/CompanyContext';
import { useAuth } from '../../context/AuthContext';
import { 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  CheckCircle2, 
  X, 
  Lock, 
  ExternalLink, 
  Radio, 
  Volume2, 
  VolumeX, 
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

export function AdminBroadcastBanner() {
  const { currentPath } = useRouter();
  const { activeCompany } = useCompany();
  const { currentUser } = useAuth();
  const [dataVersion, setDataVersion] = useState(0);
  const [soundMuted, setSoundMuted] = useState(false);
  const [activeModalBroadcast, setActiveModalBroadcast] = useState<AdminBroadcast | null>(null);

  const isAdminRoute = currentPath.startsWith('/admin');
  const userIdentifier = currentUser?.uid || 'guest_user';

  // Listen to real-time events and storage changes
  useEffect(() => {
    const handleSync = () => setDataVersion(v => v + 1);
    window.addEventListener('atelier_broadcast_updated', handleSync);
    window.addEventListener('pos_realtime_event_received', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('atelier_broadcast_updated', handleSync);
      window.removeEventListener('pos_realtime_event_received', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Fetch broadcasts matching tenant and audience
  const audience: BroadcastAudience = isAdminRoute ? 'staff' : 'customers';
  const broadcasts = useMemo(() => {
    const all = storeService.getActiveBroadcasts(audience, activeCompany.id);
    return all.filter(b => {
      // If locked, it cannot be dismissed
      if (b.isLocked) return true;
      // If unlocked and dismissed by this user, hide it
      return !b.dismissedBy?.includes(userIdentifier);
    });
  }, [audience, activeCompany.id, dataVersion, userIdentifier]);

  // Check for modal broadcasts
  useEffect(() => {
    const modalBc = broadcasts.find(b => b.placement === 'modal' && (!b.dismissedBy?.includes(userIdentifier) || b.isLocked));
    if (modalBc) {
      setActiveModalBroadcast(modalBc);
    }
  }, [broadcasts, userIdentifier]);

  // Audio chime trigger on critical broadcasts
  useEffect(() => {
    const hasCritical = broadcasts.some(b => b.urgency === 'critical' && b.soundAlert);
    if (hasCritical && !soundMuted && typeof window !== 'undefined' && 'AudioContext' in window) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } catch {}
    }
  }, [broadcasts.length, soundMuted]);

  const handleDismiss = (broadcastId: string) => {
    storeService.dismissBroadcast(broadcastId, userIdentifier, activeCompany.id);
    setDataVersion(v => v + 1);
  };

  // Filter top banners
  const bannerBroadcasts = broadcasts.filter(b => b.placement !== 'modal');

  if (bannerBroadcasts.length === 0 && !activeModalBroadcast) {
    return null;
  }

  return (
    <>
      {/* Top Banners Strip */}
      {bannerBroadcasts.map(bc => {
        const isCritical = bc.urgency === 'critical';
        const isWarning = bc.urgency === 'warning';
        const isSuccess = bc.urgency === 'success';

        // High-contrast architectural luxury color palettes
        let containerBg = 'bg-stone-900 border-stone-700 text-stone-100';
        let badgeStyle = 'bg-stone-800 text-stone-300 border-stone-600';
        let icon = <Info className="w-4 h-4 text-cyan-400 shrink-0" />;

        if (isCritical) {
          containerBg = 'bg-red-950 border-red-600/80 text-red-100 shadow-md';
          badgeStyle = 'bg-red-900/90 text-red-200 border-red-500 animate-pulse font-bold';
          icon = <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 animate-bounce" />;
        } else if (isWarning) {
          containerBg = 'bg-amber-950/90 border-amber-600/70 text-amber-100';
          badgeStyle = 'bg-amber-900/80 text-amber-200 border-amber-500 font-bold';
          icon = <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />;
        } else if (isSuccess) {
          containerBg = 'bg-emerald-950/90 border-emerald-600/70 text-emerald-100';
          badgeStyle = 'bg-emerald-900/80 text-emerald-200 border-emerald-500 font-bold';
          icon = <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
        }

        return (
          <aside
            key={bc.id}
            role="alert"
            aria-live={isCritical ? 'assertive' : 'polite'}
            className={`w-full border-b transition-all duration-200 text-xs px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${containerBg}`}
          >
            <div className="flex items-start sm:items-center gap-2.5 flex-1 min-w-0">
              {icon}

              <div className="flex items-center gap-2 flex-wrap min-w-0 flex-1">
                {/* Urgency Badge */}
                <span className={`text-[10px] uppercase font-mono px-2 py-0.5 border rounded-xs shrink-0 tracking-wider ${badgeStyle}`}>
                  {bc.urgency === 'critical' ? 'CRITICAL ALERT' : bc.urgency === 'warning' ? 'OPERATIONAL NOTICE' : bc.urgency === 'success' ? 'DISPATCH UPDATE' : 'SHOWROOM ADVISORY'}
                </span>

                {/* Target Audience Pill */}
                <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 bg-black/40 text-stone-300 border border-white/10 rounded-xs shrink-0">
                  {bc.audience === 'all' ? 'Storewide' : bc.audience === 'staff' ? 'Staff Only' : 'Customers'}
                </span>

                {/* Title & Body */}
                <span className="font-bold text-xs truncate max-w-sm sm:max-w-none text-white">
                  {bc.title}:
                </span>
                <span className="text-stone-300 text-xs font-normal">
                  {bc.message}
                </span>
              </div>
            </div>

            {/* Action Buttons & Status Indicators */}
            <div className="flex items-center gap-2.5 shrink-0 self-end sm:self-auto">
              {bc.actionLabel && bc.actionUrl && (
                <Link
                  href={bc.actionUrl}
                  className={`px-3 py-1 text-[11px] font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                    isCritical 
                      ? 'bg-red-500 hover:bg-red-400 text-stone-950 font-black' 
                      : isWarning
                      ? 'bg-amber-400 hover:bg-amber-300 text-stone-950'
                      : 'bg-white hover:bg-stone-200 text-stone-950'
                  }`}
                >
                  <span>{bc.actionLabel}</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              )}

              {/* Sound Toggle for Critical Alerts */}
              {bc.soundAlert && (
                <button
                  type="button"
                  onClick={() => setSoundMuted(!soundMuted)}
                  className="p-1 text-stone-400 hover:text-stone-200 cursor-pointer"
                  title={soundMuted ? 'Unmute alert chimes' : 'Mute alert chimes'}
                >
                  {soundMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-amber-400" />}
                </button>
              )}

              {/* Locked Badge or Dismiss Button */}
              {bc.isLocked ? (
                <span 
                  className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 bg-black/50 text-amber-400 border border-amber-500/40 rounded-xs"
                  title="Broadcast is locked by administrator. Required reading."
                >
                  <Lock className="w-3 h-3" />
                  <span className="hidden md:inline">Admin Locked</span>
                </span>
              ) : bc.dismissible ? (
                <button
                  type="button"
                  onClick={() => handleDismiss(bc.id)}
                  className="p-1 text-stone-400 hover:text-stone-100 cursor-pointer transition-colors"
                  title="Dismiss notification"
                  aria-label="Dismiss broadcast notification"
                >
                  <X className="w-4 h-4" />
                </button>
              ) : null}
            </div>
          </aside>
        );
      })}

      {/* Priority Modal Broadcast (for critical emergency announcements) */}
      {activeModalBroadcast && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border-2 border-red-600 w-full max-w-lg p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-500/20 border border-red-500/40 text-red-400">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 bg-red-950 text-red-300 border border-red-800 font-bold">
                      {activeModalBroadcast.urgency.toUpperCase()} BROADCAST
                    </span>
                    {activeModalBroadcast.isLocked && (
                      <span className="text-[10px] font-mono px-1.5 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>Locked</span>
                      </span>
                    )}
                  </div>
                  <h3 className="font-serif text-lg font-bold text-stone-100 mt-1">
                    {activeModalBroadcast.title}
                  </h3>
                </div>
              </div>
              {!activeModalBroadcast.isLocked && activeModalBroadcast.dismissible && (
                <button
                  type="button"
                  onClick={() => {
                    handleDismiss(activeModalBroadcast.id);
                    setActiveModalBroadcast(null);
                  }}
                  className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="p-4 bg-stone-950 border border-stone-800 text-stone-200 text-xs leading-relaxed space-y-3">
              <p>{activeModalBroadcast.message}</p>
              <div className="pt-2 border-t border-stone-900 flex justify-between text-[11px] text-stone-500 font-mono">
                <span>Target: {activeModalBroadcast.audience.toUpperCase()}</span>
                <span>By: {activeModalBroadcast.createdBy}</span>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 pt-2">
              <span className="text-[11px] text-stone-500">
                {activeModalBroadcast.isLocked ? 'Mandatory notice locked by administrator.' : 'You may acknowledge and proceed.'}
              </span>
              <div className="flex items-center gap-2">
                {activeModalBroadcast.actionLabel && activeModalBroadcast.actionUrl && (
                  <Link
                    href={activeModalBroadcast.actionUrl}
                    onClick={() => setActiveModalBroadcast(null)}
                    className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold uppercase tracking-wider text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <span>{activeModalBroadcast.actionLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                )}
                {(!activeModalBroadcast.isLocked || activeModalBroadcast.dismissible) && (
                  <button
                    type="button"
                    onClick={() => {
                      handleDismiss(activeModalBroadcast.id);
                      setActiveModalBroadcast(null);
                    }}
                    className="px-4 py-2 border border-stone-700 text-stone-300 hover:bg-stone-800 uppercase font-bold text-xs cursor-pointer"
                  >
                    Acknowledge & Close
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
