import React, { useState, useEffect } from 'react';
import { offlineSyncService, SyncState, QueuedTransaction } from '../../services/offlineSync';
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  CheckCircle2, 
  Clock, 
  HardDrive, 
  Cloud, 
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  Layers,
  X,
  Sparkles
} from 'lucide-react';

export const ConnectionStatusBadge: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [syncState, setSyncState] = useState<SyncState>(() => offlineSyncService.getState());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = offlineSyncService.subscribe((state) => {
      setSyncState(state);
    });
    return () => unsubscribe();
  }, []);

  const handleSyncNow = async () => {
    setIsSyncing(true);
    const result = await offlineSyncService.syncPendingQueue();
    setIsSyncing(false);
    if (result.syncedCount > 0) {
      setSyncNotice(`Successfully synchronized ${result.syncedCount} transaction(s) to cloud database.`);
      setTimeout(() => setSyncNotice(null), 4000);
    } else if (result.errors.length > 0) {
      setSyncNotice(`Sync notice: ${result.errors[0]}`);
      setTimeout(() => setSyncNotice(null), 4000);
    }
  };

  const toggleSimulateOffline = () => {
    offlineSyncService.setSimulatedOffline(!syncState.isSimulated);
  };

  const queue = offlineSyncService.getQueue();

  return (
    <>
      {/* Interactive Status Pill */}
      <button
        type="button"
        onClick={() => setIsModalOpen(true)}
        className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-xs border transition-colors cursor-pointer shadow-xs ${
          syncState.isOnline
            ? 'bg-emerald-950/20 hover:bg-emerald-950/30 border-emerald-700/40 text-emerald-600 dark:text-emerald-400'
            : 'bg-amber-950/20 hover:bg-amber-950/30 border-amber-600/40 text-amber-600 dark:text-amber-400'
        } ${className}`}
        title="View Hybrid Online / Offline Status Hub"
      >
        <span
          className={`w-2 h-2 rounded-full ${
            syncState.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500 animate-pulse'
          }`}
        />
        <span className="font-medium hidden sm:inline">
          {syncState.isOnline ? 'Online (Cloud Sync)' : 'Offline Mode'}
        </span>
        <span className="sm:hidden font-medium">
          {syncState.isOnline ? 'Online' : 'Offline'}
        </span>

        {syncState.pendingCount > 0 && (
          <span className="ml-1 px-1.5 py-0.2 bg-amber-500 text-black text-[10px] font-bold rounded-xs">
            {syncState.pendingCount} Queued
          </span>
        )}
      </button>

      {/* Hybrid Online / Offline Modal */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setIsModalOpen(false)}
        >
          <div 
            className="w-full max-w-xl bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-5 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xs flex items-center justify-center ${
                  syncState.isOnline ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                } border border-[var(--theme-border)]`}>
                  {syncState.isOnline ? <Cloud className="w-5 h-5" /> : <HardDrive className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--theme-accent)]">
                      Dual Hybrid Architecture
                    </span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 ${
                      syncState.isOnline ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {syncState.isOnline ? 'Cloud Synchronized' : 'Local Offline Database'}
                    </span>
                  </div>
                  <h3 className="font-serif-luxury text-xl font-bold mt-0.5">
                    Online & Offline Dual Mode Hub
                  </h3>
                </div>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs">
              
              {/* Notice */}
              {syncNotice && (
                <div className="p-3 bg-emerald-950/30 border border-emerald-800 text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{syncNotice}</span>
                </div>
              )}

              {/* Status Overview Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
                  <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)]">Active State</span>
                  <div className="flex items-center gap-1.5 font-bold text-sm">
                    {syncState.isOnline ? (
                      <>
                        <Wifi className="w-4 h-4 text-emerald-500" />
                        <span className="text-emerald-500">Online</span>
                      </>
                    ) : (
                      <>
                        <WifiOff className="w-4 h-4 text-amber-500" />
                        <span className="text-amber-500">Offline</span>
                      </>
                    )}
                  </div>
                  <p className="text-[10px] text-[var(--theme-text-muted)]">
                    {syncState.isSimulated ? 'Field-test simulated' : 'Hardware network'}
                  </p>
                </div>

                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
                  <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)]">Sync Outbox</span>
                  <div className="flex items-center gap-1.5 font-bold text-sm">
                    <Clock className="w-4 h-4 text-[var(--theme-accent)]" />
                    <span>{syncState.pendingCount} Pending</span>
                  </div>
                  <p className="text-[10px] text-[var(--theme-text-muted)]">
                    Queued offline orders
                  </p>
                </div>

                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1 col-span-2 sm:col-span-1">
                  <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)]">Last Sync</span>
                  <div className="flex items-center gap-1.5 font-semibold text-xs text-[var(--theme-text)] truncate">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span className="truncate">{syncState.lastSync}</span>
                  </div>
                  <p className="text-[10px] text-[var(--theme-text-muted)]">
                    Auto-sync on reconnect
                  </p>
                </div>
              </div>

              {/* Offline Field-Test Switch */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-between gap-4">
                <div>
                  <div className="font-semibold text-[var(--theme-text)] flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-[var(--theme-accent)]" />
                    <span>Simulate Offline Mode (Field Testing)</span>
                  </div>
                  <p className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                    Switch to offline mode on demand to test job site presentations, tile calculators, and offline order queueing without disabling your WiFi.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={toggleSimulateOffline}
                  className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs transition-colors cursor-pointer shrink-0 border ${
                    syncState.isSimulated
                      ? 'bg-amber-600 border-amber-500 text-white'
                      : 'bg-[var(--theme-surface)] border-[var(--theme-border)] text-[var(--theme-text)] hover:border-[var(--theme-accent)]'
                  }`}
                >
                  {syncState.isSimulated ? 'Offline: Active' : 'Go Offline'}
                </button>
              </div>

              {/* What Works in Both Modes */}
              <div className="space-y-2.5">
                <h4 className="font-serif-luxury font-bold text-sm text-[var(--theme-text)]">
                  Dual-Engine Capability Matrix
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                  <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1.5">
                    <div className="font-bold text-emerald-500 flex items-center gap-1">
                      <Cloud className="w-3.5 h-3.5" />
                      <span>Online Mode (Connected)</span>
                    </div>
                    <ul className="space-y-1 text-[var(--theme-text-muted)] list-disc list-inside">
                      <li>Real-time multi-tenant database synchronization</li>
                      <li>Gemini Architectural AI Consultation</li>
                      <li>Live Paystack & Mobile Money validation</li>
                      <li>Automatic flushing of offline outbox orders</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1.5">
                    <div className="font-bold text-amber-500 flex items-center gap-1">
                      <HardDrive className="w-3.5 h-3.5" />
                      <span>Offline Mode (Disconnected)</span>
                    </div>
                    <ul className="space-y-1 text-[var(--theme-text-muted)] list-disc list-inside">
                      <li>100% Surface Slab Catalog & filters</li>
                      <li>Area & Wastage Box Estimator</li>
                      <li>Local order placement & quote queueing</li>
                      <li>Theme Studio (64+ themes) & Company switcher</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Offline Transactions Outbox */}
              {queue.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-serif-luxury font-bold text-sm text-[var(--theme-text)]">
                      Sync Outbox ({queue.length})
                    </h4>
                    {queue.some(q => q.status === 'synced') && (
                      <button
                        onClick={() => offlineSyncService.clearSyncedTransactions()}
                        className="text-[10px] text-[var(--theme-accent)] hover:underline cursor-pointer"
                      >
                        Clear Synced History
                      </button>
                    )}
                  </div>
                  <div className="max-h-36 overflow-y-auto space-y-1.5 border border-[var(--theme-border)] p-2 bg-[var(--theme-surface-subtle)]">
                    {queue.map(item => (
                      <div key={item.id} className="p-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-[11px] truncate">{item.summary}</span>
                            <span className={`text-[9px] px-1 py-0.2 font-mono uppercase font-bold ${
                              item.status === 'synced' ? 'bg-emerald-500/20 text-emerald-400' :
                              item.status === 'syncing' ? 'bg-blue-500/20 text-blue-400' :
                              'bg-amber-500/20 text-amber-400'
                            }`}>
                              {item.status}
                            </span>
                          </div>
                          <span className="text-[10px] text-[var(--theme-text-muted)]">
                            {new Date(item.createdAt).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex items-center justify-between">
              <span className="text-[11px] text-[var(--theme-text-muted)]">
                Local Storage & Workbox Cache: Active
              </span>
              <div className="flex items-center gap-2">
                {syncState.isOnline && (
                  <button
                    onClick={handleSyncNow}
                    disabled={isSyncing}
                    className="px-4 py-2 bg-[var(--theme-accent)] hover:opacity-90 text-white font-bold text-xs uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? 'Syncing...' : 'Sync Cloud Now'}</span>
                  </button>
                )}
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] hover:border-[var(--theme-text)] transition cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
