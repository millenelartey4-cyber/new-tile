import { useState, Fragment } from 'react';
import { Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { useCompany } from '../../context/CompanyContext';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { MapPin, Phone, Mail, CheckCircle2, ArrowRight, Building2 } from 'lucide-react';

export function Footer() {
  const { companies, activeCompany, setIsSwitcherOpen } = useCompany();
  const settings = useStoreSettings(activeCompany.id);
  const panelBrightness = storeService.getPanelBrightness(activeCompany.id);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  return (
    <footer 
      style={{
        filter: `brightness(${panelBrightness.storefrontFooterBrightness}%) contrast(${panelBrightness.storefrontFooterContrast}%)`
      }}
      className="bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] text-[var(--theme-text)] mt-24 transition-all duration-150"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
          
          {/* Brand & Mission */}
          <div className="lg:col-span-2 space-y-4">
            <span className="font-serif-luxury text-2xl font-bold tracking-widest uppercase">
              {settings.brandName}
            </span>
            <p className="text-sm text-[var(--theme-text-muted)] leading-relaxed max-w-sm">
              Curators of architectural porcelain, quarry-direct Italian marble, and handcrafted sintered stone surfaces for visionary residences, luxury hotels, and commercial developments across West Africa and beyond.
            </p>
            <div className="pt-2 space-y-2 text-xs text-[var(--theme-text-muted)]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 shrink-0 text-[var(--theme-accent)] mt-0.5" />
                <span>
                  {settings.showroomAddress} {settings.ghanaPostGps ? `(GPS: ${settings.ghanaPostGps})` : ''}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 shrink-0 text-[var(--theme-accent)]" />
                <div className="flex items-center gap-1.5 flex-wrap">
                  {(settings.contactPhone || '0542443125/0596334488').includes('/') ? (
                    (settings.contactPhone || '0542443125/0596334488').split('/').map((num, idx, arr) => (
                      <Fragment key={idx}>
                        <a href={`tel:${num.trim().replace(/[^0-9+]/g, '')}`} className="hover:text-[var(--theme-text)] hover:underline transition-colors">
                          {num.trim()}
                        </a>
                        {idx < arr.length - 1 && <span className="text-[var(--theme-border)]">/</span>}
                      </Fragment>
                    ))
                  ) : (
                    <a href={`tel:${(settings.contactPhone || '0542443125').replace(/[^0-9+]/g, '')}`} className="hover:text-[var(--theme-text)] hover:underline transition-colors">
                      {settings.contactPhone || '0542443125/0596334488'}
                    </a>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 shrink-0 flex items-center justify-center font-bold text-[10px] text-emerald-500 font-mono">WA</span>
                {(() => {
                  const rawWa = settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488';
                  const firstWa = rawWa.split('/')[0].trim();
                  let waDigits = firstWa.replace(/[^0-9]/g, '');
                  if (waDigits.startsWith('0')) {
                    waDigits = '233' + waDigits.substring(1);
                  }
                  return (
                    <a 
                      href={`https://wa.me/${waDigits || '233542443125'}`} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="hover:text-[var(--theme-text)] hover:underline transition-colors text-emerald-600 dark:text-emerald-400 font-medium"
                    >
                      WhatsApp: {rawWa}
                    </a>
                  );
                })()}
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 shrink-0 text-[var(--theme-accent)]" />
                <a href={`mailto:${settings.contactEmail}`} className="hover:text-[var(--theme-text)] hover:underline transition-colors">
                  {settings.contactEmail}
                </a>
              </div>
            </div>
          </div>

          {/* Collections */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-widest text-[var(--theme-text)] mb-4">
              Collections
            </h3>
            <ul className="space-y-2.5 text-sm text-[var(--theme-text-muted)]">
              <li><Link href="/category/marble-look" className="hover:text-[var(--theme-accent)] transition-colors">Marble-Look Slabs</Link></li>
              <li><Link href="/category/floor-tiles" className="hover:text-[var(--theme-accent)] transition-colors">Architectural Floor Tiles</Link></li>
              <li><Link href="/category/natural-stone" className="hover:text-[var(--theme-accent)] transition-colors">Roman Travertine & Stone</Link></li>
              <li><Link href="/category/wall-tiles" className="hover:text-[var(--theme-accent)] transition-colors">Artisan Zellige Wall Glaze</Link></li>
              <li><Link href="/category/outdoor-tiles" className="hover:text-[var(--theme-accent)] transition-colors">20mm Outdoor Pavers</Link></li>
              <li><Link href="/shop" className="hover:text-[var(--theme-accent)] transition-colors">Complete Material Catalog</Link></li>
            </ul>
          </div>

          {/* Trade & Client Services */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-widest text-[var(--theme-text)] mb-4">
              Client & Trade
            </h3>
            <ul className="space-y-2.5 text-sm text-[var(--theme-text-muted)]">
              <li><Link href="/account" className="hover:text-[var(--theme-accent)] transition-colors">Trade Account & Orders</Link></li>
              <li><Link href="/shipping-returns" className="hover:text-[var(--theme-accent)] transition-colors">Freight & Site Delivery</Link></li>
              <li><Link href="/about" className="hover:text-[var(--theme-accent)] transition-colors">Our Quarries & Craft</Link></li>
              <li><Link href="/contact" className="hover:text-[var(--theme-accent)] transition-colors">Book Showroom Private Visit</Link></li>
              <li>
                <Link
                  href="/video-consultation"
                  className={`transition-colors flex items-center gap-1.5 font-medium ${
                    settings.videoConsultationLocked
                      ? 'text-red-500 hover:text-red-400'
                      : 'text-emerald-600 dark:text-emerald-400 hover:text-[var(--theme-accent)]'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    settings.videoConsultationLocked ? 'bg-red-500' : 'bg-emerald-500 animate-pulse'
                  }`} />
                  <span>Face-to-Face Video Consultation {settings.videoConsultationLocked ? '(Locked)' : ''}</span>
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setIsSwitcherOpen(true)}
                  className="hover:text-[var(--theme-accent)] transition-colors text-left flex items-center gap-1 cursor-pointer"
                >
                  <Building2 className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                  <span>Company Stores ({companies.length})</span>
                </button>
              </li>
              <li>
                <Link 
                  href="/install" 
                  className="hover:text-[var(--theme-accent)] transition-colors flex items-center gap-1.5 font-semibold text-[var(--theme-text)]"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Download Desktop / SaaS App</span>
                </Link>
              </li>
              <li><Link href="/terms" className="hover:text-[var(--theme-accent)] transition-colors">Terms of Supply</Link></li>
            </ul>
          </div>

          {/* Architectural Dispatch Newsletter */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-widest text-[var(--theme-text)] mb-4">
              Architectural Gazette
            </h3>
            <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed mb-4">
              Receive quarterly specimen releases, quarry updates from Italy and Spain, and material specification sheets.
            </p>
            {subscribed ? (
              <div className="flex items-center gap-2 p-3 bg-emerald-50 text-emerald-800 text-xs border border-emerald-200">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Thank you. You are enrolled in the Atelier Gazette.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={e => setNewsletterEmail(e.target.value)}
                    placeholder="architect@studio.com"
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                  <button
                    type="submit"
                    className="absolute right-1 top-1 bottom-1 px-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs hover:opacity-90 flex items-center justify-center"
                    aria-label="Subscribe to newsletter"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-[11px] text-[var(--theme-text-muted)] block">
                  Zero spam. Unsubscribe at any moment.
                </span>
              </form>
            )}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-[var(--theme-border)] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[var(--theme-text-muted)]">
          <p>© {new Date().getFullYear()} {settings.brandName}. All rights reserved. Registered trade entity in Ghana.</p>
          <div className="flex items-center gap-6">
            <Link href="/privacy" className="hover:underline">Privacy Policy</Link>
            <Link href="/terms" className="hover:underline">Terms & Conditions</Link>
            <Link href="/shipping-returns" className="hover:underline">Shipping & Breakage Guarantee</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
