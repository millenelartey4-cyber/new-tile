import { useState } from 'react';
import { useRouter, Link } from '../../router/Router';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { 
  Search, 
  ShoppingBag, 
  Heart, 
  User, 
  ShieldCheck, 
  Menu, 
  X, 
  ChevronDown,
  Lock,
  Unlock,
  Building2,
  Share2,
  Download,
  Video,
  MessageSquare,
  ScanLine
} from 'lucide-react';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { ConnectionStatusBadge } from './ConnectionStatusBadge';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { SurfaceTextureScannerModal } from '../scanner/SurfaceTextureScannerModal';

export function Header() {
  const { currentPath, navigate } = useRouter();
  const { itemCount, wishlistCount, setIsCartOpen } = useCartWishlist();
  const { activeCompany, setIsSwitcherOpen, getCompanyShareUrl } = useCompany();
  const { 
    currentUser, 
    currentRole, 
    switchRole, 
    availableRoles, 
    isAdminOrStaff, 
    isAdminConsoleUnlocked,
    lockAdminConsole,
    logout 
  } = useAuth();
  const settings = useStoreSettings(activeCompany.id);
  const panelBrightness = storeService.getPanelBrightness(activeCompany.id);

  const [announcementDismissed, setAnnouncementDismissed] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?q=${encodeURIComponent(searchQuery.trim())}`);
      setIsSearchOpen(false);
    }
  };

  const navLinks = [
    { label: 'Shop All', href: '/shop' },
    { label: 'Marble-Look', href: '/category/marble-look' },
    { label: 'Floor Tiles', href: '/category/floor-tiles' },
    { label: 'Natural Stone', href: '/category/natural-stone' },
    { label: 'Live Video Consultation', href: '/video-consultation' }
  ];

  return (
    <>
      {/* Announcement Bar */}
      {settings.announcementEnabled && !announcementDismissed && (
        <aside 
          aria-label="Announcement"
          className="relative bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] py-2 px-4 text-xs tracking-wider uppercase text-center font-medium transition-colors"
        >
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-2">
            <span>{settings.announcementText}</span>
          </div>
          <button
            onClick={() => setAnnouncementDismissed(true)}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-[var(--theme-primary-contrast)]/70 hover:text-[var(--theme-primary-contrast)]"
            aria-label="Dismiss announcement"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </aside>
      )}

      {/* Role Testing Bar & Administrative Security Gate */}
      <div className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] text-xs py-1.5 px-4 text-[var(--theme-text-muted)]">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Active Company Workspace Pill */}
            <button
              type="button"
              onClick={() => setIsSwitcherOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] transition-colors cursor-pointer shadow-xs group"
              title="Switch company storefront or deploy new company"
            >
              <Building2 className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span className="font-serif-luxury font-semibold max-w-[130px] sm:max-w-[200px] truncate">
                {activeCompany.name}
              </span>
              <span className="text-[10px] px-1 py-0.2 bg-[var(--theme-accent)] text-white font-mono uppercase font-bold">
                {activeCompany.currency}
              </span>
              <ChevronDown className="w-2.5 h-2.5 text-[var(--theme-text-muted)] group-hover:text-[var(--theme-text)]" />
            </button>

            <span className="text-[var(--theme-border)] hidden md:inline">|</span>

            <div className="hidden md:flex items-center gap-1.5 text-[11px]">
              <span className="font-semibold text-[var(--theme-text)]">Mode:</span>
              <span className="text-[var(--theme-accent)] font-medium">{currentRole?.name || 'Customer'}</span>
            </div>
          </div>

          <div className="relative flex items-center gap-3">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-1.5 font-medium text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-colors cursor-pointer"
            >
              <span>Switch Testing Role</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {isRoleDropdownOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-64 bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-lg z-50 py-1.5 text-xs text-[var(--theme-text)]">
                <div className="px-3 py-1 text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)] border-b border-[var(--theme-border)]">
                  Simulate Role & Permissions
                </div>
                {availableRoles.map(role => (
                  <button
                    key={role.id}
                    onClick={() => {
                      if (role.id !== 'customer' && !isAdminConsoleUnlocked) {
                        setIsRoleDropdownOpen(false);
                        navigate('/admin');
                        return;
                      }
                      switchRole(role.id);
                      setIsRoleDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-[var(--theme-surface-subtle)] transition-colors cursor-pointer ${
                      currentRole?.id === role.id ? 'font-semibold text-[var(--theme-accent)]' : ''
                    }`}
                  >
                    <span>{role.name}</span>
                    {role.id !== 'customer' && !isAdminConsoleUnlocked ? (
                      <span className="text-[10px] text-amber-600 font-mono flex items-center gap-0.5">
                        <Lock className="w-2.5 h-2.5" /> Key Req.
                      </span>
                    ) : currentRole?.id === role.id ? (
                      <span className="text-[10px] text-[var(--theme-accent)]">Active</span>
                    ) : null}
                  </button>
                ))}
              </div>
            )}

            <span className="text-[var(--theme-border)]">|</span>

            {/* Hybrid Online & Offline Status Pill */}
            <ConnectionStatusBadge />

            <span className="text-[var(--theme-border)]">|</span>

            {/* Face-to-Face Video Call & Chat */}
            <Link
              href="/video-consultation"
              className={`font-semibold flex items-center gap-1.5 transition-colors ${
                settings.videoConsultationLocked
                  ? 'text-red-500 hover:text-red-400'
                  : 'text-emerald-600 dark:text-emerald-400 hover:text-emerald-500'
              }`}
              title={settings.videoConsultationLocked ? 'Video Consultations Currently Locked' : 'Start or join face-to-face video consultation & live chat'}
            >
              {settings.videoConsultationLocked ? (
                <Lock className="w-3.5 h-3.5" />
              ) : (
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
              )}
              <Video className="w-3.5 h-3.5" />
              <span>Face-to-Face Video {settings.videoConsultationLocked ? '(Locked)' : 'Call'}</span>
            </Link>

            <span className="text-[var(--theme-border)]">|</span>

            {/* Install Web App / Download Desktop App */}
            <PWAInstallButton variant="header" />

            <span className="text-[var(--theme-border)]">|</span>

            {isAdminConsoleUnlocked ? (
              <div className="flex items-center gap-2">
                <Link
                  href="/admin"
                  className="font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin Console</span>
                </Link>
                <button
                  type="button"
                  onClick={lockAdminConsole}
                  className="px-2 py-0.5 bg-red-950/20 hover:bg-red-900/30 text-red-600 dark:text-red-400 border border-red-800/30 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                  title="Lock admin console"
                >
                  <Lock className="w-2.5 h-2.5" />
                  <span>Lock</span>
                </button>
              </div>
            ) : (
              <Link
                href="/admin"
                className="font-medium text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)] flex items-center gap-1 transition-colors"
                title="Protected Admin Console"
              >
                <Lock className="w-3 h-3 text-amber-600" />
                <span>Admin Login</span>
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Main Top Bar (Standard 3-Zone Contract) */}
      <header 
        style={{
          filter: `brightness(${panelBrightness.storefrontHeaderBrightness}%) contrast(${panelBrightness.storefrontHeaderContrast}%)`
        }}
        className="sticky top-0 z-40 bg-[var(--theme-nav-bg)] backdrop-blur-md border-b border-[var(--theme-border)] transition-all duration-150"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single Brand Wordmark */}
          <div className="flex items-center gap-4 shrink-0">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-[var(--theme-text)] hover:text-[var(--theme-accent)]"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <Link
              href="/"
              className="font-serif-luxury text-2xl sm:text-3xl font-semibold tracking-widest uppercase text-[var(--theme-text)] whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
            >
              {settings.brandName}
            </Link>
          </div>

          {/* Zone 2: 4-5 Single-Line Clean Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium tracking-wide text-[var(--theme-text)]">
            {navLinks.map(link => {
              const active = currentPath === link.href || (link.href !== '/' && currentPath.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 ${
                    active 
                      ? 'border-[var(--theme-accent)] text-[var(--theme-accent)] font-semibold' 
                      : 'border-transparent text-[var(--theme-text)]/80 hover:text-[var(--theme-text)] hover:border-[var(--theme-border)]'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Zone 3: Actions (Scan Texture, Search, Wishlist, Bag, Account) */}
          <div className="flex items-center gap-3 sm:gap-5 shrink-0 text-[var(--theme-text)]">
            {/* Surface Texture Scanner Shutter Button */}
            <button
              type="button"
              onClick={() => setIsScannerOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-all cursor-pointer shadow-xs group"
              title="Surface Texture Scanner: Use device camera to analyze floor sample and find catalog matches"
            >
              <ScanLine className="w-4 h-4 text-[var(--theme-accent)] group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline font-bold">Scan Texture</span>
            </button>

            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-1.5 hover:text-[var(--theme-accent)] transition-colors"
              aria-label="Search tiles and surfaces"
            >
              <Search className="w-5 h-5" />
            </button>

            <Link
              href="/wishlist"
              className="p-1.5 hover:text-[var(--theme-accent)] transition-colors relative"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1.5 w-4 h-4 rounded-full bg-[var(--theme-accent)] text-white text-[10px] font-bold flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            <button
              onClick={() => setIsCartOpen(true)}
              className="p-1.5 hover:text-[var(--theme-accent)] transition-colors relative"
              aria-label="Shopping bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1.5 w-4 h-4 rounded-full bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-[10px] font-bold flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </button>

            <Link
              href={isAdminOrStaff ? '/admin' : '/account'}
              className="hidden sm:flex items-center gap-1.5 text-xs font-medium tracking-wide uppercase px-3 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-accent)] hover:text-[var(--theme-accent)] transition-colors"
            >
              <User className="w-3.5 h-3.5" />
              <span>{isAdminOrStaff ? 'Admin' : 'Account'}</span>
            </Link>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-[var(--theme-border)] bg-[var(--theme-surface)] px-6 py-6 space-y-4">
            <nav className="flex flex-col space-y-3">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-base font-medium text-[var(--theme-text)] py-2 border-b border-[var(--theme-border-subtle)]"
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-medium text-[var(--theme-text)] py-2 border-b border-[var(--theme-border-subtle)]"
              >
                About Our Quarries & Brand
              </Link>
              <Link
                href="/contact"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-medium text-[var(--theme-text)] py-2 border-b border-[var(--theme-border-subtle)]"
              >
                Contact Concierge & Showroom
              </Link>
              <Link
                href="/video-consultation"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-semibold text-emerald-600 dark:text-emerald-400 py-2 border-b border-[var(--theme-border-subtle)] flex items-center gap-2"
              >
                <Video className="w-4 h-4 text-emerald-500" />
                <span>Face-to-Face Video Call & Chat</span>
              </Link>
              <Link
                href="/install"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-medium text-[var(--theme-text)] py-2 border-b border-[var(--theme-border-subtle)] flex items-center gap-2"
              >
                <Download className="w-4 h-4 text-[var(--theme-accent)]" />
                <span>Install Web / Desktop App</span>
              </Link>
              <Link
                href={isAdminOrStaff ? '/admin' : '/account'}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-semibold text-[var(--theme-accent)] py-2"
              >
                {isAdminOrStaff ? 'Admin Console' : 'My Account & Orders'}
              </Link>
            </nav>
          </div>
        )}
      </header>

      {/* Search Modal */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center pt-24 px-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-2xl p-6 shadow-2xl relative">
            <button
              onClick={() => setIsSearchOpen(false)}
              className="absolute right-4 top-4 p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
              aria-label="Close search"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-sm font-semibold tracking-wider uppercase text-[var(--theme-text-muted)] mb-3">
              Search Architectural Surfaces & Tiles
            </h2>
            <form onSubmit={handleSearchSubmit} className="flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by material (Calacatta, Travertine), size (60x120), or SKU..."
                autoFocus
                className="flex-1 px-4 py-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-sm focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-medium text-sm hover:opacity-95 transition-opacity"
              >
                Search
              </button>
            </form>
            <div className="mt-4 pt-4 border-t border-[var(--theme-border-subtle)] flex flex-wrap gap-2 text-xs text-[var(--theme-text-muted)]">
              <span className="font-semibold text-[var(--theme-text)]">Popular:</span>
              <button onClick={() => { setSearchQuery('Calacatta'); }} className="hover:underline">Calacatta Gold</button>
              <span>·</span>
              <button onClick={() => { setSearchQuery('Travertine'); }} className="hover:underline">Roman Travertine</button>
              <span>·</span>
              <button onClick={() => { setSearchQuery('Terrazzo'); }} className="hover:underline">Venetian Terrazzo</button>
              <span>·</span>
              <button onClick={() => { setSearchQuery('Zellige'); }} className="hover:underline">Emerald Zellige</button>
            </div>
          </div>
        </div>
      )}

      {/* Surface Texture Scanner Modal */}
      <SurfaceTextureScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
      />
    </>
  );
}
