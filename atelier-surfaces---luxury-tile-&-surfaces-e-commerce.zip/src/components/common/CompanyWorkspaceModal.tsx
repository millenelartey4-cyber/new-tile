import React, { useState } from 'react';
import { useCompany } from '../../context/CompanyContext';
import { CompanyTenant, Currency } from '../../types';
import { 
  Building2, 
  X, 
  Check, 
  Copy, 
  ExternalLink, 
  Plus, 
  Download, 
  Upload, 
  Trash2, 
  Sparkles, 
  Globe, 
  ShieldCheck, 
  Layers,
  ArrowRight
} from 'lucide-react';

export function CompanyWorkspaceModal() {
  const { 
    activeCompany, 
    companies, 
    switchCompany, 
    deployCompany, 
    deleteCompany, 
    getCompanyShareUrl, 
    exportCompany, 
    importCompany,
    isSwitcherOpen, 
    setIsSwitcherOpen,
    isDeployModalOpen,
    setIsDeployModalOpen
  } = useCompany();

  const [activeTab, setActiveTab] = useState<'switch' | 'deploy' | 'import'>('switch');
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  // New Company Form State
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [tagline, setTagline] = useState('');
  const [industry, setIndustry] = useState('Architectural Tile & Stone');
  const [currency, setCurrency] = useState<Currency>('GHS');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('+233 ');
  const [showroomAddress, setShowroomAddress] = useState('');
  const [deployPassword, setDeployPassword] = useState('');
  const [seedTemplate, setSeedTemplate] = useState<'copy' | 'empty'>('copy');
  const [deploySuccess, setDeploySuccess] = useState<string | null>(null);

  // Import State
  const [importJson, setImportJson] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);

  if (!isSwitcherOpen && !isDeployModalOpen) return null;

  const handleCopyLink = (companySlug: string) => {
    const url = getCompanyShareUrl(companySlug);
    navigator.clipboard.writeText(url);
    setCopiedSlug(companySlug);
    setTimeout(() => setCopiedSlug(null), 2000);
  };

  const handleNameChange = (val: string) => {
    setName(val);
    if (!slug || slug === name.toLowerCase().replace(/[^a-z0-9_-]/g, '-')) {
      setSlug(val.toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/^-+|-+$/g, ''));
    }
  };

  const handleDeploySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const currencySymbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency === 'GBP' ? '£' : 'GH₵';
    const newComp = deployCompany({
      name: name.trim(),
      slug: slug.trim() || name.toLowerCase().replace(/[^a-z0-9_-]/g, '-'),
      tagline: tagline.trim() || 'Architectural Tile & Natural Stone Surfaces',
      industry,
      currency,
      currencySymbol,
      contactEmail: contactEmail.trim() || `contact@${slug}.com`,
      contactPhone: contactPhone.trim(),
      showroomAddress: showroomAddress.trim() || 'Accra Showroom',
      adminPassword: deployPassword.trim() || 'admin123'
    }, seedTemplate);

    setDeploySuccess(`Successfully deployed workspace for ${newComp.name}!`);
    setDeployPassword('');
    setTimeout(() => {
      setDeploySuccess(null);
      setIsDeployModalOpen(false);
      setIsSwitcherOpen(false);
    }, 1500);
  };

  const handleExport = (comp: CompanyTenant) => {
    const jsonStr = exportCompany(comp.id);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${comp.slug}-ecommerce-workspace.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setImportError(null);
    setImportSuccess(null);
    if (!importJson.trim()) {
      setImportError('Please paste valid JSON workspace backup data.');
      return;
    }
    const res = importCompany(importJson);
    if (res.success) {
      setImportSuccess('Workspace imported and activated successfully!');
      setTimeout(() => {
        setIsSwitcherOpen(false);
        setIsDeployModalOpen(false);
      }, 1200);
    } else {
      setImportError(res.error || 'Failed to import workspace JSON.');
    }
  };

  const handleClose = () => {
    setIsSwitcherOpen(false);
    setIsDeployModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="max-w-2xl w-full bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-[var(--theme-text)]"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-sm bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] flex items-center justify-center">
              <Building2 className="w-5 h-5 text-[var(--theme-accent)]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)]">
                  Multi-Company Workspaces
                </h3>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  Zero Data Collision
                </span>
              </div>
              <p className="text-xs text-[var(--theme-text-muted)]">
                Isolated storefronts, catalogs, inventory, and orders for different companies & clients.
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[var(--theme-border)] px-6 text-xs uppercase font-bold tracking-wider bg-[var(--theme-surface)]">
          <button
            onClick={() => setActiveTab('switch')}
            className={`py-3 border-b-2 transition-colors cursor-pointer mr-6 ${
              activeTab === 'switch'
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            Active Workspaces ({companies.length})
          </button>

          <button
            onClick={() => setActiveTab('deploy')}
            className={`py-3 border-b-2 transition-colors cursor-pointer mr-6 flex items-center gap-1.5 ${
              activeTab === 'deploy'
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Deploy New Client Store</span>
          </button>

          <button
            onClick={() => setActiveTab('import')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'import'
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import / Clone</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'switch' && (
            <div className="space-y-4">
              <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-accent)]">
                    Current Active Storefront:
                  </span>
                  <h4 className="font-serif-luxury text-base font-semibold">
                    {activeCompany.name}
                  </h4>
                  <p className="text-xs text-[var(--theme-text-muted)]">
                    {activeCompany.tagline} · {activeCompany.currency} ({activeCompany.currencySymbol})
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopyLink(activeCompany.slug)}
                  className="px-3.5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-sm hover:opacity-90 transition-opacity cursor-pointer shrink-0"
                >
                  {copiedSlug === activeCompany.slug ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>URL Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Client Share Link</span>
                    </>
                  )}
                </button>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  Available Isolated Client Storefronts:
                </h4>

                <div className="space-y-2.5">
                  {companies.map(comp => {
                    const isActive = comp.id === activeCompany.id;
                    const shareUrl = getCompanyShareUrl(comp.slug);

                    return (
                      <div
                        key={comp.id}
                        className={`p-4 border transition-all ${
                          isActive
                            ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]/50 shadow-xs'
                            : 'border-[var(--theme-border)] bg-[var(--theme-surface)] hover:border-[var(--theme-text)]'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <h5 className="font-serif-luxury font-semibold text-sm text-[var(--theme-text)]">
                                {comp.name}
                              </h5>
                              {isActive && (
                                <span className="text-[10px] font-bold px-1.5 py-0.2 bg-[var(--theme-accent)] text-white uppercase">
                                  Current
                                </span>
                              )}
                              {comp.isDefault && (
                                <span className="text-[10px] font-semibold text-[var(--theme-text-muted)]">
                                  · Flagship
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-[var(--theme-text-muted)] line-clamp-1">
                              {comp.tagline}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 text-[11px] text-[var(--theme-text-muted)] font-mono">
                              <span>Currency: {comp.currency} ({comp.currencySymbol})</span>
                              <span>·</span>
                              <span>ID: ?company={comp.slug}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            {!isActive ? (
                              <button
                                type="button"
                                onClick={() => switchCompany(comp.id)}
                                className="px-3 py-1.5 bg-[var(--theme-accent)] text-white text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity cursor-pointer flex items-center gap-1"
                              >
                                <span>Switch Store</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            ) : (
                              <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" />
                                <span>Active</span>
                              </span>
                            )}

                            <button
                              type="button"
                              onClick={() => handleCopyLink(comp.slug)}
                              className="p-1.5 border border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text)] transition-colors cursor-pointer"
                              title="Copy direct share URL for this company"
                            >
                              {copiedSlug === comp.slug ? (
                                <Check className="w-3.5 h-3.5 text-emerald-500" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleExport(comp)}
                              className="p-1.5 border border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text)] transition-colors cursor-pointer"
                              title="Export workspace backup (JSON)"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>

                            {!comp.isDefault && companies.length > 1 && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Are you sure you want to delete workspace "${comp.name}"?`)) {
                                    deleteCompany(comp.id);
                                  }
                                }}
                                className="p-1.5 border border-red-200 hover:bg-red-50 text-red-600 transition-colors cursor-pointer"
                                title="Delete this workspace"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'deploy' && (
            <form onSubmit={handleDeploySubmit} className="space-y-4 text-xs">
              {deploySuccess && (
                <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-300 font-semibold flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>{deploySuccess}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Company / Brand Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => handleNameChange(e.target.value)}
                    placeholder="e.g. Apex Luxury Slabs Ltd"
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    URL Identifier Slug (?company=...) *
                  </label>
                  <input
                    type="text"
                    required
                    value={slug}
                    onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '-'))}
                    placeholder="e.g. apex-slabs"
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-mono focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                </div>
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Tagline / Brand Descriptor
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={e => setTagline(e.target.value)}
                  placeholder="e.g. Curators of Italian Sintered Stone & Porcelain Tiles"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Primary Operating Currency
                  </label>
                  <select
                    value={currency}
                    onChange={e => setCurrency(e.target.value as Currency)}
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
                  >
                    <option value="GHS">GHS (GH₵ - Ghana Cedis)</option>
                    <option value="USD">USD ($ - US Dollars)</option>
                    <option value="EUR">EUR (€ - Euros)</option>
                    <option value="GBP">GBP (£ - British Pounds)</option>
                  </select>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Catalog Template
                  </label>
                  <select
                    value={seedTemplate}
                    onChange={e => setSeedTemplate(e.target.value as 'copy' | 'empty')}
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
                  >
                    <option value="copy">Pre-populate Flagship Tiles (Ready to customize)</option>
                    <option value="empty">Empty Catalog (Build from scratch)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Contact Email
                  </label>
                  <input
                    type="email"
                    value={contactEmail}
                    onChange={e => setContactEmail(e.target.value)}
                    placeholder="orders@company.com"
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Contact Phone / WhatsApp
                  </label>
                  <input
                    type="tel"
                    value={contactPhone}
                    onChange={e => setContactPhone(e.target.value)}
                    placeholder="+233 24 000 0000"
                    className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                </div>
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Showroom / Warehouse Address
                </label>
                <input
                  type="text"
                  value={showroomAddress}
                  onChange={e => setShowroomAddress(e.target.value)}
                  placeholder="e.g. Plot 12, Airport Residential Area, Accra, Ghana"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] text-[11px]">
                    Admin Console Master Password (Optional)
                  </label>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">Encrypted & masked</span>
                </div>
                <input
                  type="password"
                  value={deployPassword}
                  onChange={e => setDeployPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="new-password"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] tracking-widest focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!name.trim()}
                  className="w-full py-3 bg-[var(--theme-accent)] text-white text-xs font-bold uppercase tracking-wider hover:opacity-95 disabled:opacity-50 transition-opacity cursor-pointer shadow-md flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Deploy Isolated Storefront Workspace</span>
                </button>
              </div>
            </form>
          )}

          {activeTab === 'import' && (
            <form onSubmit={handleImportSubmit} className="space-y-4 text-xs">
              <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                Paste JSON exported from another workspace or company deployment. The system will create an isolated tenant instance with all products, categories, settings, and orders intact.
              </p>

              {importError && (
                <div className="p-3 bg-red-50 text-red-800 border border-red-300 font-semibold">
                  {importError}
                </div>
              )}

              {importSuccess && (
                <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-300 font-semibold">
                  {importSuccess}
                </div>
              )}

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  JSON Workspace Bundle
                </label>
                <textarea
                  rows={8}
                  required
                  value={importJson}
                  onChange={e => setImportJson(e.target.value)}
                  placeholder='{"company": {"name": "..."}, "settings": {...}, "products": [...]}'
                  className="w-full p-3 font-mono text-[11px] bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition-opacity cursor-pointer shadow-md flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>Import & Activate Client Workspace</span>
              </button>
            </form>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex items-center justify-between text-[11px] text-[var(--theme-text-muted)]">
          <div className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>Send client link with <strong>?company=slug</strong> to load their exclusive store.</span>
          </div>

          <button
            onClick={handleClose}
            className="px-4 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] font-semibold uppercase tracking-wider text-[var(--theme-text)] transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
