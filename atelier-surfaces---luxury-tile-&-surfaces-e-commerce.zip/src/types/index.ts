export type Currency = 'GHS' | 'USD' | 'EUR' | 'GBP';

export interface CompanyTenant {
  id: string; // unique slug e.g. 'atelier-surfaces', 'verona-stone'
  slug: string;
  name: string; // Brand name displayed across storefront & invoices
  tagline: string;
  industry: string;
  currency: Currency;
  currencySymbol: string;
  contactEmail: string;
  contactPhone: string;
  whatsAppNumber?: string;
  showroomAddress: string;
  ghanaPostGps?: string;
  activeThemeId?: string;
  adminPassword?: string;
  createdAt: string;
  isDefault?: boolean;
}

export interface ProductVariant {
  id: string;
  colorName: string;
  colorHex: string;
  sku: string;
  images: string[];
  price: number;
  compareAtPrice?: number;
  stock: number;
  lowStockThreshold: number;
  unit: 'm²' | 'box' | 'tile';
  boxCoverage: number; // e.g. 1.44 m² per box
  finish?: string;
  active: boolean;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription?: string;
  categoryId: string;
  categoryName: string;
  material: 'Porcelain' | 'Marble' | 'Natural Stone' | 'Ceramic' | 'Terrazzo' | 'Travertine' | 'Sintered Stone';
  size: string; // e.g. "60x120 cm", "80x80 cm", "120x240 cm"
  thickness: string; // e.g. "9 mm", "12 mm", "20 mm"
  finish: 'Polished' | 'Honed' | 'Matte' | 'Textured' | 'Bush-hammered';
  applications: string[]; // e.g. ["Floor", "Wall", "Interior", "Wet Areas", "Commercial"]
  specifications: {
    waterAbsorption?: string;
    slipResistance?: string; // e.g. "R10", "R11", "PTV 36+"
    frostResistant?: boolean;
    rectified?: boolean;
    shadeVariation?: 'V1 Uniform' | 'V2 Slight' | 'V3 Moderate' | 'V4 High';
    origin?: string;
  };
  featured: boolean;
  bestSeller?: boolean;
  newArrival?: boolean;
  active: boolean;
  variants: ProductVariant[];
  rating: number;
  reviewCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  imageUrl: string;
  sortOrder: number;
  active: boolean;
}

export interface CartItem {
  id: string; // unique item id (productId + '_' + variantId or productId + '_' + variantId + '_sample')
  productId: string;
  productName: string;
  productSlug: string;
  variantId: string;
  colorName: string;
  colorHex: string;
  image: string;
  sku: string;
  unitPrice: number;
  quantity: number;
  unit: 'm²' | 'box' | 'tile' | 'sample';
  boxCoverage: number;
  maxStock: number;
  isSample?: boolean;
  sampleDimensions?: string; // e.g. "4\" × 4\" (10 × 10 cm)"
}

export interface ShippingAddress {
  fullName: string;
  email: string;
  phone: string;
  addressLine1: string;
  city: string;
  region: string;
  ghanaPostGps?: string;
  deliveryNotes?: string;
}

export interface OrderItemSnapshot {
  productId: string;
  productName: string;
  productSlug: string;
  variantId: string;
  colorName: string;
  colorHex: string;
  image: string;
  sku: string;
  unitPrice: number;
  quantity: number;
  unit: string;
  lineTotal: number;
  isSample?: boolean;
  sampleDimensions?: string;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
export type PaymentStatus = 'pending' | 'paid' | 'verification_required' | 'failed' | 'refunded';
export type PaymentMethod = 'paystack' | 'bank_transfer' | 'cash_on_delivery' | 'ecomspine_secure_pay';

export interface TrackingEvent {
  title: string;
  description: string;
  timestamp: string;
  completed: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  guestEmail?: string;
  customerSnapshot: {
    name: string;
    email: string;
    phone: string;
  };
  itemsSnapshot: OrderItemSnapshot[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  discount: number;
  shippingCost: number;
  tax: number;
  total: number;
  currency: Currency;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  paymentReference?: string;
  paymentReceiptUrl?: string; // For manual bank transfer / MoMo receipts
  trackingNumber?: string;
  ecomspineWaybillNumber?: string;
  ecomspineSettlementId?: string;
  trackingTimeline: TrackingEvent[];
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ThemeTokens {
  bg: string;
  surface: string;
  surfaceSubtle: string;
  surfaceElevated: string;
  text: string;
  textMuted: string;
  primary: string;
  primaryContrast: string;
  secondary: string;
  accent: string;
  accentHover: string;
  accentContrast: string;
  border: string;
  borderSubtle: string;
  inputBg: string;
  navBg: string;
  sidebarBg: string;
  sidebarText: string;
  sidebarMuted: string;
  sidebarBorder: string;
  sidebarActive: string;
  success: string;
  warning: string;
  danger: string;
}

export interface ThemePreset {
  id: string;
  name: string;
  family: string;
  description: string;
  category: 'Luxury' | 'Architectural' | 'Natural' | 'Minimal' | 'Rich' | 'Monochrome';
  tokens: ThemeTokens;
  appearanceMode: 'light' | 'dark';
  isBuiltIn: boolean;
}

export type ActionType = 'view' | 'create' | 'edit' | 'delete' | 'approve' | 'export' | 'manage_settings' | 'publish';

export type ModuleKey = 
  | 'dashboard'
  | 'products'
  | 'product_variations'
  | 'categories'
  | 'inventory'
  | 'stock_adjustments'
  | 'suppliers'
  | 'purchases'
  | 'orders'
  | 'customers'
  | 'discounts'
  | 'payments'
  | 'refunds'
  | 'reports'
  | 'store_settings'
  | 'theme_management'
  | 'user_management'
  | 'role_management'
  | 'permission_management'
  | 'audit_logs';

export interface ModuleDefinition {
  key: ModuleKey;
  label: string;
  category: 'Core' | 'Catalog & Stock' | 'Sales & Fulfillment' | 'Administration';
  supportedActions: ActionType[];
}

export interface UserRole {
  id: string;
  name: string;
  description: string;
  builtIn: boolean;
  permissions: Record<ModuleKey, ActionType[]>;
  createdAt: string;
  updatedAt: string;
}

export interface AppUser {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  roleId: string;
  roleName: string;
  active: boolean;
  createdAt: string;
  lastLogin?: string;
}

export interface AuditLog {
  id: string;
  actorUid: string;
  actorName: string;
  actorRole: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  safeChangeSummary: string;
  timestamp: string;
}

export interface StoreSettings {
  brandName: string;
  tagline: string;
  activeThemeId: string;
  defaultThemeId: string;
  currency: Currency;
  currencySymbol: string;
  taxRatePercent: number; // e.g. 15%
  freeDeliveryThreshold: number; // e.g. 5000 GHS
  standardDeliveryCost: number; // e.g. 250 GHS
  expressFreightCost: number; // e.g. 550 GHS
  announcementText: string;
  announcementEnabled: boolean;
  contactEmail: string;
  contactPhone: string;
  whatsAppNumber?: string;
  whatsAppPrefill?: string;
  whatsAppLocked?: boolean;
  showroomAddress: string;
  ghanaPostGps: string;
  // Contact info lock state
  contactLocked?: boolean;
  contactLastSavedBy?: string;
  // Face-to-Face Video Consultation Settings & Locks
  videoConsultationLocked?: boolean;
  videoLockMessage?: string;
  videoConsultantName?: string;
  videoConsultantTitle?: string;
  videoConsultantLocation?: string;
  videoConsultantAvailable?: boolean;
  videoConsultantHours?: string;
  videoResolution?: '1080p' | '720p';
  allowGuestVideoCalls?: boolean;
  default3DSpecimenPreset?: string;
  // Panel Brightness & POS Configuration
  panelBrightness?: PanelBrightnessConfig;
  posSettings?: POSSettings;
}

export interface PanelBrightnessConfig {
  // Admin Console Panels
  sidebarBrightness: number; // 50 to 150 (percentage, default 100)
  sidebarContrast: number;   // 80 to 125 (percentage, default 100)
  headerBrightness: number;  // 50 to 150
  headerContrast: number;
  workspaceBrightness: number; // 50 to 150
  workspaceContrast: number;
  cardsBrightness: number;   // 50 to 150
  cardsContrast: number;
  posBrightness: number;     // 50 to 150
  posContrast: number;

  // Public Storefront Panels
  storefrontHeaderBrightness: number;   // 50 to 150 (Storefront Nav & Announcement Bar)
  storefrontHeaderContrast: number;     // 80 to 125
  storefrontHeroBrightness: number;     // 50 to 150 (Hero Billboard & Architectural Showcase)
  storefrontHeroContrast: number;       // 80 to 125
  storefrontCatalogBrightness: number;  // 50 to 150 (Product Collections & Slabs Gallery Grid)
  storefrontCatalogContrast: number;    // 80 to 125
  storefrontSpecimenBrightness: number; // 50 to 150 (Slab Specimen Zoom & Detail Inspection Canvas)
  storefrontSpecimenContrast: number;   // 80 to 125
  storefrontFooterBrightness: number;   // 50 to 150 (Public Footer, Showroom Depot & Contact Deck)
  storefrontFooterContrast: number;     // 80 to 125

  isLocked: boolean;         // Locked by admin
  lockedBy?: string;
  lockedAt?: string;
}

export interface POSPaymentMethodOptions {
  cash: boolean;
  card: boolean;
  mobileMoney: boolean;
  bankTransfer: boolean;
  cheque: boolean;
  split: boolean;
}

export interface POSSettings {
  registerName: string;
  registerCode: string;
  defaultCashierName: string;
  walkInCustomerName: string;
  taxCalculationMode: 'inclusive' | 'exclusive';
  taxRatePercent: number;
  allowNegativeInventory: boolean;
  autoDeductInventory: boolean;
  maxCashierDiscountPercent: number;
  requireSupervisorDiscountPin: boolean;
  supervisorPin: string;
  quickDiscountPresets: number[];
  barcodeContinuousScan: boolean;
  cashDrawerAutoKick: boolean;
  playNotificationSound: boolean;
  receiptPrinterWidth: '80mm' | '58mm';
  receiptShowLogo: boolean;
  receiptShowBarcode: boolean;
  receiptShowGps: boolean;
  receiptHeaderNote: string;
  receiptFooterNote: string;
  enabledPaymentMethods: POSPaymentMethodOptions;
  momoMerchantNumber: string;
  offlineModeEnabled: boolean;
  quickCashDenominations: number[];
  showroomAddress?: string;
  ghanaPostGps?: string;
  contactPhone?: string;
  contactEmail?: string;
  whatsAppNumber?: string;
  isLocked: boolean;
  lockedBy?: string;
  lockedAt?: string;
}

export interface POSTransaction {
  id: string;
  transactionNumber: string;
  timestamp: string;
  cashierName: string;
  customerName: string;
  customerPhone?: string;
  items: {
    productId: string;
    productName: string;
    variantId: string;
    colorName: string;
    sku: string;
    unitPrice: number;
    quantity: number;
    unit: string;
    lineTotal: number;
  }[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  taxAmount: number;
  total: number;
  paymentMethod: 'cash' | 'card' | 'momo' | 'split' | 'bank_transfer';
  paymentDetails: {
    cashReceived?: number;
    changeGiven?: number;
    cardLast4?: string;
    momoPhone?: string;
    momoRef?: string;
    splitBreakdown?: {
      cash?: number;
      card?: number;
      momo?: number;
    };
  };
  synced: boolean;
}

export interface ConsultationRoom {
  id: string;
  name: string;
  createdAt: string;
  isLocked: boolean;
  clientName?: string;
  clientRole?: string;
  consultantName?: string;
  scheduledTime?: string;
  activeParticipantsCount?: number;
  presentingSlab?: any;
}

export interface StockAdjustment {
  id: string;
  productId: string;
  productName: string;
  variantId: string;
  colorName: string;
  previousStock: number;
  newStock: number;
  adjustment: number;
  reason: 'Received shipment' | 'Damaged in transit' | 'Sample allocated' | 'Cycle count' | 'Customer return' | 'POS Sale';
  actorName: string;
  timestamp: string;
}

export interface DiscountCode {
  id: string;
  code: string;
  discountPercent: number;
  description: string;
  minSpend: number;
  active: boolean;
}

export interface BulkPricingTier {
  id: string;
  minQuantitySqm: number;          // e.g. 50 m²
  maxQuantitySqm?: number | null;  // e.g. 99.99 m² or null for unlimited
  discountType: 'percentage' | 'fixed_price';
  discountValue: number;           // percentage (e.g. 10 for 10%) or fixed price per m² (e.g. 320 for GH₵320/m²)
  tierLabel: string;               // e.g. "Builder Tier 1 (50-99 m²)"
}

export interface BulkPricingRule {
  id: string;
  name: string;                    // e.g. "Commercial Slab Volume Incentive"
  collectionId: string;            // category id (e.g. 'marble-look', 'floor-tiles') or 'all'
  collectionName: string;          // e.g. "Marble-Look Tiles" or "All Tile Collections"
  tiers: BulkPricingTier[];
  active: boolean;
  isLocked?: boolean;
  lockedBy?: string;
  lockedAt?: string;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppliedBulkDiscount {
  ruleId: string;
  ruleName: string;
  collectionId: string;
  collectionName: string;
  tierId: string;
  tierLabel: string;
  qualifyingSqm: number;
  discountType: 'percentage' | 'fixed_price';
  discountValue: number;
  discountAmount: number;
  originalSubtotal: number;
  effectivePricePerSqm?: number;
}

export type BroadcastAudience = 'all' | 'staff' | 'customers';
export type BroadcastUrgency = 'critical' | 'warning' | 'info' | 'success';
export type BroadcastPlacement = 'top_banner' | 'modal' | 'toast';

export interface AdminBroadcast {
  id: string;
  tenantId?: string;
  title: string;
  message: string;
  audience: BroadcastAudience;       // 'all' | 'staff' | 'customers'
  urgency: BroadcastUrgency;         // 'critical' | 'warning' | 'info' | 'success'
  placement: BroadcastPlacement;     // 'top_banner' | 'modal' | 'toast'
  actionLabel?: string;             // e.g. "View Inventory Allocations", "Read Advisory"
  actionUrl?: string;               // e.g. "/admin/inventory", "/shop"
  active: boolean;                  // whether broadcast is actively shown
  isLocked: boolean;                // locked against editing/dismissal without admin auth
  lockedBy?: string;
  lockedAt?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  dismissible: boolean;             // whether users can dismiss (if locked, dismiss is disabled)
  dismissedBy?: string[];           // array of user identifiers who dismissed
  soundAlert?: boolean;             // play audio chime for urgent alerts
  scheduledExpiry?: string;         // optional ISO date
}

