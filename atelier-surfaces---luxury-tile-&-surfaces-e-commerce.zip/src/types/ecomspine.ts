export interface EcomSpineConfig {
  enabled: boolean;
  merchantId: string;
  publishableKey: string;
  liveSecretKey: string;
  // Direct Bank & MasterCard Settlement
  settlementBankName: string;
  settlementAccountName: string;
  settlementAccountNumber: string;
  settlementBranch: string;
  settlementSwiftCode: string;
  linkedMastercardNumber: string; // e.g. "5399 •••• •••• 8492"
  linkedMastercardHolder: string;
  linkedMastercardExpiry: string;
  linkedMastercardBrand: 'mastercard';
  settlementCadence: 'instant' | 'daily_t1';
  // Anti-Theft & FraudShield System
  fraudShieldLevel: 'maximum' | 'standard' | 'strict';
  require3DSecure: boolean;
  zeroTheftGuarantee: boolean;
  blockSuspiciousIps: boolean;
  payoutAutoLock: boolean;
  // Fleet & Logistics Engine
  enableGpsTracking: boolean;
  enableSmsDispatchAlerts: boolean;
  defaultFleetVehicle: string;
  logisticsHubName: string;
  isLocked: boolean;
  lockedBy?: string;
  lockedAt?: string;
}

export type EcomSpineMilestone = 
  | 'crated_at_hub'
  | 'tailgate_loaded'
  | 'in_transit'
  | 'arrived_on_site'
  | 'tailgate_offload'
  | 'client_inspected_and_delivered';

export interface EcomSpineWaypoint {
  id: string;
  status: EcomSpineMilestone;
  title: string;
  location: string;
  description: string;
  timestamp: string;
  completed: boolean;
  gpsCoordinates?: string;
}

export interface EcomSpineWaybill {
  id: string;
  waybillNumber: string; // e.g. ESP-GH-849102
  orderId: string;
  orderNumber: string;
  createdAt: string;
  clientName: string;
  clientPhone: string;
  destinationAddress: string;
  destinationCity: string;
  destinationGps: string;
  vehicleType: 'Heavy Hydraulic Tailgate (10-Wheel)' | 'Flatbed Hiab Crane Truck' | 'Secure Architectural Van';
  vehiclePlate: string;
  driverName: string;
  driverPhone: string;
  currentMilestone: EcomSpineMilestone;
  estimatedDeliveryTime: string;
  verificationPin: string; // 4-digit code provided to buyer upon delivery
  waypoints: EcomSpineWaypoint[];
  packageDetails: {
    totalPallets: number;
    totalWeightKg: number;
    specimensCount: number;
    fragileFlag: boolean;
  };
}

export interface EcomSpineSettlement {
  id: string;
  settlementNumber: string; // e.g. ESP-SET-9812
  orderId: string;
  orderNumber: string;
  grossAmount: number;
  feeAmount: number;
  netAmount: number;
  currency: string;
  cardBrand: 'mastercard' | 'visa';
  cardLast4: string;
  cardholderName: string;
  settledToBank: string;
  settledToAccountNumber: string;
  settledToMastercard: string;
  status: 'settled' | 'clearing' | 'flagged';
  antiTheftScore: number; // 0 - 100 (99+ is pristine)
  fraudShieldChecks: {
    threeDSecurePassed: boolean;
    avsAddressVerified: boolean;
    cvvMatched: boolean;
    zeroTheftSignature: string;
  };
  settledAt: string;
}
