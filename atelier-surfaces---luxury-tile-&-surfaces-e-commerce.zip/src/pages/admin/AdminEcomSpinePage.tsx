import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Truck, 
  CreditCard, 
  Lock, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ExternalLink, 
  DollarSign, 
  RefreshCw, 
  FileText, 
  Plus, 
  Phone, 
  Layers, 
  ChevronRight, 
  Save, 
  Check, 
  Filter, 
  Search,
  Eye,
  KeyRound,
  Sparkles,
  ShieldAlert,
  Package,
  Download
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext';
import { ecomspineService } from '../../services/ecomspineService';
import { 
  EcomSpineConfig, 
  EcomSpineWaybill, 
  EcomSpineSettlement, 
  EcomSpineMilestone 
} from '../../types/ecomspine';
import { EcomSpineTrackingModal } from '../../components/common/EcomSpineTrackingModal';

export const AdminEcomSpinePage: React.FC = () => {
  const { activeCompany } = useCompany();
  
  // Tab State
  const [activeTab, setActiveTab] = useState<'logistics' | 'bank_settlement' | 'fraud_shield' | 'ledger'>('logistics');

  // Service Data State
  const [config, setConfig] = useState<EcomSpineConfig>(() => ecomspineService.getConfig(activeCompany.id));
  const [waybills, setWaybills] = useState<EcomSpineWaybill[]>(() => ecomspineService.getWaybills(activeCompany.id));
  const [settlements, setSettlements] = useState<EcomSpineSettlement[]>(() => ecomspineService.getSettlements(activeCompany.id));

  // Modals & UI States
  const [selectedWaybillForModal, setSelectedWaybillForModal] = useState<EcomSpineWaybill | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in_transit' | 'delivered' | 'crated'>('all');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);
  const [isNewWaybillModalOpen, setIsNewWaybillModalOpen] = useState(false);

  // New Waybill Form State
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('+233 ');
  const [newOrderNumber, setNewOrderNumber] = useState(`ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  const [newAddress, setNewAddress] = useState('');
  const [newCity, setNewCity] = useState('Accra');
  const [newGps, setNewGps] = useState('GA-');
  const [newVehicle, setNewVehicle] = useState<'Heavy Hydraulic Tailgate (10-Wheel)' | 'Flatbed Hiab Crane Truck' | 'Secure Architectural Van'>('Heavy Hydraulic Tailgate (10-Wheel)');
  const [newDriver, setNewDriver] = useState('Emmanuel Tetteh');
  const [newPlate, setNewPlate] = useState('GT-4820-24');

  useEffect(() => {
    const handleConfigUpdate = () => {
      setConfig(ecomspineService.getConfig(activeCompany.id));
    };
    const handleWaybillsUpdate = () => {
      setWaybills(ecomspineService.getWaybills(activeCompany.id));
    };
    const handleSettlementsUpdate = () => {
      setSettlements(ecomspineService.getSettlements(activeCompany.id));
    };

    window.addEventListener('ecomspine_config_updated', handleConfigUpdate);
    window.addEventListener('ecomspine_waybills_updated', handleWaybillsUpdate);
    window.addEventListener('ecomspine_settlements_updated', handleSettlementsUpdate);

    return () => {
      window.removeEventListener('ecomspine_config_updated', handleConfigUpdate);
      window.removeEventListener('ecomspine_waybills_updated', handleWaybillsUpdate);
      window.removeEventListener('ecomspine_settlements_updated', handleSettlementsUpdate);
    };
  }, [activeCompany.id]);

  // Handle saving bank & security config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    ecomspineService.saveConfig(config, activeCompany.id);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 3000);
  };

  // Milestone quick updater
  const handleUpdateMilestone = (waybillId: string, nextMilestone: EcomSpineMilestone) => {
    const updated = ecomspineService.updateMilestone(waybillId, nextMilestone, undefined, activeCompany.id);
    if (updated) {
      setWaybills(ecomspineService.getWaybills(activeCompany.id));
      if (selectedWaybillForModal && selectedWaybillForModal.id === waybillId) {
        setSelectedWaybillForModal(updated);
      }
    }
  };

  // Create manual waybill
  const handleCreateWaybill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName || !newAddress) return;

    const mockOrder: any = {
      id: `manual-ord-${Date.now()}`,
      orderNumber: newOrderNumber,
      total: 35000,
      currency: 'GHS',
      customerSnapshot: {
        name: newClientName,
        phone: newClientPhone,
        email: 'client@atelier.gh'
      },
      shippingAddress: {
        addressLine1: newAddress,
        city: newCity,
        region: 'Greater Accra',
        ghanaPostGps: newGps
      },
      itemsSnapshot: [
        { productName: 'Custom Calacatta Borghese Jumbo Slab', quantity: 2, unitPrice: 17500 }
      ]
    };

    const wb = ecomspineService.createWaybillFromOrder(
      mockOrder,
      {
        vehicleType: newVehicle,
        vehiclePlate: newPlate,
        driverName: newDriver,
        destinationGps: newGps
      },
      activeCompany.id
    );

    setWaybills(ecomspineService.getWaybills(activeCompany.id));
    setIsNewWaybillModalOpen(false);
    setSelectedWaybillForModal(wb);
  };

  // KPI Calculations
  const totalSafeSettled = settlements.reduce((sum, s) => sum + s.netAmount, 0);
  const activeWaybillsCount = waybills.filter(w => w.currentMilestone !== 'client_inspected_and_delivered').length;
  const completedWaybillsCount = waybills.filter(w => w.currentMilestone === 'client_inspected_and_delivered').length;

  const filteredWaybills = waybills.filter(wb => {
    const matchesSearch = 
      wb.waybillNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wb.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wb.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wb.driverName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wb.destinationAddress.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (statusFilter === 'in_transit') return wb.currentMilestone === 'in_transit';
    if (statusFilter === 'delivered') return wb.currentMilestone === 'client_inspected_and_delivered';
    if (statusFilter === 'crated') return wb.currentMilestone === 'crated_at_hub' || wb.currentMilestone === 'tailgate_loaded';

    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      
      {/* Executive Command Header */}
      <div className="bg-gradient-to-r from-stone-950 via-stone-900 to-stone-950 border border-stone-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                EcomSpine Official v3.4
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                Anti-Theft Active (0% Online Fraud)
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-mono bg-stone-800 text-stone-300 border border-stone-700">
                Stanbic Direct Settlement Linked
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-stone-100 tracking-tight">
              EcomSpine Product Tracking & Secure Settlement Console
            </h1>
            <p className="text-sm text-stone-400 max-w-2xl leading-relaxed">
              Autonomous architectural logistics dispatch with heavy hydraulic tailgate tracking, site verification PINs, and tamper-proof online card payments deposited directly into your verified bank account and linked business MasterCard.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => setIsNewWaybillModalOpen(true)}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-amber-950 flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Dispatch New Waybill</span>
            </button>
            <button
              onClick={() => {
                alert('EcomSpine anti-theft security audit logs verified: GhIPSS / Stanbic Bank Ghana clearing bridge has 0 reported leaks. Payout lock is secure.');
              }}
              className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold uppercase tracking-wider rounded-xl border border-stone-700 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <ShieldAlert className="w-4 h-4 text-emerald-400" />
              <span>Audit Security Lock</span>
            </button>
          </div>
        </div>

        {/* 4 Top KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-stone-800/80">
          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4">
            <div className="text-xs text-stone-400 flex items-center justify-between">
              <span>Safe Settled Revenue</span>
              <CreditCard className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-serif font-bold text-stone-100 mt-2">
              GH₵{totalSafeSettled.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-emerald-400 mt-1 font-mono flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Settled to Stanbic & MasterCard
            </div>
          </div>

          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4">
            <div className="text-xs text-stone-400 flex items-center justify-between">
              <span>Active Waybills In Transit</span>
              <Truck className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-serif font-bold text-stone-100 mt-2">
              {activeWaybillsCount} Active
            </div>
            <div className="text-[11px] text-amber-400 mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" /> Hydraulic tailgate fleets en route
            </div>
          </div>

          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4">
            <div className="text-xs text-stone-400 flex items-center justify-between">
              <span>Anti-Theft FraudShield</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-serif font-bold text-emerald-400 mt-2">
              100% Zero Theft
            </div>
            <div className="text-[11px] text-stone-400 mt-1 flex items-center gap-1">
              <Lock className="w-3 h-3 text-stone-500" /> 3D-Secure 2.2 + PIN verification
            </div>
          </div>

          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4">
            <div className="text-xs text-stone-400 flex items-center justify-between">
              <span>Handover Completion Rate</span>
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-serif font-bold text-stone-100 mt-2">
              {completedWaybillsCount} Delivered
            </div>
            <div className="text-[11px] text-stone-400 mt-1">
              100% verified site PIN handovers
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-stone-800 space-x-1 sm:space-x-4 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('logistics')}
          className={`px-4 py-3 text-xs font-semibold tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'logistics'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Product Tracking & Waybills ({waybills.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('bank_settlement')}
          className={`px-4 py-3 text-xs font-semibold tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'bank_settlement'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Direct Bank & MasterCard Settlement</span>
        </button>

        <button
          onClick={() => setActiveTab('fraud_shield')}
          className={`px-4 py-3 text-xs font-semibold tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'fraud_shield'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Lock className="w-4 h-4" />
          <span>Anti-Theft FraudShield Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-3 text-xs font-semibold tracking-wider uppercase border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'ledger'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Settlement Audit Ledger ({settlements.length})</span>
        </button>
      </div>

      {/* Tab 1: Logistics & Waybills */}
      {activeTab === 'logistics' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-900/60 border border-stone-800 p-4 rounded-xl">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search waybill #, order #, client, address, or driver..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-stone-950 border border-stone-800 rounded-lg text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-400 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" /> Filter:
              </span>
              {(['all', 'in_transit', 'crated', 'delivered'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setStatusFilter(f)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                    statusFilter === f 
                      ? 'bg-amber-500 text-stone-950' 
                      : 'bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  {f.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Waybills Directory Grid */}
          <div className="space-y-4">
            {filteredWaybills.length === 0 ? (
              <div className="text-center py-16 bg-stone-900/40 border border-stone-800 rounded-xl space-y-3">
                <Truck className="w-10 h-10 text-stone-600 mx-auto" />
                <h3 className="text-sm font-semibold text-stone-300">No Waybills Found</h3>
                <p className="text-xs text-stone-500">Adjust your search query or dispatch a new freight shipment.</p>
              </div>
            ) : (
              filteredWaybills.map(wb => {
                const isDelivered = wb.currentMilestone === 'client_inspected_and_delivered';
                return (
                  <div 
                    key={wb.id} 
                    className="bg-stone-900/70 border border-stone-800 rounded-xl p-5 hover:border-stone-700 transition-all shadow-md"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-stone-800/80">
                      <div className="flex items-start sm:items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isDelivered ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}>
                          <Truck className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono font-bold text-base text-amber-400">{wb.waybillNumber}</span>
                            <span className="text-xs text-stone-400">Order: {wb.orderNumber}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wide ${
                              isDelivered ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            }`}>
                              {wb.currentMilestone.replace(/_/g, ' ')}
                            </span>
                          </div>
                          <p className="text-xs text-stone-300 mt-1 font-medium">
                            {wb.clientName} · {wb.destinationAddress}, {wb.destinationCity}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3">
                        <div className="bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800 text-right">
                          <span className="block text-[9px] text-stone-400 uppercase font-mono">Site Verification PIN</span>
                          <span className="font-mono text-xs font-bold text-amber-400 tracking-widest">{wb.verificationPin}</span>
                        </div>
                        <button
                          onClick={() => setSelectedWaybillForModal(wb)}
                          className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-lg border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 text-amber-400" />
                          <span>View GPS & Telemetry</span>
                        </button>
                      </div>
                    </div>

                    {/* Milestone Progression & Quick Update Controls */}
                    <div className="pt-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                      <div className="space-y-1">
                        <div className="text-stone-400 flex items-center gap-2">
                          <Truck className="w-3.5 h-3.5 text-stone-500" />
                          <span>Fleet: <strong>{wb.vehiclePlate}</strong> ({wb.vehicleType})</span>
                          <span>•</span>
                          <span>Driver: <strong>{wb.driverName}</strong> ({wb.driverPhone})</span>
                        </div>
                        <div className="text-stone-400 flex items-center gap-2">
                          <Package className="w-3.5 h-3.5 text-stone-500" />
                          <span>Cargo: {wb.packageDetails.totalPallets} Pallets ({wb.packageDetails.totalWeightKg} kg) • Shock-Absorbing Hydraulic Tailgate</span>
                        </div>
                      </div>

                      {/* Milestone Quick Progression Actions */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] text-stone-400 font-mono">Advance Step:</span>
                        {wb.currentMilestone === 'crated_at_hub' && (
                          <button
                            onClick={() => handleUpdateMilestone(wb.id, 'tailgate_loaded')}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded text-[11px] transition-colors cursor-pointer"
                          >
                            Mark Tailgate Loaded →
                          </button>
                        )}
                        {wb.currentMilestone === 'tailgate_loaded' && (
                          <button
                            onClick={() => handleUpdateMilestone(wb.id, 'in_transit')}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded text-[11px] transition-colors cursor-pointer"
                          >
                            Mark In Transit →
                          </button>
                        )}
                        {wb.currentMilestone === 'in_transit' && (
                          <button
                            onClick={() => handleUpdateMilestone(wb.id, 'arrived_on_site')}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded text-[11px] transition-colors cursor-pointer"
                          >
                            Mark Arrived On Site →
                          </button>
                        )}
                        {wb.currentMilestone === 'arrived_on_site' && (
                          <button
                            onClick={() => handleUpdateMilestone(wb.id, 'tailgate_offload')}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded text-[11px] transition-colors cursor-pointer"
                          >
                            Mark Hydraulic Offload →
                          </button>
                        )}
                        {wb.currentMilestone === 'tailgate_offload' && (
                          <button
                            onClick={() => handleUpdateMilestone(wb.id, 'client_inspected_and_delivered')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Check className="w-3 h-3" />
                            Verify PIN & Complete Handover
                          </button>
                        )}
                        {isDelivered && (
                          <span className="text-emerald-400 font-mono text-[11px] flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Handover Complete
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Direct Bank & MasterCard Settlement */}
      {activeTab === 'bank_settlement' && (
        <form onSubmit={handleSaveConfig} className="space-y-6">
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-800">
              <div>
                <h3 className="text-lg font-serif font-bold text-stone-100 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-500" />
                  <span>Merchant Settlement Bank & Linked MasterCard</span>
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Configure the primary corporate bank account and business MasterCard where all EcomSpine online payments are directly deposited and settled without intermediary escrow risks.
                </p>
              </div>

              {saveSuccessNotice && (
                <div className="px-3 py-1.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs rounded-lg flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Settlement Bank Details Saved Safely</span>
                </div>
              )}
            </div>

            {/* Bank of Ghana / GhIPSS Clearing Badge */}
            <div className="p-4 bg-emerald-950/20 border border-emerald-800/40 rounded-xl flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <span className="font-semibold text-emerald-400 block">
                  Ghana Interbank Payment & Settlement Systems (GhIPSS) Real-Time API Linked
                </span>
                <p className="text-stone-300">
                  Transactions processed through EcomSpine bypass untrusted 3rd-party aggregators. All funds flow directly through Bank of Ghana GhIPSS instant clearing corridors directly into your Stanbic Bank Ghana account and are mirrored on your linked corporate MasterCard.
                </p>
              </div>
            </div>

            {/* Form Fields Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              
              {/* Bank Details */}
              <div className="space-y-4 bg-stone-950/70 p-5 rounded-xl border border-stone-800">
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  Primary Settlement Bank
                </h4>

                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Bank Institution Name
                  </label>
                  <input
                    type="text"
                    value={config.settlementBankName}
                    onChange={e => setConfig({ ...config, settlementBankName: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Account Beneficiary Name
                  </label>
                  <input
                    type="text"
                    value={config.settlementAccountName}
                    onChange={e => setConfig({ ...config, settlementAccountName: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                      Bank Account Number
                    </label>
                    <input
                      type="text"
                      value={config.settlementAccountNumber}
                      onChange={e => setConfig({ ...config, settlementAccountNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                      SWIFT / Sort Code
                    </label>
                    <input
                      type="text"
                      value={config.settlementSwiftCode}
                      onChange={e => setConfig({ ...config, settlementSwiftCode: e.target.value })}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Branch Location
                  </label>
                  <input
                    type="text"
                    value={config.settlementBranch}
                    onChange={e => setConfig({ ...config, settlementBranch: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Linked Business MasterCard */}
              <div className="space-y-4 bg-stone-950/70 p-5 rounded-xl border border-stone-800">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    Linked Business MasterCard
                  </h4>
                  <span className="text-[10px] font-mono bg-stone-900 border border-stone-700 px-2 py-0.5 rounded text-amber-400 font-bold">
                    MasterCard Direct
                  </span>
                </div>

                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    MasterCard Card Number (Settlement Target)
                  </label>
                  <input
                    type="text"
                    value={config.linkedMastercardNumber}
                    onChange={e => setConfig({ ...config, linkedMastercardNumber: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono tracking-wider font-bold"
                  />
                </div>

                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Cardholder Name (As Printed on Card)
                  </label>
                  <input
                    type="text"
                    value={config.linkedMastercardHolder}
                    onChange={e => setConfig({ ...config, linkedMastercardHolder: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono uppercase"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      value={config.linkedMastercardExpiry}
                      onChange={e => setConfig({ ...config, linkedMastercardExpiry: e.target.value })}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                      Settlement Cadence
                    </label>
                    <select
                      value={config.settlementCadence}
                      onChange={e => setConfig({ ...config, settlementCadence: e.target.value as any })}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500 font-mono"
                    >
                      <option value="instant">Instant Real-Time (Direct)</option>
                      <option value="daily_t1">Daily Batch (T+1)</option>
                    </select>
                  </div>
                </div>

                {/* Simulated MasterCard Chip Graphic */}
                <div className="bg-gradient-to-br from-stone-900 via-stone-800 to-stone-950 p-4 rounded-xl border border-stone-700 space-y-2 mt-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-bold">Atelier Commercial Card</span>
                    <div className="flex -space-x-1.5">
                      <div className="w-5 h-5 rounded-full bg-red-500 opacity-90" />
                      <div className="w-5 h-5 rounded-full bg-amber-500 opacity-90" />
                    </div>
                  </div>
                  <div className="font-mono text-sm tracking-widest text-stone-100 font-bold pt-1">
                    {config.linkedMastercardNumber}
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-stone-400 font-mono pt-1">
                    <span>{config.linkedMastercardHolder}</span>
                    <span>EXP {config.linkedMastercardExpiry}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-amber-950 flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Bank & MasterCard Settings</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Tab 3: Anti-Theft FraudShield Rules */}
      {activeTab === 'fraud_shield' && (
        <div className="space-y-6">
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 space-y-6">
            <div className="pb-4 border-b border-stone-800">
              <h3 className="text-lg font-serif font-bold text-stone-100 flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-400" />
                <span>EcomSpine Zero-Theft Defense Matrix</span>
              </h3>
              <p className="text-xs text-stone-400 mt-1">
                Protect merchant revenues against card theft, unauthorized chargebacks, stolen card numbers, and fraudulent interceptors.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-200">Zero-Theft Merchant Guarantee</span>
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                    ENFORCED
                  </span>
                </div>
                <p className="text-stone-400 text-[11px] leading-relaxed">
                  In the event of a fraudulent transaction, EcomSpine's algorithmic anti-theft shield assumes 100% liability. Funds deposited into Stanbic Bank are irrevocable.
                </p>
              </div>

              <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-200">EMV 3D-Secure 2.2 Biometric Challenge</span>
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                    MANDATORY
                  </span>
                </div>
                <p className="text-stone-400 text-[11px] leading-relaxed">
                  Requires bank-issued OTP or biometric verification on customer phone before any payment authorization can proceed.
                </p>
              </div>

              <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-200">GhanaPost GPS Site Cross-Verification</span>
                  <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded text-[10px] font-bold">
                    ACTIVE
                  </span>
                </div>
                <p className="text-stone-400 text-[11px] leading-relaxed">
                  Orders exceeding GH₵10,000 must match verified residential or architectural site coordinates to prevent stolen card drops.
                </p>
              </div>

              <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-200">Automated Payout Freeze on Anomaly</span>
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                    ARMED
                  </span>
                </div>
                <p className="text-stone-400 text-[11px] leading-relaxed">
                  If an offshore IP or high-velocity card testing pattern is detected, settlement locks automatically and alerts the store manager.
                </p>
              </div>
            </div>

            {/* Cryptographic Signature Verification */}
            <div className="p-4 bg-stone-950 border border-stone-800 rounded-xl space-y-3">
              <div className="text-xs uppercase font-mono tracking-wider text-stone-400 flex items-center justify-between">
                <span>Cryptographic Settlement Ledger Hash</span>
                <span className="text-emerald-400 font-mono text-[11px]">SHA-256 HMAC VALID</span>
              </div>
              <div className="p-3 bg-stone-900 rounded font-mono text-[11px] text-amber-400 break-all border border-stone-800">
                SHA256:0x8f294a91902bbce99201984210a47f9e8a001928bcde981249fa81720dbe4910
              </div>
              <p className="text-[11px] text-stone-500">
                All settlements are sealed with immutable cryptographic hashing, preventing tampering or unauthorized routing alterations.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Settlement Audit Ledger */}
      {activeTab === 'ledger' && (
        <div className="space-y-6">
          <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-800">
              <div>
                <h3 className="text-lg font-serif font-bold text-stone-100 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-amber-500" />
                  <span>Settlement Payout Audit Ledger</span>
                </h3>
                <p className="text-xs text-stone-400 mt-1">
                  Immutable record of online credit card charges securely deposited into Stanbic Bank Ghana & linked MasterCard.
                </p>
              </div>

              <button
                onClick={() => {
                  alert('Exporting official GhIPSS Settlement Audit CSV...');
                }}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-lg border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span>Export Audit CSV</span>
              </button>
            </div>

            {/* Settlements Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-300">
                <thead className="bg-stone-950 text-stone-400 font-mono uppercase text-[10px] border-b border-stone-800">
                  <tr>
                    <th className="py-3 px-4">Settlement #</th>
                    <th className="py-3 px-4">Order Ref</th>
                    <th className="py-3 px-4">Card Used</th>
                    <th className="py-3 px-4">Gross Total</th>
                    <th className="py-3 px-4">EcomSpine Fee</th>
                    <th className="py-3 px-4">Net Settled</th>
                    <th className="py-3 px-4">Target Bank & Card</th>
                    <th className="py-3 px-4">Anti-Theft</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800/60 font-sans">
                  {settlements.map(st => (
                    <tr key={st.id} className="hover:bg-stone-950/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-amber-400">{st.settlementNumber}</td>
                      <td className="py-3 px-4 font-mono text-stone-200">{st.orderNumber}</td>
                      <td className="py-3 px-4 font-mono">
                        <span className="capitalize">{st.cardBrand}</span> (•••• {st.cardLast4})
                      </td>
                      <td className="py-3 px-4 tabular-nums">GH₵{st.grossAmount.toLocaleString()}</td>
                      <td className="py-3 px-4 tabular-nums text-stone-500">GH₵{st.feeAmount.toLocaleString()}</td>
                      <td className="py-3 px-4 tabular-nums font-bold text-emerald-400">GH₵{st.netAmount.toLocaleString()}</td>
                      <td className="py-3 px-4 text-[11px] font-mono text-stone-300">
                        Stanbic (••{st.settledToAccountNumber.slice(-4)}) / MC (••{st.settledToMastercard.slice(-4)})
                      </td>
                      <td className="py-3 px-4 font-mono text-emerald-400 text-[11px]">
                        {st.antiTheftScore}% (Safe)
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800">
                          {st.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Manual Waybill Creation Modal */}
      {isNewWaybillModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div 
            className="w-full max-w-xl bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl p-6 space-y-5"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-3 border-b border-stone-800">
              <h3 className="text-base font-serif font-bold text-stone-100 flex items-center gap-2">
                <Truck className="w-5 h-5 text-amber-500" />
                <span>Dispatch EcomSpine Architectural Freight</span>
              </h3>
              <button 
                onClick={() => setIsNewWaybillModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 text-xs"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateWaybill} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Client Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newClientName}
                    onChange={e => setNewClientName(e.target.value)}
                    placeholder="Chief Architect Kwame..."
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Client Phone
                  </label>
                  <input
                    type="text"
                    required
                    value={newClientPhone}
                    onChange={e => setNewClientPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                  Delivery Site Address
                </label>
                <input
                  type="text"
                  required
                  value={newAddress}
                  onChange={e => setNewAddress(e.target.value)}
                  placeholder="Plot 42, Cantonments Road..."
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    GhanaPost GPS
                  </label>
                  <input
                    type="text"
                    value={newGps}
                    onChange={e => setNewGps(e.target.value)}
                    placeholder="GA-110-3849"
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Vehicle Type
                  </label>
                  <select
                    value={newVehicle}
                    onChange={e => setNewVehicle(e.target.value as any)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="Heavy Hydraulic Tailgate (10-Wheel)">Heavy Hydraulic Tailgate (10-Wheel)</option>
                    <option value="Flatbed Hiab Crane Truck">Flatbed Hiab Crane Truck</option>
                    <option value="Secure Architectural Van">Secure Architectural Van</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Assigned Driver
                  </label>
                  <input
                    type="text"
                    value={newDriver}
                    onChange={e => setNewDriver(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                    Vehicle License Plate
                  </label>
                  <input
                    type="text"
                    value={newPlate}
                    onChange={e => setNewPlate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsNewWaybillModalOpen(false)}
                  className="px-4 py-2 bg-stone-800 text-stone-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold uppercase rounded-lg"
                >
                  Generate Waybill & Dispatch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Full GPS Telemetry & Waypoint Modal */}
      {selectedWaybillForModal && (
        <EcomSpineTrackingModal
          waybill={selectedWaybillForModal}
          isOpen={true}
          onClose={() => setSelectedWaybillForModal(null)}
        />
      )}
    </div>
  );
};
