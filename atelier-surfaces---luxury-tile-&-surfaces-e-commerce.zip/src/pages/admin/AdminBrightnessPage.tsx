import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { PanelBrightnessConfig } from '../../types';
import { Link } from '../../router/Router';
import { 
  Sun, 
  Lock, 
  Unlock, 
  Save, 
  CheckCircle2, 
  RotateCcw, 
  Sliders, 
  Sparkles, 
  Layout, 
  CreditCard, 
  Layers, 
  ShieldCheck, 
  Eye, 
  Monitor, 
  Check, 
  ExternalLink,
  Palette,
  Boxes,
  TrendingUp,
  AlertTriangle,
  Globe,
  Store,
  Compass,
  MapPin,
  Image as ImageIcon
} from 'lucide-react';

export function AdminBrightnessPage() {
  const { currentUser, hasPermission } = useAuth();
  const { activeCompany } = useCompany();
  const currentBrightness = storeService.getPanelBrightness(activeCompany.id);

  const [config, setConfig] = useState<PanelBrightnessConfig>({ ...currentBrightness });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'storefront' | 'admin' | 'all'>('storefront');

  const canManage = hasPermission('theme_management', 'edit') || 
                    hasPermission('store_settings', 'manage_settings') || 
                    currentUser?.roleId === 'super-admin' || 
                    currentUser?.roleId === 'manager';

  // Synchronize on company switch
  useEffect(() => {
    const loaded = storeService.getPanelBrightness(activeCompany.id);
    setConfig(loaded);
  }, [activeCompany.id]);

  const handleToggleLock = () => {
    const nextLocked = !config.isLocked;
    const updated = storeService.togglePanelBrightnessLock(nextLocked, currentUser?.name, activeCompany.id);
    setConfig(prev => ({
      ...prev,
      isLocked: updated,
      lockedBy: updated ? (currentUser?.name || 'Administrator') : undefined,
      lockedAt: updated ? new Date().toISOString() : undefined,
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canManage) return;

    storeService.updatePanelBrightness(config, currentUser?.name, activeCompany.id);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleSliderChange = (key: keyof PanelBrightnessConfig, value: number) => {
    if (config.isLocked) return;
    setActivePreset(null);
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const handleApplyPreset = (name: string, brightnessLevel: number, contrastLevel: number = 100) => {
    if (config.isLocked) return;
    setActivePreset(name);
    setConfig(prev => ({
      ...prev,
      // Admin Panels
      sidebarBrightness: brightnessLevel,
      sidebarContrast: contrastLevel,
      headerBrightness: brightnessLevel,
      headerContrast: contrastLevel,
      workspaceBrightness: brightnessLevel,
      workspaceContrast: contrastLevel,
      cardsBrightness: brightnessLevel,
      cardsContrast: contrastLevel,
      posBrightness: brightnessLevel,
      posContrast: contrastLevel,
      // Storefront Panels
      storefrontHeaderBrightness: brightnessLevel,
      storefrontHeaderContrast: contrastLevel,
      storefrontHeroBrightness: brightnessLevel,
      storefrontHeroContrast: contrastLevel,
      storefrontCatalogBrightness: brightnessLevel,
      storefrontCatalogContrast: contrastLevel,
      storefrontSpecimenBrightness: brightnessLevel,
      storefrontSpecimenContrast: contrastLevel,
      storefrontFooterBrightness: brightnessLevel,
      storefrontFooterContrast: contrastLevel,
    }));
  };

  const handleResetSinglePanel = (
    brightnessKey: keyof PanelBrightnessConfig, 
    contrastKey: keyof PanelBrightnessConfig
  ) => {
    if (config.isLocked) return;
    setConfig(prev => ({
      ...prev,
      [brightnessKey]: 100,
      [contrastKey]: 100
    }));
  };

  const handleResetAllDefaults = () => {
    if (config.isLocked) return;
    setActivePreset('default');
    const defaults: PanelBrightnessConfig = {
      sidebarBrightness: 100,
      sidebarContrast: 100,
      headerBrightness: 100,
      headerContrast: 100,
      workspaceBrightness: 100,
      workspaceContrast: 100,
      cardsBrightness: 100,
      cardsContrast: 100,
      posBrightness: 100,
      posContrast: 100,
      storefrontHeaderBrightness: 100,
      storefrontHeaderContrast: 100,
      storefrontHeroBrightness: 100,
      storefrontHeroContrast: 100,
      storefrontCatalogBrightness: 100,
      storefrontCatalogContrast: 100,
      storefrontSpecimenBrightness: 100,
      storefrontSpecimenContrast: 100,
      storefrontFooterBrightness: 100,
      storefrontFooterContrast: 100,
      isLocked: false,
    };
    setConfig(defaults);
  };

  // 5 Public Storefront Panels
  const storefrontPanelSections = [
    {
      id: 'storefront-header',
      category: 'storefront',
      label: 'Storefront Navigation & Announcement Header',
      description: 'Controls public navbar illumination, brand logo reflectivity, and menu readability for all visiting customers.',
      icon: Globe,
      brightnessKey: 'storefrontHeaderBrightness' as const,
      contrastKey: 'storefrontHeaderContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-nav-bg)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] px-2 py-0.5 text-[8px] uppercase tracking-wider text-center font-bold">
            Ghana Delivery & Flagship Ridge West Showroom
          </div>
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-1.5 pt-1">
            <span className="font-serif-luxury tracking-widest text-[var(--theme-text)] font-bold text-xs uppercase">
              {activeCompany.name}
            </span>
            <div className="flex items-center gap-2 text-[9px] text-[var(--theme-text-muted)] font-medium">
              <span>Marble</span>
              <span>Porcelain</span>
              <span className="text-[var(--theme-accent)] font-bold">Bag (3)</span>
            </div>
          </div>
          <div className="text-[9px] text-[var(--theme-text-muted)] flex justify-between">
            <span>Navbar Filter: {b}%</span>
            <span className="font-mono text-emerald-500 font-bold">Public Active</span>
          </div>
        </div>
      )
    },
    {
      id: 'storefront-hero',
      category: 'storefront',
      label: 'Storefront Hero Showcase & Architectural Billboard',
      description: 'Calibrates luminance of the flagship hero billboard, marble backdrop image, and headline typography.',
      icon: ImageIcon,
      brightnessKey: 'storefrontHeroBrightness' as const,
      contrastKey: 'storefrontHeroContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-stone-900 text-white p-3 rounded-xs border border-stone-800 flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30 z-0"></div>
          <div className="relative z-10 space-y-1">
            <span className="text-[8px] uppercase tracking-widest text-[var(--theme-accent)] font-bold block">
              Architectural Porcelain & Fine Stone
            </span>
            <h5 className="font-serif-luxury text-sm font-semibold text-white leading-tight">
              Surfaces That Define Spaces.
            </h5>
          </div>
          <div className="relative z-10 flex items-center justify-between pt-1 border-t border-white/20">
            <span className="px-2 py-0.5 bg-[var(--theme-accent)] text-white text-[8px] font-bold uppercase">
              Explore Catalog
            </span>
            <span className="text-[9px] text-white/70 font-mono">Hero Contrast: {c}%</span>
          </div>
        </div>
      )
    },
    {
      id: 'storefront-catalog',
      category: 'storefront',
      label: 'Product Catalog & Slabs Collection Gallery Grid',
      description: 'Controls illumination across product collection cards, material taxonomy shelves, and tile specimen cards.',
      icon: Boxes,
      brightnessKey: 'storefrontCatalogBrightness' as const,
      contrastKey: 'storefrontCatalogContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-surface)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex justify-between items-center pb-1 border-b border-[var(--theme-border)]">
            <span className="font-bold text-[var(--theme-text)] uppercase text-[9px]">Slab Gallery Grid</span>
            <span className="text-[8px] text-[var(--theme-accent)] font-bold">148 Slabs</span>
          </div>
          <div className="grid grid-cols-2 gap-2 my-auto">
            <div className="p-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs">
              <span className="font-serif-luxury font-bold block truncate">Calacatta Statuario</span>
              <span className="text-[9px] text-[var(--theme-accent)] font-mono font-bold">GH₵ 485/m²</span>
            </div>
            <div className="p-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs">
              <span className="font-serif-luxury font-bold block truncate">Nero Marquina</span>
              <span className="text-[9px] text-[var(--theme-accent)] font-mono font-bold">GH₵ 520/m²</span>
            </div>
          </div>
          <div className="text-[9px] text-[var(--theme-text-muted)] flex justify-between">
            <span>Color Swatches Active</span>
            <span className="font-mono text-amber-500 font-bold">{b}% Lum</span>
          </div>
        </div>
      )
    },
    {
      id: 'storefront-specimen',
      category: 'storefront',
      label: 'Slab Specimen Inspection & Detail Zoom Canvas',
      description: 'Controls high-resolution slab veining clarity, 2D photometry lighting simulator, and Three.js 3D texture studio.',
      icon: Eye,
      brightnessKey: 'storefrontSpecimenBrightness' as const,
      contrastKey: 'storefrontSpecimenContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-stone-950 text-white p-3 rounded-xs border border-stone-800 flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex justify-between items-center border-b border-stone-800 pb-1">
            <span className="font-serif-luxury font-bold text-amber-300">Specimen Macro Inspection</span>
            <span className="text-[8px] bg-white/10 px-1 py-0.2 rounded-xs font-mono">5500K Daylight</span>
          </div>
          <div className="p-1 bg-stone-900 border border-stone-800 rounded-xs flex items-center justify-between text-[9px]">
            <span>Calacatta Vein Zoom (120x240cm)</span>
            <span className="text-emerald-400 font-mono font-bold">Specular 94%</span>
          </div>
          <div className="text-[8px] text-stone-400 flex justify-between">
            <span>Three.js WebGL Normal Map</span>
            <span className="font-mono text-amber-400 font-bold">Contrast: {c}%</span>
          </div>
        </div>
      )
    },
    {
      id: 'storefront-footer',
      category: 'storefront',
      label: 'Public Storefront Footer & Showroom Depot Panel',
      description: 'Controls public footer visibility, flagship coordinates (GA-110-3849), and phone (0542443125/0596334488).',
      icon: MapPin,
      brightnessKey: 'storefrontFooterBrightness' as const,
      contrastKey: 'storefrontFooterContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-surface-subtle)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex justify-between items-center border-b border-[var(--theme-border)] pb-1">
            <span className="font-serif-luxury font-bold uppercase tracking-wider">{activeCompany.name}</span>
            <span className="text-[8px] text-[var(--theme-accent)] font-bold">Accra Flagship</span>
          </div>
          <div className="text-[9px] text-[var(--theme-text-muted)] space-y-0.5">
            <div>14 Independence Avenue, Ridge West (GPS: GA-110-3849)</div>
            <div className="font-mono text-[var(--theme-text)]">0542443125/0596334488 · concierge@ateliersurfaces.com</div>
          </div>
          <div className="text-[8px] text-[var(--theme-text-muted)] flex justify-between border-t border-[var(--theme-border)] pt-1">
            <span>© 2026 Atelier Surfaces</span>
            <span className="font-mono text-emerald-600 font-bold">Footer {b}%</span>
          </div>
        </div>
      )
    }
  ];

  // 5 Internal Administration & POS Panels
  const adminPanelSections = [
    {
      id: 'sidebar',
      category: 'admin',
      label: 'Atelier Obsidian Navigation Dock (Sidebar)',
      description: 'Controls contrast, dark obsidian hue, and typography luminance on the persistent left administration navigation menu.',
      icon: Layout,
      brightnessKey: 'sidebarBrightness' as const,
      contrastKey: 'sidebarContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-stone-950 text-stone-200 p-3 rounded-xs border border-stone-800 flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex items-center justify-between border-b border-stone-800 pb-1.5">
            <span className="font-serif-luxury tracking-widest text-white font-bold uppercase">ATELIER SURFACES</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          </div>
          <div className="space-y-1 my-auto">
            <div className="bg-white/15 text-white px-2 py-1 rounded-xs font-semibold flex items-center justify-between">
              <span>Overview & Slabs</span>
              <span className="text-[8px] bg-white/20 px-1 rounded-xs">Active</span>
            </div>
            <div className="text-stone-400 px-2 py-0.5">Surface Inventory</div>
            <div className="text-stone-400 px-2 py-0.5">Showroom POS (Ridge West)</div>
          </div>
          <div className="text-[9px] text-stone-500 border-t border-stone-800/80 pt-1 flex justify-between">
            <span>Tenant: {activeCompany.name}</span>
            <span className="font-mono text-emerald-400">Online</span>
          </div>
        </div>
      )
    },
    {
      id: 'header',
      category: 'admin',
      label: 'Top Command Header Bar & Breadcrumb Shelf',
      description: 'Controls illumination, status pill intensity, and background reflectivity for the top horizontal sticky navigation bar.',
      icon: Monitor,
      brightnessKey: 'headerBrightness' as const,
      contrastKey: 'headerContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-surface)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex items-center justify-between">
            <span className="font-semibold text-[var(--theme-text)]">Admin Console &gt; Panel Brightness</span>
            <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold border border-emerald-500/30 rounded-xs">
              Tenant: {activeCompany.currency}
            </span>
          </div>
          <div className="p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs flex items-center justify-between">
            <span className="font-medium text-[var(--theme-text-muted)]">Active Admin: {currentUser?.name || 'Administrator'}</span>
            <span className="px-2 py-0.5 bg-[var(--theme-accent)] text-white font-bold rounded-xs text-[9px]">
              Super Admin
            </span>
          </div>
          <div className="text-[9px] text-[var(--theme-text-muted)] flex items-center justify-between">
            <span>Calls: ONLINE (GA-110-3849)</span>
            <span className="font-mono text-amber-500 font-bold">Luminance: {b}%</span>
          </div>
        </div>
      )
    },
    {
      id: 'workspace',
      category: 'admin',
      label: 'Main Administrative Workspace & Specimen Tables',
      description: 'Controls primary canvas white/dark balance, specimen cards, and ledger tables throughout all internal admin pages.',
      icon: Layers,
      brightnessKey: 'workspaceBrightness' as const,
      contrastKey: 'workspaceContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-bg)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex justify-between items-center pb-1 border-b border-[var(--theme-border)]">
            <span className="font-bold uppercase tracking-wider text-[var(--theme-text)]">Live Catalog Specs</span>
            <span className="text-[9px] text-emerald-600 font-mono">148 Slabs Active</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between p-1 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs">
              <span className="font-medium truncate max-w-[120px]">Calacatta Statuario Imperiale</span>
              <span className="font-mono font-bold text-[var(--theme-accent)]">GH₵ 485/m²</span>
            </div>
            <div className="flex justify-between p-1 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs">
              <span className="font-medium truncate max-w-[120px]">Nero Marquina Bookmatch</span>
              <span className="font-mono font-bold text-[var(--theme-accent)]">GH₵ 520/m²</span>
            </div>
          </div>
          <span className="text-[9px] text-[var(--theme-text-muted)]">Data Grid Contrast: {c}%</span>
        </div>
      )
    },
    {
      id: 'cards',
      category: 'admin',
      label: 'Executive Metric KPI & Replenishment Cards',
      description: 'Controls illumination of statistical revenue counters, stock warning banners, and visual charts.',
      icon: TrendingUp,
      brightnessKey: 'cardsBrightness' as const,
      contrastKey: 'cardsContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-[var(--theme-surface)] text-[var(--theme-text)] p-3 rounded-xs border border-[var(--theme-border)] flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150"
        >
          <div className="flex items-center justify-between text-[var(--theme-text-muted)]">
            <span className="font-bold uppercase tracking-wider">Verified Revenue</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <div className="font-mono text-base font-bold text-[var(--theme-text)]">
            GH₵ 2,840,500.00
          </div>
          <div className="p-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 rounded-xs flex items-center justify-between text-[9px]">
            <span className="flex items-center gap-1">
              <AlertTriangle className="w-2.5 h-2.5" />
              <span>4 Low Stock Variants</span>
            </span>
            <span className="font-bold underline">Restock</span>
          </div>
        </div>
      )
    },
    {
      id: 'pos',
      category: 'admin',
      label: 'Showroom POS Terminal & Checkout Screen',
      description: 'Controls screen clarity for the cashier touch terminal, barcode scanner HUD, and thermal receipt review dialogs.',
      icon: CreditCard,
      brightnessKey: 'posBrightness' as const,
      contrastKey: 'posContrast' as const,
      previewContent: (b: number, c: number) => (
        <div 
          style={{ filter: `brightness(${b}%) contrast(${c}%)` }}
          className="h-28 bg-stone-900 text-stone-100 p-3 rounded-xs border border-stone-700 flex flex-col justify-between text-[10px] select-none shadow-xs transition-all duration-150 font-mono"
        >
          <div className="flex justify-between items-center border-b border-stone-800 pb-1">
            <span className="text-emerald-400 font-bold">POS · REGISTER #01</span>
            <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded-xs">SCANNER READY</span>
          </div>
          <div className="space-y-0.5 text-[9px]">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>GH₵ 12,450.00</span>
            </div>
            <div className="flex justify-between text-amber-400">
              <span>Trade Discount (15%):</span>
              <span>-GH₵ 1,867.50</span>
            </div>
            <div className="flex justify-between font-bold text-white border-t border-stone-800 pt-0.5">
              <span>Total Due:</span>
              <span className="text-emerald-400">GH₵ 10,582.50</span>
            </div>
          </div>
          <div className="text-[8px] text-stone-400 flex justify-between">
            <span>Tenders: Cash / MoMo</span>
            <span>GA-110-3849</span>
          </div>
        </div>
      )
    }
  ];

  const displayedSections = activeTab === 'storefront'
    ? storefrontPanelSections
    : activeTab === 'admin'
    ? adminPanelSections
    : [...storefrontPanelSections, ...adminPanelSections];

  return (
    <AdminLayout
      title={`Atelier Surfaces Panel Brightness & Display Calibration · ${activeCompany.name}`}
      subtitle="Calibrate luminance and contrast for both public storefront panels and internal admin consoles, engage tamper-proof admin lock, and save showroom display settings."
      actions={
        <div className="flex items-center gap-2 flex-wrap">
          <Link
            href="/"
            className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>View Public Storefront</span>
          </Link>

          <Link
            href="/admin/pos"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Open POS Screen</span>
          </Link>

          <button
            type="button"
            onClick={handleToggleLock}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs ${
              config.isLocked
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
            }`}
          >
            {config.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            <span>{config.isLocked ? 'Brightness LOCKED' : 'Lock Brightness Settings'}</span>
          </button>

          <button
            type="button"
            onClick={handleResetAllDefaults}
            disabled={config.isLocked}
            className="px-3.5 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Reset all panels to balanced 100% default"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset 100%</span>
          </button>

          <button
            type="button"
            onClick={() => handleSave()}
            className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save All Panels</span>
          </button>
        </div>
      }
    >
      <div className="space-y-8 max-w-5xl text-xs text-[var(--theme-text)]">
        
        {/* Success Alert Banner */}
        {saveSuccess && (
          <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in rounded-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="font-semibold">
              Panel illumination, contrast ratios, and security lock state saved successfully! Both public storefront and admin panels updated.
            </span>
          </div>
        )}

        {/* Master Security Lock & Governance Banner (Same Format as POS Settings) */}
        <div className={`p-6 border rounded-xs transition shadow-sm space-y-4 ${
          config.isLocked 
            ? 'bg-amber-950/20 border-amber-500/40' 
            : 'bg-[var(--theme-surface)] border-[var(--theme-border)]'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Sun className={`w-5 h-5 ${config.isLocked ? 'text-amber-500' : 'text-[var(--theme-accent)]'}`} />
              <div>
                <h2 className="font-serif-luxury text-base font-bold text-[var(--theme-text)] flex items-center gap-2">
                  <span>Atelier Surfaces Display Illumination Security Gate</span>
                  {config.isLocked && <Lock className="w-4 h-4 text-amber-500" />}
                </h2>
                <p className="text-[11px] text-[var(--theme-text-muted)]">
                  When locked by administrator, all brightness and contrast sliders across public storefront panels and internal administrative consoles are frozen against unauthorized alteration.
                </p>
              </div>
            </div>

            <span className={`px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-xs self-start sm:self-auto ${
              config.isLocked
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}>
              {config.isLocked ? `Locked by ${config.lockedBy || 'Admin'}` : 'Unlocked (Configurable)'}
            </span>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between border-t border-[var(--theme-border)] text-xs gap-3">
            <div className="text-[var(--theme-text-muted)] font-medium flex items-center gap-2 flex-wrap">
              <span>Status: <strong className="text-[var(--theme-text)]">{config.isLocked ? 'Tamper-Proof Lock Active' : 'Live Calibration Allowed'}</strong></span>
              {config.lockedAt && (
                <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                  (Enforced on {new Date(config.lockedAt).toLocaleDateString()} {new Date(config.lockedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleToggleLock}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto ${
                config.isLocked
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-amber-600 hover:bg-amber-500 text-white'
              }`}
            >
              {config.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              <span>{config.isLocked ? 'Unlock All Panels' : 'Lock All Panels Now'}</span>
            </button>
          </div>
        </div>

        {/* SECTION 1: QUICK PRESET PALETTES & GLOBAL HARMONIZATION */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 1 · Studio Presets
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Atelier Surfaces Curated Lighting Environments
              </h3>
            </div>
            <Sparkles className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <p className="text-xs text-[var(--theme-text-muted)]">
            Select an architectural preset engineered for specific Ghanaian lighting conditions, daylight showroom skylights, or high-definition slab presentations:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 pt-1">
            <button
              type="button"
              disabled={config.isLocked}
              onClick={() => handleApplyPreset('default', 100, 100)}
              className={`p-3 text-left border rounded-xs transition cursor-pointer disabled:opacity-50 flex flex-col justify-between ${
                activePreset === 'default'
                  ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
            >
              <span className="font-bold text-[11px] block">Standard Balanced</span>
              <span className="text-[10px] opacity-80 block mt-1">100% Bright / 100% Contrast</span>
              <span className="text-[9px] mt-2 block opacity-70">Natural neutral balance</span>
            </button>

            <button
              type="button"
              disabled={config.isLocked}
              onClick={() => handleApplyPreset('showroom_day', 125, 105)}
              className={`p-3 text-left border rounded-xs transition cursor-pointer disabled:opacity-50 flex flex-col justify-between ${
                activePreset === 'showroom_day'
                  ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
            >
              <span className="font-bold text-[11px] block text-amber-500 dark:text-amber-300">Showroom Daylight</span>
              <span className="text-[10px] opacity-80 block mt-1">125% Bright / 105% Contrast</span>
              <span className="text-[9px] mt-2 block opacity-70">Cuts glare in bright sunlight</span>
            </button>

            <button
              type="button"
              disabled={config.isLocked}
              onClick={() => handleApplyPreset('evening_atelier', 85, 95)}
              className={`p-3 text-left border rounded-xs transition cursor-pointer disabled:opacity-50 flex flex-col justify-between ${
                activePreset === 'evening_atelier'
                  ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
            >
              <span className="font-bold text-[11px] block text-indigo-400">Architectural Evening</span>
              <span className="text-[10px] opacity-80 block mt-1">85% Bright / 95% Contrast</span>
              <span className="text-[9px] mt-2 block opacity-70">Warm low-glare evening tone</span>
            </button>

            <button
              type="button"
              disabled={config.isLocked}
              onClick={() => handleApplyPreset('high_contrast', 110, 118)}
              className={`p-3 text-left border rounded-xs transition cursor-pointer disabled:opacity-50 flex flex-col justify-between ${
                activePreset === 'high_contrast'
                  ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
            >
              <span className="font-bold text-[11px] block text-emerald-500">High Contrast Focus</span>
              <span className="text-[10px] opacity-80 block mt-1">110% Bright / 118% Contrast</span>
              <span className="text-[9px] mt-2 block opacity-70">Pinpoint marble vein analysis</span>
            </button>

            <button
              type="button"
              disabled={config.isLocked}
              onClick={() => handleApplyPreset('oled_eco', 65, 90)}
              className={`p-3 text-left border rounded-xs transition cursor-pointer disabled:opacity-50 flex flex-col justify-between ${
                activePreset === 'oled_eco'
                  ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                  : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border-[var(--theme-border)] text-[var(--theme-text)]'
              }`}
            >
              <span className="font-bold text-[11px] block text-stone-400">OLED Eco Dim</span>
              <span className="text-[10px] opacity-80 block mt-1">65% Bright / 90% Contrast</span>
              <span className="text-[9px] mt-2 block opacity-70">Max battery saving on tablets</span>
            </button>
          </div>
        </div>

        {/* SECTION 2: PER-PANEL GRANULAR CALIBRATION (WITH PUBLIC STOREFRONT & ADMIN TABS) */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 2 · Granular Panel Controls
              </span>
              <h3 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Calibrate Each Atelier Surfaces Interface Panel
              </h3>
            </div>

            {/* Zero-pill clean luxury tab switcher */}
            <div className="flex items-center gap-2 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('storefront')}
                className={`px-3 py-1.5 border transition cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'storefront'
                    ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                    : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border-[var(--theme-border)] text-[var(--theme-text)]'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Public Storefront Panels ({storefrontPanelSections.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-1.5 border transition cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'admin'
                    ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                    : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border-[var(--theme-border)] text-[var(--theme-text)]'
                }`}
              >
                <Layout className="w-3.5 h-3.5" />
                <span>Admin Console & POS Panels ({adminPanelSections.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 border transition cursor-pointer hidden md:flex items-center gap-1.5 ${
                  activeTab === 'all'
                    ? 'bg-[var(--theme-accent)] text-white border-[var(--theme-accent)]'
                    : 'bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border-[var(--theme-border)] text-[var(--theme-text)]'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>All 10 Panels</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-5">
            {displayedSections.map(panel => {
              const Icon = panel.icon;
              const bValue = config[panel.brightnessKey] ?? 100;
              const cValue = config[panel.contrastKey] ?? 100;

              return (
                <div 
                  key={panel.id}
                  className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 rounded-xs shadow-xs space-y-4 transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--theme-border)] pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-[var(--theme-surface-subtle)] text-[var(--theme-accent)] border border-[var(--theme-border)] rounded-xs">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded-xs border ${
                            panel.category === 'storefront'
                              ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30'
                              : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                          }`}>
                            {panel.category === 'storefront' ? 'Storefront Panel' : 'Admin Panel'}
                          </span>
                          <h4 className="font-bold text-sm text-[var(--theme-text)]">
                            {panel.label}
                          </h4>
                        </div>
                        <p className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                          {panel.description}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={config.isLocked}
                      onClick={() => handleResetSinglePanel(panel.brightnessKey, panel.contrastKey)}
                      className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition rounded-xs cursor-pointer disabled:opacity-40 self-start sm:self-auto"
                      title="Reset this panel only to 100% / 100%"
                    >
                      Reset Panel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                    
                    {/* Live Swatch Preview */}
                    <div className="md:col-span-5 space-y-1">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)] block">
                        Live Panel Swatch Simulation
                      </span>
                      {panel.previewContent(bValue, cValue)}
                    </div>

                    {/* Dual Sliders & Inputs */}
                    <div className="md:col-span-7 space-y-4">
                      {/* Brightness Control */}
                      <div className="space-y-1.5 bg-[var(--theme-surface-subtle)] p-3.5 border border-[var(--theme-border)] rounded-xs">
                        <div className="flex items-center justify-between">
                          <label className="font-bold flex items-center gap-1.5 text-xs text-[var(--theme-text)]">
                            <Sun className="w-3.5 h-3.5 text-amber-500" />
                            <span>Panel Luminance (Brightness)</span>
                          </label>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min={50}
                              max={150}
                              disabled={config.isLocked}
                              value={bValue}
                              onChange={e => handleSliderChange(panel.brightnessKey, Math.min(150, Math.max(50, Number(e.target.value) || 100)))}
                              className="w-14 px-1.5 py-0.5 font-mono text-center font-bold bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] rounded-xs disabled:opacity-50"
                            />
                            <span className="font-mono text-xs text-[var(--theme-text-muted)]">%</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-mono text-[var(--theme-text-muted)] w-8">50%</span>
                          <input
                            type="range"
                            min={50}
                            max={150}
                            step={1}
                            disabled={config.isLocked}
                            value={bValue}
                            onChange={e => handleSliderChange(panel.brightnessKey, Number(e.target.value))}
                            className="flex-1 h-1.5 bg-stone-300 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-amber-500 disabled:opacity-40"
                          />
                          <span className="text-[10px] font-mono text-[var(--theme-text-muted)] w-8 text-right">150%</span>
                        </div>
                      </div>

                      {/* Contrast Control */}
                      <div className="space-y-1.5 bg-[var(--theme-surface-subtle)] p-3.5 border border-[var(--theme-border)] rounded-xs">
                        <div className="flex items-center justify-between">
                          <label className="font-bold flex items-center gap-1.5 text-xs text-[var(--theme-text)]">
                            <Sliders className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                            <span>Panel Contrast Ratio</span>
                          </label>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min={80}
                              max={125}
                              disabled={config.isLocked}
                              value={cValue}
                              onChange={e => handleSliderChange(panel.contrastKey, Math.min(125, Math.max(80, Number(e.target.value) || 100)))}
                              className="w-14 px-1.5 py-0.5 font-mono text-center font-bold bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] rounded-xs disabled:opacity-50"
                            />
                            <span className="font-mono text-xs text-[var(--theme-text-muted)]">%</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-mono text-[var(--theme-text-muted)] w-8">80%</span>
                          <input
                            type="range"
                            min={80}
                            max={125}
                            step={1}
                            disabled={config.isLocked}
                            value={cValue}
                            onChange={e => handleSliderChange(panel.contrastKey, Number(e.target.value))}
                            className="flex-1 h-1.5 bg-stone-300 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-[var(--theme-accent)] disabled:opacity-40"
                          />
                          <span className="text-[10px] font-mono text-[var(--theme-text-muted)] w-8 text-right">125%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* SECTION 3: LIVE INTERACTIVE ATELIER SURFACES COMPOSITE SIMULATION */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 3 · Multi-Panel Simulation
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Interactive Storefront & Console Synchronization Preview
              </h3>
            </div>
            <Eye className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <p className="text-xs text-[var(--theme-text-muted)]">
            This live architectural composite renders the public storefront panels and admin console with their exact assigned filters. Notice how the Storefront Header, Hero, Catalog, Specimen Inspector, and Footer harmonize together:
          </p>

          <div className="border border-[var(--theme-border)] rounded-xs overflow-hidden shadow-md space-y-2 p-2 bg-[var(--theme-surface-subtle)]">
            {/* Simulated Storefront Header */}
            <div 
              style={{ filter: `brightness(${config.storefrontHeaderBrightness ?? 100}%) contrast(${config.storefrontHeaderContrast ?? 100}%)` }}
              className="h-9 bg-[var(--theme-nav-bg)] border border-[var(--theme-border)] px-4 flex items-center justify-between text-[10px] font-semibold transition-all duration-150"
            >
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="font-serif-luxury uppercase font-bold">{activeCompany.name} · Storefront</span>
              </div>
              <div className="flex items-center gap-3 text-[9px] text-[var(--theme-text-muted)] font-mono">
                <span>Shop All</span>
                <span>Marble Slabs</span>
                <span>Cart (GH₵ 1,470)</span>
              </div>
            </div>

            {/* Simulated Hero */}
            <div 
              style={{ filter: `brightness(${config.storefrontHeroBrightness ?? 100}%) contrast(${config.storefrontHeroContrast ?? 100}%)` }}
              className="h-20 bg-stone-900 border border-stone-800 p-3 flex flex-col justify-between text-white transition-all duration-150 relative overflow-hidden"
            >
              <div className="text-[9px] uppercase tracking-widest text-[var(--theme-accent)] font-bold">
                Hero Showcase Panel
              </div>
              <h6 className="font-serif-luxury text-xs font-semibold">Surfaces That Define Spaces.</h6>
              <div className="text-[8px] text-white/60">14 Independence Avenue, Ridge West Flagship</div>
            </div>

            {/* Simulated Catalog & Specimen */}
            <div className="grid grid-cols-2 gap-2">
              <div 
                style={{ filter: `brightness(${config.storefrontCatalogBrightness ?? 100}%) contrast(${config.storefrontCatalogContrast ?? 100}%)` }}
                className="p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs text-[9px] transition-all duration-150"
              >
                <span className="font-bold text-[var(--theme-text)] uppercase block">Catalog Gallery Grid</span>
                <span className="text-[var(--theme-accent)] font-mono font-bold">Calacatta · GH₵ 485/m²</span>
              </div>

              <div 
                style={{ filter: `brightness(${config.storefrontSpecimenBrightness ?? 100}%) contrast(${config.storefrontSpecimenContrast ?? 100}%)` }}
                className="p-2.5 bg-stone-950 border border-stone-800 text-white rounded-xs text-[9px] transition-all duration-150"
              >
                <span className="font-bold text-amber-300 uppercase block">Specimen Zoom Inspector</span>
                <span className="text-emerald-400 font-mono font-bold">120x240cm Bookmatched</span>
              </div>
            </div>

            {/* Simulated Storefront Footer */}
            <div 
              style={{ filter: `brightness(${config.storefrontFooterBrightness ?? 100}%) contrast(${config.storefrontFooterContrast ?? 100}%)` }}
              className="h-9 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] px-4 flex items-center justify-between text-[9px] transition-all duration-150"
            >
              <span>GPS: GA-110-3849 · Ridge West Showroom</span>
              <span className="font-mono text-emerald-600 font-bold">0542443125/0596334488</span>
            </div>
          </div>
        </div>

        {/* BOTTOM ACTION BAR */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-[var(--theme-border)]">
          <div className="text-[11px] text-[var(--theme-text-muted)]">
            Brightness adjustments apply live to active company workspace (<strong className="text-[var(--theme-text)]">{activeCompany.name}</strong>).
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetAllDefaults}
              disabled={config.isLocked}
              className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] transition rounded-xs cursor-pointer disabled:opacity-50"
            >
              Reset 100%
            </button>

            <button
              type="button"
              onClick={handleToggleLock}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs ${
                config.isLocked
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
              }`}
            >
              {config.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              <span>{config.isLocked ? 'Unlock Panels' : 'Lock Panels'}</span>
            </button>

            <button
              type="button"
              onClick={() => handleSave()}
              className="px-6 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition rounded-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Panel Brightness</span>
            </button>
          </div>
        </div>

      </div>
    </AdminLayout>
  );
}
