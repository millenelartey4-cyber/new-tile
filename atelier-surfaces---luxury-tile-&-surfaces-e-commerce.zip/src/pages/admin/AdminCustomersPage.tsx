import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { Users, Search, ShoppingBag, ShieldCheck, Mail, Phone } from 'lucide-react';

export function AdminCustomersPage() {
  const users = storeService.getUsers();
  const orders = storeService.getOrders();
  const [search, setSearch] = useState('');

  // Extract customer and trade profiles
  const customerList = users.map(u => {
    const userOrders = orders.filter(o => o.customerId === u.uid || o.customerSnapshot.email.toLowerCase() === u.email.toLowerCase());
    const totalSpent = userOrders.filter(o => o.paymentStatus === 'paid').reduce((sum, o) => sum + o.total, 0);
    return {
      ...u,
      orderCount: userOrders.length,
      totalSpent
    };
  }).filter(u => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.roleName.toLowerCase().includes(q);
  });

  return (
    <AdminLayout
      title="Client & Trade Directory"
      subtitle="Architectural practices, interior designers, commercial contractors, and verified trade buyers."
    >
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search clients by name or email..."
            className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[var(--theme-text)]">
            <thead>
              <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                <th className="py-3 px-4">Client Name / Studio</th>
                <th className="py-3 px-4">Account Type</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4">Lifetime Orders</th>
                <th className="py-3 px-4">Total Reconciled Spend</th>
                <th className="py-3 px-4 text-right">Registered</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--theme-border-subtle)]">
              {customerList.map(c => (
                <tr key={c.uid} className="hover:bg-[var(--theme-surface-subtle)]/50 transition-colors">
                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-sm text-[var(--theme-text)] block">{c.name}</span>
                    <span className="text-[11px] text-[var(--theme-text-muted)] font-mono">{c.uid}</span>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-accent)]">
                      {c.roleName}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-[11px] text-[var(--theme-text-muted)]">
                    <div className="flex items-center gap-1.5">
                      <Mail className="w-3 h-3 text-[var(--theme-accent)]" />
                      <span>{c.email}</span>
                    </div>
                    {c.phone && (
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Phone className="w-3 h-3 text-[var(--theme-accent)]" />
                        <span>{c.phone}</span>
                      </div>
                    )}
                  </td>

                  <td className="py-3.5 px-4 font-bold tabular-nums">
                    {c.orderCount} Orders
                  </td>

                  <td className="py-3.5 px-4 font-bold tabular-nums text-sm text-[var(--theme-text)]">
                    GH₵{c.totalSpent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>

                  <td className="py-3.5 px-4 text-right text-[11px] text-[var(--theme-text-muted)]">
                    {new Date(c.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
