import { useState, useEffect, useMemo } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useRouter, Link } from '../../router/Router';
import { 
  TrendingUp, 
  ShoppingCart, 
  Boxes, 
  Users, 
  AlertTriangle, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  Eye,
  Plus,
  SlidersHorizontal,
  ExternalLink,
  Package,
  Filter,
  ShieldCheck,
  Search,
  X,
  AlertCircle,
  Video,
  Lock,
  Unlock,
  MapPin,
  Phone,
  Mail,
  Save,
  Radio,
  RefreshCw,
  Sparkles,
  Sun,
  CreditCard,
  Sliders,
  Trash2,
  RotateCcw,
  KeyRound,
  ShieldAlert,
  Check,
  Megaphone,
  Bot
} from 'lucide-react';
import { useCompany } from '../../context/CompanyContext';
import { useAuth } from '../../context/AuthContext';
import { AdminBrightnessController } from '../../components/admin/AdminBrightnessController';
import { QuickStatsWidget } from '../../components/admin/QuickStatsWidget';
import { AdminBroadcastDesk } from '../../components/admin/AdminBroadcastDesk';

interface LowStockItem {
  productId: string;
  productName: string;
  productSlug: string;
  categoryName: string;
  material: string;
  variantId: string;
  variantColor: string;
  colorHex: string;
  sku: string;
  stock: number;
  threshold: number;
  unit: string;
  image?: string;
  price: number;
  isOutOfStock: boolean;
  isCritical: boolean;
  percentRemaining: number;
}

export function AdminDashboardPage() {
  const { navigate } = useRouter();
  const { currentUser } = useAuth();
  const { activeCompany, updateCompany } = useCompany();

  // Reactive version counter for instant sync across actions
  const [dashboardVersion, setDashboardVersion] = useState(0);

  const products = useMemo(() => storeService.getProducts(activeCompany.id), [activeCompany.id, dashboardVersion]);
  const orders = useMemo(() => storeService.getOrders(activeCompany.id), [activeCompany.id, dashboardVersion]);
  const settings = useMemo(() => storeService.getStoreSettings(activeCompany.id), [activeCompany.id, dashboardVersion]);
  const posSettings = useMemo(() => storeService.getPOSSettings(activeCompany.id), [activeCompany.id, dashboardVersion]);
  const posTransactions = useMemo(() => storeService.getPOSTransactions(activeCompany.id), [activeCompany.id, dashboardVersion]);
  const consultationRooms = useMemo(() => storeService.getConsultationRooms(activeCompany.id), [activeCompany.id, dashboardVersion]);

  // Master Reset & Zeroing Security State
  const [masterResetLock, setMasterResetLock] = useState(() => storeService.getMasterResetLock(activeCompany.id));
  const [isZeroConfirmModalOpen, setIsZeroConfirmModalOpen] = useState(false);
  const [zeroActionType, setZeroActionType] = useState<'products' | 'revenues' | 'dashboard' | 'restore' | null>(null);
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [confirmError, setConfirmError] = useState('');
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [unlockPasswordInput, setUnlockPasswordInput] = useState('');
  const [unlockModalError, setUnlockModalError] = useState('');
  const [masterToast, setMasterToast] = useState<{ title: string; message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Panel Brightness State
  const [panelBrightness, setPanelBrightness] = useState(() => storeService.getPanelBrightness(activeCompany.id));
  const [isBrightnessModalOpen, setIsBrightnessModalOpen] = useState(false);

  // Face-to-face video & showroom desk state
  const [consultSettings, setConsultSettings] = useState(() => ({ ...settings }));
  const [quickSaveSuccess, setQuickSaveSuccess] = useState(false);
  const [showAddRoom, setShowAddRoom] = useState(false);
  const [quickRoomName, setQuickRoomName] = useState('');
  const [quickRoomClient, setQuickRoomClient] = useState('');
  const [quickRoomLocked, setQuickRoomLocked] = useState(false);

  // Keep states reactive if tenant changes
  useEffect(() => {
    const latest = storeService.getStoreSettings(activeCompany.id);
    setConsultSettings({ ...latest });
    setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
    setDashboardVersion(v => v + 1);
  }, [activeCompany.id]);

  // Real-time synchronization events across tabs and POS updates
  useEffect(() => {
    const handleSync = () => {
      setDashboardVersion(v => v + 1);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
    };
    window.addEventListener('atelier_dashboard_reset', handleSync);
    window.addEventListener('atelier_revenue_reset', handleSync);
    window.addEventListener('atelier_products_updated', handleSync);
    window.addEventListener('master_reset_lock_changed', handleSync);
    window.addEventListener('pos_sale_broadcast', handleSync);
    window.addEventListener('pos_inventory_synced', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('atelier_dashboard_reset', handleSync);
      window.removeEventListener('atelier_revenue_reset', handleSync);
      window.removeEventListener('atelier_products_updated', handleSync);
      window.removeEventListener('master_reset_lock_changed', handleSync);
      window.removeEventListener('pos_sale_broadcast', handleSync);
      window.removeEventListener('pos_inventory_synced', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, [activeCompany.id]);

  // Master Lock Toggle Handler
  const handleToggleMasterLock = () => {
    if (masterResetLock.isLocked) {
      setUnlockPasswordInput('');
      setUnlockModalError('');
      setIsUnlockModalOpen(true);
    } else {
      storeService.toggleMasterResetLock(true, currentUser?.name, activeCompany.id);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
      setMasterToast({
        title: 'Master Controls Secured',
        message: 'Master Reset & Zeroing controls are now locked. System data is protected against accidental modifications.',
        type: 'info'
      });
      setTimeout(() => setMasterToast(null), 4000);
    }
  };

  // Master Unlock Form Submit
  const handleConfirmMasterUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    setUnlockModalError('');
    const input = unlockPasswordInput.trim();
    const validPassword = activeCompany.adminPassword || 'admin123';

    if (input === validPassword || input === 'admin123' || currentUser?.roleId === 'super-admin') {
      storeService.toggleMasterResetLock(false, currentUser?.name, activeCompany.id);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
      setIsUnlockModalOpen(false);
      setMasterToast({
        title: 'Master Controls Unlocked',
        message: 'Administrator authorization confirmed. Master zeroing controls are armed.',
        type: 'success'
      });
      setTimeout(() => setMasterToast(null), 4000);
    } else {
      setUnlockModalError('Incorrect administrator credentials. Default is "admin123" or company admin password.');
    }
  };

  // Open Zeroing Confirmation Dialog
  const handleOpenZeroAction = (action: 'products' | 'revenues' | 'dashboard' | 'restore') => {
    if (masterResetLock.isLocked && action !== 'restore') {
      setUnlockPasswordInput('');
      setUnlockModalError('');
      setIsUnlockModalOpen(true);
      return;
    }
    setZeroActionType(action);
    setConfirmPasswordInput('');
    setConfirmError('');
    setIsZeroConfirmModalOpen(true);
  };

  // Execute Zeroing / Restore Action
  const handleExecuteZeroAction = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmError('');
    const input = confirmPasswordInput.trim();
    const validPassword = activeCompany.adminPassword || 'admin123';

    let isAuthorized = false;
    if (input === validPassword || input === 'admin123') {
      isAuthorized = true;
    } else if (zeroActionType === 'products' && (input.toUpperCase() === 'DELETE-PRODUCTS' || input.toUpperCase() === 'DELETE')) {
      isAuthorized = true;
    } else if (zeroActionType === 'revenues' && (input.toUpperCase() === 'DELETE-REVENUES' || input.toUpperCase() === 'DELETE')) {
      isAuthorized = true;
    } else if (zeroActionType === 'dashboard' && (input.toUpperCase() === 'CONFIRM-ZERO' || input.toUpperCase() === 'RESTART' || input.toUpperCase() === 'ZERO')) {
      isAuthorized = true;
    } else if (zeroActionType === 'restore' && (input.toUpperCase() === 'RESTORE' || input.toUpperCase() === 'RESTORE-DEMO')) {
      isAuthorized = true;
    }

    if (!isAuthorized) {
      setConfirmError('Invalid authorization PIN or confirmation phrase. Please enter "admin123" or the prompt keyword.');
      return;
    }

    try {
      if (zeroActionType === 'products') {
        storeService.deleteAllProducts(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Catalog Specimens Deleted',
          message: 'All catalog items and variants deleted. Product count sent to 0.',
          type: 'success'
        });
      } else if (zeroActionType === 'revenues') {
        storeService.deleteAllRevenues(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Dashboard Revenues Deleted',
          message: 'All customer order history and Showroom POS receipts cleared. Verified revenue reset to GH₵0.00.',
          type: 'success'
        });
      } else if (zeroActionType === 'dashboard') {
        storeService.restartDashboardToZero(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Dashboard Restarted to Zero',
          message: 'Full master reset executed: products, orders, POS sales, and verified revenues set to zero.',
          type: 'success'
        });
      } else if (zeroActionType === 'restore') {
        storeService.restoreDemoData(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Factory Demo Data Restored',
          message: 'Catalog specimens, inventory records, and demo orders have been repopulated.',
          type: 'success'
        });
      }

      setIsZeroConfirmModalOpen(false);
      setDashboardVersion(v => v + 1);
      setTimeout(() => setMasterToast(null), 5000);
    } catch (err: any) {
      setConfirmError(err?.message || 'Failed to execute operation.');
    }
  };

  // Save & Apply Changes
  const handleSaveAndApply = () => {
    window.dispatchEvent(new CustomEvent('atelier_dashboard_reset', { detail: { tenantId: activeCompany.id } }));
    window.dispatchEvent(new CustomEvent('storage'));
    storeService.addAuditLog(
      currentUser?.name || 'Administrator',
      'super-admin',
      'SAVE_AND_APPLY_DASHBOARD',
      'EnterpriseDashboard',
      activeCompany.id,
      'Saved and applied master dashboard configuration and verified real-time sync across system.',
      activeCompany.id
    );
    setDashboardVersion(v => v + 1);
    setMasterToast({
      title: 'Changes Saved & Applied',
      message: 'Dashboard state committed to local storage and broadcast to all live tabs and components.',
      type: 'success'
    });
    setTimeout(() => setMasterToast(null), 4000);
  };

  const handleToggleCallLock = () => {
    const nextLocked = !consultSettings.videoConsultationLocked;
    setConsultSettings(prev => ({ ...prev, videoConsultationLocked: nextLocked }));
    storeService.toggleVideoConsultationLock(nextLocked, currentUser?.name, activeCompany.id);
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isLocked: nextLocked })
    }).catch(() => {});
    setQuickSaveSuccess(true);
    setTimeout(() => setQuickSaveSuccess(false), 3000);
  };

  const handleToggleContactLock = () => {
    const nextLocked = !consultSettings.contactLocked;
    setConsultSettings(prev => ({ ...prev, contactLocked: nextLocked, contactLastSavedBy: currentUser?.name || 'Administrator' }));
    storeService.toggleContactDetailsLock(nextLocked, currentUser?.name, activeCompany.id);
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        showroomContact: {
          address: consultSettings.showroomAddress,
          gps: consultSettings.ghanaPostGps,
          phone: consultSettings.contactPhone,
          email: consultSettings.contactEmail,
          isLocked: nextLocked
        }
      })
    }).catch(() => {});
    setQuickSaveSuccess(true);
    setTimeout(() => setQuickSaveSuccess(false), 3000);
  };

  const handleSaveShowroomAndVideo = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    storeService.updateStoreSettings(consultSettings, currentUser?.name, activeCompany.id);

    // Sync with active company context so storefront header/footer/pages update immediately
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        showroomAddress: consultSettings.showroomAddress,
        ghanaPostGps: consultSettings.ghanaPostGps,
        contactPhone: consultSettings.contactPhone,
        contactEmail: consultSettings.contactEmail
      });
    }

    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        isLocked: !!consultSettings.videoConsultationLocked,
        lockReason: consultSettings.videoLockMessage,
        consultantName: consultSettings.videoConsultantName,
        consultantTitle: consultSettings.videoConsultantTitle,
        consultantLocation: consultSettings.videoConsultantLocation,
        consultantAvailable: !!consultSettings.videoConsultantAvailable,
        consultantHours: consultSettings.videoConsultantHours,
        showroomContact: {
          address: consultSettings.showroomAddress,
          gps: consultSettings.ghanaPostGps,
          phone: consultSettings.contactPhone,
          email: consultSettings.contactEmail,
          isLocked: !!consultSettings.contactLocked
        }
      })
    }).catch(() => {});
    setQuickSaveSuccess(true);
    setTimeout(() => setQuickSaveSuccess(false), 3500);
  };

  const handleApplyOfficialAccraDefaults = () => {
    setConsultSettings(prev => ({
      ...prev,
      showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
      ghanaPostGps: 'GA-110-3849',
      contactPhone: '0542443125/0596334488',
      contactEmail: 'concierge@ateliersurfaces.com'
    }));
  };

  const handleQuickCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickRoomName.trim()) return;
    const roomId = `atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`;
    storeService.saveConsultationRoom({
      id: roomId,
      name: quickRoomName.trim(),
      createdAt: new Date().toISOString(),
      isLocked: quickRoomLocked,
      clientName: quickRoomClient.trim() || 'General Client',
      clientRole: 'architect',
      consultantName: consultSettings.videoConsultantName || 'Kwame Mensah',
      scheduledTime: 'Active Session',
      activeParticipantsCount: 0
    }, currentUser?.name, activeCompany.id);
    fetch('/api/video/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        roomId,
        name: quickRoomName.trim(),
        clientName: quickRoomClient.trim(),
        isLocked: quickRoomLocked
      })
    }).catch(() => {});
    setQuickRoomName('');
    setQuickRoomClient('');
    setShowAddRoom(false);
    setQuickSaveSuccess(true);
    setTimeout(() => setQuickSaveSuccess(false), 3000);
  };

  const [stockTab, setStockTab] = useState<'all' | 'out_of_stock' | 'critical' | 'warning'>('all');
  const [stockSearchQuery, setStockSearchQuery] = useState('');
  const [displayLimit, setDisplayLimit] = useState(6);

  const currencySymbol = settings.currencySymbol || (settings.currency === 'USD' ? '$' : settings.currency === 'EUR' ? '€' : settings.currency === 'GBP' ? '£' : 'GH₵');

  // Metrics
  const paidOrders = orders.filter(o => o.paymentStatus === 'paid');
  const posTotalRevenue = posTransactions.reduce((acc, p) => acc + p.total, 0);
  const verifiedRevenue = paidOrders.reduce((acc, o) => acc + o.total, 0) + posTotalRevenue;
  const pendingOrdersCount = orders.filter(o => o.orderStatus === 'pending' || o.paymentStatus === 'verification_required').length;
  const isZeroState = storeService.isDashboardZeroed(activeCompany.id) || (products.length === 0 && orders.length === 0 && verifiedRevenue === 0);

  // Low stock variants calculation across all products
  const lowStockItems: LowStockItem[] = [];
  products.forEach(p => {
    p.variants.forEach(v => {
      if (v.stock <= v.lowStockThreshold) {
        const isOutOfStock = v.stock <= 0;
        const isCritical = !isOutOfStock && v.stock <= Math.max(1, Math.round(v.lowStockThreshold * 0.4));
        const percentRemaining = Math.min(100, Math.round((v.stock / (v.lowStockThreshold || 1)) * 100));
        lowStockItems.push({
          productId: p.id,
          productName: p.name,
          productSlug: p.slug,
          categoryName: p.categoryName || 'Surface Slab',
          material: p.material || 'Porcelain',
          variantId: v.id,
          variantColor: v.colorName,
          colorHex: v.colorHex || '#D4AF37',
          sku: v.sku,
          stock: v.stock,
          threshold: v.lowStockThreshold,
          unit: v.unit || 'm²',
          image: v.images?.[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg',
          price: v.price,
          isOutOfStock,
          isCritical,
          percentRemaining
        });
      }
    });
  });

  // Sort: Out of stock first, then critical, then lowest percentage
  lowStockItems.sort((a, b) => {
    if (a.isOutOfStock !== b.isOutOfStock) return a.isOutOfStock ? -1 : 1;
    if (a.isCritical !== b.isCritical) return a.isCritical ? -1 : 1;
    return a.percentRemaining - b.percentRemaining;
  });

  const outOfStockCount = lowStockItems.filter(i => i.isOutOfStock).length;
  const criticalCount = lowStockItems.filter(i => i.isCritical).length;
  const warningCount = lowStockItems.filter(i => !i.isOutOfStock && !i.isCritical).length;

  const filteredLowStockItems = lowStockItems.filter(item => {
    if (stockTab === 'out_of_stock' && !item.isOutOfStock) return false;
    if (stockTab === 'critical' && !item.isCritical) return false;
    if (stockTab === 'warning' && (item.isOutOfStock || item.isCritical)) return false;
    if (stockSearchQuery.trim()) {
      const q = stockSearchQuery.toLowerCase();
      return (
        item.productName.toLowerCase().includes(q) ||
        item.variantColor.toLowerCase().includes(q) ||
        item.sku.toLowerCase().includes(q) ||
        item.material.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const visibleLowStockItems = filteredLowStockItems.slice(0, displayLimit);

  return (
    <AdminLayout
      title="Enterprise Dashboard & Analytics"
      subtitle="Real-time verified revenue, pallet logistics, inventory allocation, and warehouse replenishment alerts."
      actions={
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setIsBrightnessModalOpen(true)}
            className="px-3 py-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-700 dark:text-amber-300 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="Adjust & lock panel brightness"
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span>Panels {panelBrightness.workspaceBrightness}% {panelBrightness.isLocked ? '(Locked)' : ''}</span>
          </button>
          <Link
            href="/admin/pos"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Showroom POS</span>
          </Link>
          <Link
            href="/admin/analytics"
            className="px-4 py-2 bg-[var(--theme-accent)] hover:opacity-95 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Sales Analytics</span>
          </Link>
          <Link
            href="/admin/video-consultations"
            className="px-4 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 hover:border-[var(--theme-text)] transition-colors shadow-xs"
          >
            <Video className="w-3.5 h-3.5 text-emerald-500" />
            <span>Video & Showroom Lock Desk</span>
          </Link>
          <Link
            href="/admin/products/new"
            className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity"
          >
            + New Surface Specimen
          </Link>
          <Link
            href="/admin/inventory"
            className="px-4 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] transition-colors"
          >
            Stock Adjustments
          </Link>
        </div>
      }
    >
      {/* Quick Stats Widget: Real-time inventory alerts, daily sales volume, pending video consultations */}
      <div 
        style={{
          filter: `brightness(${panelBrightness.cardsBrightness}%) contrast(${panelBrightness.cardsContrast}%)`
        }}
        className="transition-all duration-150"
      >
        <QuickStatsWidget
          lowStockItems={lowStockItems}
          orders={orders}
          posTransactions={posTransactions}
          rooms={consultationRooms}
          currencySymbol={currencySymbol}
        />
      </div>

      {/* Low Stock Warning Banner if any items are below threshold */}
      {lowStockItems.length > 0 && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500" />
            </span>
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>
              <strong>Warehouse Reorder Warning:</strong> {lowStockItems.length} tile variant(s) are at or below safety stock threshold ({outOfStockCount} out of stock).
            </span>
          </div>
          <Link
            href="/admin/inventory?lowStock=true"
            className="font-bold underline text-amber-800 dark:text-amber-300 hover:opacity-80 shrink-0 inline-flex items-center gap-1"
          >
            <span>Open Inventory Adjustments</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      )}

      {/* Master Toast Notification */}
      {masterToast && (
        <div 
          className={`p-4 border text-xs flex items-center justify-between gap-3 shadow-lg transition-all animate-in fade-in duration-200 ${
            masterToast.type === 'success' 
              ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-100'
              : masterToast.type === 'error'
              ? 'bg-red-950/90 border-red-500/60 text-red-100'
              : 'bg-stone-900 border-amber-500/60 text-amber-100'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {masterToast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : masterToast.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            ) : (
              <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <div>
              <strong className="font-bold uppercase tracking-wider block text-[11px]">
                {masterToast.title}
              </strong>
              <span className="text-[12px] opacity-90">{masterToast.message}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMasterToast(null)}
            className="text-stone-400 hover:text-stone-100 p-1 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ========================================================= */}
      {/* MASTER SYSTEM RESET & CATALOG ZEROING CONTROL DESK        */}
      {/* ========================================================= */}
      <section 
        aria-label="Master System Reset & Catalog Zeroing Control Desk"
        className="bg-stone-950 border-2 border-stone-800 text-stone-100 shadow-xl p-5 space-y-4"
      >
        {/* Header Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-stone-800 pb-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                Admin Master Control Desk
              </span>
              {masterResetLock.isLocked ? (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-red-950/80 text-red-300 border border-red-800 font-bold">
                  <Lock className="w-3.5 h-3.5 text-red-400" />
                  <span>Controls Secured · Locked</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-emerald-950/80 text-emerald-300 border border-emerald-800 font-bold animate-pulse">
                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Controls Armed · Unlocked</span>
                </span>
              )}
              {isZeroState && (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-purple-950/80 text-purple-300 border border-purple-800 font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Zero State Active (GH₵0.00 / 0 Products)</span>
                </span>
              )}
              <span className="text-[10px] text-stone-400 font-mono">
                Logged in: <strong className="text-stone-200">{currentUser?.name || 'Administrator'}</strong> ({currentUser?.roleName || 'Super Admin'})
              </span>
            </div>
            <h2 className="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
              <span>Catalog & Revenue Zeroing Control Station</span>
              <span className="text-stone-400 text-xs font-normal">[{activeCompany.name}]</span>
            </h2>
            <p className="text-[11px] text-stone-400">
              Administrative master controls to wipe catalog items, clear customer revenues, or restart entire dashboard to zero with persistent save, real-time sync, and security lock.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap shrink-0">
            {/* Lock / Unlock Toggle Button */}
            <button
              type="button"
              onClick={handleToggleMasterLock}
              className={`px-3.5 py-2 text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer border shadow-sm ${
                masterResetLock.isLocked
                  ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border-stone-600'
              }`}
              title={masterResetLock.isLocked ? 'Authenticate with admin credentials to unlock zeroing actions' : 'Lock controls to prevent accidental wipes'}
            >
              {masterResetLock.isLocked ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Unlock className="w-3.5 h-3.5 text-emerald-400" />}
              <span>{masterResetLock.isLocked ? 'Unlock Master Controls' : 'Lock Master Controls'}</span>
            </button>

            {/* Save & Apply Changes */}
            <button
              type="button"
              onClick={handleSaveAndApply}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer shadow-md"
              title="Save current state to storage and sync live across all tabs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Apply Changes</span>
            </button>
          </div>
        </div>

        {/* 4 Action Tiles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Action 1: Delete All Products */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <Boxes className="w-3.5 h-3.5 text-amber-400" />
                  <span>Delete All Products</span>
                </span>
                <span className="text-[10px] font-mono text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded-xs">
                  {products.length} Products
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Wipes all catalog surface specimens, variations, and stock allocations down to 0.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('products')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-950/50 hover:bg-red-900/70 text-red-300 border border-red-800/90 cursor-pointer'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to delete products' : 'Delete all products'}
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Delete All Products</span>
            </button>
          </div>

          {/* Action 2: Delete All Revenues */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Delete All Revenues</span>
                </span>
                <span className="text-[10px] font-mono text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded-xs">
                  {currencySymbol}{verifiedRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Clears all customer orders and Showroom POS receipts, sending verified revenue to GH₵0.00.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('revenues')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-950/50 hover:bg-red-900/70 text-red-300 border border-red-800/90 cursor-pointer'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to clear revenues' : 'Delete all revenues'}
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Delete All Revenues</span>
            </button>
          </div>

          {/* Action 3: Restart Dashboard to Zero */}
          <div className="bg-stone-900/90 border border-amber-900/60 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Restart Dashboard</span>
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 bg-red-950 text-red-400 border border-red-800 font-bold">
                  TOTAL ZERO
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Master reset: wipes catalog products, orders, POS sales, and revenues all to 0 simultaneously.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('dashboard')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-600 hover:bg-red-500 text-white cursor-pointer shadow-md'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to restart dashboard' : 'Restart dashboard sending all to zero'}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Restart All to Zero</span>
            </button>
          </div>

          {/* Action 4: Restore Factory Demo Data */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Restore Demo Data</span>
                </span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-1.5 py-0.5">
                  RECOVERY
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Safely reload default catalog specimens, sample orders, and demo revenue after zeroing.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleOpenZeroAction('restore')}
              className="w-full py-2.5 px-3 bg-cyan-950/50 hover:bg-cyan-900/70 text-cyan-300 border border-cyan-800/80 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              title="Repopulate demo products and order records"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Restore Factory Data</span>
            </button>
          </div>
        </div>

        {/* Lock Notice banner if controls are locked */}
        {masterResetLock.isLocked && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Master Protection Active:</strong> System zeroing controls are locked against unauthorized clicks. Click "Unlock Master Controls" with administrator credentials to arm controls.
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleMasterLock}
              className="text-[11px] underline font-bold text-amber-400 hover:text-amber-300 uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
            >
              Authenticate & Unlock
            </button>
          </div>
        )}
      </section>

      {/* ========================================================= */}
      {/* ADMIN BROADCAST SYSTEM (STAFF & CUSTOMER BANNER ENGINE)   */}
      {/* ========================================================= */}
      <div id="admin-broadcast-system">
        <AdminBroadcastDesk />
      </div>

      {/* KPI Cards Strip with live card brightness/contrast filter */}
      <div 
        style={{
          filter: `brightness(${panelBrightness.cardsBrightness}%) contrast(${panelBrightness.cardsContrast}%)`
        }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 transition-all duration-150"
      >
        
        {/* Verified Revenue */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2">
          <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)]">
            <span className="font-bold uppercase tracking-wider">Verified Revenue</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            {currencySymbol}{verifiedRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[11px] text-[var(--theme-text-muted)]">
            From {paidOrders.length} confirmed customer orders.
          </p>
        </div>

        {/* Total Orders */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2">
          <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)]">
            <span className="font-bold uppercase tracking-wider">Total Orders</span>
            <ShoppingCart className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            {orders.length} Orders
          </div>
          <p className="text-[11px] text-amber-600 font-semibold">
            {pendingOrdersCount} pending settlement/review.
          </p>
        </div>

        {/* Catalog Specimens */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2">
          <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)]">
            <span className="font-bold uppercase tracking-wider">Catalog & Variants</span>
            <Boxes className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            {products.length} Products
          </div>
          <p className="text-[11px] text-[var(--theme-text-muted)]">
            {products.reduce((acc, p) => acc + p.variants.length, 0)} active color variations.
          </p>
        </div>

        {/* Low Stock Alerts - Clickable to Inventory View */}
        <Link
          href="/admin/inventory?lowStock=true"
          className="bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-amber-500/50 p-6 space-y-2 transition-all block group"
          title="Click to view all low stock products in inventory view"
        >
          <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)]">
            <span className="font-bold uppercase tracking-wider group-hover:text-amber-600 transition-colors">
              Inventory Alerts
            </span>
            <AlertTriangle className={`w-4 h-4 ${lowStockItems.length > 0 ? 'text-amber-600 animate-pulse' : 'text-[var(--theme-text-muted)]'}`} />
          </div>
          <div className="text-2xl font-bold tabular-nums text-amber-600 dark:text-amber-400 flex items-center justify-between">
            <span>{lowStockItems.length} Variants</span>
            <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <p className="text-[11px] text-[var(--theme-text-muted)]">
            {outOfStockCount > 0 ? `${outOfStockCount} out of stock. ` : ''}Click to open inventory editor.
          </p>
        </Link>
      </div>

      {/* ========================================================= */}
      {/* AUTONOMOUS AI TILE SHOP AGENT COMMAND BAR                 */}
      {/* ========================================================= */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] relative shrink-0">
            <Bot className="w-5 h-5 text-[var(--theme-accent)]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                Autonomous AI Tile Shop Agent
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 font-bold uppercase">
                Active · 24/7 Operations
              </span>
              <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                Model: Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
              Handling customer tile calculations, box packaging estimates, Ghana freight rates, sample kit requests, and store operational alerts.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              const chatBtn = document.querySelector('button[title*="Open Atelier Autonomous AI Tile Shop Agent"]') as HTMLButtonElement | null;
              if (chatBtn) chatBtn.click();
            }}
            className="px-3 py-1.5 bg-[var(--theme-accent)] hover:opacity-90 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Launch Agent Desk</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SHOWROOM POS TERMINAL & PANEL ILLUMINANCE SUITE           */}
      {/* ========================================================= */}
      <section 
        aria-label="Showroom POS Terminal & Panel Illumination Suite"
        className="bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-sm space-y-4 p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-600 dark:text-emerald-400">
                Showroom Checkout & Display Command
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-semibold">
                Register: {posSettings.registerName}
              </span>
              {posSettings.isLocked ? (
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-red-500/10 border border-red-500/30 text-red-500 flex items-center gap-1 font-bold">
                  <Lock className="w-2.5 h-2.5" />
                  <span>POS CONFIG LOCKED</span>
                </span>
              ) : (
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <Unlock className="w-2.5 h-2.5" />
                  <span>POS CONFIG EDITABLE</span>
                </span>
              )}
            </div>
            <h2 className="font-serif-luxury text-xl font-bold text-[var(--theme-text)] flex items-center gap-2.5">
              <CreditCard className="w-5 h-5 text-emerald-600" />
              <span>Showroom POS & Admin Display Brightness Controls</span>
            </h2>
            <p className="text-xs text-[var(--theme-text-muted)]">
              Process walk-in showroom purchases with barcode scanning and thermal receipts, configure custom POS features, and calibrate/lock panel brightness.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Link
              href="/admin/pos"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Launch POS Terminal</span>
            </Link>

            <Link
              href="/admin/pos/settings"
              className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Configure POS Features</span>
            </Link>

            <button
              type="button"
              onClick={() => setIsBrightnessModalOpen(true)}
              className="px-3.5 py-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-700 dark:text-amber-300 text-xs font-bold uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Quick Brightness</span>
            </button>

            <Link
              href="/admin/settings/brightness"
              className="px-3.5 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Full Panel Studio</span>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-1 text-xs">
          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Tax Calculation</span>
            <div className="font-bold text-[var(--theme-text)] capitalize">{posSettings.taxCalculationMode} ({posSettings.taxRatePercent}%)</div>
            <span className="text-[10px] text-[var(--theme-text-muted)]">GRA Standard</span>
          </div>

          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Max Cashier Discount</span>
            <div className="font-bold text-[var(--theme-text)]">{posSettings.maxCashierDiscountPercent}% Cap</div>
            <span className="text-[10px] text-amber-600 font-semibold">PIN: {posSettings.requireSupervisorDiscountPin ? 'Required' : 'Disabled'}</span>
          </div>

          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Receipt Format</span>
            <div className="font-bold text-[var(--theme-text)]">{posSettings.receiptPrinterWidth} Thermal</div>
            <span className="text-[10px] text-[var(--theme-text-muted)] font-mono truncate block">
              {posSettings.receiptShowGps ? (settings.ghanaPostGps || 'GA-110-3849') : 'GPS Suppressed'}
            </span>
          </div>

          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Payment Tenders</span>
            <div className="font-bold text-[var(--theme-text)] flex items-center gap-1">
              <span>{posSettings.enabledPaymentMethods.cash ? 'Cash' : ''}</span>
              <span>{posSettings.enabledPaymentMethods.mobileMoney ? '· MoMo' : ''}</span>
              <span>{posSettings.enabledPaymentMethods.card ? '· Card' : ''}</span>
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold">
              {posSettings.autoDeductInventory ? 'Auto-Stock Decrement' : 'Manual Audit'}
            </span>
          </div>

          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Display Luminance</span>
            <div className="font-bold text-[var(--theme-text)] flex items-center gap-1.5">
              <span>SF: {panelBrightness.storefrontHeroBrightness ?? 100}%</span>
              <span>· Ws: {panelBrightness.workspaceBrightness}%</span>
            </div>
            <span className="text-[10px] text-[var(--theme-text-muted)] truncate block">SB: {panelBrightness.sidebarBrightness}% · POS: {panelBrightness.posBrightness}%</span>
          </div>

          <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-1">
            <span className="text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider block">Brightness Security</span>
            <div className={`font-bold flex items-center gap-1 ${panelBrightness.isLocked ? 'text-amber-600' : 'text-emerald-600'}`}>
              {panelBrightness.isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
              <span>{panelBrightness.isLocked ? 'LOCKED' : 'UNLOCKED'}</span>
            </div>
            <span className="text-[10px] text-[var(--theme-text-muted)] truncate block" title={panelBrightness.lockedBy || 'Admin'}>
              By: {panelBrightness.lockedBy || 'Admin'}
            </span>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* FACE-TO-FACE VIDEO ONLINE CALLS & SHOWROOM MASTER CONSOLE */}
      {/* ========================================================= */}
      <section 
        aria-label="Face-to-Face Video Online Calls & Showroom Desk"
        className="bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-sm space-y-6 p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Admin Operations Console
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]">
                Tenant: {activeCompany.name}
              </span>
            </div>
            <h2 className="font-serif-luxury text-2xl font-bold text-[var(--theme-text)] flex items-center gap-2.5">
              <Video className="w-5 h-5 text-[var(--theme-accent)]" />
              <span>Face-to-Face Video Online Calls & Showroom Desk</span>
            </h2>
            <p className="text-xs text-[var(--theme-text-muted)]">
              Admin can edit, add, save, make changes, and lock both real-time face-to-face video consultation calls and official flagship showroom coordinates.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              type="button"
              onClick={() => handleSaveShowroomAndVideo()}
              className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>

            <Link
              href="/admin/video-consultations"
              className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Open Dedicated Desk</span>
            </Link>
          </div>
        </div>

        {quickSaveSuccess && (
          <div className="p-3.5 bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in rounded-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="font-semibold">
              Changes and locks saved successfully for Face-to-Face Video Calls and Showroom records.
            </span>
          </div>
        )}

        {/* Master 2-Column Split: Video Calls on Left, Showroom on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* CARD 1: FACE-TO-FACE VIDEO ONLINE CALLS */}
          <div className={`p-5 border rounded-xs transition space-y-4 ${
            consultSettings.videoConsultationLocked 
              ? 'bg-red-950/20 border-red-500/40' 
              : 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)]'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className={`w-5 h-5 ${consultSettings.videoConsultationLocked ? 'text-red-500' : 'text-emerald-500'}`} />
                <div>
                  <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
                    Face-to-Face Video Online Calls
                  </h3>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">
                    Two-way encrypted WebRTC calls with 3D slab co-viewing & chat
                  </span>
                </div>
              </div>

              <span className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded-xs ${
                consultSettings.videoConsultationLocked 
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {consultSettings.videoConsultationLocked ? 'LOCKED / RESTRICTED' : 'ACTIVE & ONLINE'}
              </span>
            </div>

            {/* Lock/Unlock Toggle Button */}
            <div className="flex items-center justify-between p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs">
              <div className="text-xs">
                <span className="font-bold text-[var(--theme-text)] block">
                  {consultSettings.videoConsultationLocked ? 'Consultation Calls are Locked' : 'Consultation Calls are Open'}
                </span>
                <span className="text-[11px] text-[var(--theme-text-muted)]">
                  {consultSettings.videoConsultationLocked
                    ? 'Storefront visitors cannot initiate unapproved calls.'
                    : 'Visitors and architects can start or join live consultations.'}
                </span>
              </div>

              <button
                type="button"
                onClick={handleToggleCallLock}
                className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                  consultSettings.videoConsultationLocked
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-red-600 hover:bg-red-500 text-white'
                }`}
              >
                {consultSettings.videoConsultationLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{consultSettings.videoConsultationLocked ? 'Unlock Video Calls' : 'Lock Video Calls'}</span>
              </button>
            </div>

            {/* Quick Edit Consultant & Operational Hours */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Lead Consultant Name
                </label>
                <input
                  type="text"
                  value={consultSettings.videoConsultantName || 'Kwame Mensah'}
                  onChange={e => setConsultSettings(prev => ({ ...prev, videoConsultantName: e.target.value }))}
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Consultant Title
                </label>
                <input
                  type="text"
                  value={consultSettings.videoConsultantTitle || 'Lead Architectural Consultant'}
                  onChange={e => setConsultSettings(prev => ({ ...prev, videoConsultantTitle: e.target.value }))}
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Operational Consultation Hours
                </label>
                <input
                  type="text"
                  value={consultSettings.videoConsultantHours || 'Mon–Sat: 8:00 AM – 6:00 PM GMT'}
                  onChange={e => setConsultSettings(prev => ({ ...prev, videoConsultantHours: e.target.value }))}
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Lockdown Notice (Displayed to visitors when calls are locked)
                </label>
                <input
                  type="text"
                  value={consultSettings.videoLockMessage || ''}
                  onChange={e => setConsultSettings(prev => ({ ...prev, videoLockMessage: e.target.value }))}
                  placeholder="Video consultations are currently locked for a private architectural masterclass. Please contact the concierge."
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                />
              </div>
            </div>

            {/* Quick Add Video Room Trigger / Form */}
            <div className="pt-2 border-t border-[var(--theme-border)]">
              {showAddRoom ? (
                <form onSubmit={handleQuickCreateRoom} className="p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between text-xs font-bold uppercase">
                    <span>Provision New Consultation Room</span>
                    <button type="button" onClick={() => setShowAddRoom(false)} className="text-stone-400 hover:text-white">✕</button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <input
                      type="text"
                      required
                      placeholder="Room Topic (e.g. Ridge Penthouse Slabs)"
                      value={quickRoomName}
                      onChange={e => setQuickRoomName(e.target.value)}
                      className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                    <input
                      type="text"
                      placeholder="Client Name / Practice"
                      value={quickRoomClient}
                      onChange={e => setQuickRoomClient(e.target.value)}
                      className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-1.5 text-[11px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={quickRoomLocked}
                        onChange={e => setQuickRoomLocked(e.target.checked)}
                        className="accent-red-500"
                      />
                      <span>Create locked</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => setShowAddRoom(false)} className="px-2.5 py-1 border border-[var(--theme-border)] text-xs">Cancel</button>
                      <button type="submit" className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase">Add Room</button>
                    </div>
                  </div>
                </form>
              ) : (
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setShowAddRoom(true)}
                    className="text-xs font-bold uppercase text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add New Consultation Room</span>
                  </button>

                  <Link
                    href="/video-consultation"
                    target="_blank"
                    className="text-xs font-semibold text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] flex items-center gap-1"
                  >
                    <span>Preview Call Screen</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* CARD 2: OFFICIAL ACCRA FLAGSHIP SHOWROOM DESK */}
          <div className={`p-5 border rounded-xs transition space-y-4 ${
            consultSettings.contactLocked 
              ? 'bg-amber-950/20 border-amber-500/40' 
              : 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)]'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className={`w-5 h-5 ${consultSettings.contactLocked ? 'text-amber-500' : 'text-[var(--theme-accent)]'}`} />
                <div>
                  <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
                    Ridge West Flagship Showroom Desk
                  </h3>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">
                    Official coordinates, GhanaPost GPS routing, invoices & customer inquiries
                  </span>
                </div>
              </div>

              <span className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded-xs ${
                consultSettings.contactLocked 
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {consultSettings.contactLocked ? 'PROTECTED / LOCKED' : 'UNLOCKED (EDITABLE)'}
              </span>
            </div>

            {/* Lock/Unlock Toggle Button */}
            <div className="flex items-center justify-between p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs">
              <div className="text-xs">
                <span className="font-bold text-[var(--theme-text)] block">
                  {consultSettings.contactLocked ? 'Showroom Details are Locked' : 'Showroom Details are Unlocked'}
                </span>
                <span className="text-[11px] text-[var(--theme-text-muted)]">
                  {consultSettings.contactLocked
                    ? `Locked by ${consultSettings.contactLastSavedBy || 'Admin'}. Prevents unauthorized coordinate edits.`
                    : 'Editable across all regional fields.'}
                </span>
              </div>

              <button
                type="button"
                onClick={handleToggleContactLock}
                className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                  consultSettings.contactLocked
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
                }`}
              >
                {consultSettings.contactLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{consultSettings.contactLocked ? 'Unlock Coordinates' : 'Lock Coordinates'}</span>
              </button>
            </div>

            {/* Editable Fields for 14 Independence Avenue, Ridge West, Accra, Ghana */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Showroom Address *
                </label>
                <input
                  type="text"
                  required
                  disabled={consultSettings.contactLocked}
                  value={consultSettings.showroomAddress}
                  onChange={e => setConsultSettings(prev => ({ ...prev, showroomAddress: e.target.value }))}
                  placeholder="14 Independence Avenue, Ridge West, Accra, Ghana"
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium disabled:opacity-60 disabled:cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  GhanaPost GPS Code *
                </label>
                <input
                  type="text"
                  required
                  disabled={consultSettings.contactLocked}
                  value={consultSettings.ghanaPostGps}
                  onChange={e => setConsultSettings(prev => ({ ...prev, ghanaPostGps: e.target.value.toUpperCase() }))}
                  placeholder="GA-110-3849"
                  className="w-full px-2.5 py-1.5 font-mono uppercase bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-bold disabled:opacity-60 disabled:cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Concierge Contact Phone *
                </label>
                <input
                  type="text"
                  required
                  disabled={consultSettings.contactLocked}
                  value={consultSettings.contactPhone}
                  onChange={e => setConsultSettings(prev => ({ ...prev, contactPhone: e.target.value }))}
                  placeholder="0542443125/0596334488"
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium disabled:opacity-60 disabled:cursor-not-allowed"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                  Concierge Official Email *
                </label>
                <input
                  type="email"
                  required
                  disabled={consultSettings.contactLocked}
                  value={consultSettings.contactEmail}
                  onChange={e => setConsultSettings(prev => ({ ...prev, contactEmail: e.target.value }))}
                  placeholder="concierge@ateliersurfaces.com"
                  className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-medium disabled:opacity-60 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            {/* Actions for Showroom Card */}
            <div className="pt-2 border-t border-[var(--theme-border)] flex items-center justify-between">
              <button
                type="button"
                onClick={handleApplyOfficialAccraDefaults}
                className="text-xs font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1 cursor-pointer"
                title="Reset to 14 Independence Avenue, Ridge West, Accra, Ghana"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset to Official Accra Flagship</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveShowroomAndVideo()}
                className="px-4 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition cursor-pointer flex items-center gap-1"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Coordinates</span>
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* ========================================================= */}
      {/* LOW STOCK PRODUCTS INVENTORY WIDGET                       */}
      {/* ========================================================= */}
      <section 
        aria-label="Low Stock Inventory Alerts"
        className="bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-sm overflow-hidden"
      >
        {/* Widget Header with Status & Direct Links */}
        <div className="p-5 sm:p-6 bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-sm bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600 dark:text-amber-400">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
                    Low Stock Inventory Alerts
                  </h3>
                  {lowStockItems.length > 0 && (
                    <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-[10px] font-bold uppercase font-mono tracking-wider">
                      {lowStockItems.length} Reorder Items
                    </span>
                  )}
                </div>
                <p className="text-xs text-[var(--theme-text-muted)]">
                  Products and color variants below safe replenishment levels. Click <strong>"Adjust Stock"</strong> to open the live adjustment modal.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Link
              href="/admin/inventory?lowStock=true"
              className="px-3.5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-xs hover:opacity-90 transition-opacity cursor-pointer shrink-0"
              title="Open all items in the inventory manager"
            >
              <Boxes className="w-3.5 h-3.5" />
              <span>Full Inventory View</span>
              <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
            </Link>
          </div>
        </div>

        {/* Filter Controls & Search Strip */}
        {lowStockItems.length > 0 && (
          <div className="px-5 py-3 border-b border-[var(--theme-border)] bg-[var(--theme-surface)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            {/* Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setStockTab('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors cursor-pointer shrink-0 ${
                  stockTab === 'all'
                    ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] shadow-xs'
                    : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] hover:bg-[var(--theme-surface-subtle)]'
                }`}
              >
                All Low Stock ({lowStockItems.length})
              </button>

              {outOfStockCount > 0 && (
                <button
                  type="button"
                  onClick={() => setStockTab('out_of_stock')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                    stockTab === 'out_of_stock'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-red-600 dark:text-red-400 hover:bg-red-500/10'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Out of Stock ({outOfStockCount})</span>
                </button>
              )}

              {criticalCount > 0 && (
                <button
                  type="button"
                  onClick={() => setStockTab('critical')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors cursor-pointer shrink-0 ${
                    stockTab === 'critical'
                      ? 'bg-rose-700 text-white shadow-xs'
                      : 'text-rose-600 dark:text-rose-400 hover:bg-rose-500/10'
                  }`}
                >
                  <span>Critical &lt; 40% ({criticalCount})</span>
                </button>
              )}

              {warningCount > 0 && (
                <button
                  type="button"
                  onClick={() => setStockTab('warning')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors cursor-pointer shrink-0 ${
                    stockTab === 'warning'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-amber-600 dark:text-amber-400 hover:bg-amber-500/10'
                  }`}
                >
                  <span>Buffer Warning ({warningCount})</span>
                </button>
              )}
            </div>

            {/* Quick Search inside Widget */}
            <div className="relative w-full sm:w-64">
              <input
                type="text"
                value={stockSearchQuery}
                onChange={e => setStockSearchQuery(e.target.value)}
                placeholder="Filter by product or SKU..."
                className="w-full pl-8 pr-7 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
              <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {stockSearchQuery && (
                <button
                  onClick={() => setStockSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Empty State: All Stock Levels Optimal */}
        {lowStockItems.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
              All Surface Inventories Are Optimal
            </h4>
            <p className="text-xs text-[var(--theme-text-muted)] max-w-md mx-auto leading-relaxed">
              Every warehouse variant meets or exceeds safety stock buffers. No factory crate reorders required at this time.
            </p>
            <div className="pt-2">
              <Link
                href="/admin/inventory"
                className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider text-[var(--theme-text)] inline-flex items-center gap-1.5 transition-colors"
              >
                <Boxes className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <span>Inspect Live Inventory</span>
              </Link>
            </div>
          </div>
        ) : filteredLowStockItems.length === 0 ? (
          <div className="p-8 text-center text-xs text-[var(--theme-text-muted)] space-y-2">
            <p>No low stock products match the current filter or search criteria.</p>
            <button
              onClick={() => { setStockTab('all'); setStockSearchQuery(''); }}
              className="text-[var(--theme-accent)] font-semibold underline hover:opacity-80"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="divide-y divide-[var(--theme-border-subtle)]">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[var(--theme-text)]">
                <thead>
                  <tr className="bg-[var(--theme-surface-subtle)]/60 text-[10px] uppercase font-bold text-[var(--theme-text-muted)] border-b border-[var(--theme-border)]">
                    <th className="py-3 px-5">Surface Specimen</th>
                    <th className="py-3 px-4">Variant & SKU</th>
                    <th className="py-3 px-4 min-w-[160px]">Stock vs. Threshold</th>
                    <th className="py-3 px-4">Urgency</th>
                    <th className="py-3 px-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                  {visibleLowStockItems.map(item => {
                    const healthPercentage = Math.min(100, Math.max(0, Math.round((item.stock / (item.threshold || 1)) * 100)));
                    const inventoryEditUrl = `/admin/inventory?search=${encodeURIComponent(item.sku)}&adjustVariant=${item.variantId}`;
                    const productEditUrl = `/admin/products/${item.productId}/edit`;

                    return (
                      <tr 
                        key={`${item.productId}-${item.variantId}`}
                        className="hover:bg-[var(--theme-surface-subtle)]/50 transition-colors group"
                      >
                        {/* Product Specimen with Thumbnail */}
                        <td className="py-3.5 px-5">
                          <div className="flex items-center gap-3">
                            <div className="w-11 h-11 rounded-xs overflow-hidden bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] shrink-0 relative">
                              <img
                                src={item.image ? (item.image.startsWith('/src/assets/') ? item.image.replace('/src/assets/', '/assets/') : item.image) : '/assets/images/category_porcelain_floors_1792523066985.jpg'}
                                alt={item.productName}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                                }}
                              />
                            </div>
                            <div className="min-w-0">
                              <Link
                                href={productEditUrl}
                                className="font-semibold text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-colors line-clamp-1 block text-sm"
                                title="Click to edit product specimen"
                              >
                                {item.productName}
                              </Link>
                              <div className="flex items-center gap-1.5 text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                                <span className="font-medium text-[var(--theme-accent)]">{item.material}</span>
                                <span>·</span>
                                <span className="truncate">{item.categoryName}</span>
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Variant & SKU */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-medium">
                              <span
                                className="w-3 h-3 rounded-full border border-black/20 shrink-0"
                                style={{ backgroundColor: item.colorHex }}
                                title={`Hex: ${item.colorHex}`}
                              />
                              <span className="truncate">{item.variantColor}</span>
                            </div>
                            <span className="font-mono text-[10px] text-[var(--theme-text-muted)] block tracking-wider">
                              {item.sku}
                            </span>
                          </div>
                        </td>

                        {/* Stock Level & Health Bar Gauge */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-1.5">
                            <div className="flex items-baseline justify-between text-xs">
                              <span className={`font-bold tabular-nums text-sm ${
                                item.isOutOfStock 
                                  ? 'text-red-600 dark:text-red-400' 
                                  : item.isCritical 
                                  ? 'text-rose-600 dark:text-rose-400' 
                                  : 'text-amber-600 dark:text-amber-400'
                              }`}>
                                {item.stock} {item.unit}
                              </span>
                              <span className="text-[11px] text-[var(--theme-text-muted)] font-mono">
                                Min: {item.threshold} {item.unit}
                              </span>
                            </div>

                            {/* Visual Progress Gauge */}
                            <div className="w-full h-1.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                              <div
                                className={`h-full transition-all duration-500 rounded-full ${
                                  item.isOutOfStock 
                                    ? 'w-0' 
                                    : item.isCritical 
                                    ? 'bg-rose-500' 
                                    : 'bg-amber-500'
                                }`}
                                style={{ width: `${healthPercentage}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-[var(--theme-text-muted)] font-mono block">
                              {item.isOutOfStock ? '0% available' : `${healthPercentage}% of safety buffer`}
                            </span>
                          </div>
                        </td>

                        {/* Urgency Badge */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {item.isOutOfStock ? (
                            <span className="px-2.5 py-1 bg-red-100 dark:bg-red-950/60 text-red-800 dark:text-red-300 border border-red-300 dark:border-red-800 text-[10px] font-bold uppercase tracking-wider rounded-xs inline-flex items-center gap-1 shadow-2xs">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping" />
                              <span>Out of Stock</span>
                            </span>
                          ) : item.isCritical ? (
                            <span className="px-2.5 py-1 bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800 text-[10px] font-bold uppercase tracking-wider rounded-xs inline-flex items-center gap-1">
                              <AlertCircle className="w-3 h-3 text-rose-600 shrink-0" />
                              <span>Critical (&lt; 40%)</span>
                            </span>
                          ) : (
                            <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800 text-[10px] font-bold uppercase tracking-wider rounded-xs inline-flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                              <span>Low Buffer</span>
                            </span>
                          )}
                        </td>

                        {/* Direct Actions: Links to Inventory Edit View & Product Spec Edit */}
                        <td className="py-3.5 px-5 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-2">
                            {/* Primary: Direct link to Inventory Edit View with auto-opened adjustment modal */}
                            <Link
                              href={inventoryEditUrl}
                              className="px-3 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] hover:opacity-90 font-bold uppercase tracking-wider text-[11px] rounded-xs inline-flex items-center gap-1 shadow-xs transition-opacity cursor-pointer"
                              title={`Directly edit stock level for ${item.productName} (${item.variantColor})`}
                            >
                              <Plus className="w-3 h-3" />
                              <span>Adjust Stock</span>
                            </Link>

                            {/* Secondary: Edit product specimen details */}
                            <Link
                              href={productEditUrl}
                              className="p-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] rounded-xs transition-colors cursor-pointer inline-flex items-center"
                              title="Edit product specimen specifications"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Widget Footer Strip with Pagination & Deep Link */}
            <div className="p-4 bg-[var(--theme-surface-subtle)]/40 border-t border-[var(--theme-border)] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[var(--theme-text-muted)]">
              <div>
                Showing <strong>{visibleLowStockItems.length}</strong> of <strong>{filteredLowStockItems.length}</strong> low stock alert(s).
              </div>

              <div className="flex items-center gap-3">
                {filteredLowStockItems.length > displayLimit && (
                  <button
                    type="button"
                    onClick={() => setDisplayLimit(prev => prev + 6)}
                    className="font-semibold text-[var(--theme-accent)] hover:underline cursor-pointer"
                  >
                    Load More Alerts ({filteredLowStockItems.length - displayLimit} remaining)
                  </button>
                )}

                <Link
                  href="/admin/inventory?lowStock=true"
                  className="font-bold text-[var(--theme-text)] hover:text-[var(--theme-accent)] underline inline-flex items-center gap-1"
                >
                  <span>Open Complete Inventory Management</span>
                  <ExternalLink className="w-3 h-3" />
                </Link>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Main Tables Grid: Recent Orders & Quick System Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Recent Orders (Span 8) */}
        <div className="lg:col-span-8 bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
              Recent Orders & Verified Receipts
            </h3>
            <Link href="/admin/orders" className="text-xs uppercase font-semibold text-[var(--theme-accent)] hover:underline">
              View All ({orders.length})
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[var(--theme-text)]">
              <thead>
                <tr className="border-b border-[var(--theme-border)] text-[var(--theme-text-muted)] uppercase text-[10px] font-bold">
                  <th className="pb-3">Order Number</th>
                  <th className="pb-3">Client</th>
                  <th className="pb-3">Destination</th>
                  <th className="pb-3">Total ({settings.currency})</th>
                  <th className="pb-3">Payment</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                {orders.slice(0, 5).map(o => (
                  <tr key={o.id} className="hover:bg-[var(--theme-surface-subtle)] transition-colors">
                    <td className="py-3 font-mono font-bold text-[var(--theme-text)]">
                      {o.orderNumber}
                    </td>
                    <td className="py-3">
                      <span className="font-medium block">{o.customerSnapshot.name}</span>
                      <span className="text-[11px] text-[var(--theme-text-muted)]">{o.customerSnapshot.phone}</span>
                    </td>
                    <td className="py-3 text-[11px] text-[var(--theme-text-muted)]">
                      {o.shippingAddress.city} {o.shippingAddress.ghanaPostGps ? `(${o.shippingAddress.ghanaPostGps})` : ''}
                    </td>
                    <td className="py-3 font-bold tabular-nums">
                      {currencySymbol}{o.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3">
                      <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-xs ${
                        o.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {o.paymentStatus.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 capitalize">
                      {o.orderStatus}
                    </td>
                    <td className="py-3 text-right">
                      <Link
                        href={`/admin/orders/${o.id}`}
                        className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[11px] font-semibold hover:border-[var(--theme-accent)] transition-colors inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Inspect</span>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Regional Status & Inventory Health (Span 4) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
            <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-3">
              Warehouse Stock Health
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between items-center p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)]">Total Active SKUs:</span>
                <strong className="font-mono font-bold text-sm">
                  {products.reduce((acc, p) => acc + p.variants.length, 0)}
                </strong>
              </div>

              <div className="flex justify-between items-center p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-200">
                <span>Healthy Stock Levels:</span>
                <strong className="font-mono font-bold text-sm">
                  {products.reduce((acc, p) => acc + p.variants.length, 0) - lowStockItems.length}
                </strong>
              </div>

              <div className="flex justify-between items-center p-3 bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-200">
                <span>Needs Factory Reorder:</span>
                <strong className="font-mono font-bold text-sm text-amber-600 dark:text-amber-400">
                  {lowStockItems.length}
                </strong>
              </div>

              <Link
                href="/admin/inventory"
                className="w-full py-2.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-center text-xs font-semibold uppercase tracking-wider block transition-colors"
              >
                Inspect Pallet Allocations &rarr;
              </Link>
            </div>
          </div>

          {/* Quick System Status */}
          <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-5 text-xs text-[var(--theme-text-muted)] space-y-2">
            <span className="font-bold uppercase tracking-wider text-[var(--theme-text)] block">
              Regional Engine Status
            </span>
            <div className="flex justify-between">
              <span>Currency:</span>
              <strong className="text-[var(--theme-text)]">{settings.currency} ({currencySymbol})</strong>
            </div>
            <div className="flex justify-between">
              <span>VAT / NHIL:</span>
              <strong className="text-[var(--theme-text)]">{settings.taxRatePercent}%</strong>
            </div>
            <div className="flex justify-between">
              <span>Payment Gateway:</span>
              <strong className="text-[var(--theme-text)]">Paystack Live/Test Engine</strong>
            </div>
            <div className="flex justify-between">
              <span>Showroom Depot:</span>
              <strong className="text-[var(--theme-text)] truncate max-w-[180px]">{settings.showroomAddress}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Master Control Unlock Modal */}
      {isUnlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-100">
                    Administrator Authentication
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Unlock Master Reset & Zeroing Station
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUnlockModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {unlockModalError && (
              <div className="p-3 bg-red-950/70 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{unlockModalError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmMasterUnlock} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-400 mb-1 font-mono text-[11px]">
                  Master Administrator Password
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={unlockPasswordInput}
                  onChange={e => setUnlockPasswordInput(e.target.value)}
                  placeholder="Enter administrator password..."
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[11px] text-stone-500 mt-1">
                  Default: <code className="text-amber-400">admin123</code> or active company credentials.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsUnlockModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Authenticate & Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Master Zero Confirmation Modal */}
      {isZeroConfirmModalOpen && zeroActionType && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border-2 border-red-600/60 w-full max-w-lg p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-500/20 border border-red-500/40 text-red-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-red-200 uppercase tracking-wide">
                    {zeroActionType === 'products' && 'Confirm: Delete All Catalog Products'}
                    {zeroActionType === 'revenues' && 'Confirm: Delete All Dashboard Revenues'}
                    {zeroActionType === 'dashboard' && 'Critical: Restart Dashboard to Zero'}
                    {zeroActionType === 'restore' && 'Restore Factory Demo Data'}
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Workspace: <strong className="text-stone-200">{activeCompany.name}</strong> ({activeCompany.id})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsZeroConfirmModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Warning Message Box */}
            <div className={`p-3.5 border text-xs space-y-1.5 ${
              zeroActionType === 'restore' 
                ? 'bg-cyan-950/40 border-cyan-800/80 text-cyan-200' 
                : 'bg-red-950/50 border-red-800/80 text-red-200'
            }`}>
              <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[11px]">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>
                  {zeroActionType === 'restore' ? 'Factory Recovery Operation' : 'Destructive Master Action Warning'}
                </span>
              </div>
              <p className="text-[11px] leading-relaxed text-stone-300">
                {zeroActionType === 'products' && (
                  `This will permanently delete all ${products.length} catalog items and their variations for "${activeCompany.name}". Product count will immediately show 0 across the dashboard and inventory view.`
                )}
                {zeroActionType === 'revenues' && (
                  `This will wipe all customer orders and Showroom POS receipts for "${activeCompany.name}". Verified revenue will immediately drop to GH₵0.00 and total orders will show 0.`
                )}
                {zeroActionType === 'dashboard' && (
                  `This will execute a complete system restart sending all metrics to zero: all ${products.length} catalog products, all customer orders, and all showroom POS revenue will be completely cleared.`
                )}
                {zeroActionType === 'restore' && (
                  `This will restore default architectural tile specimens, stock allocations, and demo customer orders for "${activeCompany.name}".`
                )}
              </p>
            </div>

            {confirmError && (
              <div className="p-3 bg-red-950/80 border border-red-500/60 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{confirmError}</span>
              </div>
            )}

            <form onSubmit={handleExecuteZeroAction} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                  Confirm Action: Enter Administrator Password or{' '}
                  <span className="text-amber-400 font-mono">
                    "{zeroActionType === 'products' ? 'DELETE-PRODUCTS' : zeroActionType === 'revenues' ? 'DELETE-REVENUES' : zeroActionType === 'dashboard' ? 'CONFIRM-ZERO' : 'RESTORE'}"
                  </span>
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={confirmPasswordInput}
                  onChange={e => setConfirmPasswordInput(e.target.value)}
                  placeholder={`Enter admin123 or ${zeroActionType === 'products' ? 'DELETE-PRODUCTS' : zeroActionType === 'revenues' ? 'DELETE-REVENUES' : zeroActionType === 'dashboard' ? 'CONFIRM-ZERO' : 'RESTORE'}...`}
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsZeroConfirmModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md ${
                    zeroActionType === 'restore'
                      ? 'bg-cyan-600 hover:bg-cyan-500 text-white'
                      : 'bg-red-600 hover:bg-red-500 text-white'
                  }`}
                >
                  {zeroActionType === 'restore' ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Execute Restore</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Confirm & Execute Wipe</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Panel Brightness Calibration Modal */}
      <AdminBrightnessController
        isOpen={isBrightnessModalOpen}
        onClose={() => setIsBrightnessModalOpen(false)}
        onUpdate={(newConfig) => setPanelBrightness(newConfig)}
      />
    </AdminLayout>
  );
}
