import { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { Product, ProductVariant } from '../../types';
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Save, 
  AlertCircle, 
  Check, 
  Layers, 
  Image as ImageIcon,
  UploadCloud
} from 'lucide-react';

interface AdminProductEditPageProps {
  productId?: string;
}

export function AdminProductEditPage({ productId }: AdminProductEditPageProps) {
  const { navigate } = useRouter();
  const { currentUser, hasPermission } = useAuth();
  const isNew = !productId || productId === 'new';
  const existingProduct = productId && !isNew ? storeService.getProductById(productId) : null;
  const categories = storeService.getCategories();

  // Basic Details State
  const [name, setName] = useState(existingProduct?.name || '');
  const [slug, setSlug] = useState(existingProduct?.slug || '');
  const [description, setDescription] = useState(existingProduct?.description || '');
  const [categoryId, setCategoryId] = useState(existingProduct?.categoryId || categories[0]?.id || 'floor-tiles');
  const [material, setMaterial] = useState<Product['material']>(existingProduct?.material || 'Porcelain');
  const [size, setSize] = useState(existingProduct?.size || '60x120 cm');
  const [thickness, setThickness] = useState(existingProduct?.thickness || '9 mm');
  const [finish, setFinish] = useState<Product['finish']>(existingProduct?.finish || 'Polished');
  const [applications, setApplications] = useState<string>(existingProduct?.applications.join(', ') || 'Floor, Wall, Interior');
  
  // Specifications
  const [waterAbsorption, setWaterAbsorption] = useState(existingProduct?.specifications.waterAbsorption || '< 0.05%');
  const [slipResistance, setSlipResistance] = useState(existingProduct?.specifications.slipResistance || 'R10');
  const [origin, setOrigin] = useState(existingProduct?.specifications.origin || 'Italy');
  const [rectified, setRectified] = useState(existingProduct?.specifications.rectified ?? true);

  // Variants State (At least 1 variant required)
  const [variants, setVariants] = useState<ProductVariant[]>(() => {
    if (existingProduct?.variants && existingProduct.variants.length > 0) {
      return JSON.parse(JSON.stringify(existingProduct.variants));
    }
    return [
      {
        id: `var-${Date.now()}-1`,
        colorName: 'Pure Ivory',
        colorHex: '#F5F2EB',
        sku: 'AS-NEW-IVR-01',
        images: ['/assets/images/category_porcelain_floors_1792523066985.jpg'],
        price: 380,
        compareAtPrice: 420,
        stock: 200,
        lowStockThreshold: 30,
        unit: 'm²',
        boxCoverage: 1.44,
        active: true
      }
    ];
  });

  const [active, setActive] = useState(existingProduct?.active ?? true);
  const [featured, setFeatured] = useState(existingProduct?.featured ?? false);
  const [errorMsg, setErrorMsg] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Auto-generate slug from name if creating new
  const handleNameChange = (val: string) => {
    setName(val);
    if (isNew) {
      setSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, ''));
    }
  };

  const handleAddVariant = () => {
    const newVar: ProductVariant = {
      id: `var-${Date.now()}-${variants.length + 1}`,
      colorName: 'New Color Variant',
      colorHex: '#B69A62',
      sku: `AS-${(slug || 'SPEC').toUpperCase().substring(0, 4)}-${Math.floor(100 + Math.random() * 900)}`,
      images: ['/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'],
      price: variants[0]?.price || 350,
      stock: 100,
      lowStockThreshold: 20,
      unit: variants[0]?.unit || 'm²',
      boxCoverage: variants[0]?.boxCoverage || 1.44,
      active: true
    };
    setVariants([...variants, newVar]);
  };

  const handleRemoveVariant = (variantId: string) => {
    if (variants.length <= 1) {
      alert('Every architectural surface must maintain at least one active color variation.');
      return;
    }
    setVariants(variants.filter(v => v.id !== variantId));
  };

  const handleUpdateVariant = (variantId: string, updates: Partial<ProductVariant>) => {
    setVariants(prev => prev.map(v => v.id === variantId ? { ...v, ...updates } : v));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name.trim() || !slug.trim()) {
      setErrorMsg('Please specify product title and slug.');
      return;
    }

    if (variants.length === 0) {
      setErrorMsg('Please configure at least one color variation.');
      return;
    }

    const catObj = categories.find(c => c.id === categoryId) || categories[0];

    const productPayload: Product = {
      id: existingProduct?.id || `prod-${Date.now()}`,
      name: name.trim(),
      slug: slug.trim(),
      description: description.trim(),
      categoryId: catObj.id,
      categoryName: catObj.name,
      material,
      size: size.trim(),
      thickness: thickness.trim(),
      finish,
      applications: applications.split(',').map(s => s.trim()).filter(Boolean),
      specifications: {
        waterAbsorption,
        slipResistance,
        origin,
        rectified
      },
      featured,
      active,
      variants,
      rating: existingProduct?.rating || 4.9,
      reviewCount: existingProduct?.reviewCount || 1,
      createdAt: existingProduct?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    storeService.saveProduct(productPayload, currentUser?.name);
    setSaveSuccess(true);
    setTimeout(() => {
      navigate('/admin/products');
    }, 800);
  };

  return (
    <AdminLayout
      title={isNew ? 'New Architectural Specimen' : `Edit Specimen: ${name}`}
      subtitle="Configure material taxonomy, technical standards, and independent color variation galleries."
      actions={
        <Link
          href="/admin/products"
          className="px-3 py-1.5 border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 hover:border-[var(--theme-text)]"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Catalog</span>
        </Link>
      }
    >
      {errorMsg && (
        <div className="p-4 bg-red-50 text-red-700 border border-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {saveSuccess && (
        <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>Surface specimen saved to database successfully. Redirecting...</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* Section 1: General Product Meta */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-3">
            1. Surface Identity & General Specifications
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Specimen Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => handleNameChange(e.target.value)}
                placeholder="e.g. Calacatta Statuario Imperiale"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                URL Slug *
              </label>
              <input
                type="text"
                required
                value={slug}
                onChange={e => setSlug(e.target.value)}
                placeholder="calacatta-statuario"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-mono focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Category *
              </label>
              <select
                value={categoryId}
                onChange={e => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              >
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Material Composition
              </label>
              <select
                value={material}
                onChange={e => setMaterial(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              >
                <option value="Porcelain">Vitrified Porcelain</option>
                <option value="Marble">Natural Marble</option>
                <option value="Natural Stone">Natural Stone / Quartzite</option>
                <option value="Travertine">Roman Travertine</option>
                <option value="Ceramic">Glazed Ceramic / Zellige</option>
                <option value="Terrazzo">Venetian Terrazzo</option>
                <option value="Sintered Stone">Sintered Stone Compact</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Surface Finish
              </label>
              <select
                value={finish}
                onChange={e => setFinish(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              >
                <option value="Polished">High-Gloss Polished</option>
                <option value="Honed">Velvet Honed / Satin</option>
                <option value="Matte">Architectural Matte</option>
                <option value="Textured">Textured Anti-Slip (R11)</option>
                <option value="Bush-hammered">Bush-hammered Split</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Format Dimensions
              </label>
              <input
                type="text"
                value={size}
                onChange={e => setSize(e.target.value)}
                placeholder="60x120 cm / 120x240 cm"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Thickness
              </label>
              <input
                type="text"
                value={thickness}
                onChange={e => setThickness(e.target.value)}
                placeholder="9 mm / 12 mm / 20 mm"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Slip Rating (DIN 51130)
              </label>
              <input
                type="text"
                value={slipResistance}
                onChange={e => setSlipResistance(e.target.value)}
                placeholder="R10 / PTV 36+"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Quarry Origin
              </label>
              <input
                type="text"
                value={origin}
                onChange={e => setOrigin(e.target.value)}
                placeholder="Sassuolo, Italy"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Spatial Applications (Comma separated)
              </label>
              <input
                type="text"
                value={applications}
                onChange={e => setApplications(e.target.value)}
                placeholder="Floor, Wall, Bathroom, Kitchen, Outdoor, Commercial"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Architectural Editorial Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe stone geology, veining characteristics, lighting response..."
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Color Variations & Independent Image Galleries (Mandatory) */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--theme-border)] pb-3">
            <div>
              <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
                2. Color Variations & Dedicated Galleries ({variants.length})
              </h2>
              <p className="text-xs text-[var(--theme-text-muted)]">
                Each color variation maintains its own SKU, price, stock quantity, box coverage, and dedicated photography.
              </p>
            </div>
            <button
              type="button"
              onClick={handleAddVariant}
              className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Add Color Variant</span>
            </button>
          </div>

          <div className="space-y-6">
            {variants.map((v, idx) => (
              <div
                key={v.id}
                className="p-5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-4"
              >
                <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-4 h-4 rounded-full border border-black/20"
                      style={{ backgroundColor: v.colorHex }}
                    />
                    <strong className="text-sm font-semibold text-[var(--theme-text)]">
                      Variant {idx + 1}: {v.colorName}
                    </strong>
                    <span className="font-mono text-[11px] text-[var(--theme-text-muted)]">({v.sku})</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveVariant(v.id)}
                    className="text-red-600 hover:text-red-800 p-1 flex items-center gap-1 text-[11px]"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Variant</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Color Name</label>
                    <input
                      type="text"
                      value={v.colorName}
                      onChange={e => handleUpdateVariant(v.id, { colorName: e.target.value })}
                      className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs"
                    />
                  </div>

                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Color Hex</label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="color"
                        value={v.colorHex}
                        onChange={e => handleUpdateVariant(v.id, { colorHex: e.target.value })}
                        className="w-7 h-7 rounded border border-black/10 cursor-pointer"
                      />
                      <input
                        type="text"
                        value={v.colorHex}
                        onChange={e => handleUpdateVariant(v.id, { colorHex: e.target.value })}
                        className="w-full px-2 py-1 font-mono text-xs uppercase bg-[var(--theme-surface)] border border-[var(--theme-border)]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">SKU</label>
                    <input
                      type="text"
                      value={v.sku}
                      onChange={e => handleUpdateVariant(v.id, { sku: e.target.value })}
                      className="w-full px-2.5 py-1.5 font-mono bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs"
                    />
                  </div>

                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Price (GH₵)</label>
                    <input
                      type="number"
                      min="1"
                      value={v.price}
                      onChange={e => handleUpdateVariant(v.id, { price: parseFloat(e.target.value) || 0 })}
                      className="w-full px-2.5 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Available Stock ({v.unit})</label>
                    <input
                      type="number"
                      min="0"
                      value={v.stock}
                      onChange={e => handleUpdateVariant(v.id, { stock: parseInt(e.target.value, 10) || 0 })}
                      className="w-full px-2.5 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold text-emerald-800"
                    />
                  </div>

                  <div>
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Box Coverage (m²)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={v.boxCoverage}
                      onChange={e => handleUpdateVariant(v.id, { boxCoverage: parseFloat(e.target.value) || 1.44 })}
                      className="w-full px-2.5 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs"
                    />
                  </div>

                  {/* Dedicated Images */}
                  <div className="col-span-2 sm:col-span-4 lg:col-span-6 pt-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block uppercase font-bold text-[var(--theme-text-muted)] text-[11px]">
                        Variant Photography & Slabs
                      </label>
                      <label className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold uppercase tracking-wider cursor-pointer transition shadow-xs">
                        <UploadCloud className="w-3.5 h-3.5" />
                        <span>Upload Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = evt => {
                                if (evt.target?.result) {
                                  handleUpdateVariant(v.id, {
                                    images: [evt.target.result as string, ...v.images]
                                  });
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                    </div>
                    <input
                      type="text"
                      value={v.images.join(', ')}
                      onChange={e => handleUpdateVariant(v.id, { images: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                      placeholder="Comma-separated image URLs or data URLs..."
                      className="w-full px-2.5 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-mono"
                    />
                    <div className="flex flex-wrap gap-2 mt-2">
                      {v.images.map((img, i) => (
                        <div key={i} className="relative group">
                          <img 
                            src={img.startsWith('/src/assets/') ? img.replace('/src/assets/', '/assets/') : img} 
                            alt="Thumb" 
                            className="w-12 h-12 object-cover border border-[var(--theme-border)] bg-stone-100" 
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                            }}
                          />
                          {v.images.length > 1 && (
                            <button
                              type="button"
                              onClick={() => {
                                const newImgs = v.images.filter((_, idx) => idx !== i);
                                handleUpdateVariant(v.id, { images: newImgs });
                              }}
                              className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                              title="Remove image"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Publishing Flags */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6 text-xs">
            <label className="flex items-center gap-2 font-semibold cursor-pointer">
              <input
                type="checkbox"
                checked={active}
                onChange={e => setActive(e.target.checked)}
                className="accent-[var(--theme-accent)]"
              />
              <span>Published to Storefront Catalog</span>
            </label>

            <label className="flex items-center gap-2 font-semibold cursor-pointer">
              <input
                type="checkbox"
                checked={featured}
                onChange={e => setFeatured(e.target.checked)}
                className="accent-[var(--theme-accent)]"
              />
              <span>Featured on Homepage</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2 shadow-md cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Surface Specimen</span>
          </button>
        </div>
      </form>
    </AdminLayout>
  );
}
