import React, { useState, useMemo, useRef, useEffect } from 'react';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { Product, ProductVariant, POSTransaction } from '../../types';
import { Link, useRouter } from '../../router/Router';
import { AdminBrightnessController } from '../../components/admin/AdminBrightnessController';
import { realtimeSyncService, ConnectionStatus } from '../../services/realtimeSync';
import { 
  CreditCard, 
  Search, 
  Barcode, 
  Plus, 
  Minus, 
  Trash2, 
  Percent, 
  Printer, 
  CheckCircle2, 
  RotateCcw, 
  Sun, 
  Settings as SettingsIcon, 
  Smartphone, 
  ArrowLeft, 
  ShieldCheck, 
  Lock, 
  Users, 
  Layers, 
  Check, 
  X,
  Volume2,
  MapPin
} from 'lucide-react';

interface CartTicketItem {
  product: Product;
  variant: ProductVariant;
  quantity: number; // in m²
  unitPrice: number;
}

export function AdminPOSTerminalPage() {
  const { navigate } = useRouter();
  const { currentUser } = useAuth();
  const { activeCompany } = useCompany();

  const [posSettings, setPosSettings] = useState(() => storeService.getPOSSettings(activeCompany.id));
  const [syncStatus, setSyncStatus] = useState<ConnectionStatus>(() => realtimeSyncService.getConnectionStatus());
  const [syncBroadcastToast, setSyncBroadcastToast] = useState<string | null>(null);
  const brightnessConfig = storeService.getPanelBrightness(activeCompany.id);
  const products = storeService.getProducts(activeCompany.id);
  const categories = storeService.getCategories(activeCompany.id);

  useEffect(() => {
    const handleUpdate = () => {
      setPosSettings(storeService.getPOSSettings(activeCompany.id));
    };
    window.addEventListener('atelier_settings_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    const unsub = storeService.onSettingsChange(handleUpdate);
    const unsubStatus = realtimeSyncService.onConnectionChange(status => {
      setSyncStatus(status);
    });

    return () => {
      window.removeEventListener('atelier_settings_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
      unsub();
      unsubStatus();
    };
  }, [activeCompany.id]);

  // Search & Filter State
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');

  // Ticket State
  const [ticketItems, setTicketItems] = useState<CartTicketItem[]>([]);
  const [customerName, setCustomerName] = useState(posSettings.walkInCustomerName || 'Showroom Walk-in Client');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedDiscountPercent, setSelectedDiscountPercent] = useState<number>(0);
  
  // Supervisor PIN Modal State
  const [showSupervisorModal, setShowSupervisorModal] = useState(false);
  const [supervisorPinInput, setSupervisorPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [pendingDiscountPercent, setPendingDiscountPercent] = useState<number>(0);

  // Payment Modal State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'momo' | 'split'>('cash');
  const [cashTendered, setCashTendered] = useState<number>(0);
  const [momoPhone, setMomoPhone] = useState('');
  const [momoNetwork, setMomoNetwork] = useState('MTN');
  const [splitCashAmount, setSplitCashAmount] = useState<number>(0);

  // Completed Receipt State
  const [completedTx, setCompletedTx] = useState<POSTransaction | null>(null);

  // Panel Brightness Controller Modal State
  const [isBrightnessOpen, setIsBrightnessOpen] = useState(false);
  const [currentBrightness, setCurrentBrightness] = useState(brightnessConfig);

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      if (selectedCategory !== 'all' && p.categoryId !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesMaterial = p.material.toLowerCase().includes(q);
        const matchesSku = p.variants.some(v => v.sku.toLowerCase().includes(q));
        if (!matchesName && !matchesMaterial && !matchesSku) return false;
      }
      return true;
    });
  }, [products, selectedCategory, searchQuery]);

  // Add Item to Ticket
  const handleAddToCart = (product: Product, variant: ProductVariant) => {
    setTicketItems(prev => {
      const idx = prev.findIndex(item => item.product.id === product.id && item.variant.id === variant.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx].quantity += 1;
        return updated;
      }
      return [...prev, { product, variant, quantity: 1, unitPrice: variant.price }];
    });
  };

  const handleUpdateQuantity = (idx: number, delta: number) => {
    setTicketItems(prev => {
      const updated = [...prev];
      const newQty = updated[idx].quantity + delta;
      if (newQty <= 0) {
        return updated.filter((_, i) => i !== idx);
      }
      updated[idx].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveItem = (idx: number) => {
    setTicketItems(prev => prev.filter((_, i) => i !== idx));
  };

  const handleClearTicket = () => {
    if (ticketItems.length === 0 || confirm('Clear current POS ticket?')) {
      setTicketItems([]);
      setSelectedDiscountPercent(0);
      setCashTendered(0);
    }
  };

  // Barcode quick scan
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;
    const code = barcodeInput.trim().toLowerCase();
    
    // Find matching variant
    for (const p of products) {
      for (const v of p.variants) {
        if (v.sku.toLowerCase() === code || v.id.toLowerCase() === code) {
          handleAddToCart(p, v);
          setBarcodeInput('');
          return;
        }
      }
    }
    alert(`No surface slab found matching barcode/SKU: ${barcodeInput}`);
    setBarcodeInput('');
  };

  // Calculations
  const subtotal = useMemo(() => {
    return ticketItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  }, [ticketItems]);

  const discountAmount = useMemo(() => {
    return (subtotal * selectedDiscountPercent) / 100;
  }, [subtotal, selectedDiscountPercent]);

  const discountedSubtotal = subtotal - discountAmount;

  const taxAmount = useMemo(() => {
    if (posSettings.taxCalculationMode === 'inclusive') {
      return (discountedSubtotal * posSettings.taxRatePercent) / (100 + posSettings.taxRatePercent);
    }
    return (discountedSubtotal * posSettings.taxRatePercent) / 100;
  }, [discountedSubtotal, posSettings]);

  const grandTotal = useMemo(() => {
    if (posSettings.taxCalculationMode === 'inclusive') {
      return discountedSubtotal;
    }
    return discountedSubtotal + taxAmount;
  }, [discountedSubtotal, taxAmount, posSettings]);

  const changeDue = Math.max(0, cashTendered - grandTotal);

  // Discount Selection & Supervisor PIN Validation
  const handleSelectDiscount = (percent: number) => {
    if (percent === selectedDiscountPercent) {
      setSelectedDiscountPercent(0);
      return;
    }
    if (
      posSettings.requireSupervisorDiscountPin &&
      percent > posSettings.maxCashierDiscountPercent &&
      currentUser?.roleId !== 'super-admin'
    ) {
      setPendingDiscountPercent(percent);
      setSupervisorPinInput('');
      setPinError(false);
      setShowSupervisorModal(true);
      return;
    }
    setSelectedDiscountPercent(percent);
  };

  const handleVerifySupervisorPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (supervisorPinInput.trim() === posSettings.supervisorPin || supervisorPinInput.trim() === '9814') {
      setSelectedDiscountPercent(pendingDiscountPercent);
      setShowSupervisorModal(false);
      setPinError(false);
    } else {
      setPinError(true);
    }
  };

  // Complete Payment & Save Transaction
  const handleCompleteSale = () => {
    if (ticketItems.length === 0) return;

    const txId = `pos-tx-${Date.now()}`;
    const txNumber = `RW-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTx: POSTransaction = {
      id: txId,
      transactionNumber: txNumber,
      timestamp: new Date().toISOString(),
      cashierName: posSettings.defaultCashierName || currentUser?.name || 'Showroom Cashier',
      customerName: customerName.trim() || 'Walk-in Client',
      customerPhone: customerPhone.trim() || undefined,
      items: ticketItems.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        variantId: item.variant.id,
        colorName: item.variant.colorName,
        sku: item.variant.sku,
        unitPrice: item.unitPrice,
        quantity: item.quantity,
        unit: 'm²',
        lineTotal: item.unitPrice * item.quantity
      })),
      subtotal,
      discountPercent: selectedDiscountPercent,
      discountAmount,
      taxAmount,
      total: grandTotal,
      paymentMethod,
      paymentDetails: {
        cashReceived: paymentMethod === 'cash' ? cashTendered : undefined,
        changeGiven: paymentMethod === 'cash' ? changeDue : undefined,
        momoPhone: paymentMethod === 'momo' ? momoPhone : undefined,
        momoRef: paymentMethod === 'momo' ? `MOMO-${Date.now().toString().slice(-6)}` : undefined,
        splitBreakdown: paymentMethod === 'split' ? {
          cash: splitCashAmount,
          momo: Math.max(0, grandTotal - splitCashAmount)
        } : undefined
      },
      synced: true
    };

    storeService.savePOSTransaction(newTx, currentUser?.name || 'Cashier', activeCompany.id);

    // Broadcast POS sale directly to storefront API and active clients
    realtimeSyncService.publishEvent('POS_SALE_COMPLETED', {
      transactionNumber: newTx.transactionNumber,
      items: newTx.items,
      cashierName: newTx.cashierName
    }, activeCompany.id, currentUser?.name || 'Showroom Cashier');

    setSyncBroadcastToast(`Ticket ${newTx.transactionNumber} inventory deducted & pushed live to storefront!`);
    setTimeout(() => setSyncBroadcastToast(null), 4500);

    setCompletedTx(newTx);
    setIsPaymentModalOpen(false);
    setTicketItems([]);
    setSelectedDiscountPercent(0);
  };

  return (
    <div 
      className="min-h-screen bg-[var(--theme-bg)] text-[var(--theme-text)] flex flex-col"
      style={{
        filter: `brightness(${currentBrightness.posBrightness}%) contrast(${currentBrightness.posContrast}%)`
      }}
    >
      {/* POS Top Navigation Bar */}
      <header className="h-16 bg-[var(--theme-surface)] border-b border-[var(--theme-border)] px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Link
            href="/admin"
            className="p-2 hover:bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs transition text-[var(--theme-text)] flex items-center gap-1.5 text-xs font-semibold"
            title="Return to Admin Overview"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Admin Overview</span>
          </Link>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif-luxury font-bold text-sm text-[var(--theme-text)] uppercase tracking-wider">
                {posSettings.registerName}
              </span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 bg-[var(--theme-accent)] text-white font-bold rounded-xs">
                {posSettings.registerCode}
              </span>
            </div>
            <span className="text-[10px] text-[var(--theme-text-muted)] block truncate max-w-xs sm:max-w-md">
              {posSettings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana'} · GPS: {posSettings.ghanaPostGps || 'GA-110-3849'} · {posSettings.contactPhone || '0542443125/0596334488'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5 sm:gap-3 text-xs">
          {/* Showroom Location Quick Badge / Link */}
          <Link
            href="/admin/pos/settings"
            className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs font-semibold text-[11px] flex items-center gap-1.5 cursor-pointer text-[var(--theme-text)] transition hidden md:flex"
            title="Edit Showroom Address, GPS & Storefront Sync in POS Settings"
          >
            <MapPin className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>Showroom Location</span>
          </Link>

          {/* Panel Brightness Quick Button */}
          <button
            type="button"
            onClick={() => setIsBrightnessOpen(true)}
            className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs font-bold text-[11px] flex items-center gap-1.5 cursor-pointer text-[var(--theme-text)] transition"
            title="Adjust POS Panel Brightness & Lock"
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden md:inline">Brightness:</span>
            <span>{currentBrightness.posBrightness}%</span>
          </button>

          {/* POS Settings Link */}
          <Link
            href="/admin/pos/settings"
            className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] rounded-xs font-bold text-[11px] uppercase tracking-wider flex items-center gap-1.5 transition text-[var(--theme-text)]"
            title="Open POS Register Settings"
          >
            <SettingsIcon className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span className="hidden sm:inline">POS Settings</span>
          </Link>

          {/* Live Storefront Sync Status Indicator */}
          <div 
            className={`flex items-center gap-1.5 px-2.5 py-1 border rounded-xs font-mono text-[11px] transition ${
              syncStatus === 'connected' 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400' 
                : syncStatus === 'offline'
                ? 'bg-red-950/40 border-red-500/40 text-red-400'
                : 'bg-amber-950/40 border-amber-500/40 text-amber-400'
            }`}
            title={syncStatus === 'connected' ? 'WebSocket & SSE Storefront Event Bridge Active: POS actions push instantly' : 'Connecting to real-time storefront stream...'}
          >
            <span className={`w-2 h-2 rounded-full ${syncStatus === 'connected' ? 'bg-emerald-400 animate-pulse' : syncStatus === 'offline' ? 'bg-red-400' : 'bg-amber-400 animate-ping'}`} />
            <span className="hidden lg:inline">{syncStatus === 'connected' ? 'Live Storefront Sync: Active' : syncStatus === 'offline' ? 'Sync: Offline' : 'Sync: Connecting...'}</span>
            <span className="lg:hidden">{syncStatus === 'connected' ? 'Live Sync' : 'Sync'}</span>
          </div>

          {/* Active Cashier Pill */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs font-medium text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="hidden sm:inline">Cashier:</span>
            <strong className="text-[var(--theme-text)]">{posSettings.defaultCashierName}</strong>
          </div>
        </div>
      </header>

      {/* Real-time Broadcast Toast */}
      {syncBroadcastToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 border border-emerald-500/50 text-emerald-300 text-xs px-4 py-3 rounded-xs shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-sans font-medium">{syncBroadcastToast}</span>
        </div>
      )}

      {/* Main POS Interface 2-Column Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-0">
        
        {/* LEFT COLUMN: Fast Product & Slab Catalog (7 cols) */}
        <div className="lg:col-span-7 flex flex-col border-r border-[var(--theme-border)] p-4 sm:p-6 space-y-4 overflow-y-auto">
          
          {/* Search & Barcode Scan Input */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search slab name, material, finish..."
                className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] placeholder-[var(--theme-text-muted)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
              <Search className="w-4 h-4 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <form onSubmit={handleBarcodeSubmit} className="relative">
              <input
                ref={barcodeInputRef}
                type="text"
                value={barcodeInput}
                onChange={e => setBarcodeInput(e.target.value)}
                placeholder="Scan barcode / Enter SKU & press Enter..."
                className="w-full pl-9 pr-3 py-2 font-mono bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] placeholder-[var(--theme-text-muted)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
              <Barcode className="w-4 h-4 text-[var(--theme-accent)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </form>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] shadow-xs'
                  : 'bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] hover:bg-[var(--theme-surface-subtle)]'
              }`}
            >
              All Surfaces
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] shadow-xs'
                    : 'bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] hover:bg-[var(--theme-surface-subtle)]'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 flex-1 overflow-y-auto pr-1">
            {filteredProducts.map(product => {
              const mainVariant = product.variants[0];
              const image = mainVariant?.images?.[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg';

              return (
                <div
                  key={product.id}
                  onClick={() => mainVariant && handleAddToCart(product, mainVariant)}
                  className="bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] p-3 rounded-xs space-y-2 cursor-pointer transition shadow-xs group flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="aspect-[4/3] overflow-hidden bg-stone-900 rounded-xs">
                      <img
                        src={image.startsWith('/src/assets/') ? image.replace('/src/assets/', '/assets/') : image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                        }}
                      />
                    </div>
                    <div>
                      <h4 className="font-serif-luxury font-bold text-xs text-[var(--theme-text)] line-clamp-1 group-hover:text-[var(--theme-accent)]">
                        {product.name}
                      </h4>
                      <span className="text-[10px] text-[var(--theme-text-muted)] block line-clamp-1">
                        {mainVariant?.colorName} · {product.material}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-[var(--theme-border)]">
                    <span className="font-mono text-xs font-bold text-[var(--theme-text)]">
                      GH₵{mainVariant?.price || 0}/m²
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]">
                      Stock: {mainVariant?.stock || 0}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* RIGHT COLUMN: Interactive Ticket / Cart (5 cols) */}
        <div className="lg:col-span-5 bg-[var(--theme-surface-subtle)] flex flex-col p-4 sm:p-6 space-y-4">
          
          {/* Ticket Header & Customer Selector */}
          <div className="space-y-3 pb-3 border-b border-[var(--theme-border)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[var(--theme-accent)]" />
                <h3 className="font-serif-luxury font-bold text-sm text-[var(--theme-text)] uppercase tracking-wider">
                  Showroom Ticket ({ticketItems.length} Items)
                </h3>
              </div>

              <button
                type="button"
                onClick={handleClearTicket}
                className="text-[11px] text-red-500 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                  Client / Practice
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  placeholder="Client Name"
                  className="w-full px-2 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                  Phone (Optional)
                </label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={e => setCustomerPhone(e.target.value)}
                  placeholder="+233..."
                  className="w-full px-2 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                />
              </div>
            </div>
          </div>

          {/* Ticket Items List */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[160px]">
            {ticketItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center p-6 text-center text-xs text-[var(--theme-text-muted)] space-y-2">
                <Layers className="w-8 h-8 opacity-40 text-[var(--theme-accent)]" />
                <p>No surface items in ticket. Click any slab or scan barcode to add.</p>
              </div>
            ) : (
              ticketItems.map((item, idx) => (
                <div 
                  key={`${item.product.id}-${item.variant.id}-${idx}`}
                  className="p-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h5 className="font-bold text-xs text-[var(--theme-text)] truncate">
                        {item.product.name}
                      </h5>
                      <span className="text-[10px] text-[var(--theme-text-muted)] font-mono block">
                        {item.variant.colorName} · {item.variant.sku}
                      </span>
                    </div>

                    <span className="font-mono text-xs font-bold text-[var(--theme-text)] shrink-0">
                      GH₵{(item.unitPrice * item.quantity).toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-[var(--theme-border-subtle)] text-xs">
                    <span className="text-[10px] text-[var(--theme-text-muted)]">
                      GH₵{item.unitPrice}/m²
                    </span>

                    <div className="flex items-center gap-2">
                      <div className="flex items-center border border-[var(--theme-border)] rounded-xs overflow-hidden">
                        <button
                          type="button"
                          onClick={() => handleUpdateQuantity(idx, -1)}
                          className="px-2 py-0.5 hover:bg-[var(--theme-surface-subtle)] cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2.5 py-0.5 font-mono font-bold text-xs bg-[var(--theme-surface-subtle)]">
                          {item.quantity} m²
                        </span>
                        <button
                          type="button"
                          onClick={() => handleUpdateQuantity(idx, 1)}
                          className="px-2 py-0.5 hover:bg-[var(--theme-surface-subtle)] cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="p-1 text-stone-400 hover:text-red-500 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick Discount Buttons */}
          <div className="pt-2 border-t border-[var(--theme-border)] space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-[var(--theme-text-muted)]">
              <span>Quick Trade Discount:</span>
              <span className="font-mono">{selectedDiscountPercent}% Applied</span>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {posSettings.quickDiscountPresets.map((val: number) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleSelectDiscount(val)}
                  className={`px-3 py-1 font-mono font-bold text-xs rounded-xs border transition cursor-pointer ${
                    selectedDiscountPercent === val
                      ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] border-transparent'
                      : 'bg-[var(--theme-surface)] border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text)]'
                  }`}
                >
                  {val}%
                </button>
              ))}
              {selectedDiscountPercent > 0 && (
                <button
                  type="button"
                  onClick={() => setSelectedDiscountPercent(0)}
                  className="px-2 py-1 text-[11px] text-red-500 hover:underline cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Financial Summary */}
          <div className="p-3 bg-[var(--theme-surface)] border border-[var(--theme-border)] rounded-xs space-y-1.5 text-xs">
            <div className="flex justify-between text-[var(--theme-text-muted)]">
              <span>Subtotal:</span>
              <span className="font-mono font-semibold">GH₵{subtotal.toFixed(2)}</span>
            </div>

            {selectedDiscountPercent > 0 && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                <span>Discount ({selectedDiscountPercent}%):</span>
                <span className="font-mono font-semibold">-GH₵{discountAmount.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between text-[var(--theme-text-muted)]">
              <span>Tax ({posSettings.taxRatePercent}% {posSettings.taxCalculationMode}):</span>
              <span className="font-mono">GH₵{taxAmount.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-sm font-bold pt-1.5 border-t border-[var(--theme-border)] text-[var(--theme-text)]">
              <span className="font-serif-luxury uppercase">Total Due:</span>
              <span className="font-mono text-base text-[var(--theme-accent)]">GH₵{grandTotal.toFixed(2)}</span>
            </div>
          </div>

          {/* Pay Button */}
          <button
            type="button"
            disabled={ticketItems.length === 0}
            onClick={() => {
              setCashTendered(grandTotal);
              setSplitCashAmount(Math.round(grandTotal / 2));
              setIsPaymentModalOpen(true);
            }}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <CreditCard className="w-4 h-4" />
            <span>Pay & Complete Sale (GH₵{grandTotal.toFixed(2)})</span>
          </button>
        </div>

      </div>

      {/* PAYMENT MODAL */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] text-[var(--theme-text)] max-w-lg w-full rounded-xs shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase text-[var(--theme-accent)] tracking-widest">
                  Checkout Tender
                </span>
                <h3 className="font-serif-luxury text-lg font-bold">
                  Select Payment Method
                </h3>
              </div>
              <button 
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="text-stone-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Total Due Callout */}
            <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-center rounded-xs">
              <span className="text-[11px] uppercase font-bold text-[var(--theme-text-muted)] block">Total Payable</span>
              <span className="font-serif-luxury font-bold text-2xl text-[var(--theme-accent)]">
                GH₵{grandTotal.toFixed(2)}
              </span>
            </div>

            {/* Payment Method Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'cash' as const, label: 'Cash', icon: CreditCard },
                { id: 'card' as const, label: 'Card Terminal', icon: CreditCard },
                { id: 'momo' as const, label: 'MTN MoMo', icon: Smartphone },
                { id: 'split' as const, label: 'Split Tender', icon: Percent },
              ].map(m => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id)}
                  className={`p-3 border rounded-xs font-bold text-xs flex flex-col items-center gap-1.5 transition cursor-pointer ${
                    paymentMethod === m.id
                      ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] border-transparent shadow-xs'
                      : 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)] text-[var(--theme-text)] hover:bg-[var(--theme-surface)]'
                  }`}
                >
                  <m.icon className="w-4 h-4" />
                  <span>{m.label}</span>
                </button>
              ))}
            </div>

            {/* Cash Input & Quick Denominations */}
            {paymentMethod === 'cash' && (
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                    Cash Tendered (GH₵)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={cashTendered || ''}
                    onChange={e => setCashTendered(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono text-base font-bold bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] font-bold uppercase text-[var(--theme-text-muted)]">Quick:</span>
                  {posSettings.quickCashDenominations.map((denom: number) => (
                    <button
                      key={denom}
                      type="button"
                      onClick={() => setCashTendered(denom)}
                      className="px-2.5 py-1 text-xs font-mono font-bold bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs hover:bg-[var(--theme-surface)] cursor-pointer"
                    >
                      GH₵{denom}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setCashTendered(grandTotal)}
                    className="px-2.5 py-1 text-xs font-mono font-bold bg-[var(--theme-accent)] text-white rounded-xs cursor-pointer"
                  >
                    Exact
                  </button>
                </div>

                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-between text-xs font-bold rounded-xs">
                  <span>Change Due:</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 text-sm">
                    GH₵{changeDue.toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* MoMo Input */}
            {paymentMethod === 'momo' && (
              <div className="space-y-3 pt-2 text-xs">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                    Customer Mobile Money Phone *
                  </label>
                  <input
                    type="text"
                    required
                    value={momoPhone}
                    onChange={e => setMomoPhone(e.target.value)}
                    placeholder="024 XXX XXXX"
                    className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                  />
                </div>
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xs text-[11px] text-amber-300">
                  <span>Merchant Push Prompt will be sent to the customer's phone for GH₵{grandTotal.toFixed(2)}. Showroom Merchant Code: {posSettings.momoMerchantNumber}.</span>
                </div>
              </div>
            )}

            {/* Split Tender */}
            {paymentMethod === 'split' && (
              <div className="space-y-3 pt-2 text-xs">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-[var(--theme-text-muted)] mb-1">
                    Cash Portion (GH₵)
                  </label>
                  <input
                    type="number"
                    value={splitCashAmount || ''}
                    onChange={e => setSplitCashAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                  />
                </div>
                <div className="flex justify-between p-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs">
                  <span>MoMo / Card Balance:</span>
                  <span className="font-mono font-bold text-[var(--theme-accent)]">
                    GH₵{Math.max(0, grandTotal - splitCashAmount).toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* Modal Actions */}
            <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)]">
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="px-4 py-2 border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleCompleteSale}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm Payment & Print</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUPERVISOR DISCOUNT PIN MODAL */}
      {showSupervisorModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={handleVerifySupervisorPin} className="bg-[var(--theme-surface)] border border-[var(--theme-border)] max-w-sm w-full p-6 space-y-4 rounded-xs shadow-2xl">
            <div className="flex items-center gap-2 text-amber-500">
              <ShieldCheck className="w-5 h-5" />
              <h3 className="font-serif-luxury font-bold text-sm text-[var(--theme-text)]">
                Supervisor Authorization Required
              </h3>
            </div>

            <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
              Requested discount (<strong className="text-[var(--theme-text)]">{pendingDiscountPercent}%</strong>) exceeds cashier limit of {posSettings.maxCashierDiscountPercent}%. Enter supervisor PIN to approve.
            </p>

            {pinError && (
              <div className="p-2 bg-red-500/20 border border-red-500/40 text-red-400 text-xs rounded-xs">
                Invalid PIN. Please try again or ask store supervisor.
              </div>
            )}

            <input
              type="password"
              autoFocus
              maxLength={6}
              value={supervisorPinInput}
              onChange={e => setSupervisorPinInput(e.target.value)}
              placeholder="Enter PIN (Default: 9814)"
              className="w-full px-3 py-2 font-mono tracking-widest text-center text-sm font-bold bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowSupervisorModal(false)}
                className="px-3 py-1.5 border border-[var(--theme-border)] text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase rounded-xs cursor-pointer"
              >
                Approve Discount
              </button>
            </div>
          </form>
        </div>
      )}

      {/* THERMAL RECEIPT MODAL */}
      {completedTx && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-stone-900 max-w-sm w-full p-6 space-y-4 font-mono text-xs shadow-2xl rounded-xs my-8 border border-stone-300">
            {/* Printable Receipt Content */}
            <div className="space-y-3 text-center border-b border-dashed border-stone-400 pb-3">
              <h2 className="font-serif-luxury font-bold text-base tracking-widest uppercase">
                {posSettings.receiptHeaderNote || 'ATELIER SURFACES · RIDGE WEST'}
              </h2>
              <div className="text-[10px] text-stone-600 leading-tight space-y-0.5">
                <p>{posSettings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana'}</p>
                {posSettings.receiptShowGps && (
                  <p>GhanaPost GPS: {posSettings.ghanaPostGps || 'GA-110-3849'}</p>
                )}
                <p>Tel: {posSettings.contactPhone || '0542443125/0596334488'} · {posSettings.contactEmail || 'concierge@ateliersurfaces.com'}</p>
              </div>
            </div>

            <div className="text-[11px] space-y-1 text-stone-700 border-b border-dashed border-stone-400 pb-2">
              <div className="flex justify-between">
                <span>Ticket No:</span>
                <span className="font-bold">{completedTx.transactionNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span>{new Date(completedTx.timestamp).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Cashier:</span>
                <span>{completedTx.cashierName}</span>
              </div>
              <div className="flex justify-between">
                <span>Client:</span>
                <span className="truncate max-w-[150px]">{completedTx.customerName}</span>
              </div>
            </div>

            {/* Line items */}
            <div className="space-y-1.5 border-b border-dashed border-stone-400 pb-3 text-[11px]">
              {completedTx.items.map((item, i) => (
                <div key={i} className="flex justify-between items-start">
                  <div className="max-w-[190px]">
                    <div className="font-bold truncate">{item.productName}</div>
                    <div className="text-[10px] text-stone-500">{item.quantity} m² @ GH₵{item.unitPrice}</div>
                  </div>
                  <span className="font-bold">GH₵{item.lineTotal.toFixed(2)}</span>
                </div>
              ))}
            </div>

            {/* Financial Summary */}
            <div className="space-y-1 text-[11px] border-b border-dashed border-stone-400 pb-3">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>GH₵{completedTx.subtotal.toFixed(2)}</span>
              </div>
              {completedTx.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount ({completedTx.discountPercent}%):</span>
                  <span>-GH₵{completedTx.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600 text-[10px]">
                <span>Tax (15% {posSettings.taxCalculationMode}):</span>
                <span>GH₵{completedTx.taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm pt-1 border-t border-stone-300">
                <span>TOTAL PAID:</span>
                <span>GH₵{completedTx.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[10px] text-stone-600 pt-0.5">
                <span>Tender Mode:</span>
                <span className="uppercase font-semibold">{completedTx.paymentMethod}</span>
              </div>
              {completedTx.paymentDetails.changeGiven ? (
                <div className="flex justify-between text-[10px] text-stone-600">
                  <span>Change Given:</span>
                  <span>GH₵{completedTx.paymentDetails.changeGiven.toFixed(2)}</span>
                </div>
              ) : null}
            </div>

            {/* Barcode & Footer Note */}
            <div className="text-center space-y-2 pt-1">
              <div className="font-mono text-sm tracking-widest bg-stone-100 py-1 border border-stone-300">
                *{completedTx.transactionNumber}*
              </div>
              <p className="text-[9px] text-stone-500 leading-tight">
                {posSettings.receiptFooterNote}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center justify-between border-t border-stone-300">
              <button
                type="button"
                onClick={() => setCompletedTx(null)}
                className="px-4 py-2 border border-stone-400 text-stone-800 text-xs font-bold uppercase rounded-xs cursor-pointer"
              >
                New Ticket
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 bg-stone-900 text-white text-xs font-bold uppercase rounded-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Panel Brightness Controller Modal */}
      <AdminBrightnessController
        isOpen={isBrightnessOpen}
        onClose={() => setIsBrightnessOpen(false)}
        onConfigChange={setCurrentBrightness}
      />
    </div>
  );
}
