import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { OrderStatus, PaymentStatus } from '../../types';
import { 
  ShoppingCart, 
  Search, 
  Eye, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertCircle,
  Printer
} from 'lucide-react';

export function AdminOrdersPage() {
  const { navigate } = useRouter();
  const { currentUser, hasPermission } = useAuth();
  const [orders, setOrders] = useState(() => storeService.getOrders());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');

  const filteredOrders = orders.filter(o => {
    if (statusFilter !== 'all' && o.orderStatus !== statusFilter) return false;
    if (paymentFilter !== 'all' && o.paymentStatus !== paymentFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchNum = o.orderNumber.toLowerCase().includes(q);
      const matchClient = o.customerSnapshot.name.toLowerCase().includes(q);
      const matchEmail = o.customerSnapshot.email.toLowerCase().includes(q);
      const matchPhone = o.customerSnapshot.phone.toLowerCase().includes(q);
      if (!matchNum && !matchClient && !matchEmail && !matchPhone) return false;
    }
    return true;
  });

  return (
    <AdminLayout
      title="Orders, Invoices & Receipt Verification"
      subtitle="Fulfillment tracking, Paystack automated settlement, wire receipt verification, and dispatch management."
    >
      {/* Controls */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by order #, client name, phone..."
            className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs w-full md:w-auto">
          <div className="flex items-center gap-1.5">
            <span className="text-[var(--theme-text-muted)] font-bold uppercase text-[10px]">Fulfillment:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing / Crating</option>
              <option value="shipped">Dispatched / En Route</option>
              <option value="delivered">Delivered to Site</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[var(--theme-text-muted)] font-bold uppercase text-[10px]">Payment:</span>
            <select
              value={paymentFilter}
              onChange={e => setPaymentFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none"
            >
              <option value="all">All Payments</option>
              <option value="paid">Paid & Verified</option>
              <option value="verification_required">Receipt Review Needed</option>
              <option value="pending">Pending Settlement</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[var(--theme-text)]">
            <thead>
              <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                <th className="py-3 px-4">Order Reference</th>
                <th className="py-3 px-4">Client / Practice</th>
                <th className="py-3 px-4">Site Destination</th>
                <th className="py-3 px-4">Specifications</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4">Fulfillment</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--theme-border-subtle)]">
              {filteredOrders.map(order => (
                <tr key={order.id} className="hover:bg-[var(--theme-surface-subtle)]/50 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-[var(--theme-text)]">
                    {order.orderNumber}
                    <span className="text-[10px] text-[var(--theme-text-muted)] block font-normal">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </span>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="font-semibold block">{order.customerSnapshot.name}</span>
                    <span className="text-[11px] text-[var(--theme-text-muted)]">{order.customerSnapshot.phone}</span>
                  </td>

                  <td className="py-3.5 px-4 text-[11px]">
                    <span className="font-medium text-[var(--theme-text)] block">{order.shippingAddress.city}</span>
                    <span className="font-mono text-[var(--theme-accent)]">{order.shippingAddress.ghanaPostGps || 'Ghana'}</span>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="font-medium">{order.itemsSnapshot.length} surface line(s)</span>
                    <span className="text-[10px] text-[var(--theme-text-muted)] block">
                      {order.itemsSnapshot[0]?.productName} ({order.itemsSnapshot[0]?.colorName})
                    </span>
                  </td>

                  <td className="py-3.5 px-4 font-bold tabular-nums">
                    GH₵{order.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>

                  <td className="py-3.5 px-4">
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-xs ${
                      order.paymentStatus === 'paid'
                        ? 'bg-emerald-100 text-emerald-800'
                        : order.paymentStatus === 'verification_required'
                        ? 'bg-amber-100 text-amber-800 animate-pulse'
                        : 'bg-stone-200 text-stone-700'
                    }`}>
                      {order.paymentStatus.replace('_', ' ')}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 capitalize font-medium">
                    {order.orderStatus}
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <Link
                      href={`/admin/orders/${order.id}`}
                      className="px-3 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold hover:border-[var(--theme-accent)] transition-colors inline-flex items-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Review</span>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
