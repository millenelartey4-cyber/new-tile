import React, { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { CompanyTenant } from '../../types';
import { 
  Building2, 
  Plus, 
  Copy, 
  Check, 
  ExternalLink, 
  Download, 
  Upload, 
  Trash2, 
  Layers, 
  ShoppingCart, 
  Globe, 
  ShieldCheck, 
  Sparkles,
  ArrowRight,
  Settings,
  Send,
  MessageSquare,
  Lock,
  X,
  Share2
} from 'lucide-react';

export function AdminCompaniesPage() {
  const { 
    activeCompany, 
    companies, 
    switchCompany, 
    deployCompany, 
    deleteCompany, 
    getCompanyShareUrl, 
    exportCompany, 
    setIsDeployModalOpen,
    setIsSwitcherOpen
  } = useCompany();

  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);
  const [sharingCompany, setSharingCompany] = useState<CompanyTenant | null>(null);
  const [copiedType, setCopiedType] = useState<'store' | 'admin' | 'msg' | null>(null);


  const handleCopy = (slug: string) => {
    const url = getCompanyShareUrl(slug);
    navigator.clipboard.writeText(url);
    setCopiedSlug(slug);
    setTimeout(() => setCopiedSlug(null), 2000);
  };

  const handleExport = (comp: CompanyTenant) => {
    const jsonStr = exportCompany(comp.id);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${comp.slug}-ecommerce-workspace.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <AdminLayout
      title="Company Workspaces"
      subtitle="Deploy and manage isolated e-commerce stores for different brands and clients without data conflict."
      actions={
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsSwitcherOpen(true)}
            className="px-3.5 py-2 bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider text-[var(--theme-text)] transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import / Switch</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDeployModalOpen(true)}
            className="px-4 py-2 bg-[var(--theme-accent)] hover:opacity-90 text-white text-xs font-bold uppercase tracking-wider transition-opacity cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Deploy New Client Store</span>
          </button>
        </div>
      }
    >
      <div className="space-y-6">
        
        {/* Metric Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
              Active Client Workspaces
            </span>
            <div className="text-2xl font-bold font-serif-luxury text-[var(--theme-text)]">
              {companies.length}
            </div>
            <span className="text-[11px] text-emerald-600 font-semibold block">
              100% Scoped & Isolated
            </span>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
              Current Active Store
            </span>
            <div className="text-lg font-bold font-serif-luxury text-[var(--theme-accent)] truncate" title={activeCompany.name}>
              {activeCompany.name}
            </div>
            <span className="text-[11px] text-[var(--theme-text-muted)] block truncate">
              {activeCompany.industry}
            </span>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
              Active Currency & Locale
            </span>
            <div className="text-2xl font-bold font-serif-luxury text-[var(--theme-text)]">
              {activeCompany.currency} ({activeCompany.currencySymbol})
            </div>
            <span className="text-[11px] text-[var(--theme-text-muted)] block">
              Direct Invoicing & Checkout
            </span>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
              Multi-Client Distribution
            </span>
            <div className="text-base font-bold text-[var(--theme-text)] flex items-center gap-1.5 pt-1">
              <Globe className="w-4 h-4 text-[var(--theme-accent)]" />
              <span>URL Query Routing</span>
            </div>
            <span className="text-[11px] text-[var(--theme-text-muted)] block">
              Append <strong>?company=slug</strong>
            </span>
          </div>
        </div>

        {/* Informative Guidance Banner */}
        <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[var(--theme-accent)]" />
              <h4 className="font-serif-luxury font-semibold text-sm text-[var(--theme-text)]">
                How to Send This E-Commerce Store to Different Companies
              </h4>
            </div>
            <p className="text-xs text-[var(--theme-text-muted)] max-w-2xl leading-relaxed">
              Each company deployed below has its own completely separate product catalog, pricing, currency, orders, and theme. To give a specific company their store, click <strong>"Copy Client Link"</strong> and send it to them. When they open their link, only their catalog and branding will appear.
            </p>
          </div>

          <button
            type="button"
            onClick={() => handleCopy(activeCompany.slug)}
            className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shrink-0 shadow-xs hover:opacity-90 transition-opacity cursor-pointer"
          >
            {copiedSlug === activeCompany.slug ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Link Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Current Company Link</span>
              </>
            )}
          </button>
        </div>

        {/* Company Workspaces Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)]">
              All Deployed Client Stores
            </h3>
            <span className="text-xs text-[var(--theme-text-muted)]">
              Click "Switch Workspace" to manage a company's specific inventory or orders.
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {companies.map(comp => {
              const isActive = comp.id === activeCompany.id;
              const products = storeService.getProducts(comp.id);
              const orders = storeService.getOrders(comp.id);
              const shareUrl = getCompanyShareUrl(comp.slug);

              return (
                <div
                  key={comp.id}
                  className={`bg-[var(--theme-surface)] border transition-all flex flex-col justify-between ${
                    isActive
                      ? 'border-[var(--theme-accent)] shadow-md ring-1 ring-[var(--theme-accent)]/30'
                      : 'border-[var(--theme-border)] hover:border-[var(--theme-text)]'
                  }`}
                >
                  <div className="p-6 space-y-4">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="w-12 h-12 rounded-sm bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center font-serif-luxury font-bold text-lg text-[var(--theme-accent)]">
                        {comp.name.charAt(0)}
                      </div>

                      <div className="flex items-center gap-1.5">
                        {isActive && (
                          <span className="px-2 py-0.5 bg-[var(--theme-accent)] text-white text-[10px] font-bold uppercase tracking-wider">
                            Active Store
                          </span>
                        )}
                        {comp.isDefault && (
                          <span className="px-2 py-0.5 bg-stone-200 dark:bg-stone-800 text-[10px] font-semibold text-[var(--theme-text-muted)] uppercase">
                            Flagship
                          </span>
                        )}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-serif-luxury text-base font-semibold text-[var(--theme-text)] line-clamp-1">
                        {comp.name}
                      </h4>
                      <p className="text-xs text-[var(--theme-accent)] font-medium mt-0.5">
                        {comp.industry}
                      </p>
                      <p className="text-xs text-[var(--theme-text-muted)] mt-1.5 line-clamp-2 leading-relaxed">
                        {comp.tagline}
                      </p>
                    </div>

                    {/* Meta stats */}
                    <div className="pt-3 border-t border-[var(--theme-border)] grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border-subtle)]">
                        <span className="block text-[10px] text-[var(--theme-text-muted)] uppercase">Products</span>
                        <strong className="text-sm font-semibold">{products.length}</strong>
                      </div>
                      <div className="p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border-subtle)]">
                        <span className="block text-[10px] text-[var(--theme-text-muted)] uppercase">Orders</span>
                        <strong className="text-sm font-semibold">{orders.length}</strong>
                      </div>
                      <div className="p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border-subtle)]">
                        <span className="block text-[10px] text-[var(--theme-text-muted)] uppercase">Currency</span>
                        <strong className="text-sm font-semibold">{comp.currencySymbol}</strong>
                      </div>
                    </div>

                    {/* Showroom & Contact info */}
                    <div className="space-y-1 text-[11px] text-[var(--theme-text-muted)] pt-1">
                      <div className="truncate">
                        <strong>Showroom:</strong> {comp.showroomAddress}
                      </div>
                      <div className="truncate">
                        <strong>Email:</strong> {comp.contactEmail}
                      </div>
                      <div className="truncate font-mono text-[10px]">
                        <strong>Parameter:</strong> ?company={comp.slug}
                      </div>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSharingCompany(comp)}
                        className="px-3 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-semibold text-[11px] flex items-center gap-1.5 hover:opacity-90 transition-opacity cursor-pointer shadow-xs"
                        title="Send this store to company or client"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Send to Client</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCopy(comp.slug)}
                        className="px-2.5 py-1.5 bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold text-[var(--theme-text)] flex items-center gap-1 transition-colors cursor-pointer text-[11px]"
                        title="Copy direct link"
                      >
                        {copiedSlug === comp.slug ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                        )}
                        <span>{copiedSlug === comp.slug ? 'Copied' : 'Link'}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleExport(comp)}
                        className="p-1.5 border border-[var(--theme-border)] bg-[var(--theme-surface)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition-colors cursor-pointer"
                        title="Export JSON backup"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      {!isActive ? (
                        <button
                          type="button"
                          onClick={() => switchCompany(comp.id)}
                          className="px-3 py-1.5 bg-[var(--theme-accent)] hover:opacity-90 text-white font-semibold uppercase tracking-wider text-[11px] flex items-center gap-1 transition-opacity cursor-pointer"
                        >
                          <span>Manage</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1 px-2 py-1 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800">
                          <Check className="w-3 h-3" />
                          <span>Active</span>
                        </span>
                      )}

                      {!comp.isDefault && companies.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Delete workspace "${comp.name}"? This removes all isolated data for this company.`)) {
                              deleteCompany(comp.id);
                            }
                          }}
                          className="p-1.5 border border-red-200 hover:bg-red-50 text-red-600 transition-colors cursor-pointer"
                          title="Delete company workspace"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Share & Send Store to Company Modal */}
        {sharingCompany && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
            <div 
              className="max-w-xl w-full bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-2xl p-6 sm:p-8 space-y-6 text-[var(--theme-text)] max-h-[90vh] overflow-y-auto"
              role="dialog"
              aria-modal="true"
            >
              <div className="flex items-start justify-between border-b border-[var(--theme-border)] pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-sm bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] flex items-center justify-center font-bold">
                    <Send className="w-5 h-5 text-[var(--theme-accent)]" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-accent)]">
                      Reusable Client Store Package
                    </span>
                    <h3 className="font-serif-luxury text-xl font-semibold">
                      {sharingCompany.name}
                    </h3>
                  </div>
                </div>

                <button
                  onClick={() => { setSharingCompany(null); setCopiedType(null); }}
                  className="p-1 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] cursor-pointer"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Zero Conflict Guarantee Badge */}
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-200 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-[11px] leading-relaxed">
                  <strong>Zero Data Collision:</strong> When this client visits their store link, only their catalog, pricing ({sharingCompany.currency}), orders, and brand colors load. Their data will never mix with other companies.
                </div>
              </div>

              <div className="space-y-4 text-xs">
                {/* 1. Public Storefront URL */}
                <div className="space-y-1.5">
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] text-[11px]">
                    1. Public Storefront URL (For Customers & Buyers)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={getCompanyShareUrl(sharingCompany.slug)}
                      className="flex-1 px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-mono text-xs text-[var(--theme-text)] select-all"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(getCompanyShareUrl(sharingCompany.slug));
                        setCopiedType('store');
                        setTimeout(() => setCopiedType(null), 2000);
                      }}
                      className="px-3 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase text-[11px] flex items-center gap-1 transition-opacity hover:opacity-90 cursor-pointer shrink-0"
                    >
                      {copiedType === 'store' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedType === 'store' ? 'Copied' : 'Copy'}</span>
                    </button>
                    <a
                      href={getCompanyShareUrl(sharingCompany.slug)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 border border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text)] cursor-pointer"
                      title="Open in new tab"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* 2. Admin Management URL */}
                <div className="space-y-1.5">
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] text-[11px]">
                    2. Company Staff & Admin Portal (Catalog & Order Management)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={`${typeof window !== 'undefined' ? window.location.origin : ''}/admin?company=${sharingCompany.slug}`}
                      className="flex-1 px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-mono text-xs text-[var(--theme-text)] select-all"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const adminUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}/admin?company=${sharingCompany.slug}`;
                        navigator.clipboard.writeText(adminUrl);
                        setCopiedType('admin');
                        setTimeout(() => setCopiedType(null), 2000);
                      }}
                      className="px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-bold uppercase text-[11px] flex items-center gap-1 transition-colors hover:bg-[var(--theme-surface)] cursor-pointer shrink-0"
                    >
                      {copiedType === 'admin' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedType === 'admin' ? 'Copied' : 'Copy'}</span>
                    </button>
                    <a
                      href={`/admin?company=${sharingCompany.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 border border-[var(--theme-border)] hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text)] cursor-pointer"
                      title="Open admin console in new tab"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* 3. Ready-to-Send Client Message (WhatsApp / Email) */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="block uppercase font-bold text-[var(--theme-text-muted)] text-[11px]">
                      3. Ready-to-Send Message (For WhatsApp or Email)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const storeUrl = getCompanyShareUrl(sharingCompany.slug);
                        const adminUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}/admin?company=${sharingCompany.slug}`;
                        const message = `Hello ${sharingCompany.name} Team,\n\nHere are the links to your dedicated e-commerce storefront and catalog:\n\n🛒 Public Storefront (For your customers):\n${storeUrl}\n\n🔐 Staff & Admin Management Console:\n${adminUrl}\n\nYour catalog, inventory, pricing (${sharingCompany.currency}), and orders are completely isolated and private.`;
                        navigator.clipboard.writeText(message);
                        setCopiedType('msg');
                        setTimeout(() => setCopiedType(null), 2000);
                      }}
                      className="text-[11px] text-[var(--theme-accent)] font-bold flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      {copiedType === 'msg' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedType === 'msg' ? 'Message Copied!' : 'Copy Formatted Message'}</span>
                    </button>
                  </div>
                  <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[11px] text-[var(--theme-text)] whitespace-pre-line font-sans leading-relaxed">
{`Hello ${sharingCompany.name} Team,

Here are the links to your dedicated e-commerce storefront and catalog:

🛒 Public Storefront (For your customers):
${getCompanyShareUrl(sharingCompany.slug)}

🔐 Staff & Admin Management Console:
${typeof window !== 'undefined' ? window.location.origin : ''}/admin?company=${sharingCompany.slug}

Your catalog, inventory, pricing (${sharingCompany.currency}), and orders are completely isolated and private.`}
                  </div>
                </div>

                {/* 4. Standalone JSON Backup */}
                <div className="pt-2 border-t border-[var(--theme-border)] flex items-center justify-between">
                  <div>
                    <span className="block font-bold text-xs">Offline Workspace Export</span>
                    <span className="text-[11px] text-[var(--theme-text-muted)]">Download full JSON backup of products, settings & orders.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleExport(sharingCompany)}
                    className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold text-xs flex items-center gap-1.5 hover:bg-[var(--theme-surface)] cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                    <span>Download JSON File</span>
                  </button>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => { setSharingCompany(null); setCopiedType(null); }}
                  className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase tracking-wider text-xs hover:opacity-90 cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

