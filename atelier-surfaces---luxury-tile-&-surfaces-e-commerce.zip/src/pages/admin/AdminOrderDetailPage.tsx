import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { OrderStatus, PaymentStatus } from '../../types';
import { 
  ArrowLeft, 
  CheckCircle2, 
  Printer, 
  ShieldCheck, 
  Truck, 
  MapPin, 
  AlertCircle, 
  FileText,
  Clock
} from 'lucide-react';

interface AdminOrderDetailPageProps {
  orderId: string;
}

export function AdminOrderDetailPage({ orderId }: AdminOrderDetailPageProps) {
  const { navigate } = useRouter();
  const { currentUser, hasPermission } = useAuth();
  const [order, setOrder] = useState(() => storeService.getOrderById(orderId));
  const [newStatus, setNewStatus] = useState<OrderStatus>(order?.orderStatus || 'pending');
  const [newPaymentStatus, setNewPaymentStatus] = useState<PaymentStatus>(order?.paymentStatus || 'pending');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const canUpdateOrder = hasPermission('orders', 'edit') || hasPermission('orders', 'approve');
  const canApprovePayment = hasPermission('payments', 'approve');

  if (!order) {
    return (
      <AdminLayout title="Order Not Located">
        <div className="p-8 text-center space-y-4">
          <p className="text-xs text-[var(--theme-text-muted)]">Order ID #{orderId} not found.</p>
          <Link href="/admin/orders" className="text-xs text-[var(--theme-accent)] underline">
            Back to Orders
          </Link>
        </div>
      </AdminLayout>
    );
  }

  const handleUpdateStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canUpdateOrder) {
      alert('You lack permission to modify order statuses.');
      return;
    }

    const updated = storeService.updateOrderStatus(
      order.id, 
      newStatus, 
      newPaymentStatus, 
      currentUser?.name || 'Staff'
    );

    if (updated) {
      setOrder(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  const handleApprovePayment = () => {
    if (!canApprovePayment) {
      alert('Your user role lacks payment approval authorization.');
      return;
    }
    const updated = storeService.updateOrderStatus(
      order.id, 
      'processing', 
      'paid', 
      currentUser?.name || 'Staff'
    );
    if (updated) {
      setOrder(updated);
      setNewStatus('processing');
      setNewPaymentStatus('paid');
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  return (
    <AdminLayout
      title={`Order Review: ${order.orderNumber}`}
      subtitle={`Created ${new Date(order.createdAt).toLocaleString()} · Destination: ${order.shippingAddress.city}`}
      actions={
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>Print Invoice</span>
          </button>
          <Link
            href="/admin/orders"
            className="px-3 py-1.5 border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider"
          >
            All Orders
          </Link>
        </div>
      }
    >
      {saveSuccess && (
        <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Order verification status updated and timeline synced.</span>
        </div>
      )}

      {/* Payment Receipt Review (Order Total Verification feature) */}
      {order.paymentStatus === 'verification_required' && (
        <div className="p-6 bg-amber-500/10 border border-amber-400 text-amber-900 space-y-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-amber-600" />
            <h3 className="text-sm font-bold uppercase tracking-wider">
              Order Total Verification Required
            </h3>
          </div>
          <p className="text-xs text-amber-800 leading-relaxed max-w-2xl">
            The client selected Bank Wire / Manual Transfer and submitted payment reference: <strong className="font-mono">{order.paymentReference || 'N/A'}</strong>. Please verify that <strong>GH₵{order.total.toLocaleString()}</strong> has cleared our Stanbic Bank Ghana account.
          </p>
          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={handleApprovePayment}
              className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider hover:bg-emerald-800 flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Verify & Approve Payment (Mark Paid)</span>
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Items & Delivery Details (Span 8) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Purchased Items Table */}
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
            <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-3">
              Allocated Surface Slabs & Tiles ({order.itemsSnapshot.length})
            </h3>

            <div className="divide-y divide-[var(--theme-border-subtle)] text-xs">
              {order.itemsSnapshot.map((item, idx) => (
                <div key={idx} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img src={item.image} alt={item.productName} className="w-14 h-14 object-cover border border-[var(--theme-border)]" />
                    <div>
                      <Link href={`/product/${item.productSlug}`} target="_blank" className="font-semibold text-sm hover:text-[var(--theme-accent)] transition-colors">
                        {item.productName}
                      </Link>
                      <div className="flex items-center gap-2 text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                        <span className="w-2.5 h-2.5 rounded-full border border-black/10" style={{ backgroundColor: item.colorHex }} />
                        <span>Color: {item.colorName}</span>
                        <span>·</span>
                        <span className="font-mono">{item.sku}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-bold tabular-nums block text-[var(--theme-text)]">
                      GH₵{item.lineTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                    <span className="text-[11px] text-[var(--theme-text-muted)]">
                      {item.quantity} {item.unit} @ GH₵{item.unitPrice}/{item.unit}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Total Math */}
            <div className="pt-4 border-t border-[var(--theme-border)] space-y-2 text-xs text-right max-w-xs ml-auto">
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Subtotal:</span>
                <span className="font-semibold tabular-nums">GH₵{order.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Site Freight:</span>
                <span className="font-semibold tabular-nums">{order.shippingCost === 0 ? 'Complimentary' : `GH₵${order.shippingCost}`}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Ghana VAT / NHIL (15%):</span>
                <span className="font-semibold tabular-nums">GH₵{order.tax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[var(--theme-border)] text-sm font-bold">
                <span>Total Amount:</span>
                <span className="tabular-nums text-base text-[var(--theme-accent)]">GH₵{order.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          {/* Delivery & Site Details */}
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3 text-xs">
            <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-2 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[var(--theme-accent)]" />
              <span>Building Site Logistics & GhanaPost GPS</span>
            </h3>
            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Client / Recipient</span>
                <strong className="text-sm">{order.shippingAddress.fullName}</strong>
                <p className="text-[var(--theme-text-muted)]">{order.shippingAddress.phone}</p>
                <p className="text-[var(--theme-text-muted)]">{order.shippingAddress.email}</p>
              </div>

              <div>
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Delivery Address & Region</span>
                <strong className="text-sm">{order.shippingAddress.addressLine1}</strong>
                <p className="text-[var(--theme-text-muted)]">{order.shippingAddress.city}, {order.shippingAddress.region}</p>
                {order.shippingAddress.ghanaPostGps && (
                  <p className="font-mono text-[var(--theme-accent)] font-bold mt-1">
                    GhanaPost GPS: {order.shippingAddress.ghanaPostGps}
                  </p>
                )}
              </div>
            </div>

            {order.shippingAddress.deliveryNotes && (
              <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] mt-2">
                <span className="font-bold text-[10px] uppercase text-[var(--theme-text-muted)] block">Site Access Notes:</span>
                <p className="text-[var(--theme-text)]">{order.shippingAddress.deliveryNotes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Right: Status Update Form (Span 4) */}
        <div className="lg:col-span-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-6">
          <h3 className="font-serif-luxury text-xl font-semibold border-b border-[var(--theme-border)] pb-3">
            Fulfillment Governance
          </h3>

          <form onSubmit={handleUpdateStatus} className="space-y-4 text-xs">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Fulfillment Status
              </label>
              <select
                value={newStatus}
                onChange={e => setNewStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] capitalize"
              >
                <option value="pending">Pending</option>
                <option value="processing">Processing & Warehouse Crating</option>
                <option value="shipped">Dispatched on Tailgate Truck</option>
                <option value="delivered">Delivered to Site & Handed Over</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Settlement Verification Status
              </label>
              <select
                value={newPaymentStatus}
                onChange={e => setNewPaymentStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] uppercase"
              >
                <option value="paid">Paid & Reconciled</option>
                <option value="verification_required">Verification Required</option>
                <option value="pending">Pending Transfer</option>
                <option value="refunded">Refunded</option>
              </select>
            </div>

            {canUpdateOrder ? (
              <button
                type="submit"
                className="w-full py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase tracking-wider text-xs hover:opacity-90 transition-opacity"
              >
                Update Order Status
              </button>
            ) : (
              <p className="text-[11px] text-[var(--theme-text-muted)] italic">
                Your role does not have authorization to edit order statuses.
              </p>
            )}
          </form>

          {/* Tracking milestones display */}
          <div className="pt-4 border-t border-[var(--theme-border)] space-y-3">
            <span className="font-bold uppercase tracking-wider text-[10px] text-[var(--theme-text-muted)] block">
              Freight Milestones
            </span>
            <div className="space-y-2.5 text-xs">
              {order.trackingTimeline.map((step, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className={`w-3 h-3 rounded-full mt-0.5 shrink-0 ${step.completed ? 'bg-emerald-600' : 'bg-stone-300'}`} />
                  <div>
                    <span className="font-medium text-[var(--theme-text)] block">{step.title}</span>
                    <span className="text-[10px] text-[var(--theme-text-muted)]">{step.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
