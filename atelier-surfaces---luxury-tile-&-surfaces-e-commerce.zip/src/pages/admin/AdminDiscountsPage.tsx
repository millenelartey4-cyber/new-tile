import React, { useState, useEffect, useMemo } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { BulkPricingRule, BulkPricingTier, DiscountCode } from '../../types';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Lock, 
  Unlock, 
  Check, 
  Calculator, 
  Layers, 
  Percent, 
  Search, 
  Filter, 
  Sparkles,
  AlertCircle,
  X,
  TrendingDown,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export function AdminDiscountsPage() {
  const { currentUser, hasPermission } = useAuth();
  const { activeCompany } = useCompany();

  // Active Tab: 'bulk_tiers' (Volume / m² tiers) vs 'coupons' (Promo codes)
  const [activeTab, setActiveTab] = useState<'bulk_tiers' | 'coupons'>('bulk_tiers');

  // Tenant-scoped rules and coupons
  const [bulkRules, setBulkRules] = useState<BulkPricingRule[]>(() => 
    storeService.getBulkPricingRules(activeCompany.id)
  );
  const [coupons, setCoupons] = useState<DiscountCode[]>(() => 
    storeService.getDiscountCodes(activeCompany.id)
  );
  const categories = useMemo(() => 
    storeService.getCategories(activeCompany.id), 
    [activeCompany.id]
  );

  // Filters & Search
  const [selectedCollectionFilter, setSelectedCollectionFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Bulk Rule Modal State
  const [isRuleModalOpen, setIsRuleModalOpen] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formCollectionId, setFormCollectionId] = useState('all');
  const [formDescription, setFormDescription] = useState('');
  const [formIsLocked, setFormIsLocked] = useState(false);
  const [formTiers, setFormTiers] = useState<BulkPricingTier[]>([
    {
      id: `tier-${Date.now()}-1`,
      minQuantitySqm: 50,
      maxQuantitySqm: 99.99,
      discountType: 'percentage',
      discountValue: 10,
      tierLabel: 'Site Batch Tier (50 - 99 m²)'
    },
    {
      id: `tier-${Date.now()}-2`,
      minQuantitySqm: 100,
      maxQuantitySqm: null,
      discountType: 'percentage',
      discountValue: 18,
      tierLabel: 'Commercial Volume Tier (100+ m²)'
    }
  ]);

  // Coupon Code Modal State
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponPercent, setNewCouponPercent] = useState(5);
  const [newCouponDesc, setNewCouponDesc] = useState('');
  const [newCouponMinSpend, setNewCouponMinSpend] = useState(5000);

  // Volume Calculator Simulator State
  const [simCollectionId, setSimCollectionId] = useState<string>('marble-look');
  const [simAreaSqm, setSimAreaSqm] = useState<number>(75);
  const [simBasePrice, setSimBasePrice] = useState<number>(485); // Standard price per m²

  // Notification Toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const canManage = hasPermission('discounts', 'create') || currentUser?.roleId === 'super-admin';

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Synchronize on tenant switch or external change
  useEffect(() => {
    setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
    setCoupons(storeService.getDiscountCodes(activeCompany.id));
  }, [activeCompany.id]);

  useEffect(() => {
    const handleRulesUpdate = () => {
      setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
    };
    window.addEventListener('bulk_pricing_updated', handleRulesUpdate);
    return () => window.removeEventListener('bulk_pricing_updated', handleRulesUpdate);
  }, [activeCompany.id]);

  // Filtered Bulk Rules
  const filteredBulkRules = useMemo(() => {
    return bulkRules.filter(rule => {
      const matchesCollection = selectedCollectionFilter === 'all' || rule.collectionId === selectedCollectionFilter;
      const matchesSearch = 
        rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rule.collectionName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rule.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCollection && matchesSearch;
    });
  }, [bulkRules, selectedCollectionFilter, searchQuery]);

  // Overall KPI stats
  const kpiStats = useMemo(() => {
    const activeRules = bulkRules.filter(r => r.active);
    const coveredCollections = new Set(bulkRules.map(r => r.collectionId));
    let lowestThreshold = Infinity;
    let maxDiscount = 0;

    bulkRules.forEach(r => {
      r.tiers.forEach(t => {
        if (t.minQuantitySqm < lowestThreshold) lowestThreshold = t.minQuantitySqm;
        if (t.discountType === 'percentage' && t.discountValue > maxDiscount) {
          maxDiscount = t.discountValue;
        }
      });
    });

    return {
      totalRules: bulkRules.length,
      activeRules: activeRules.length,
      collectionCount: coveredCollections.has('all') ? 'All Collections' : `${coveredCollections.size} Collections`,
      lowestThreshold: lowestThreshold === Infinity ? 'None' : `${lowestThreshold} m²`,
      maxDiscount: maxDiscount > 0 ? `${maxDiscount}% OFF` : 'Variable'
    };
  }, [bulkRules]);

  // Open Create Modal
  const handleOpenCreateRule = () => {
    setEditingRuleId(null);
    setFormName('New Collection Bulk Pricing Tier');
    setFormCollectionId(categories[0]?.id || 'all');
    setFormDescription('Standard site volume incentive tiers for bulk deliveries exceeding square meter thresholds.');
    setFormIsLocked(false);
    setFormTiers([
      {
        id: `tier-${Date.now()}-1`,
        minQuantitySqm: 50,
        maxQuantitySqm: 99.99,
        discountType: 'percentage',
        discountValue: 10,
        tierLabel: 'Site Batch Tier (50 - 99 m²)'
      },
      {
        id: `tier-${Date.now()}-2`,
        minQuantitySqm: 100,
        maxQuantitySqm: null,
        discountType: 'percentage',
        discountValue: 18,
        tierLabel: 'Commercial Volume Tier (100+ m²)'
      }
    ]);
    setIsRuleModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditRule = (rule: BulkPricingRule) => {
    setEditingRuleId(rule.id);
    setFormName(rule.name);
    setFormCollectionId(rule.collectionId);
    setFormDescription(rule.description);
    setFormIsLocked(!!rule.isLocked);
    setFormTiers(rule.tiers.map(t => ({ ...t })));
    setIsRuleModalOpen(true);
  };

  // Add tier row in modal
  const handleAddTierRow = () => {
    const lastTier = formTiers[formTiers.length - 1];
    const nextMin = lastTier ? (lastTier.maxQuantitySqm ? Math.ceil(lastTier.maxQuantitySqm) : lastTier.minQuantitySqm + 50) : 50;

    const newTier: BulkPricingTier = {
      id: `tier-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      minQuantitySqm: nextMin,
      maxQuantitySqm: null,
      discountType: 'percentage',
      discountValue: 15,
      tierLabel: `Volume Tier (${nextMin}+ m²)`
    };

    setFormTiers([...formTiers, newTier]);
  };

  // Remove tier row
  const handleRemoveTierRow = (tierId: string) => {
    if (formTiers.length <= 1) {
      alert('A bulk pricing rule must maintain at least one quantity tier.');
      return;
    }
    setFormTiers(formTiers.filter(t => t.id !== tierId));
  };

  // Update tier field
  const handleUpdateTierField = (tierId: string, field: keyof BulkPricingTier, val: any) => {
    setFormTiers(formTiers.map(t => {
      if (t.id === tierId) {
        return { ...t, [field]: val };
      }
      return t;
    }));
  };

  // Save Bulk Rule
  const handleSaveBulkRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      alert('Rule name is required.');
      return;
    }

    // Resolve collection name
    let collName = 'All Collections';
    if (formCollectionId !== 'all') {
      const found = categories.find(c => c.id === formCollectionId);
      if (found) collName = found.name;
    }

    const ruleObj: BulkPricingRule = {
      id: editingRuleId || `bpr-${Date.now()}`,
      name: formName.trim(),
      collectionId: formCollectionId,
      collectionName: collName,
      tiers: formTiers,
      active: true,
      isLocked: formIsLocked,
      lockedBy: formIsLocked ? (currentUser?.name || 'Administrator') : undefined,
      lockedAt: formIsLocked ? new Date().toISOString() : undefined,
      description: formDescription.trim(),
      createdAt: editingRuleId 
        ? (bulkRules.find(r => r.id === editingRuleId)?.createdAt || new Date().toISOString())
        : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    try {
      storeService.saveBulkPricingRule(ruleObj, currentUser?.name || 'Admin', activeCompany.id);
      setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
      setIsRuleModalOpen(false);
      showToast(`Bulk pricing matrix "${ruleObj.name}" saved successfully.`);
    } catch (err: any) {
      alert(err?.message || 'Failed to save bulk pricing rule.');
    }
  };

  // Delete Bulk Rule
  const handleDeleteBulkRule = (rule: BulkPricingRule) => {
    if (rule.isLocked) {
      alert(`Rule "${rule.name}" is locked. Please unlock it before deleting.`);
      return;
    }
    if (!window.confirm(`Are you sure you want to delete the bulk pricing rule "${rule.name}" for ${rule.collectionName}?`)) {
      return;
    }

    try {
      storeService.deleteBulkPricingRule(rule.id, currentUser?.name || 'Admin', activeCompany.id);
      setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
      showToast(`Bulk pricing rule "${rule.name}" deleted.`);
    } catch (err: any) {
      alert(err?.message || 'Could not delete rule.');
    }
  };

  // Toggle Lock
  const handleToggleLock = (rule: BulkPricingRule) => {
    const newLockState = !rule.isLocked;
    const confirmMsg = newLockState
      ? `Lock bulk pricing rule "${rule.name}"? This protects the tier thresholds and rates from unauthorized removal.`
      : `Unlock bulk pricing rule "${rule.name}" for administrative edits?`;

    if (window.confirm(confirmMsg)) {
      storeService.toggleBulkPricingLock(rule.id, newLockState, currentUser?.name || 'Admin', activeCompany.id);
      setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
      showToast(`Rule "${rule.name}" is now ${newLockState ? 'locked' : 'unlocked'}.`);
    }
  };

  // Toggle Active
  const handleToggleActive = (rule: BulkPricingRule) => {
    const newActiveState = !rule.active;
    storeService.toggleBulkPricingActive(rule.id, newActiveState, currentUser?.name || 'Admin', activeCompany.id);
    setBulkRules(storeService.getBulkPricingRules(activeCompany.id));
    showToast(`Rule "${rule.name}" set to ${newActiveState ? 'active' : 'paused'}.`);
  };

  // Create Coupon Code
  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    const newDisc: DiscountCode = {
      id: `dsc-${Date.now()}`,
      code: newCouponCode.trim().toUpperCase(),
      discountPercent: newCouponPercent,
      description: newCouponDesc.trim() || 'Trade promotional discount.',
      minSpend: newCouponMinSpend,
      active: true
    };

    storeService.saveDiscountCode(newDisc, currentUser?.name || 'Admin', activeCompany.id);
    setCoupons(storeService.getDiscountCodes(activeCompany.id));
    setIsCouponModalOpen(false);
    setNewCouponCode('');
    showToast(`Coupon code ${newDisc.code} created.`);
  };

  // Delete Coupon Code
  const handleDeleteCoupon = (id: string) => {
    if (window.confirm('Delete this coupon code?')) {
      storeService.deleteDiscountCode(id, currentUser?.name || 'Admin', activeCompany.id);
      setCoupons(storeService.getDiscountCodes(activeCompany.id));
      showToast('Coupon code removed.');
    }
  };

  // Simulator Calculation
  const simResult = useMemo(() => {
    const matchingRule = bulkRules.find(r => r.active && (r.collectionId === simCollectionId || r.collectionId === 'all'));
    const standardTotal = simBasePrice * simAreaSqm;

    if (!matchingRule || !matchingRule.tiers || matchingRule.tiers.length === 0) {
      return {
        hasDiscount: false,
        ruleName: 'Standard Catalog Pricing',
        tierLabel: 'No tier qualified',
        discountType: 'none',
        discountRate: 0,
        effectivePricePerM2: simBasePrice,
        netTotal: standardTotal,
        savings: 0,
        qualifyingTier: null
      };
    }

    const sortedDesc = [...matchingRule.tiers].sort((a, b) => b.minQuantitySqm - a.minQuantitySqm);
    const qualifyingTier = sortedDesc.find(t => {
      const meetsMin = simAreaSqm >= t.minQuantitySqm;
      const meetsMax = t.maxQuantitySqm == null || simAreaSqm <= t.maxQuantitySqm;
      return meetsMin && meetsMax;
    });

    if (!qualifyingTier) {
      return {
        hasDiscount: false,
        ruleName: matchingRule.name,
        tierLabel: `Below minimum volume threshold (${sortedDesc[sortedDesc.length - 1]?.minQuantitySqm || 50} m²)`,
        discountType: 'none',
        discountRate: 0,
        effectivePricePerM2: simBasePrice,
        netTotal: standardTotal,
        savings: 0,
        qualifyingTier: null
      };
    }

    let effectivePrice = simBasePrice;
    let savings = 0;

    if (qualifyingTier.discountType === 'percentage') {
      savings = (standardTotal * qualifyingTier.discountValue) / 100;
      effectivePrice = simBasePrice * (1 - qualifyingTier.discountValue / 100);
    } else {
      if (simBasePrice > qualifyingTier.discountValue) {
        effectivePrice = qualifyingTier.discountValue;
        savings = (simBasePrice - qualifyingTier.discountValue) * simAreaSqm;
      }
    }

    return {
      hasDiscount: savings > 0,
      ruleName: matchingRule.name,
      tierLabel: qualifyingTier.tierLabel,
      discountType: qualifyingTier.discountType,
      discountRate: qualifyingTier.discountValue,
      effectivePricePerM2: effectivePrice,
      netTotal: standardTotal - savings,
      savings,
      qualifyingTier
    };
  }, [bulkRules, simCollectionId, simAreaSqm, simBasePrice]);

  return (
    <AdminLayout
      title="Discounts & Bulk Pricing Matrix"
      subtitle="Configure quantity-based price tiers by tile collection (e.g. orders exceeding 50 m²) and manage trade promotional vouchers."
      actions={
        canManage && (
          <div className="flex items-center gap-2">
            {activeTab === 'bulk_tiers' ? (
              <button
                onClick={handleOpenCreateRule}
                className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New Bulk Tier Matrix</span>
              </button>
            ) : (
              <button
                onClick={() => setIsCouponModalOpen(true)}
                className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create Coupon Code</span>
              </button>
            )}
          </div>
        )
      }
    >
      <div className="space-y-6">

        {/* Toast Alert */}
        {toastMsg && (
          <div className="p-3 bg-emerald-900/90 text-emerald-100 border border-emerald-600 rounded text-xs flex items-center justify-between shadow-lg animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span className="font-medium">{toastMsg}</span>
            </div>
            <button onClick={() => setToastMsg(null)} className="text-emerald-300 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-[var(--theme-border)]">
          <button
            onClick={() => setActiveTab('bulk_tiers')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'bulk_tiers'
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]'
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Bulk & Tier Quantity Pricing ({bulkRules.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'coupons'
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]'
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <Percent className="w-4 h-4" />
            <span>Promotional Coupons & Codes ({coupons.length})</span>
          </button>
        </div>

        {activeTab === 'bulk_tiers' ? (
          <div className="space-y-6">
            
            {/* KPI Metric Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  Active Tier Rules
                </span>
                <div className="text-2xl font-bold font-serif-luxury text-[var(--theme-text)]">
                  {kpiStats.activeRules} <span className="text-xs font-sans font-normal text-[var(--theme-text-muted)]">/ {kpiStats.totalRules}</span>
                </div>
                <span className="text-[11px] text-emerald-600 font-medium block">
                  Enforced on Storefront & POS
                </span>
              </div>

              <div className="p-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  Catalog Coverage
                </span>
                <div className="text-2xl font-bold font-serif-luxury text-[var(--theme-text)]">
                  {kpiStats.collectionCount}
                </div>
                <span className="text-[11px] text-[var(--theme-text-muted)] block">
                  Scoped per Tile Line
                </span>
              </div>

              <div className="p-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  Min. Volume Area
                </span>
                <div className="text-2xl font-bold font-serif-luxury text-[var(--theme-accent)]">
                  {kpiStats.lowestThreshold}
                </div>
                <span className="text-[11px] text-[var(--theme-text-muted)] block">
                  Qualifying m² Threshold
                </span>
              </div>

              <div className="p-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  Max Volume Incentive
                </span>
                <div className="text-2xl font-bold font-serif-luxury text-emerald-600">
                  {kpiStats.maxDiscount}
                </div>
                <span className="text-[11px] text-[var(--theme-text-muted)] block">
                  Site Batch / Container Savings
                </span>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="p-4 bg-[var(--theme-surface)] border border-[var(--theme-border)] flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="flex items-center gap-2 text-xs">
                  <Filter className="w-4 h-4 text-[var(--theme-text-muted)]" />
                  <span className="font-semibold text-[var(--theme-text)]">Collection:</span>
                </div>
                <select
                  value={selectedCollectionFilter}
                  onChange={e => setSelectedCollectionFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none"
                >
                  <option value="all">All Tile Collections</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--theme-text-muted)]" />
                <input
                  type="text"
                  placeholder="Search rules or notes..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none"
                />
              </div>
            </div>

            {/* Bulk Pricing Rules List */}
            {filteredBulkRules.length === 0 ? (
              <div className="p-12 text-center bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-3">
                <Layers className="w-10 h-10 text-[var(--theme-text-muted)] mx-auto opacity-40" />
                <h4 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)]">
                  No Bulk Pricing Rules Found
                </h4>
                <p className="text-xs text-[var(--theme-text-muted)] max-w-md mx-auto">
                  {selectedCollectionFilter !== 'all' 
                    ? 'No specific quantity tiers configured for this collection yet.' 
                    : 'Set up quantity-based price tiers (e.g. 10% off for 50+ m²) to drive large-scale commercial specifications.'}
                </p>
                {canManage && (
                  <button
                    onClick={handleOpenCreateRule}
                    className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 mt-2 inline-flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create First Bulk Tier Rule</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredBulkRules.map(rule => (
                  <div
                    key={rule.id}
                    className={`bg-[var(--theme-surface)] border transition-all ${
                      rule.active ? 'border-[var(--theme-border)] shadow-xs' : 'border-[var(--theme-border)] opacity-60'
                    }`}
                  >
                    {/* Rule Header Bar */}
                    <div className="p-4 sm:p-5 border-b border-[var(--theme-border)] flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2.5">
                          <h3 className="font-serif-luxury text-base sm:text-lg font-semibold text-[var(--theme-text)]">
                            {rule.name}
                          </h3>

                          {/* Scoped Collection Badge */}
                          <span className="px-2 py-0.5 bg-[var(--theme-accent)]/15 text-[var(--theme-accent)] border border-[var(--theme-accent)]/30 text-[10px] font-bold uppercase tracking-wider">
                            {rule.collectionName}
                          </span>

                          {/* Status Pill */}
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-2xs ${
                            rule.active ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-700'
                          }`}>
                            {rule.active ? 'Active on Storefront' : 'Paused'}
                          </span>

                          {/* Locked Badge */}
                          {rule.isLocked && (
                            <span className="flex items-center gap-1 text-[10px] font-mono text-amber-700 bg-amber-50 px-2 py-0.5 border border-amber-200">
                              <Lock className="w-3 h-3 text-amber-600" />
                              <span>Locked ({rule.lockedBy || 'Admin'})</span>
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-[var(--theme-text-muted)] max-w-2xl">
                          {rule.description}
                        </p>
                      </div>

                      {/* Admin Controls */}
                      {canManage && (
                        <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleActive(rule)}
                            className="px-2.5 py-1.5 border border-[var(--theme-border)] text-[11px] font-semibold text-[var(--theme-text)] hover:bg-[var(--theme-surface-subtle)]"
                          >
                            {rule.active ? 'Pause Rule' : 'Activate'}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleToggleLock(rule)}
                            className={`p-1.5 border border-[var(--theme-border)] text-xs flex items-center gap-1 hover:bg-[var(--theme-surface-subtle)] ${
                              rule.isLocked ? 'text-amber-600' : 'text-[var(--theme-text-muted)]'
                            }`}
                            title={rule.isLocked ? 'Unlock rule for deletion/editing' : 'Lock rule'}
                          >
                            {rule.isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleOpenEditRule(rule)}
                            className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] hover:bg-[var(--theme-border)] flex items-center gap-1"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Tiers</span>
                          </button>

                          <button
                            type="button"
                            disabled={rule.isLocked}
                            onClick={() => handleDeleteBulkRule(rule)}
                            className="p-1.5 text-[var(--theme-text-muted)] hover:text-red-600 border border-[var(--theme-border)] disabled:opacity-40 disabled:hover:text-[var(--theme-text-muted)] cursor-pointer"
                            title={rule.isLocked ? 'Locked against deletion' : 'Delete rule'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Tiers Breakdown Matrix */}
                    <div className="p-4 sm:p-5 bg-[var(--theme-surface-subtle)]/40">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {rule.tiers.map((tier, idx) => (
                          <div
                            key={tier.id}
                            className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-3.5 space-y-2 relative overflow-hidden"
                          >
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-mono text-[10px] text-[var(--theme-text-muted)] uppercase tracking-wider">
                                Step 0{idx + 1}
                              </span>
                              <span className="font-bold text-sm font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 border border-emerald-200">
                                {tier.discountType === 'percentage' 
                                  ? `${tier.discountValue}% OFF` 
                                  : `GH₵${tier.discountValue}/m²`}
                              </span>
                            </div>

                            <div className="space-y-0.5">
                              <div className="text-sm font-bold text-[var(--theme-text)]">
                                {tier.minQuantitySqm}
                                {tier.maxQuantitySqm ? ` – ${Math.floor(tier.maxQuantitySqm)} m²` : '+ m²'}
                              </div>
                              <div className="text-xs font-medium text-[var(--theme-text-muted)]">
                                {tier.tierLabel}
                              </div>
                            </div>

                            <div className="pt-2 border-t border-[var(--theme-border-subtle)] text-[10px] text-[var(--theme-text-muted)] flex items-center justify-between">
                              <span>Threshold Type</span>
                              <span className="font-mono font-semibold text-[var(--theme-text)]">
                                {tier.discountType === 'percentage' ? 'Relative Margin %' : 'Fixed Unit Rate'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Interactive Volume Pricing Simulator & Calculator Card */}
            <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-5 shadow-xs">
              <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-4">
                <div className="flex items-center gap-2.5">
                  <span className="p-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] rounded-xs">
                    <Calculator className="w-4 h-4" />
                  </span>
                  <div>
                    <h3 className="font-serif-luxury text-base font-semibold text-[var(--theme-text)]">
                      Real-Time Bulk Pricing Simulator & Volume Calculator
                    </h3>
                    <p className="text-xs text-[var(--theme-text-muted)]">
                      Simulate how your configured quantity tiers compute invoice totals and contractor margins.
                    </p>
                  </div>
                </div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-accent)] bg-[var(--theme-accent)]/10 px-2 py-1">
                  Interactive Test Bench
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--theme-text-muted)] mb-1.5">
                    Target Collection
                  </label>
                  <select
                    value={simCollectionId}
                    onChange={e => setSimCollectionId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--theme-text-muted)] mb-1.5">
                    Order Surface Area (m²)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      step="1"
                      value={simAreaSqm}
                      onChange={e => setSimAreaSqm(Math.max(1, parseFloat(e.target.value) || 1))}
                      className="w-full px-3 py-2 text-xs tabular-nums bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none font-bold"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--theme-text-muted)] font-mono">
                      m²
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--theme-text-muted)] mb-1.5">
                    Catalog Base Price (GH₵ / m²)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="10"
                      step="5"
                      value={simBasePrice}
                      onChange={e => setSimBasePrice(Math.max(1, parseFloat(e.target.value) || 10))}
                      className="w-full px-3 py-2 text-xs tabular-nums bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none font-bold"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--theme-text-muted)] font-mono">
                      GH₵/m²
                    </span>
                  </div>
                </div>
              </div>

              {/* Simulation Result Box */}
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[var(--theme-text)]">
                      {simResult.ruleName}
                    </span>
                    <span className="text-xs text-[var(--theme-text-muted)]">·</span>
                    <span className={`text-xs font-semibold ${simResult.hasDiscount ? 'text-emerald-700' : 'text-[var(--theme-text-muted)]'}`}>
                      {simResult.tierLabel}
                    </span>
                  </div>
                  <div className="text-xs text-[var(--theme-text-muted)] flex items-center gap-3">
                    <span>Standard Rate: <strong>GH₵{simBasePrice.toFixed(2)}/m²</strong></span>
                    <span>→</span>
                    <span>Net Tier Rate: <strong className="text-emerald-700">GH₵{simResult.effectivePricePerM2.toFixed(2)}/m²</strong></span>
                  </div>
                </div>

                <div className="text-right self-stretch sm:self-auto border-t sm:border-t-0 pt-2 sm:pt-0 border-[var(--theme-border)]">
                  <div className="text-xs text-[var(--theme-text-muted)]">Simulated Payable Subtotal</div>
                  <div className="text-xl font-bold font-mono text-[var(--theme-text)]">
                    GH₵{simResult.netTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  {simResult.savings > 0 && (
                    <div className="text-[11px] text-emerald-700 font-bold">
                      Contractor Saves: GH₵{simResult.savings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                  )}
                </div>
              </div>
            </div>

          </div>
        ) : (
          /* Promotional Coupon Codes Tab */
          <div className="space-y-4">
            <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-[var(--theme-text)]">
                <thead>
                  <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                    <th className="py-3 px-4">Coupon Code</th>
                    <th className="py-3 px-4">Rate (%)</th>
                    <th className="py-3 px-4">Description</th>
                    <th className="py-3 px-4">Min. Qualifying Spend</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                  {coupons.map(d => (
                    <tr key={d.id} className="hover:bg-[var(--theme-surface-subtle)]/50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-sm text-[var(--theme-text)]">
                        {d.code}
                      </td>
                      <td className="py-3 px-4 font-bold tabular-nums text-emerald-700">
                        {d.discountPercent}% OFF
                      </td>
                      <td className="py-3 px-4 text-[var(--theme-text-muted)]">
                        {d.description}
                      </td>
                      <td className="py-3 px-4 tabular-nums font-semibold">
                        GH₵{d.minSpend.toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-2xs">
                          Active
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {canManage && (
                          <button
                            onClick={() => handleDeleteCoupon(d.id)}
                            className="p-1 text-[var(--theme-text-muted)] hover:text-red-600 cursor-pointer"
                            title="Delete coupon"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Modal: Create / Edit Bulk Pricing Rule */}
      {isRuleModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl text-[var(--theme-text)]">
            <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
              <div>
                <h3 className="font-serif-luxury text-xl font-semibold">
                  {editingRuleId ? 'Edit Bulk Pricing Matrix' : 'Configure New Bulk Tier Rule'}
                </h3>
                <p className="text-xs text-[var(--theme-text-muted)]">
                  Define square meter thresholds and associated trade discounts for selected collections.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsRuleModalOpen(false)}
                className="p-1 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBulkRule} className="space-y-5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Rule Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={e => setFormName(e.target.value)}
                    placeholder="e.g. Marble Slab Volume Incentive"
                    className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-medium text-[var(--theme-text)] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                    Applicable Tile Collection
                  </label>
                  <select
                    value={formCollectionId}
                    onChange={e => setFormCollectionId(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none"
                  >
                    <option value="all">★ All Catalog Collections</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Description / Architect & Contractor Eligibility
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  placeholder="e.g. Volume tier incentives for residential developers and commercial specifiers ordering full crates."
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text)] focus:outline-none"
                />
              </div>

              {/* Tiers List Section */}
              <div className="space-y-3 pt-2 border-t border-[var(--theme-border)]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold uppercase tracking-wider text-[var(--theme-text)]">
                      Quantity Tiers (Area in m²)
                    </span>
                    <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                      Sorted ascending by minimum m²
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddTierRow}
                    className="px-2.5 py-1 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-[11px] font-semibold uppercase tracking-wider hover:opacity-90 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Tier Row</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {formTiers.map((tier, idx) => (
                    <div
                      key={tier.id}
                      className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
                    >
                      <div className="sm:col-span-1 text-center font-mono font-bold text-xs text-[var(--theme-text-muted)]">
                        #{idx + 1}
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                          Min Area (m²)
                        </label>
                        <input
                          type="number"
                          min="1"
                          required
                          value={tier.minQuantitySqm}
                          onChange={e => handleUpdateTierField(tier.id, 'minQuantitySqm', parseFloat(e.target.value) || 0)}
                          className="w-full px-2 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] font-bold text-xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                          Max (m² / opt)
                        </label>
                        <input
                          type="number"
                          placeholder="No max"
                          value={tier.maxQuantitySqm == null ? '' : tier.maxQuantitySqm}
                          onChange={e => handleUpdateTierField(tier.id, 'maxQuantitySqm', e.target.value === '' ? null : parseFloat(e.target.value))}
                          className="w-full px-2 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                          Discount Type
                        </label>
                        <select
                          value={tier.discountType}
                          onChange={e => handleUpdateTierField(tier.id, 'discountType', e.target.value as any)}
                          className="w-full px-2 py-1.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs"
                        >
                          <option value="percentage">% OFF</option>
                          <option value="fixed_price">GH₵/m² Rate</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[10px] uppercase font-bold text-[var(--theme-text-muted)] mb-0.5">
                          Value ({tier.discountType === 'percentage' ? '%' : 'GH₵'})
                        </label>
                        <input
                          type="number"
                          min="1"
                          required
                          value={tier.discountValue}
                          onChange={e => handleUpdateTierField(tier.id, 'discountValue', parseFloat(e.target.value) || 0)}
                          className="w-full px-2 py-1.5 tabular-nums bg-[var(--theme-surface)] border border-[var(--theme-border)] font-bold text-xs text-emerald-700"
                        />
                      </div>

                      <div className="sm:col-span-2 flex items-center justify-end gap-1.5 pt-4 sm:pt-0">
                        <button
                          type="button"
                          onClick={() => handleRemoveTierRow(tier.id)}
                          className="p-1.5 text-[var(--theme-text-muted)] hover:text-red-600 cursor-pointer"
                          title="Remove tier"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Tier Label sub-input */}
                      <div className="sm:col-span-12 pt-1 border-t border-[var(--theme-border-subtle)] flex items-center gap-2">
                        <span className="text-[10px] text-[var(--theme-text-muted)] shrink-0">Label:</span>
                        <input
                          type="text"
                          value={tier.tierLabel}
                          onChange={e => handleUpdateTierField(tier.id, 'tierLabel', e.target.value)}
                          placeholder="e.g. Tier 1 · Site Batch (50-99 m²)"
                          className="w-full px-2 py-1 bg-transparent border-b border-[var(--theme-border-subtle)] text-[11px] text-[var(--theme-text)] focus:outline-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Lock protection checkbox */}
              <div className="pt-3 border-t border-[var(--theme-border)]">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsLocked}
                    onChange={e => setFormIsLocked(e.target.checked)}
                    className="accent-[var(--theme-accent)]"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[var(--theme-text)] flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-600 inline" />
                      Lock rule against unauthorized deletion
                    </span>
                    <span className="text-[11px] text-[var(--theme-text-muted)] block">
                      Requires unlocking before this rule can be modified or removed by other managers.
                    </span>
                  </div>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[var(--theme-border)]">
                <button
                  type="button"
                  onClick={() => setIsRuleModalOpen(false)}
                  className="px-4 py-2 border border-[var(--theme-border)] uppercase font-semibold text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 cursor-pointer"
                >
                  Save Bulk Pricing Matrix
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Create Promotional Coupon Code */}
      {isCouponModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-md p-6 space-y-4 shadow-2xl text-[var(--theme-text)]">
            <h3 className="font-serif-luxury text-xl font-semibold">
              Create Promotional Code
            </h3>
            <form onSubmit={handleCreateCoupon} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Coupon Code</label>
                <input
                  type="text"
                  required
                  value={newCouponCode}
                  onChange={e => setNewCouponCode(e.target.value.toUpperCase())}
                  placeholder="e.g. VIPARCH10"
                  className="w-full px-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Discount Percentage (%)</label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  required
                  value={newCouponPercent}
                  onChange={e => setNewCouponPercent(parseFloat(e.target.value) || 5)}
                  className="w-full px-3 py-2 tabular-nums bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Min Spend Qualifying (GH₵)</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={newCouponMinSpend}
                  onChange={e => setNewCouponMinSpend(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 tabular-nums bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Description / Trade Eligibility</label>
                <input
                  type="text"
                  value={newCouponDesc}
                  onChange={e => setNewCouponDesc(e.target.value)}
                  placeholder="e.g. Registered architects and trade builders"
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[var(--theme-border)]">
                <button
                  type="button"
                  onClick={() => setIsCouponModalOpen(false)}
                  className="px-4 py-2 border border-[var(--theme-border)] uppercase font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90"
                >
                  Publish Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
