import React, { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { ConsultationRoom, StoreSettings } from '../../types';
import { 
  Video, 
  Lock, 
  Unlock, 
  Plus, 
  Trash2, 
  Check, 
  Copy, 
  Save, 
  CheckCircle2, 
  ShieldCheck, 
  MapPin, 
  Phone, 
  Mail, 
  Radio, 
  Sparkles, 
  ExternalLink,
  Users,
  Clock, 
  RefreshCw,
  AlertCircle,
  Pencil
} from 'lucide-react';

export function AdminVideoConsultationsPage() {
  const { currentUser, hasPermission } = useAuth();
  const { activeCompany, updateCompany } = useCompany();
  const currentSettings = storeService.getStoreSettings(activeCompany.id);

  const [settings, setSettings] = useState<StoreSettings>({ ...currentSettings });
  const [rooms, setRooms] = useState<ConsultationRoom[]>(() => storeService.getConsultationRooms(activeCompany.id));
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copiedRoomId, setCopiedRoomId] = useState<string | null>(null);

  // New Room Modal / Input State
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomId, setNewRoomId] = useState('');
  const [newRoomClient, setNewRoomClient] = useState('');
  const [newRoomRole, setNewRoomRole] = useState<'architect' | 'client' | 'contractor'>('architect');
  const [newRoomLock, setNewRoomLock] = useState(false);
  const [showAddRoomModal, setShowAddRoomModal] = useState(false);

  // Edit Existing Room Modal State
  const [editingRoom, setEditingRoom] = useState<ConsultationRoom | null>(null);

  const handleSaveEditedRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRoom || !editingRoom.name.trim()) return;

    storeService.saveConsultationRoom(editingRoom, currentUser?.name, activeCompany.id);
    fetch('/api/video/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        roomId: editingRoom.id,
        name: editingRoom.name,
        clientName: editingRoom.clientName,
        clientRole: editingRoom.clientRole,
        isLocked: editingRoom.isLocked
      })
    }).catch(() => {});

    setRooms(storeService.getConsultationRooms(activeCompany.id));
    setEditingRoom(null);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const canManage = hasPermission('store_settings', 'manage_settings') || currentUser?.roleId === 'super-admin' || currentUser?.roleId === 'manager';

  // Synchronize with server on mount
  useEffect(() => {
    fetch('/api/video/config')
      .then(res => res.json())
      .then(serverCfg => {
        if (serverCfg) {
          setSettings(prev => ({
            ...prev,
            videoConsultationLocked: typeof serverCfg.isLocked === 'boolean' ? serverCfg.isLocked : prev.videoConsultationLocked,
            videoLockMessage: serverCfg.lockReason || prev.videoLockMessage,
            videoConsultantName: serverCfg.consultantName || prev.videoConsultantName,
            videoConsultantTitle: serverCfg.consultantTitle || prev.videoConsultantTitle,
            videoConsultantLocation: serverCfg.consultantLocation || prev.videoConsultantLocation,
            videoConsultantAvailable: typeof serverCfg.consultantAvailable === 'boolean' ? serverCfg.consultantAvailable : prev.videoConsultantAvailable,
            videoConsultantHours: serverCfg.consultantHours || prev.videoConsultantHours,
            showroomAddress: prev.showroomAddress || serverCfg.showroomContact?.address,
            ghanaPostGps: prev.ghanaPostGps || serverCfg.showroomContact?.gps,
            contactPhone: prev.contactPhone || serverCfg.showroomContact?.phone,
            contactEmail: prev.contactEmail || serverCfg.showroomContact?.email,
            contactLocked: typeof serverCfg.showroomContact?.isLocked === 'boolean' ? serverCfg.showroomContact.isLocked : prev.contactLocked
          }));
        }
      })
      .catch(() => {});

    fetch('/api/video/rooms')
      .then(res => res.json())
      .then(serverRooms => {
        if (Array.isArray(serverRooms) && serverRooms.length > 0) {
          // Merge server rooms
          setRooms(prev => {
            const map = new Map<string, ConsultationRoom>();
            prev.forEach(r => map.set(r.id, r));
            serverRooms.forEach(sr => {
              const existing = map.get(sr.id);
              map.set(sr.id, {
                id: sr.id,
                name: sr.name,
                createdAt: sr.createdAt,
                isLocked: sr.isLocked,
                clientName: sr.clientName || existing?.clientName,
                clientRole: sr.clientRole || existing?.clientRole,
                activeParticipantsCount: sr.participantsCount || 0
              });
            });
            return Array.from(map.values());
          });
        }
      })
      .catch(() => {});
  }, []);

  // Save Settings & Locks
  const handleSaveAll = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canManage) return;

    storeService.updateStoreSettings(settings, currentUser?.name, activeCompany.id);

    // Sync with active company context
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        showroomAddress: settings.showroomAddress,
        ghanaPostGps: settings.ghanaPostGps,
        contactPhone: settings.contactPhone,
        contactEmail: settings.contactEmail
      });
    }

    // Sync to backend server
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        isLocked: !!settings.videoConsultationLocked,
        lockReason: settings.videoLockMessage,
        consultantName: settings.videoConsultantName,
        consultantTitle: settings.videoConsultantTitle,
        consultantLocation: settings.videoConsultantLocation,
        consultantAvailable: !!settings.videoConsultantAvailable,
        consultantHours: settings.videoConsultantHours,
        showroomContact: {
          address: settings.showroomAddress,
          gps: settings.ghanaPostGps,
          phone: settings.contactPhone,
          email: settings.contactEmail,
          isLocked: !!settings.contactLocked
        }
      })
    }).catch(() => {});

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  // Toggle Video Call Lock
  const handleToggleGlobalCallLock = () => {
    const nextLocked = !settings.videoConsultationLocked;
    setSettings(prev => ({ ...prev, videoConsultationLocked: nextLocked }));
    storeService.toggleVideoConsultationLock(nextLocked, currentUser?.name, activeCompany.id);
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isLocked: nextLocked })
    }).catch(() => {});
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Toggle Showroom Contact Lock
  const handleToggleContactLock = () => {
    const nextLocked = !settings.contactLocked;
    setSettings(prev => ({
      ...prev,
      contactLocked: nextLocked,
      contactLastSavedBy: currentUser?.name || 'Administrator'
    }));
    storeService.toggleContactDetailsLock(nextLocked, currentUser?.name, activeCompany.id);
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        showroomContact: {
          address: settings.showroomAddress,
          gps: settings.ghanaPostGps,
          phone: settings.contactPhone,
          email: settings.contactEmail,
          isLocked: nextLocked
        }
      })
    }).catch(() => {});
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Apply Official Accra Flagship Defaults
  const handleApplyOfficialAccraDefaults = () => {
    setSettings(prev => ({
      ...prev,
      showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
      ghanaPostGps: 'GA-110-3849',
      contactPhone: '0542443125/0596334488',
      contactEmail: 'concierge@ateliersurfaces.com'
    }));
  };

  // Toggle Single Room Lock
  const handleToggleRoomLock = (roomId: string) => {
    const nextLocked = storeService.toggleRoomLock(roomId, currentUser?.name, activeCompany.id);
    fetch(`/api/video/rooms/${roomId}/lock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isLocked: nextLocked })
    }).catch(() => {});
    setRooms(storeService.getConsultationRooms(activeCompany.id));
  };

  // Delete Room
  const handleDeleteRoom = (roomId: string) => {
    if (confirm(`Close and delete consultation room "${roomId}"?`)) {
      storeService.deleteConsultationRoom(roomId, currentUser?.name, activeCompany.id);
      fetch(`/api/video/rooms/${roomId}`, { method: 'DELETE' }).catch(() => {});
      setRooms(storeService.getConsultationRooms(activeCompany.id));
    }
  };

  // Add Room
  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;

    const roomId = (newRoomId.trim() || `atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`).replace(/\s+/g, '-');
    const created = storeService.saveConsultationRoom({
      id: roomId,
      name: newRoomName.trim(),
      createdAt: new Date().toISOString(),
      isLocked: newRoomLock,
      clientName: newRoomClient.trim() || 'Direct Client / Architect',
      clientRole: newRoomRole,
      consultantName: settings.videoConsultantName || 'Kwame Mensah',
      scheduledTime: 'Active Session',
      activeParticipantsCount: 0
    }, currentUser?.name, activeCompany.id);

    fetch('/api/video/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        roomId: created.id,
        name: created.name,
        clientName: created.clientName,
        clientRole: created.clientRole,
        isLocked: created.isLocked
      })
    }).catch(() => {});

    setRooms(storeService.getConsultationRooms(activeCompany.id));
    setNewRoomName('');
    setNewRoomId('');
    setNewRoomClient('');
    setShowAddRoomModal(false);
  };

  // Copy Link
  const handleCopyInviteLink = (roomId: string) => {
    const link = `${window.location.origin}/video-consultation?room=${roomId}`;
    navigator.clipboard.writeText(link);
    setCopiedRoomId(roomId);
    setTimeout(() => setCopiedRoomId(null), 2500);
  };

  return (
    <AdminLayout
      title="Face-to-Face Video Online Consultation & Showroom Desk"
      subtitle="Edit, save, configure, and lock real-time face-to-face video consultation calls and official flagship showroom coordinates."
      actions={
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleToggleGlobalCallLock}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs ${
              settings.videoConsultationLocked
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {settings.videoConsultationLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{settings.videoConsultationLocked ? 'Video Calls LOCKED' : 'Video Calls OPEN'}</span>
          </button>

          <button
            type="button"
            onClick={() => handleSaveAll()}
            className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save All Changes</span>
          </button>
        </div>
      }
    >
      <div className="space-y-8 max-w-6xl text-xs text-[var(--theme-text)]">
        
        {saveSuccess && (
          <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in rounded-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="font-semibold">
              Changes and locks saved successfully across video consultation tunnels and official showroom contact records.
            </span>
          </div>
        )}

        {/* Master Control Banner */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Card 1: Face-to-Face Video Consultation Status & Master Lock */}
          <div className={`p-6 border rounded-xs transition shadow-sm space-y-4 ${
            settings.videoConsultationLocked 
              ? 'bg-red-950/20 border-red-500/40' 
              : 'bg-emerald-950/20 border-emerald-500/40'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className={`w-5 h-5 ${settings.videoConsultationLocked ? 'text-red-500' : 'text-emerald-500'}`} />
                <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
                  Face-to-Face Video Online Calls
                </h3>
              </div>

              <span className={`px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-xs ${
                settings.videoConsultationLocked 
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {settings.videoConsultationLocked ? 'Locked / Restricted' : 'Active & Online'}
              </span>
            </div>

            <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
              {settings.videoConsultationLocked 
                ? 'Video consultation lobby is currently locked. Storefront visitors will see a reserved masterclass disclaimer and cannot initiate unapproved calls.'
                : 'Encrypted two-way WebRTC video calls with 3D slab co-viewing are enabled. Architects, clients, and contractors can join or create rooms.'}
            </p>

            <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)]">
              <span className="text-[11px] text-[var(--theme-text-muted)] font-medium">
                Master Security Gate:
              </span>
              <button
                type="button"
                onClick={handleToggleGlobalCallLock}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                  settings.videoConsultationLocked
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-red-600 hover:bg-red-500 text-white'
                }`}
              >
                {settings.videoConsultationLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{settings.videoConsultationLocked ? 'Unlock Video Calls' : 'Lock Video Calls Now'}</span>
              </button>
            </div>
          </div>

          {/* Card 2: Official Flagship Showroom Contact & Lock */}
          <div className={`p-6 border rounded-xs transition shadow-sm space-y-4 ${
            settings.contactLocked 
              ? 'bg-amber-950/20 border-amber-500/40' 
              : 'bg-[var(--theme-surface)] border-[var(--theme-border)]'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className={`w-5 h-5 ${settings.contactLocked ? 'text-amber-500' : 'text-[var(--theme-accent)]'}`} />
                <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
                  Showroom Contact & Location
                </h3>
              </div>

              <span className={`px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-xs ${
                settings.contactLocked 
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {settings.contactLocked ? 'Protected / Locked' : 'Unlocked (Editable)'}
              </span>
            </div>

            <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
              Official headquarters coordinates for Greater Accra, GhanaPost GPS routing, invoices, and showroom dispatch desk.
            </p>

            <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)]">
              <button
                type="button"
                onClick={handleApplyOfficialAccraDefaults}
                className="text-[11px] text-[var(--theme-accent)] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                title="Fill with official Accra Ridge West flagship defaults"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset to Official Accra Flagship</span>
              </button>

              <button
                type="button"
                onClick={handleToggleContactLock}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                  settings.contactLocked
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
                }`}
              >
                {settings.contactLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{settings.contactLocked ? 'Unlock Contact Details' : 'Lock Contact Details'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Section 1: Edit & Save Showroom Contact Details */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 1 · Official Coordinates
              </span>
              <h2 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                14 Independence Avenue, Ridge West Showroom Credentials
              </h2>
            </div>

            {settings.contactLocked && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/30 text-[10px] font-bold uppercase rounded-xs">
                <Lock className="w-3 h-3" />
                <span>Locked by {settings.contactLastSavedBy || 'Admin'}</span>
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Showroom Address *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.contactLocked}
                  value={settings.showroomAddress}
                  onChange={e => setSettings(prev => ({ ...prev, showroomAddress: e.target.value }))}
                  placeholder="14 Independence Avenue, Ridge West, Accra, Ghana"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] disabled:opacity-65 disabled:cursor-not-allowed font-medium focus:outline-none focus:border-[var(--theme-accent)]"
                />
                <MapPin className="w-4 h-4 text-[var(--theme-text-muted)] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                GhanaPost GPS Code *
              </label>
              <input
                type="text"
                required
                disabled={settings.contactLocked}
                value={settings.ghanaPostGps}
                onChange={e => setSettings(prev => ({ ...prev, ghanaPostGps: e.target.value.toUpperCase() }))}
                placeholder="GA-110-3849"
                className="w-full px-3 py-2.5 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] disabled:opacity-65 disabled:cursor-not-allowed font-bold focus:outline-none focus:border-[var(--theme-accent)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Concierge Contact Phone *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.contactLocked}
                  value={settings.contactPhone}
                  onChange={e => setSettings(prev => ({ ...prev, contactPhone: e.target.value }))}
                  placeholder="0542443125/0596334488"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] disabled:opacity-65 disabled:cursor-not-allowed font-medium focus:outline-none focus:border-[var(--theme-accent)]"
                />
                <Phone className="w-4 h-4 text-[var(--theme-text-muted)] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Concierge Official Email *
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  disabled={settings.contactLocked}
                  value={settings.contactEmail}
                  onChange={e => setSettings(prev => ({ ...prev, contactEmail: e.target.value }))}
                  placeholder="concierge@ateliersurfaces.com"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] disabled:opacity-65 disabled:cursor-not-allowed font-medium focus:outline-none focus:border-[var(--theme-accent)]"
                />
                <Mail className="w-4 h-4 text-[var(--theme-text-muted)] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={() => handleSaveAll()}
              className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase tracking-wider text-xs hover:opacity-90 transition cursor-pointer flex items-center gap-1.5 shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Contact Coordinates</span>
            </button>
          </div>
        </div>

        {/* Section 2: Edit & Save Face-to-Face Video Consultation Settings */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 2 · Consultant Identity & Parameters
              </span>
              <h2 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Lead Consultant Profile & WebRTC Protocol
              </h2>
            </div>

            <span className="text-[10px] font-mono text-[var(--theme-text-muted)]">
              Active Tenant: {activeCompany.name}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Lead Showroom Consultant Name
              </label>
              <input
                type="text"
                value={settings.videoConsultantName || 'Kwame Mensah'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantName: e.target.value }))}
                placeholder="Kwame Mensah"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultant Title & Role
              </label>
              <input
                type="text"
                value={settings.videoConsultantTitle || 'Lead Architectural Consultant'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantTitle: e.target.value }))}
                placeholder="Lead Architectural Consultant"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultant Gallery Location
              </label>
              <input
                type="text"
                value={settings.videoConsultantLocation || '14 Independence Avenue, Ridge West, Accra'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantLocation: e.target.value }))}
                placeholder="14 Independence Avenue, Ridge West, Accra"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultation Operational Hours
              </label>
              <input
                type="text"
                value={settings.videoConsultantHours || 'Mon–Sat: 8:00 AM – 6:00 PM GMT'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantHours: e.target.value }))}
                placeholder="Mon–Sat: 8:00 AM – 6:00 PM GMT"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Video Stream Quality
              </label>
              <select
                value={settings.videoResolution || '1080p'}
                onChange={e => setSettings(prev => ({ ...prev, videoResolution: e.target.value as any }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] cursor-pointer"
              >
                <option value="1080p">1080p Full High-Definition (Ultra-Low Latency)</option>
                <option value="720p">720p Balanced (Low Bandwidth Optimized)</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultant Live Status
              </label>
              <div className="flex items-center gap-4 pt-2">
                <label className="flex items-center gap-1.5 cursor-pointer font-medium">
                  <input
                    type="radio"
                    name="consultantStatus"
                    checked={settings.videoConsultantAvailable !== false}
                    onChange={() => setSettings(prev => ({ ...prev, videoConsultantAvailable: true }))}
                    className="accent-emerald-500"
                  />
                  <span className="text-emerald-500 font-bold">Online & Available</span>
                </label>

                <label className="flex items-center gap-1.5 cursor-pointer font-medium">
                  <input
                    type="radio"
                    name="consultantStatus"
                    checked={settings.videoConsultantAvailable === false}
                    onChange={() => setSettings(prev => ({ ...prev, videoConsultantAvailable: false }))}
                    className="accent-amber-500"
                  />
                  <span className="text-amber-500 font-bold">In Client Walkthrough</span>
                </label>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Custom Lockdown / Reserved Disclaimer Message (Shown to callers when locked)
              </label>
              <input
                type="text"
                value={settings.videoLockMessage || ''}
                onChange={e => setSettings(prev => ({ ...prev, videoLockMessage: e.target.value }))}
                placeholder="Video consultations are currently locked for a private architectural masterclass. Please contact the concierge."
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={() => handleSaveAll()}
              className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase tracking-wider text-xs hover:opacity-90 transition cursor-pointer flex items-center gap-1.5 shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Video Parameters</span>
            </button>
          </div>
        </div>

        {/* Section 3: Consultation Rooms Management (Add, Save, Lock, Delete) */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 3 · Room Management & Individual Locks
              </span>
              <h2 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Active Consultation Rooms & Meeting Locks ({rooms.length})
              </h2>
            </div>

            <button
              type="button"
              onClick={() => setShowAddRoomModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Consultation Room</span>
            </button>
          </div>

          {/* New Room Creator Modal / Drawer */}
          {showAddRoomModal && (
            <form onSubmit={handleCreateRoom} className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-2">
                <span className="font-bold text-xs uppercase text-[var(--theme-text)]">
                  Provision New Video Consultation Room
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddRoomModal(false)}
                  className="text-stone-400 hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Room Name / Topic *
                  </label>
                  <input
                    type="text"
                    required
                    value={newRoomName}
                    onChange={e => setNewRoomName(e.target.value)}
                    placeholder="e.g. Penthouse Marble Review"
                    className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Client / Architectural Practice
                  </label>
                  <input
                    type="text"
                    value={newRoomClient}
                    onChange={e => setNewRoomClient(e.target.value)}
                    placeholder="e.g. Studio Arch Ghana"
                    className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Target Room ID (Leave blank to generate)
                  </label>
                  <input
                    type="text"
                    value={newRoomId}
                    onChange={e => setNewRoomId(e.target.value)}
                    placeholder="e.g. consult-penthouse-901"
                    className="w-full px-3 py-2 font-mono bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                  <input
                    type="checkbox"
                    checked={newRoomLock}
                    onChange={e => setNewRoomLock(e.target.checked)}
                    className="accent-red-500"
                  />
                  <span>Lock room on creation (Require host unlock)</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddRoomModal(false)}
                    className="px-3 py-1.5 border border-[var(--theme-border)] text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase rounded-xs cursor-pointer shadow-xs"
                  >
                    Create Room
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Edit Existing Room Modal / Drawer */}
          {editingRoom && (
            <form onSubmit={handleSaveEditedRoom} className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xs space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-2">
                <div className="flex items-center gap-2">
                  <Pencil className="w-4 h-4 text-amber-500" />
                  <span className="font-bold text-xs uppercase text-[var(--theme-text)]">
                    Edit Consultation Room: <span className="font-mono">{editingRoom.id}</span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingRoom(null)}
                  className="text-stone-400 hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Room Name / Topic *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingRoom.name}
                    onChange={e => setEditingRoom(prev => prev ? { ...prev, name: e.target.value } : null)}
                    className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Client / Practice
                  </label>
                  <input
                    type="text"
                    value={editingRoom.clientName || ''}
                    onChange={e => setEditingRoom(prev => prev ? { ...prev, clientName: e.target.value } : null)}
                    className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[var(--theme-text-muted)] mb-1">
                    Consultant Assigned
                  </label>
                  <input
                    type="text"
                    value={editingRoom.consultantName || ''}
                    onChange={e => setEditingRoom(prev => prev ? { ...prev, consultantName: e.target.value } : null)}
                    className="w-full px-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                  <input
                    type="checkbox"
                    checked={!!editingRoom.isLocked}
                    onChange={e => setEditingRoom(prev => prev ? { ...prev, isLocked: e.target.checked } : null)}
                    className="accent-red-500"
                  />
                  <span>Lock this consultation room (Restrict access)</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingRoom(null)}
                    className="px-3 py-1.5 border border-[var(--theme-border)] text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase rounded-xs cursor-pointer shadow-xs flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Table of Existing Rooms */}
          <div className="overflow-x-auto border border-[var(--theme-border)]">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">
                  <th className="p-3">Room Identification</th>
                  <th className="p-3">Client / Practice</th>
                  <th className="p-3">Consultant</th>
                  <th className="p-3">Lock Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--theme-border)]">
                {rooms.map(room => (
                  <tr key={room.id} className="hover:bg-[var(--theme-surface-subtle)] transition">
                    <td className="p-3">
                      <div className="font-serif-luxury font-bold text-sm text-[var(--theme-text)]">
                        {room.name}
                      </div>
                      <div className="font-mono text-[10px] text-[var(--theme-text-muted)] flex items-center gap-1.5">
                        <Radio className="w-2.5 h-2.5 text-emerald-500 animate-pulse" />
                        <span>{room.id}</span>
                      </div>
                    </td>

                    <td className="p-3">
                      <span className="font-semibold block text-[var(--theme-text)]">
                        {room.clientName || 'General Client'}
                      </span>
                      <span className="text-[10px] text-[var(--theme-text-muted)] block">
                        {room.clientRole || 'Architect'}
                      </span>
                    </td>

                    <td className="p-3">
                      <span className="font-medium text-[var(--theme-text)]">
                        {room.consultantName || settings.videoConsultantName || 'Kwame Mensah'}
                      </span>
                    </td>

                    <td className="p-3">
                      <button
                        type="button"
                        onClick={() => handleToggleRoomLock(room.id)}
                        className={`px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-xs flex items-center gap-1 transition cursor-pointer ${
                          room.isLocked
                            ? 'bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30'
                        }`}
                        title={room.isLocked ? 'Click to Unlock Room' : 'Click to Lock Room'}
                      >
                        {room.isLocked ? <Lock className="w-3 h-3 text-red-400" /> : <Unlock className="w-3 h-3 text-emerald-400" />}
                        <span>{room.isLocked ? 'Locked' : 'Unlocked'}</span>
                      </button>
                    </td>

                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => handleCopyInviteLink(room.id)}
                          className="p-1.5 hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs rounded-xs transition cursor-pointer text-[var(--theme-text)]"
                          title="Copy shareable room invite link"
                        >
                          {copiedRoomId === room.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => setEditingRoom(room)}
                          className="p-1.5 hover:bg-amber-500/10 border border-amber-500/30 text-amber-500 rounded-xs transition cursor-pointer"
                          title="Edit consultation room parameters & lock"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>

                        <a
                          href={`/video-consultation?room=${room.id}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] uppercase rounded-xs transition flex items-center gap-1"
                          title="Join room as Consultant / Host"
                        >
                          <Video className="w-3 h-3" />
                          <span>Join Call</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => handleDeleteRoom(room.id)}
                          className="p-1.5 hover:bg-red-500/20 text-red-500 border border-red-500/30 rounded-xs transition cursor-pointer"
                          title="Close & delete room"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </AdminLayout>
  );
}
