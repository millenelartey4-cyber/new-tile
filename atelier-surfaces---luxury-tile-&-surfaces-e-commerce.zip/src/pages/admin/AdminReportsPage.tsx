import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { 
  FileText, 
  TrendingUp, 
  Download, 
  Sparkles, 
  Boxes, 
  BarChart3, 
  PieChart, 
  CheckCircle2
} from 'lucide-react';

export function AdminReportsPage() {
  const orders = storeService.getOrders();
  const products = storeService.getProducts();

  const paidOrders = orders.filter(o => o.paymentStatus === 'paid');
  const totalRevenue = paidOrders.reduce((sum, o) => sum + o.total, 0);
  const totalTilesSoldM2 = paidOrders.reduce((sum, o) => 
    sum + o.itemsSnapshot.reduce((iSum, item) => iSum + item.quantity, 0), 0
  );

  const [dateRange, setDateRange] = useState('month');
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Sales by Category
  const categorySalesMap = new Map<string, number>();
  paidOrders.forEach(o => {
    o.itemsSnapshot.forEach(item => {
      const prod = products.find(p => p.id === item.productId);
      const cat = prod?.categoryName || 'Other Surfaces';
      categorySalesMap.set(cat, (categorySalesMap.get(cat) || 0) + item.lineTotal);
    });
  });

  const categorySales = Array.from(categorySalesMap.entries()).map(([name, amount]) => ({
    name,
    amount,
    percent: totalRevenue > 0 ? (amount / totalRevenue) * 100 : 0
  }));

  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Order Number,Client Name,Total (GHS),Payment Status,Fulfillment Status,Date\n"
      + orders.map(o => `${o.orderNumber},"${o.customerSnapshot.name}",${o.total},${o.paymentStatus},${o.orderStatus},${o.createdAt}`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `atelier_surfaces_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <AdminLayout
      title="Daily AI Business Report & Surface Analytics"
      subtitle="Automated inventory turnover diagnostics, revenue reconciliation, and category sales velocity."
      actions={
        <div className="flex items-center gap-2">
          <Link
            href="/admin/analytics"
            className="px-4 py-2 bg-[var(--theme-accent)] text-white text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5 transition-opacity"
          >
            <BarChart3 className="w-4 h-4" />
            <span>Interactive Recharts Analytics</span>
          </Link>
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV Audit</span>
          </button>
        </div>
      }
    >
      {downloadSuccess && (
        <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Financial summary CSV downloaded successfully.</span>
        </div>
      )}

      {/* AI Executive Summary Card */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4 relative overflow-hidden">
        <div className="flex items-center gap-2 text-xs uppercase font-bold tracking-widest text-[var(--theme-accent)]">
          <Sparkles className="w-4 h-4" />
          <span>Daily AI Commercial Intelligence Dispatch</span>
        </div>

        <h3 className="font-serif-luxury text-2xl font-semibold text-[var(--theme-text)]">
          Executive Quarry & Order Velocity Briefing
        </h3>

        <div className="prose text-xs text-[var(--theme-text-muted)] space-y-2 leading-relaxed max-w-3xl">
          <p>
            • <strong>Revenue Performance:</strong> Gross reconciled revenue stands at <strong className="text-[var(--theme-text)]">GH₵{totalRevenue.toLocaleString()}</strong> across {paidOrders.length} verified trade invoices.
          </p>
          <p>
            • <strong>High-Volume Material:</strong> Marble-Look porcelain slabs represent over 60% of total yardage demand, driven by large residential master suite specifications in Airport Residential and East Legon.
          </p>
          <p>
            • <strong>Inventory Recommendation:</strong> Restock orders should be placed with our Sassuolo factory for <em>Travertino Navona (Silver Cloud)</em> and <em>Terrazzo Venezia</em> to avert lead time bottlenecks before Q4 commercial groundbreakings.
          </p>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-1">
          <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider">
            Reconciled Invoiced Revenue
          </span>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            GH₵{totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-emerald-700 font-semibold">Verified through Paystack & Wire</span>
        </div>

        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-1">
          <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider">
            Total Material Allocated
          </span>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            {totalTilesSoldM2.toLocaleString()} m²
          </div>
          <span className="text-[11px] text-[var(--theme-text-muted)]">Crated and palletized</span>
        </div>

        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-1">
          <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] tracking-wider">
            Average Order Value (AOV)
          </span>
          <div className="text-2xl font-bold tabular-nums text-[var(--theme-text)]">
            GH₵{paidOrders.length > 0 ? (totalRevenue / paidOrders.length).toLocaleString(undefined, { maximumFractionDigits: 0 }) : '0'}
          </div>
          <span className="text-[11px] text-[var(--theme-text-muted)]">Per architectural contract</span>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
        <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-3 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-[var(--theme-accent)]" />
          <span>Material Sales Distribution by Category</span>
        </h3>

        <div className="space-y-4 text-xs">
          {categorySales.map(cs => (
            <div key={cs.name} className="space-y-1">
              <div className="flex justify-between items-center font-medium">
                <span className="text-[var(--theme-text)]">{cs.name}</span>
                <span className="tabular-nums font-bold text-[var(--theme-text)]">
                  GH₵{cs.amount.toLocaleString()} ({cs.percent.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full h-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] overflow-hidden">
                <div
                  className="h-full bg-[var(--theme-accent)] transition-all duration-500"
                  style={{ width: `${cs.percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
