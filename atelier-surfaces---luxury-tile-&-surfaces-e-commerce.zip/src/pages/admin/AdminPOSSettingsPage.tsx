import React, { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { realtimeSyncService } from '../../services/realtimeSync';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { POSSettings } from '../../types';
import { Link } from '../../router/Router';
import { 
  CreditCard, 
  Lock, 
  Unlock, 
  Save, 
  CheckCircle2, 
  Sliders, 
  Printer, 
  Receipt, 
  Percent, 
  Smartphone, 
  ShieldAlert, 
  RefreshCw, 
  Volume2, 
  Layers, 
  Barcode, 
  KeyRound, 
  ExternalLink,
  Store,
  DollarSign,
  MapPin,
  Phone,
  Mail,
  Globe,
  RotateCcw,
  MessageSquare
} from 'lucide-react';

export function AdminPOSSettingsPage() {
  const { currentUser, hasPermission } = useAuth();
  const { activeCompany, updateCompany } = useCompany();
  const currentPOS = storeService.getPOSSettings(activeCompany.id);
  const storeSettings = storeService.getStoreSettings(activeCompany.id);

  const [settings, setSettings] = useState<POSSettings>(() => ({
    ...currentPOS,
    showroomAddress: currentPOS.showroomAddress || storeSettings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana',
    ghanaPostGps: currentPOS.ghanaPostGps || storeSettings.ghanaPostGps || 'GA-110-3849',
    contactPhone: currentPOS.contactPhone || storeSettings.contactPhone || '0542443125/0596334488',
    whatsAppNumber: currentPOS.whatsAppNumber || storeSettings.whatsAppNumber || '0542443125/0596334488',
    contactEmail: currentPOS.contactEmail || storeSettings.contactEmail || 'concierge@ateliersurfaces.com'
  }));
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isApplyingShowroom, setIsApplyingShowroom] = useState(false);
  const [showroomApplySuccess, setShowroomApplySuccess] = useState(false);
  const [newPresetValue, setNewPresetValue] = useState<number>(0);

  const canManage = hasPermission('store_settings', 'manage_settings') || currentUser?.roleId === 'super-admin' || currentUser?.roleId === 'manager';

  const handleApplyAndSaveShowroom = async (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (!canManage) {
      alert('You lack permission to edit showroom credentials.');
      return;
    }
    if (!settings.showroomAddress?.trim() || !settings.ghanaPostGps?.trim() || !settings.contactPhone?.trim() || !settings.contactEmail?.trim()) {
      alert('Please fill Showroom Address, GhanaPost GPS, Phone, WhatsApp, and Email before applying.');
      return;
    }

    setIsApplyingShowroom(true);

    const cleanAddress = settings.showroomAddress.trim();
    const cleanGps = settings.ghanaPostGps.trim().toUpperCase();
    const cleanPhone = settings.contactPhone.trim();
    const cleanWhatsApp = (settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488').trim();
    const cleanEmail = settings.contactEmail.trim();

    // 1. Update POS Settings & replace old values in storeService
    storeService.updatePOSSettings({
      showroomAddress: cleanAddress,
      ghanaPostGps: cleanGps,
      contactPhone: cleanPhone,
      whatsAppNumber: cleanWhatsApp,
      contactEmail: cleanEmail,
      momoMerchantNumber: cleanPhone
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 2. Update Store Settings & replace old values
    storeService.updateStoreSettings({
      showroomAddress: cleanAddress,
      ghanaPostGps: cleanGps,
      contactPhone: cleanPhone,
      whatsAppNumber: cleanWhatsApp,
      contactEmail: cleanEmail
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 3. Update Company Tenant in CompanyContext
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        showroomAddress: cleanAddress,
        ghanaPostGps: cleanGps,
        contactPhone: cleanPhone,
        whatsAppNumber: cleanWhatsApp,
        contactEmail: cleanEmail
      });
    }

    // 4. Sync backend video config
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        showroomContact: {
          address: cleanAddress,
          gps: cleanGps,
          phone: cleanPhone,
          email: cleanEmail
        }
      })
    }).catch(() => {});

    // 5. Broadcast real-time event to storefront WebSocket & SSE
    try {
      await realtimeSyncService.publishEvent('SHOWROOM_LOCATION_UPDATED', {
        showroomAddress: cleanAddress,
        ghanaPostGps: cleanGps,
        contactPhone: cleanPhone,
        contactEmail: cleanEmail
      }, activeCompany.id, currentUser?.name || 'Showroom Administrator');
    } catch {}

    setIsApplyingShowroom(false);
    setShowroomApplySuccess(true);
    setTimeout(() => setShowroomApplySuccess(false), 4000);
  };

  const handleToggleLock = () => {
    const nextLocked = !settings.isLocked;
    const updated = storeService.togglePOSLock(nextLocked, currentUser?.name, activeCompany.id);
    setSettings(prev => ({
      ...prev,
      isLocked: updated,
      lockedBy: updated ? currentUser?.name : undefined,
      lockedAt: updated ? new Date().toISOString() : undefined,
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleResetToFlagshipDefault = () => {
    if (settings.isLocked) return;
    setSettings(prev => ({
      ...prev,
      showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
      ghanaPostGps: 'GA-110-3849',
      contactPhone: '0542443125/0596334488',
      contactEmail: 'concierge@ateliersurfaces.com',
      momoMerchantNumber: '0542443125/0596334488',
      receiptHeaderNote: 'ATELIER SURFACES · RIDGE WEST FLAGSHIP'
    }));
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canManage) return;

    // 1. Update POS Settings in storeService (with auto-sync to StoreSettings)
    storeService.updatePOSSettings(settings, currentUser?.name, activeCompany.id);

    // 2. Also directly update StoreSettings for immediate storefront reactivity
    storeService.updateStoreSettings({
      showroomAddress: settings.showroomAddress,
      ghanaPostGps: settings.ghanaPostGps,
      contactPhone: settings.contactPhone,
      contactEmail: settings.contactEmail
    }, currentUser?.name, activeCompany.id);

    // 3. Update Company Tenant record in CompanyContext
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        showroomAddress: settings.showroomAddress || activeCompany.showroomAddress,
        ghanaPostGps: settings.ghanaPostGps || activeCompany.ghanaPostGps,
        contactPhone: settings.contactPhone || activeCompany.contactPhone,
        contactEmail: settings.contactEmail || activeCompany.contactEmail
      });
    }

    // 4. Sync backend video config & contact
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        showroomContact: {
          address: settings.showroomAddress,
          gps: settings.ghanaPostGps,
          phone: settings.contactPhone,
          email: settings.contactEmail
        }
      })
    }).catch(() => {});

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddDiscountPreset = () => {
    if (newPresetValue > 0 && newPresetValue <= 100 && !settings.quickDiscountPresets.includes(newPresetValue)) {
      const nextPresets = [...settings.quickDiscountPresets, newPresetValue].sort((a, b) => a - b);
      setSettings(prev => ({ ...prev, quickDiscountPresets: nextPresets }));
      setNewPresetValue(0);
    }
  };

  const handleRemoveDiscountPreset = (val: number) => {
    if (settings.isLocked) return;
    setSettings(prev => ({
      ...prev,
      quickDiscountPresets: prev.quickDiscountPresets.filter(p => p !== val)
    }));
  };

  const handleTogglePaymentMethod = (method: keyof POSSettings['enabledPaymentMethods']) => {
    if (settings.isLocked) return;
    setSettings(prev => ({
      ...prev,
      enabledPaymentMethods: {
        ...prev.enabledPaymentMethods,
        [method]: !prev.enabledPaymentMethods[method]
      }
    }));
  };

  return (
    <AdminLayout
      title={`Showroom Point of Sale (POS) Settings & Configuration · ${activeCompany.name}`}
      subtitle="Configure showroom cashier terminals, pricing & tax rules, cashier discount caps, thermal receipt formatting, and payment tender locks."
      actions={
        <div className="flex items-center gap-2">
          <Link
            href="/admin/pos"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Launch POS Terminal</span>
          </Link>

          <button
            type="button"
            onClick={handleToggleLock}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs ${
              settings.isLocked
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600'
            }`}
          >
            {settings.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            <span>{settings.isLocked ? 'POS Settings LOCKED' : 'Lock POS Settings'}</span>
          </button>

          <button
            type="button"
            onClick={() => handleSave()}
            className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save All POS Settings</span>
          </button>
        </div>
      }
    >
      <div className="space-y-8 max-w-5xl text-xs text-[var(--theme-text)]">
        
        {saveSuccess && (
          <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in rounded-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="font-semibold">
              POS register settings, payment methods, discount caps, and hardware preferences saved successfully!
            </span>
          </div>
        )}

        {/* Master Status & Lock Card */}
        <div className={`p-6 border rounded-xs transition shadow-sm space-y-4 ${
          settings.isLocked 
            ? 'bg-amber-950/20 border-amber-500/40' 
            : 'bg-[var(--theme-surface)] border-[var(--theme-border)]'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Store className={`w-5 h-5 ${settings.isLocked ? 'text-amber-500' : 'text-[var(--theme-accent)]'}`} />
              <div>
                <h2 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                  Showroom POS Security & Administration Gate
                </h2>
                <p className="text-[11px] text-[var(--theme-text-muted)]">
                  When locked by administrator, cashiers cannot modify tax calculation, override maximum discount limits, or disable audit records.
                </p>
              </div>
            </div>

            <span className={`px-2.5 py-1 text-[10px] font-mono font-bold uppercase rounded-xs self-start sm:self-auto ${
              settings.isLocked
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}>
              {settings.isLocked ? `Locked by ${settings.lockedBy || 'Admin'}` : 'Unlocked (Configurable)'}
            </span>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-[var(--theme-border)] text-xs">
            <span className="text-[var(--theme-text-muted)] font-medium">
              Terminal Code: <strong className="font-mono text-[var(--theme-text)]">{settings.registerCode}</strong> ({settings.registerName})
            </span>

            <button
              type="button"
              onClick={handleToggleLock}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                settings.isLocked
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-amber-600 hover:bg-amber-500 text-white'
              }`}
            >
              {settings.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
              <span>{settings.isLocked ? 'Unlock Configuration' : 'Lock POS Settings Now'}</span>
            </button>
          </div>
        </div>

        {/* SECTION 1: REGISTER & CASHIER PROFILE */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 1 · Hardware & Profile
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Showroom Terminal Identification & Cashier Default
              </h3>
            </div>
            <Store className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Register Terminal Name *
              </label>
              <input
                type="text"
                required
                disabled={settings.isLocked}
                value={settings.registerName}
                onChange={e => setSettings(prev => ({ ...prev, registerName: e.target.value }))}
                placeholder="e.g. Ridge West Showroom Terminal #1"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Terminal Code / Serial Identifier *
              </label>
              <input
                type="text"
                required
                disabled={settings.isLocked}
                value={settings.registerCode}
                onChange={e => setSettings(prev => ({ ...prev, registerCode: e.target.value.toUpperCase() }))}
                placeholder="RW-POS-01"
                className="w-full px-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-bold disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Default Cashier Display Name
              </label>
              <input
                type="text"
                disabled={settings.isLocked}
                value={settings.defaultCashierName}
                onChange={e => setSettings(prev => ({ ...prev, defaultCashierName: e.target.value }))}
                placeholder="Kwame Mensah"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Walk-In Client Label (Default Customer)
              </label>
              <input
                type="text"
                disabled={settings.isLocked}
                value={settings.walkInCustomerName}
                onChange={e => setSettings(prev => ({ ...prev, walkInCustomerName: e.target.value }))}
                placeholder="Showroom Walk-in Client"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>
          </div>
        </div>

        {/* SECTION 1.5: SHOWROOM PHYSICAL LOCATION & STOREFRONT CONTACT SYNCHRONIZATION */}
        <div className="bg-[var(--theme-surface)] border-2 border-[var(--theme-accent)]/50 p-6 space-y-4 shadow-sm rounded-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[var(--theme-border)] pb-3 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                  Section 1.5 · Storefront & POS Unified Registry
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-emerald-950/80 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full font-mono">
                  <Globe className="w-3 h-3" /> Live Storefront Sync
                </span>
              </div>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)] mt-0.5">
                Flagship Showroom Contact & GPS Credentials
              </h3>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Physical showroom address, digital GPS routing, desk phone, and trade concierge inquiries.
              </p>
            </div>
            
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                type="button"
                disabled={settings.isLocked}
                onClick={handleResetToFlagshipDefault}
                className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] text-xs font-semibold rounded-xs flex items-center gap-1.5 text-[var(--theme-text)] cursor-pointer disabled:opacity-50"
                title="Reset address, GPS, phone and email to 14 Independence Avenue Ridge West"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <span>Accra Defaults</span>
              </button>

              {/* Dedicated Apply and Save Button in Header */}
              <button
                type="button"
                disabled={settings.isLocked || isApplyingShowroom}
                onClick={handleApplyAndSaveShowroom}
                className={`px-4 py-1.5 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer ${
                  showroomApplySuccess
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
                title="Apply & save these credentials to immediately replace the old across storefront and POS"
              >
                {showroomApplySuccess ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                <span>{isApplyingShowroom ? 'Applying...' : showroomApplySuccess ? 'Applied & Saved!' : 'Apply & Save'}</span>
              </button>
            </div>
          </div>

          {/* Sync Guarantee Notice */}
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xs flex items-start gap-2.5 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <div className="text-[11px] text-[var(--theme-text)] space-y-0.5">
              <span className="font-bold block text-[var(--theme-text)]">
                Real-Time Storefront & POS Hardware Synchronization
              </span>
              <span className="text-[var(--theme-text-muted)]">
                Changes saved here instantly update the public Storefront Footer, Contact Us Directory, Checkout Surcharge Rules, Cashier Thermal Receipts, and Lead Consultant Video Consultations without requiring application rebuild or reload.
              </span>
            </div>
          </div>

          {showroomApplySuccess && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs rounded-xs flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Changes Applied & Saved:</strong> Flagship Showroom credentials have taken effect immediately and replaced old data across Storefront, POS Receipts, and Video Concierge!
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Flagship Showroom Street Address *</span>
                <span className="text-[10px] text-[var(--theme-text-muted)] font-normal">Displayed on storefront footer & receipts</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.isLocked}
                  value={settings.showroomAddress || ''}
                  onChange={e => setSettings(prev => ({ ...prev, showroomAddress: e.target.value }))}
                  placeholder="14 Independence Avenue, Ridge West, Accra, Ghana"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] disabled:opacity-60 focus:outline-none focus:border-[var(--theme-accent)]"
                />
                <MapPin className="w-4 h-4 text-[var(--theme-accent)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>GhanaPost GPS Digital Code *</span>
                <span className="text-[10px] font-mono text-[var(--theme-accent)]">Digital Address</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.isLocked}
                  value={settings.ghanaPostGps || ''}
                  onChange={e => setSettings(prev => ({ ...prev, ghanaPostGps: e.target.value.toUpperCase() }))}
                  placeholder="GA-110-3849"
                  className="w-full pl-9 pr-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-bold text-[var(--theme-text)] disabled:opacity-60 focus:outline-none focus:border-[var(--theme-accent)]"
                />
                <Globe className="w-4 h-4 text-[var(--theme-accent)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Showroom Desk & Customer Hotline *</span>
                <span className="text-[10px] text-[var(--theme-text-muted)] font-normal">Calls & MoMo inquiries</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.isLocked}
                  value={settings.contactPhone || ''}
                  onChange={e => setSettings(prev => ({ ...prev, contactPhone: e.target.value, momoMerchantNumber: e.target.value }))}
                  placeholder="0542443125/0596334488"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] disabled:opacity-60 focus:outline-none focus:border-[var(--theme-accent)] font-mono"
                />
                <Phone className="w-4 h-4 text-[var(--theme-accent)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Direct Trade WhatsApp Desk WhatsApp Number *</span>
                <span className="text-[10px] font-mono text-emerald-500 font-bold">WhatsApp Trade Desk</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  disabled={settings.isLocked}
                  value={settings.whatsAppNumber || ''}
                  onChange={e => setSettings(prev => ({ ...prev, whatsAppNumber: e.target.value }))}
                  placeholder="0542443125/0596334488"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] disabled:opacity-60 focus:outline-none focus:border-emerald-500 font-mono"
                />
                <MessageSquare className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Official Concierge Inquiries Email *</span>
                <span className="text-[10px] text-[var(--theme-text-muted)] font-normal">Trade specifications & invoices</span>
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  disabled={settings.isLocked}
                  value={settings.contactEmail || ''}
                  onChange={e => setSettings(prev => ({ ...prev, contactEmail: e.target.value }))}
                  placeholder="concierge@ateliersurfaces.com"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] disabled:opacity-60 focus:outline-none focus:border-[var(--theme-accent)] font-mono"
                />
                <Mail className="w-4 h-4 text-[var(--theme-accent)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Dedicated Apply and Save Action Bar */}
          <div className="pt-3 border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Clicking <strong>Apply & Save</strong> immediately commits these credentials and replaces the old settings across Storefront & POS.</span>
            </div>

            <button
              type="button"
              disabled={settings.isLocked || isApplyingShowroom}
              onClick={handleApplyAndSaveShowroom}
              className={`px-5 py-2.5 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition shadow-md cursor-pointer ${
                showroomApplySuccess
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {showroomApplySuccess ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              <span>{isApplyingShowroom ? 'Applying & Saving...' : showroomApplySuccess ? 'Applied & Saved Successfully!' : 'Apply & Save Showroom Credentials'}</span>
            </button>
          </div>
        </div>

        {/* SECTION 2: PRICING, TAX & DISCOUNT RULES (FEATURES OF CHOICE) */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 2 · Financial Governance & Discounts
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Taxes, Cashier Discount Caps & Supervisor PIN
              </h3>
            </div>
            <Percent className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Tax Calculation Mode
              </label>
              <select
                disabled={settings.isLocked}
                value={settings.taxCalculationMode}
                onChange={e => setSettings(prev => ({ ...prev, taxCalculationMode: e.target.value as any }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold cursor-pointer disabled:opacity-60"
              >
                <option value="inclusive">Tax Inclusive (Prices include VAT/NHIL/GETFund)</option>
                <option value="exclusive">Tax Exclusive (Added at checkout subtotal)</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                POS Tax Rate (%)
              </label>
              <input
                type="number"
                min="0"
                max="50"
                disabled={settings.isLocked}
                value={settings.taxRatePercent}
                onChange={e => setSettings(prev => ({ ...prev, taxRatePercent: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs tabular-nums disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Max Cashier Discount Cap (%)
              </label>
              <input
                type="number"
                min="0"
                max="100"
                disabled={settings.isLocked}
                value={settings.maxCashierDiscountPercent}
                onChange={e => setSettings(prev => ({ ...prev, maxCashierDiscountPercent: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs tabular-nums font-bold text-amber-500 disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Supervisor Override PIN
              </label>
              <div className="relative">
                <input
                  type="password"
                  maxLength={6}
                  disabled={settings.isLocked}
                  value={settings.supervisorPin}
                  onChange={e => setSettings(prev => ({ ...prev, supervisorPin: e.target.value }))}
                  placeholder="9814"
                  className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-bold tracking-widest disabled:opacity-60"
                />
                <KeyRound className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="sm:col-span-2 space-y-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Quick Discount Preset Buttons (Available in POS Ticket)
              </label>
              <div className="flex flex-wrap items-center gap-2">
                {settings.quickDiscountPresets.map(preset => (
                  <span
                    key={preset}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs font-mono font-bold text-xs"
                  >
                    <span>{preset}%</span>
                    {!settings.isLocked && (
                      <button
                        type="button"
                        onClick={() => handleRemoveDiscountPreset(preset)}
                        className="text-stone-400 hover:text-red-500 cursor-pointer ml-1"
                      >
                        ✕
                      </button>
                    )}
                  </span>
                ))}

                {!settings.isLocked && (
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="1"
                      max="100"
                      placeholder="Add %"
                      value={newPresetValue || ''}
                      onChange={e => setNewPresetValue(parseInt(e.target.value, 10) || 0)}
                      className="w-16 px-2 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleAddDiscountPreset}
                      className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600 text-xs font-bold rounded-xs cursor-pointer"
                    >
                      + Add
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-[var(--theme-border)]">
            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.requireSupervisorDiscountPin}
                onChange={e => setSettings(prev => ({ ...prev, requireSupervisorDiscountPin: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Require Supervisor PIN when discount exceeds {settings.maxCashierDiscountPercent}%</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.autoDeductInventory}
                onChange={e => setSettings(prev => ({ ...prev, autoDeductInventory: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Real-Time Inventory Auto-Decrement upon completed sale</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.allowNegativeInventory}
                onChange={e => setSettings(prev => ({ ...prev, allowNegativeInventory: e.target.checked }))}
                className="accent-amber-500"
              />
              <span>Allow Backorders / Negative Stock Selling in Showroom</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.offlineModeEnabled}
                onChange={e => setSettings(prev => ({ ...prev, offlineModeEnabled: e.target.checked }))}
                className="accent-emerald-500"
              />
              <span>Enable Offline Transaction Caching & Background Sync Queue</span>
            </label>
          </div>
        </div>

        {/* SECTION 3: PAYMENT METHODS & SPLIT TENDER */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 3 · Payment Tenders & Mobile Money
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Accepted Tenders & Mobile Money Routing
              </h3>
            </div>
            <Smartphone className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { key: 'cash' as const, label: 'Cash Payment' },
              { key: 'card' as const, label: 'Credit / Debit Card Terminal' },
              { key: 'mobileMoney' as const, label: 'MTN MoMo & Telecel Cash' },
              { key: 'bankTransfer' as const, label: 'Bank Transfer / Wire' },
              { key: 'cheque' as const, label: 'Bank Certified Cheque' },
              { key: 'split' as const, label: 'Split Tender (e.g. Cash + MoMo)' },
            ].map(m => (
              <label 
                key={m.key} 
                className={`p-3 border rounded-xs flex items-center justify-between transition cursor-pointer ${
                  settings.enabledPaymentMethods[m.key]
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-[var(--theme-text)]'
                    : 'bg-[var(--theme-surface-subtle)] border-[var(--theme-border)] text-[var(--theme-text-muted)] opacity-60'
                }`}
              >
                <span className="font-bold text-xs">{m.label}</span>
                <input
                  type="checkbox"
                  disabled={settings.isLocked}
                  checked={settings.enabledPaymentMethods[m.key]}
                  onChange={() => handleTogglePaymentMethod(m.key)}
                  className="accent-emerald-500"
                />
              </label>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[var(--theme-border)]">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Showroom MoMo Merchant / Desk Phone *
              </label>
              <input
                type="text"
                disabled={settings.isLocked}
                value={settings.momoMerchantNumber}
                onChange={e => setSettings(prev => ({ ...prev, momoMerchantNumber: e.target.value }))}
                placeholder="0542443125/0596334488"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Quick Cash Payment Denomination Buttons (GH₵)
              </label>
              <div className="flex items-center gap-2 pt-1 font-mono font-bold text-xs">
                {settings.quickCashDenominations.map(denom => (
                  <span key={denom} className="px-2 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs">
                    GH₵{denom}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 4: THERMAL RECEIPT & PRINTING PREFERENCES */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                Section 4 · Hardware & Thermal Receipts
              </span>
              <h3 className="font-serif-luxury text-base font-bold text-[var(--theme-text)]">
                Thermal Printer Formatting & GhanaPost GPS Printing
              </h3>
            </div>
            <Printer className="w-4 h-4 text-[var(--theme-accent)]" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Receipt Printer Width Format
              </label>
              <select
                disabled={settings.isLocked}
                value={settings.receiptPrinterWidth}
                onChange={e => setSettings(prev => ({ ...prev, receiptPrinterWidth: e.target.value as any }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold cursor-pointer disabled:opacity-60"
              >
                <option value="80mm">80mm Standard Architectural Thermal Paper (Recommended)</option>
                <option value="58mm">58mm Compact Retail Roll</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Receipt Top Banner Heading
              </label>
              <input
                type="text"
                disabled={settings.isLocked}
                value={settings.receiptHeaderNote}
                onChange={e => setSettings(prev => ({ ...prev, receiptHeaderNote: e.target.value }))}
                placeholder="ATELIER SURFACES · RIDGE WEST FLAGSHIP"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Receipt Footer Verification Note
              </label>
              <input
                type="text"
                disabled={settings.isLocked}
                value={settings.receiptFooterNote}
                onChange={e => setSettings(prev => ({ ...prev, receiptFooterNote: e.target.value }))}
                placeholder="Thank you for choosing Atelier Surfaces. Goods inspected & verified at Ridge West Showroom."
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium disabled:opacity-60"
              />
            </div>
          </div>

          <div className="pt-2 grid grid-cols-1 sm:grid-cols-3 gap-3 border-t border-[var(--theme-border)]">
            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.receiptShowGps}
                onChange={e => setSettings(prev => ({ ...prev, receiptShowGps: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Print GhanaPost GPS GA-110-3849</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.receiptShowBarcode}
                onChange={e => setSettings(prev => ({ ...prev, receiptShowBarcode: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Print Verification Barcode on Ticket</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.cashDrawerAutoKick}
                onChange={e => setSettings(prev => ({ ...prev, cashDrawerAutoKick: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Auto-Kick Cash Drawer on Cash Sale</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.barcodeContinuousScan}
                onChange={e => setSettings(prev => ({ ...prev, barcodeContinuousScan: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Barcode Continuous Scan Mode</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold">
              <input
                type="checkbox"
                disabled={settings.isLocked}
                checked={settings.playNotificationSound}
                onChange={e => setSettings(prev => ({ ...prev, playNotificationSound: e.target.checked }))}
                className="accent-[var(--theme-accent)]"
              />
              <span>Audio Chime on Scan & Tender</span>
            </label>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2">
          <Link
            href="/admin/pos"
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-2 transition"
          >
            <CreditCard className="w-4 h-4" />
            <span>Open POS Cashier Terminal</span>
          </Link>

          <button
            type="button"
            onClick={() => handleSave()}
            className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center gap-1.5 shadow-md cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save All Changes</span>
          </button>
        </div>

      </div>
    </AdminLayout>
  );
}
