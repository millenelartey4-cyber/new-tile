import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { History, Search, ShieldCheck } from 'lucide-react';

export function AdminAuditLogsPage() {
  const [logs] = useState(() => storeService.getAuditLogs());
  const [search, setSearch] = useState('');

  const filteredLogs = logs.filter(l => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      l.actorName.toLowerCase().includes(q) ||
      l.action.toLowerCase().includes(q) ||
      l.safeChangeSummary.toLowerCase().includes(q) ||
      l.resourceType.toLowerCase().includes(q)
    );
  });

  return (
    <AdminLayout
      title="System Audit Trail & Security Logs"
      subtitle="Immutable event log of administrative authorizations, stock adjustments, theme publications, and role alterations."
    >
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search audit trail by actor, action, or summary..."
            className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[var(--theme-text)]">
            <thead>
              <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                <th className="py-3 px-4">Event Timestamp</th>
                <th className="py-3 px-4">Authorized Actor</th>
                <th className="py-3 px-4">Action Event</th>
                <th className="py-3 px-4">Resource</th>
                <th className="py-3 px-4">Event Modification Summary</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--theme-border-subtle)]">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-[var(--theme-surface-subtle)]/50 transition-colors">
                  <td className="py-3 px-4 font-mono text-[11px] text-[var(--theme-text-muted)] whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>

                  <td className="py-3 px-4">
                    <span className="font-semibold block text-[var(--theme-text)]">{log.actorName}</span>
                    <span className="text-[10px] text-[var(--theme-accent)] uppercase">{log.actorRole}</span>
                  </td>

                  <td className="py-3 px-4">
                    <span className="font-mono text-[11px] font-bold px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs">
                      {log.action}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-[11px] font-medium text-[var(--theme-text)]">
                    {log.resourceType} {log.resourceId ? `(${log.resourceId})` : ''}
                  </td>

                  <td className="py-3 px-4 text-xs text-[var(--theme-text-muted)] max-w-md">
                    {log.safeChangeSummary}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
