import React, { useState, useMemo, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { useAuth } from '../../context/AuthContext';
import { storeService } from '../../services/store';
import { SYSTEM_MODULES } from '../../data/roles';
import { UserRole, ActionType, ModuleKey } from '../../types';
import { 
  ShieldCheck, 
  Users, 
  Lock, 
  Unlock,
  Check, 
  Copy, 
  Plus, 
  AlertCircle, 
  RotateCcw, 
  Save, 
  UserCheck, 
  Search,
  CheckSquare, 
  Square,
  Trash2,
  CheckCheck,
  XSquare,
  KeyRound,
  X,
  Sparkles,
  CheckCircle2,
  ShieldAlert
} from 'lucide-react';

export function AdminRolesPage() {
  const { 
    currentUser, 
    currentRole, 
    hasPermission, 
    isAdminConsoleUnlocked, 
    unlockAdminConsole 
  } = useAuth();

  const [allRoles, setAllRoles] = useState<UserRole[]>(() => storeService.getRoles());
  const [allUsers, setAllUsers] = useState(() => storeService.getUsers());

  const [selectedRoleId, setSelectedRoleId] = useState<string>('super-admin');
  const [activeTab, setActiveTab] = useState<'matrix' | 'users'>('matrix');

  // Matrix Lock / Unlock State (Defaults to locked/protected mode)
  const [isMatrixLocked, setIsMatrixLocked] = useState<boolean>(true);

  // Password Unlock Modal
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockError, setUnlockError] = useState('');

  // Delete Role Modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  // Working copy of role permissions for staged saving
  const [stagedPermissions, setStagedPermissions] = useState<Record<string, Record<ModuleKey, ActionType[]>>>(() => {
    const map: Record<string, Record<ModuleKey, ActionType[]>> = {};
    storeService.getRoles().forEach(r => {
      map[r.id] = JSON.parse(JSON.stringify(r.permissions));
    });
    return map;
  });

  const [hasChanges, setHasChanges] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [userSearch, setUserSearch] = useState('');

  // New Role Modal state
  const [isNewRoleModalOpen, setIsNewRoleModalOpen] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDesc, setNewRoleDesc] = useState('');

  // Refresh roles and users when store changes
  useEffect(() => {
    const handleUpdate = () => {
      const refreshedRoles = storeService.getRoles();
      setAllRoles(refreshedRoles);
      setAllUsers(storeService.getUsers());
      setStagedPermissions(prev => {
        const next = { ...prev };
        refreshedRoles.forEach(r => {
          if (!next[r.id]) {
            next[r.id] = JSON.parse(JSON.stringify(r.permissions));
          }
        });
        return next;
      });
    };

    window.addEventListener('roles_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('roles_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3800);
  };

  // Selected role object
  const activeSelectedRole = useMemo(() => {
    return allRoles.find(r => r.id === selectedRoleId) || allRoles[0] || {
      id: 'super-admin',
      name: 'Super Admin',
      description: 'Full administrative access',
      builtIn: true,
      permissions: {} as any,
      createdAt: '',
      updatedAt: ''
    };
  }, [allRoles, selectedRoleId]);

  const currentPermissions = stagedPermissions[selectedRoleId] || activeSelectedRole.permissions || {};

  const canManageRoles = currentRole?.id === 'super-admin' || hasPermission('role_management', 'edit') || isAdminConsoleUnlocked;

  const actionColumns: { key: ActionType; label: string }[] = [
    { key: 'view', label: 'View' },
    { key: 'create', label: 'Create' },
    { key: 'edit', label: 'Edit' },
    { key: 'delete', label: 'Delete' },
    { key: 'approve', label: 'Approve' },
    { key: 'export', label: 'Export' },
    { key: 'manage_settings', label: 'Settings' },
    { key: 'publish', label: 'Publish' }
  ];

  // Group modules by category
  const categories = useMemo(() => {
    const map = new Map<string, typeof SYSTEM_MODULES>();
    SYSTEM_MODULES.forEach(mod => {
      if (!map.has(mod.category)) {
        map.set(mod.category, []);
      }
      map.get(mod.category)!.push(mod);
    });
    return Array.from(map.entries());
  }, []);

  // Total count of granted permissions for the active role
  const totalGrantedCount = useMemo(() => {
    return Object.values(currentPermissions).reduce((acc, actions) => acc + (actions?.length || 0), 0);
  }, [currentPermissions]);

  // Total possible permissions for this schema
  const totalPossibleCount = useMemo(() => {
    return SYSTEM_MODULES.reduce((acc, mod) => acc + mod.supportedActions.length, 0);
  }, []);

  // LOCK & UNLOCK ACTIONS
  const handleRequestUnlock = () => {
    if (isAdminConsoleUnlocked) {
      setIsMatrixLocked(false);
      showToast('Permission Matrix unlocked: Admin edit mode is now active.');
    } else {
      setUnlockError('');
      setUnlockPassword('');
      setIsUnlockModalOpen(true);
    }
  };

  const handleConfirmUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const res = unlockAdminConsole(unlockPassword);
    if (res.success) {
      setIsUnlockModalOpen(false);
      setIsMatrixLocked(false);
      setUnlockPassword('');
      setUnlockError('');
      showToast('Admin authenticated. Permission Matrix unlocked for editing.');
    } else {
      setUnlockError(res.error || 'Invalid admin password.');
    }
  };

  const handleLockMatrix = () => {
    setIsMatrixLocked(true);
    showToast('Permission Matrix locked securely in protected read-only mode.');
  };

  // PERMISSION SELECTION & UNSELECTION
  const handleTogglePermission = (moduleKey: ModuleKey, action: ActionType) => {
    if (isMatrixLocked) {
      showToast('Matrix is currently locked. Click "Unlock Matrix" to make modifications.');
      return;
    }

    setStagedPermissions(prev => {
      const rolePerms = { ...prev[selectedRoleId] };
      const currentModuleActions = rolePerms[moduleKey] ? [...rolePerms[moduleKey]] : [];

      if (currentModuleActions.includes(action)) {
        rolePerms[moduleKey] = currentModuleActions.filter(a => a !== action);
      } else {
        rolePerms[moduleKey] = [...currentModuleActions, action];
      }

      setHasChanges(true);
      return {
        ...prev,
        [selectedRoleId]: rolePerms
      };
    });
  };

  // Toggle entire row for a module
  const handleToggleEntireRow = (moduleKey: ModuleKey, supportedActions: ActionType[]) => {
    if (isMatrixLocked) {
      showToast('Matrix is currently locked. Click "Unlock Matrix" to modify.');
      return;
    }

    setStagedPermissions(prev => {
      const rolePerms = { ...prev[selectedRoleId] };
      const currentModuleActions = rolePerms[moduleKey] || [];
      const allActive = supportedActions.every(a => currentModuleActions.includes(a));

      if (allActive) {
        rolePerms[moduleKey] = [];
      } else {
        rolePerms[moduleKey] = [...supportedActions];
      }

      setHasChanges(true);
      return {
        ...prev,
        [selectedRoleId]: rolePerms
      };
    });
  };

  // Grant ALL permissions across all 20 modules
  const handleGrantAllPermissions = () => {
    if (isMatrixLocked) {
      showToast('Matrix is locked. Unlock first to grant permissions.');
      return;
    }

    setStagedPermissions(prev => {
      const newPerms: Record<ModuleKey, ActionType[]> = {} as any;
      SYSTEM_MODULES.forEach(m => {
        newPerms[m.key] = [...m.supportedActions];
      });
      setHasChanges(true);
      return {
        ...prev,
        [selectedRoleId]: newPerms
      };
    });
    showToast(`All 20 modules granted full authorizations for "${activeSelectedRole.name}". Click Apply & Save.`);
  };

  // Unselect / Revoke ALL permissions across all 20 modules
  const handleRevokeAllPermissions = () => {
    if (isMatrixLocked) {
      showToast('Matrix is locked. Unlock first to unselect permissions.');
      return;
    }

    setStagedPermissions(prev => {
      const newPerms: Record<ModuleKey, ActionType[]> = {} as any;
      SYSTEM_MODULES.forEach(m => {
        newPerms[m.key] = [];
      });
      setHasChanges(true);
      return {
        ...prev,
        [selectedRoleId]: newPerms
      };
    });
    showToast(`All permissions unselected/cleared for "${activeSelectedRole.name}". Click Apply & Save.`);
  };

  // Toggle column
  const handleToggleColumn = (actionKey: ActionType) => {
    if (isMatrixLocked) {
      showToast('Matrix is locked. Unlock first.');
      return;
    }

    // Determine if all supported modules have this action active
    const applicableModules = SYSTEM_MODULES.filter(m => m.supportedActions.includes(actionKey));
    const allHaveIt = applicableModules.every(m => {
      const actions = (stagedPermissions[selectedRoleId]?.[m.key]) || [];
      return actions.includes(actionKey);
    });

    setStagedPermissions(prev => {
      const rolePerms = { ...prev[selectedRoleId] };
      applicableModules.forEach(m => {
        const cur = rolePerms[m.key] ? [...rolePerms[m.key]] : [];
        if (allHaveIt) {
          rolePerms[m.key] = cur.filter(a => a !== actionKey);
        } else {
          if (!cur.includes(actionKey)) {
            rolePerms[m.key] = [...cur, actionKey];
          }
        }
      });
      setHasChanges(true);
      return {
        ...prev,
        [selectedRoleId]: rolePerms
      };
    });
  };

  // APPLY AND SAVE
  const handleApplyAndSave = (relockAfter: boolean = false) => {
    const updated: UserRole = {
      ...activeSelectedRole,
      permissions: stagedPermissions[selectedRoleId] || activeSelectedRole.permissions
    };
    storeService.saveRole(updated, currentUser?.name || 'Administrator');
    setHasChanges(false);

    if (relockAfter) {
      setIsMatrixLocked(true);
      showToast(`Role "${updated.name}" permissions applied, saved & matrix locked securely.`);
    } else {
      showToast(`Permissions for role "${updated.name}" applied & saved successfully! You can continue editing or lock it again.`);
    }
  };

  const handleCancelChanges = () => {
    setStagedPermissions(prev => ({
      ...prev,
      [selectedRoleId]: JSON.parse(JSON.stringify(activeSelectedRole.permissions))
    }));
    setHasChanges(false);
    showToast('Unsaved matrix modifications discarded.');
  };

  // DELETE ROLE
  const handleDeleteRoleClick = () => {
    if (isMatrixLocked) {
      showToast('Matrix is locked. Please unlock matrix before deleting roles.');
      return;
    }
    if (allRoles.length <= 1) {
      alert('Cannot delete the only remaining role in the enterprise directory.');
      return;
    }
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDeleteRole = () => {
    const roleNameToDelete = activeSelectedRole.name;
    const res = storeService.deleteRole(selectedRoleId, currentUser?.name || 'Administrator');
    setIsDeleteModalOpen(false);

    if (res.success) {
      const refreshedRoles = storeService.getRoles();
      setAllRoles(refreshedRoles);
      const nextRole = refreshedRoles[0];
      if (nextRole) {
        setSelectedRoleId(nextRole.id);
      }
      setHasChanges(false);
      showToast(`Role "${roleNameToDelete}" deleted successfully. Affected staff were safely reassigned.`);
    } else {
      alert(res.error || 'Failed to delete role.');
    }
  };

  // DUPLICATE ROLE
  const handleDuplicateRole = () => {
    const copyName = `${activeSelectedRole.name} (Copy)`;
    const newRole: UserRole = {
      id: `role-${Date.now()}`,
      name: copyName,
      description: `Duplicated from ${activeSelectedRole.name}`,
      builtIn: false,
      permissions: JSON.parse(JSON.stringify(currentPermissions)),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    storeService.saveRole(newRole, currentUser?.name || 'Administrator');
    const refreshed = storeService.getRoles();
    setAllRoles(refreshed);
    setSelectedRoleId(newRole.id);
    setStagedPermissions(prev => ({
      ...prev,
      [newRole.id]: newRole.permissions
    }));
    showToast(`Role "${copyName}" created successfully.`);
  };

  // CREATE ROLE
  const handleCreateNewRole = () => {
    if (!newRoleName.trim()) return;
    const newRole: UserRole = {
      id: `role-${Date.now()}`,
      name: newRoleName.trim(),
      description: newRoleDesc.trim() || 'Custom organizational role.',
      builtIn: false,
      permissions: {} as any,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    SYSTEM_MODULES.forEach(m => {
      newRole.permissions[m.key] = [];
    });
    storeService.saveRole(newRole, currentUser?.name || 'Administrator');
    const refreshed = storeService.getRoles();
    setAllRoles(refreshed);
    setIsNewRoleModalOpen(false);
    setNewRoleName('');
    setNewRoleDesc('');
    setSelectedRoleId(newRole.id);
    showToast(`New role "${newRole.name}" created. You can now configure permissions.`);
  };

  const handleAssignUserRole = (userId: string, roleId: string) => {
    const success = storeService.updateUserRole(userId, roleId, currentUser?.name || 'Administrator');
    if (!success) {
      alert('Cannot reassign this role: at least one active Super Admin must remain in the system.');
    } else {
      setAllUsers(storeService.getUsers());
      showToast('Personnel role assignment updated successfully.');
    }
  };

  // Filtered users for user assignment tab
  const filteredUsers = allUsers.filter(u => {
    const q = userSearch.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.roleName.toLowerCase().includes(q);
  });

  const assignedCountForActiveRole = allUsers.filter(u => u.roleId === selectedRoleId).length;

  return (
    <AdminLayout
      title="Enterprise Permission Matrix & Role Access"
      subtitle="Comprehensive role-based authorization matrix across all 20 business modules. Securely lock, unlock, configure, apply & save, or delete roles."
      actions={
        <div className="flex items-center gap-2">
          {/* Lock / Unlock Toggle Button in Header */}
          {isMatrixLocked ? (
            <button
              type="button"
              onClick={handleRequestUnlock}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Unlock Matrix</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleLockMatrix}
              className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Lock Matrix</span>
            </button>
          )}

          {/* Staged Changes Actions */}
          {!isMatrixLocked && (
            <>
              {hasChanges && (
                <button
                  type="button"
                  onClick={handleCancelChanges}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold uppercase flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Discard</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => handleApplyAndSave(false)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md cursor-pointer transition"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Apply & Save</span>
              </button>

              <button
                type="button"
                onClick={() => handleApplyAndSave(true)}
                className="hidden sm:flex px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-emerald-400 border border-emerald-500/40 text-xs font-bold uppercase tracking-wider items-center gap-1.5 cursor-pointer transition"
                title="Apply changes and lock the matrix in one click"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Apply, Save & Lock</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => setIsNewRoleModalOpen(true)}
            className="px-3.5 py-2 bg-[var(--theme-accent)] text-white text-xs font-semibold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Role</span>
          </button>
        </div>
      }
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-stone-900 text-stone-100 border border-emerald-500/60 px-4 py-3 rounded-none shadow-2xl flex items-center gap-2.5 text-xs animate-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Security Status Banner: Locked vs Unlocked Mode */}
      <div className={`p-4 border transition-colors ${
        isMatrixLocked 
          ? 'bg-stone-900/90 border-stone-700 text-stone-300' 
          : 'bg-emerald-950/40 border-emerald-500/60 text-stone-100'
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3">
            <div className={`p-2.5 shrink-0 ${
              isMatrixLocked 
                ? 'bg-stone-800 border border-stone-700 text-amber-400' 
                : 'bg-emerald-900/60 border border-emerald-500/50 text-emerald-300 animate-pulse'
            }`}>
              {isMatrixLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold uppercase tracking-wider text-xs font-mono">
                  {isMatrixLocked ? 'Permission Matrix Locked' : 'Permission Matrix Unlocked (Edit Mode Active)'}
                </span>
                <span className={`px-2 py-0.5 text-[10px] uppercase font-mono font-bold border ${
                  isMatrixLocked
                    ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                    : 'bg-emerald-900 text-emerald-200 border-emerald-600'
                }`}>
                  {isMatrixLocked ? 'Protected Read-Only' : 'Authorized Administrator Access'}
                </span>
                {hasChanges && (
                  <span className="px-2 py-0.5 bg-amber-500 text-stone-950 text-[10px] font-bold uppercase font-mono animate-pulse">
                    Unsaved Matrix Edits
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-400 mt-1">
                {isMatrixLocked ? (
                  <span>
                    The permission matrix is currently secured against accidental edits or deletions. Click <strong>Unlock Matrix</strong> with admin credentials to select, unselect, modify, or delete roles.
                  </span>
                ) : (
                  <span>
                    You have administrator authorization to select or unselect any permissions, delete roles, and commit modifications. When done, click <strong>Apply & Save</strong> and <strong>Lock Matrix</strong> again.
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
            {isMatrixLocked ? (
              <button
                type="button"
                onClick={handleRequestUnlock}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition shadow-sm cursor-pointer"
              >
                <Unlock className="w-4 h-4" />
                <span>Unlock Matrix to Edit</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyAndSave(false)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Apply & Save</span>
                </button>
                <button
                  type="button"
                  onClick={handleLockMatrix}
                  className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>Lock It Again</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Role Selection Tabs & Role Actions Bar */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Role pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] shrink-0 font-mono">
              Roles ({allRoles.length}):
            </span>
            {allRoles.map(role => {
              const count = allUsers.filter(u => u.roleId === role.id).length;
              const isSelected = selectedRoleId === role.id;
              return (
                <button
                  key={role.id}
                  onClick={() => {
                    if (hasChanges && !isMatrixLocked) {
                      if (!window.confirm('You have unsaved matrix modifications. Switch role anyway?')) return;
                    }
                    setSelectedRoleId(role.id);
                    setHasChanges(false);
                  }}
                  className={`px-3 py-1.5 shrink-0 rounded-none transition-colors flex items-center gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold shadow-xs'
                      : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                  }`}
                >
                  <span>{role.name}</span>
                  <span className="text-[10px] opacity-75 tabular-nums font-mono">({count})</span>
                </button>
              );
            })}
          </div>

          {/* Quick Action Buttons for Selected Role */}
          <div className="flex items-center gap-2 text-xs flex-wrap">
            <button
              type="button"
              onClick={handleDuplicateRole}
              className="px-3 py-1.5 border border-[var(--theme-border)] hover:border-[var(--theme-text)] flex items-center gap-1.5 text-[var(--theme-text)] font-medium cursor-pointer transition"
              title="Duplicate current role matrix"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Duplicate Role</span>
            </button>

            {/* DELETE ROLE BUTTON (Enabled when unlocked) */}
            <button
              type="button"
              onClick={handleDeleteRoleClick}
              disabled={isMatrixLocked || allRoles.length <= 1}
              className={`px-3 py-1.5 border flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider transition ${
                isMatrixLocked || allRoles.length <= 1
                  ? 'border-stone-800 text-stone-500 cursor-not-allowed opacity-50'
                  : 'border-red-600/60 bg-red-950/30 text-red-400 hover:bg-red-900/40 hover:text-red-300 cursor-pointer'
              }`}
              title={
                isMatrixLocked 
                  ? 'Unlock matrix to enable role deletion' 
                  : allRoles.length <= 1 
                  ? 'Cannot delete the only remaining role' 
                  : `Delete role ${activeSelectedRole.name}`
              }
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Delete Role</span>
            </button>
          </div>
        </div>

        {/* Selected Role Meta Header & Fast Selection Tools */}
        <div className="pt-3 border-t border-[var(--theme-border-subtle)] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-[var(--theme-text-muted)]">
          <div className="flex items-center gap-2 flex-wrap">
            <ShieldCheck className="w-4 h-4 text-[var(--theme-accent)]" />
            <strong className="text-[var(--theme-text)] text-sm">{activeSelectedRole.name}</strong>
            <span>·</span>
            <span>{activeSelectedRole.description}</span>
            <span>·</span>
            <span className="font-mono text-[11px] text-[var(--theme-accent)] font-semibold">
              {totalGrantedCount} / {totalPossibleCount} Permissions Active
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab('matrix')}
              className={`font-semibold uppercase text-[11px] cursor-pointer ${
                activeTab === 'matrix' ? 'text-[var(--theme-accent)] underline font-bold' : 'hover:text-[var(--theme-text)]'
              }`}
            >
              Permission Matrix
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveTab('users')}
              className={`font-semibold uppercase text-[11px] cursor-pointer ${
                activeTab === 'users' ? 'text-[var(--theme-accent)] underline font-bold' : 'hover:text-[var(--theme-text)]'
              }`}
            >
              Assigned Personnel ({assignedCountForActiveRole})
            </button>
          </div>
        </div>

        {/* BATCH SELECT / UNSELECT TOOLBAR (Visible on matrix tab) */}
        {activeTab === 'matrix' && (
          <div className="pt-2 border-t border-[var(--theme-border-subtle)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] font-mono">
                Batch Tools:
              </span>
              <button
                type="button"
                onClick={handleGrantAllPermissions}
                disabled={isMatrixLocked}
                className={`px-2.5 py-1 text-[11px] font-semibold border flex items-center gap-1 transition ${
                  isMatrixLocked
                    ? 'border-stone-800 text-stone-600 cursor-not-allowed'
                    : 'border-emerald-600/50 bg-emerald-950/20 text-emerald-400 hover:bg-emerald-900/30 cursor-pointer'
                }`}
                title={isMatrixLocked ? 'Unlock matrix to select all' : 'Grant all 20 modules full permissions'}
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Select All (Grant All)</span>
              </button>

              <button
                type="button"
                onClick={handleRevokeAllPermissions}
                disabled={isMatrixLocked}
                className={`px-2.5 py-1 text-[11px] font-semibold border flex items-center gap-1 transition ${
                  isMatrixLocked
                    ? 'border-stone-800 text-stone-600 cursor-not-allowed'
                    : 'border-red-600/50 bg-red-950/20 text-red-400 hover:bg-red-900/30 cursor-pointer'
                }`}
                title={isMatrixLocked ? 'Unlock matrix to unselect all' : 'Unselect/clear all permissions for this role'}
              >
                <XSquare className="w-3.5 h-3.5" />
                <span>Unselect All (Clear All)</span>
              </button>
            </div>

            {!isMatrixLocked && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyAndSave(false)}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Apply & Save</span>
                </button>
                <button
                  type="button"
                  onClick={handleLockMatrix}
                  className="px-3 py-1 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 text-xs font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Lock It Again</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Tab Content 1: Permission Matrix Grid */}
      {activeTab === 'matrix' && (
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] text-[var(--theme-text)]">
                  <th className="py-3 px-4 font-bold uppercase text-[11px] tracking-wider w-80 font-mono">
                    Functional Business Module (20)
                  </th>
                  {actionColumns.map(col => (
                    <th 
                      key={col.key} 
                      className="py-3 px-3 text-center font-bold uppercase text-[10px] tracking-wider cursor-pointer group"
                      onClick={() => handleToggleColumn(col.key)}
                      title={isMatrixLocked ? 'Unlock matrix to toggle column' : `Click to toggle all ${col.label} authorizations`}
                    >
                      <span className="group-hover:text-[var(--theme-accent)] transition-colors inline-block">
                        {col.label}
                      </span>
                    </th>
                  ))}
                  <th className="py-3 px-3 text-center font-bold uppercase text-[10px] tracking-wider">
                    Row
                  </th>
                </tr>
              </thead>

              <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                {categories.map(([categoryName, moduleList]) => (
                  <React.Fragment key={categoryName}>
                    {/* Category Divider Row */}
                    <tr className="bg-[var(--theme-surface-subtle)]/70 border-t border-b border-[var(--theme-border)]">
                      <td colSpan={10} className="py-2.5 px-4 font-bold uppercase text-[10px] tracking-wider text-[var(--theme-accent)] font-mono">
                        {categoryName}
                      </td>
                    </tr>

                    {/* Modules in this category */}
                    {moduleList.map(mod => {
                      const modActions = currentPermissions[mod.key] || [];
                      const allActive = mod.supportedActions.every(a => modActions.includes(a));

                      return (
                        <tr 
                          key={mod.key} 
                          className="hover:bg-[var(--theme-surface-subtle)]/40 transition-colors text-[var(--theme-text)]"
                        >
                          <td className="py-3 px-4 font-medium text-xs">
                            <span className="block text-[var(--theme-text)] font-semibold">{mod.label}</span>
                            <span className="font-mono text-[10px] text-[var(--theme-text-muted)]">{mod.key}</span>
                          </td>

                          {/* 8 Action Checkboxes */}
                          {actionColumns.map(col => {
                            const isSupported = mod.supportedActions.includes(col.key);
                            const isGranted = modActions.includes(col.key);

                            if (!isSupported) {
                              return (
                                <td key={col.key} className="py-3 px-3 text-center text-stone-600">
                                  -
                                </td>
                              );
                            }

                            return (
                              <td key={col.key} className="py-3 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleTogglePermission(mod.key, col.key)}
                                  disabled={isMatrixLocked}
                                  className={`p-1 rounded-none inline-flex items-center justify-center transition-colors ${
                                    isMatrixLocked 
                                      ? 'cursor-not-allowed opacity-75' 
                                      : 'cursor-pointer hover:scale-110'
                                  } ${
                                    isGranted
                                      ? 'text-emerald-500 hover:text-emerald-400'
                                      : 'text-[var(--theme-text-muted)]/40 hover:text-[var(--theme-text)]'
                                  }`}
                                  aria-label={`Toggle ${col.label} for ${mod.label}`}
                                  title={
                                    isMatrixLocked 
                                      ? 'Matrix is locked. Click Unlock Matrix to select/unselect.' 
                                      : `${isGranted ? 'Unselect' : 'Select'} ${col.label} for ${mod.label}`
                                  }
                                >
                                  {isGranted ? (
                                    <CheckSquare className="w-4 h-4 fill-emerald-500/20 text-emerald-500" />
                                  ) : (
                                    <Square className="w-4 h-4" />
                                  )}
                                </button>
                              </td>
                            );
                          })}

                          {/* Toggle All in Row */}
                          <td className="py-3 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleToggleEntireRow(mod.key, mod.supportedActions)}
                              disabled={isMatrixLocked}
                              className={`text-[10px] uppercase font-bold tracking-wider font-mono ${
                                isMatrixLocked
                                  ? 'text-stone-600 cursor-not-allowed'
                                  : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)] cursor-pointer'
                              }`}
                              title={isMatrixLocked ? 'Matrix is locked' : allActive ? 'Unselect all row actions' : 'Select all row actions'}
                            >
                              {allActive ? 'Clear' : 'Select'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

          {/* Matrix Footer Action Strip */}
          <div className="p-4 bg-[var(--theme-surface-subtle)] border-t border-[var(--theme-border)] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="text-[var(--theme-text-muted)]">
              {isMatrixLocked ? (
                <span className="flex items-center gap-1.5 text-stone-400">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  Protected mode: Checkboxes are read-only until unlocked.
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <Unlock className="w-3.5 h-3.5" />
                  Edit mode active: Click checkboxes to unselect or select, then Apply & Save and lock it again.
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {isMatrixLocked ? (
                <button
                  type="button"
                  onClick={handleRequestUnlock}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold uppercase tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock Matrix to Edit</span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => handleApplyAndSave(false)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold uppercase tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-sm transition"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Apply & Save</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleLockMatrix}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 font-bold uppercase tracking-wider text-xs flex items-center gap-1.5 cursor-pointer transition"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Lock It Again</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab Content 2: Personnel & Role Assignments */}
      {activeTab === 'users' && (
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
            <div>
              <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
                Assigned Personnel Directory
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)]">
                Assign staff members to roles. Permissions take effect immediately upon next session refresh.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <input
                type="text"
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                placeholder="Search staff members..."
                className="w-full pl-8 pr-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
              />
              <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div className="divide-y divide-[var(--theme-border-subtle)] text-xs">
            {filteredUsers.map(user => (
              <div key={user.uid} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-none bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center font-bold text-[var(--theme-accent)] text-xs">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <span className="font-semibold text-[var(--theme-text)] block">{user.name}</span>
                    <span className="text-[11px] text-[var(--theme-text-muted)]">{user.email}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <select
                    value={user.roleId}
                    onChange={e => handleAssignUserRole(user.uid, e.target.value)}
                    disabled={isMatrixLocked}
                    className={`px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold text-xs focus:outline-none focus:border-[var(--theme-accent)] ${
                      isMatrixLocked ? 'opacity-75 cursor-not-allowed' : 'cursor-pointer'
                    }`}
                  >
                    {allRoles.map(r => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>

                  <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                    ID: {user.uid}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ADMIN UNLOCK MODAL */}
      {isUnlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-100">
                    Admin Permission Unlock
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Master administrator credential required to modify matrix
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUnlockModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {unlockError && (
              <div className="p-3 bg-red-950/60 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{unlockError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmUnlock} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-400 mb-1 font-mono text-[11px]">
                  Master Admin Password
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={unlockPassword}
                  onChange={e => setUnlockPassword(e.target.value)}
                  placeholder="Enter administrator password (e.g. admin123)..."
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[11px] text-stone-500 mt-1">
                  Default credentials: <code className="text-amber-400">admin123</code> or active company credentials.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsUnlockModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Authenticate & Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE ROLE CONFIRMATION MODAL */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-red-500/50 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 border-b border-stone-800 pb-3">
              <div className="p-2.5 bg-red-950/80 border border-red-500/50 text-red-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-red-200">
                  Delete Role Definition
                </h3>
                <p className="text-[11px] text-stone-400">
                  Permanent removal from enterprise directory
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-stone-300">
              <p>
                Are you sure you want to permanently delete the role <strong className="text-stone-100">"{activeSelectedRole.name}"</strong>?
              </p>
              
              <div className="p-3 bg-stone-950 border border-stone-800 space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between text-stone-400">
                  <span>Assigned Personnel Affected:</span>
                  <strong className="text-stone-200 font-mono">{assignedCountForActiveRole} users</strong>
                </div>
                <div className="flex items-center justify-between text-stone-400">
                  <span>Fallback Reassignment:</span>
                  <span className="text-emerald-400 font-semibold">Super Admin / Primary Staff</span>
                </div>
              </div>

              <p className="text-stone-400 text-[11px]">
                All associated permission configurations will be purged. Assigned users will automatically be reassigned to ensure zero disruption. After deleting, you can lock the matrix again.
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(false)}
                className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteRole}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm & Delete Role</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW ROLE MODAL */}
      {isNewRoleModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-md p-6 space-y-4 shadow-2xl text-[var(--theme-text)]">
            <h3 className="font-serif-luxury text-xl font-semibold">
              Create New Organizational Role
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Role Name</label>
                <input
                  type="text"
                  required
                  value={newRoleName}
                  onChange={e => setNewRoleName(e.target.value)}
                  placeholder="e.g. Regional Freight Specialist"
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newRoleDesc}
                  onChange={e => setNewRoleDesc(e.target.value)}
                  placeholder="Responsibilities and permission perimeter..."
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[var(--theme-border)] text-xs">
              <button
                type="button"
                onClick={() => setIsNewRoleModalOpen(false)}
                className="px-4 py-2 border border-[var(--theme-border)] uppercase font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCreateNewRole}
                className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] uppercase font-bold tracking-wider hover:opacity-90 cursor-pointer"
              >
                Create Role
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
