import { useState, useMemo } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { 
  Package, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Eye, 
  EyeOff,
  Boxes, 
  Layers, 
  Check, 
  X,
  ExternalLink,
  DollarSign,
  TrendingUp,
  TrendingDown,
  CheckSquare,
  Square,
  MinusSquare,
  AlertCircle,
  FolderSync,
  Sparkles,
  CheckCircle2,
  UploadCloud,
  Globe
} from 'lucide-react';
import { ManualProductUploadModal } from '../../components/admin/ManualProductUploadModal';
import { Product } from '../../types';

export function AdminProductsPage() {
  const { navigate } = useRouter();
  const { currentUser, hasPermission } = useAuth();
  const { activeCompany } = useCompany();

  const [products, setProducts] = useState(() => storeService.getProducts(activeCompany.id));
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [isManualUploadOpen, setIsManualUploadOpen] = useState(false);
  const [recentlyUploadedProduct, setRecentlyUploadedProduct] = useState<Product | null>(null);

  // Bulk Modals
  const [isBulkPriceModalOpen, setIsBulkPriceModalOpen] = useState(false);
  const [isBulkCategoryModalOpen, setIsBulkCategoryModalOpen] = useState(false);
  const [priceUpdateMode, setPriceUpdateMode] = useState<'percentage' | 'fixed_adjust' | 'set_fixed'>('percentage');
  const [priceUpdateValue, setPriceUpdateValue] = useState<number>(10);
  const [selectedTargetCategoryId, setSelectedTargetCategoryId] = useState('');

  // Toast Feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleManualUploadSuccess = (newProduct: Product) => {
    // Refresh products list
    setProducts(storeService.getProducts(activeCompany.id));
    setRecentlyUploadedProduct(newProduct);
    showToast(`Surface "${newProduct.name}" uploaded, saved & published live to storefront!`);
  };

  const categories = useMemo(() => storeService.getCategories(activeCompany.id), [activeCompany.id]);

  const canEdit = hasPermission('products', 'edit');
  const canDelete = hasPermission('products', 'delete');
  const canCreate = hasPermission('products', 'create');

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      if (categoryFilter && p.categoryId !== categoryFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchMat = p.material.toLowerCase().includes(q);
        const matchSku = p.variants.some(v => v.sku.toLowerCase().includes(q));
        if (!matchName && !matchMat && !matchSku) return false;
      }
      return true;
    });
  }, [products, categoryFilter, search]);

  // Selection Logic
  const allFilteredSelected = filteredProducts.length > 0 && filteredProducts.every(p => selectedProductIds.includes(p.id));
  const someFilteredSelected = filteredProducts.some(p => selectedProductIds.includes(p.id));

  const handleToggleSelectAll = () => {
    if (allFilteredSelected) {
      // Deselect all filtered
      const filteredIds = new Set(filteredProducts.map(p => p.id));
      setSelectedProductIds(prev => prev.filter(id => !filteredIds.has(id)));
    } else {
      // Select all filtered
      const newSelected = new Set([...selectedProductIds, ...filteredProducts.map(p => p.id)]);
      setSelectedProductIds(Array.from(newSelected));
    }
  };

  const handleToggleSelectOne = (id: string) => {
    setSelectedProductIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleClearSelection = () => {
    setSelectedProductIds([]);
  };

  // Individual Actions
  const handleDeleteProduct = (id: string, name: string) => {
    if (!canDelete) {
      alert('You lack permission to delete catalog products.');
      return;
    }

    if (window.confirm(`Are you sure you want to permanently delete "${name}"? Historical orders will retain their snapshots.`)) {
      storeService.deleteProduct(id, currentUser?.name, activeCompany.id);
      setProducts(storeService.getProducts(activeCompany.id));
      setSelectedProductIds(prev => prev.filter(item => item !== id));
      showToast(`Deleted "${name}".`);
    }
  };

  const handleToggleActive = (id: string) => {
    if (!canEdit) return;
    const prod = products.find(p => p.id === id);
    if (!prod) return;
    const updated = { ...prod, active: !prod.active };
    storeService.saveProduct(updated, currentUser?.name, activeCompany.id);
    setProducts(storeService.getProducts(activeCompany.id));
    showToast(`Updated visibility for "${prod.name}" to ${updated.active ? 'Published' : 'Draft'}.`);
  };

  // Bulk Actions
  const handleApplyBulkPrices = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEdit || selectedProductIds.length === 0) return;

    const count = storeService.bulkUpdateProductPrices(
      selectedProductIds,
      priceUpdateMode,
      Number(priceUpdateValue),
      currentUser?.name,
      activeCompany.id
    );

    setProducts(storeService.getProducts(activeCompany.id));
    setIsBulkPriceModalOpen(false);
    showToast(`Successfully updated prices for ${count} selected products.`);
  };

  const handleApplyBulkCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEdit || selectedProductIds.length === 0 || !selectedTargetCategoryId) return;

    const targetCategory = categories.find(c => c.id === selectedTargetCategoryId);
    if (!targetCategory) return;

    const count = storeService.bulkUpdateProductCategory(
      selectedProductIds,
      targetCategory.id,
      targetCategory.name,
      currentUser?.name,
      activeCompany.id
    );

    setProducts(storeService.getProducts(activeCompany.id));
    setIsBulkCategoryModalOpen(false);
    showToast(`Assigned ${count} products to category "${targetCategory.name}".`);
  };

  const handleBulkSetVisibility = (active: boolean) => {
    if (!canEdit || selectedProductIds.length === 0) return;

    const count = storeService.bulkUpdateProductVisibility(
      selectedProductIds,
      active,
      currentUser?.name,
      activeCompany.id
    );

    setProducts(storeService.getProducts(activeCompany.id));
    showToast(`Set ${count} products to ${active ? 'Published' : 'Draft'}.`);
  };

  const handleBulkDelete = () => {
    if (!canDelete || selectedProductIds.length === 0) return;

    if (window.confirm(`Are you sure you want to permanently delete all ${selectedProductIds.length} selected products? This action cannot be undone.`)) {
      const count = storeService.bulkDeleteProducts(
        selectedProductIds,
        currentUser?.name,
        activeCompany.id
      );

      setProducts(storeService.getProducts(activeCompany.id));
      setSelectedProductIds([]);
      showToast(`Permanently deleted ${count} products.`);
    }
  };

  // Sample Price Preview Calculation
  const sampleProductsForPricePreview = useMemo(() => {
    return products
      .filter(p => selectedProductIds.includes(p.id))
      .slice(0, 3);
  }, [products, selectedProductIds]);

  return (
    <AdminLayout
      title="Product Catalog & Slabs"
      subtitle="Architectural surface catalog, multi-color variants, box coverages, and specifications."
      actions={
        <div className="flex items-center gap-2">
          {canCreate && (
            <>
              <button
                type="button"
                onClick={() => setIsManualUploadOpen(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition shadow-sm cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Manual Product Upload</span>
              </button>
              <Link
                href="/admin/products/new"
                className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5 transition-all shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Surface</span>
              </Link>
            </>
          )}
        </div>
      }
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-stone-900 text-stone-100 border border-stone-700 px-4 py-3 rounded-lg shadow-xl flex items-center gap-2 text-xs animate-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Live Storefront Publication Confirmation Banner */}
      {recentlyUploadedProduct && (
        <div className="mb-4 p-4 bg-emerald-950/40 border border-emerald-500/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-stone-900 border border-emerald-500/40 overflow-hidden shrink-0 flex items-center justify-center">
              {recentlyUploadedProduct.variants[0]?.images[0] ? (
                <img 
                  src={recentlyUploadedProduct.variants[0].images[0]} 
                  alt={recentlyUploadedProduct.name}
                  className="w-full h-full object-cover" 
                />
              ) : (
                <Package className="w-6 h-6 text-emerald-400" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-mono uppercase tracking-wider font-semibold border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live at Storefront
                </span>
                <span className="text-[11px] font-mono text-stone-400">
                  SKU: {recentlyUploadedProduct.variants[0]?.sku}
                </span>
              </div>
              <h4 className="text-sm font-serif font-bold text-stone-100 mt-0.5">
                {recentlyUploadedProduct.name}
              </h4>
              <p className="text-xs text-stone-400">
                GH₵{recentlyUploadedProduct.variants[0]?.price.toLocaleString()} / {recentlyUploadedProduct.variants[0]?.unit || 'm²'} • Stock: {recentlyUploadedProduct.variants[0]?.stock} {recentlyUploadedProduct.variants[0]?.unit || 'm²'} • {recentlyUploadedProduct.categoryName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto">
            <Link
              href={`/product/${recentlyUploadedProduct.slug}`}
              className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-stone-950 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition shadow-sm"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>View on Storefront</span>
            </Link>
            <button
              type="button"
              onClick={() => setRecentlyUploadedProduct(null)}
              className="p-1.5 text-stone-400 hover:text-stone-200 cursor-pointer"
              title="Dismiss banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Search and Filters Bar */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, SKU, or material..."
            className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto text-xs">
          <span className="text-[var(--theme-text-muted)] font-bold uppercase text-[10px]">Filter:</span>
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none"
          >
            <option value="">All Categories ({products.length})</option>
            {categories.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} ({products.filter(p => p.categoryId === c.id).length})
              </option>
            ))}
          </select>

          {selectedProductIds.length > 0 && (
            <button
              onClick={handleClearSelection}
              className="text-[11px] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] underline cursor-pointer"
            >
              Clear selection ({selectedProductIds.length})
            </button>
          )}
        </div>
      </div>

      {/* Floating / Sticky Bulk Action Bar */}
      {selectedProductIds.length > 0 && (
        <div className="sticky top-20 z-30 bg-stone-900 border-2 border-amber-500/80 text-stone-100 p-4 rounded-xl shadow-2xl flex flex-wrap items-center justify-between gap-4 animate-in slide-in-from-top-2">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
              {selectedProductIds.length}
            </div>
            <div>
              <span className="text-sm font-semibold text-stone-100">
                {selectedProductIds.length} {selectedProductIds.length === 1 ? 'Product' : 'Products'} Selected
              </span>
              <span className="block text-[11px] text-stone-400">
                Choose a bulk action to apply across all selected items
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {canEdit && (
              <>
                {/* Bulk Price Button */}
                <button
                  type="button"
                  onClick={() => setIsBulkPriceModalOpen(true)}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Update Prices</span>
                </button>

                {/* Bulk Category Button */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTargetCategoryId(categories[0]?.id || '');
                    setIsBulkCategoryModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold uppercase tracking-wider rounded-lg border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <FolderSync className="w-3.5 h-3.5 text-amber-400" />
                  <span>Change Category</span>
                </button>

                {/* Bulk Publish Button */}
                <button
                  type="button"
                  onClick={() => handleBulkSetVisibility(true)}
                  className="px-3 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 text-xs font-semibold uppercase tracking-wider rounded-lg border border-emerald-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Make all selected products visible on public storefront"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Publish All</span>
                </button>

                {/* Bulk Draft Button */}
                <button
                  type="button"
                  onClick={() => handleBulkSetVisibility(false)}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold uppercase tracking-wider rounded-lg border border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Hide all selected products from public storefront"
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Set as Draft</span>
                </button>
              </>
            )}

            {canDelete && (
              <button
                type="button"
                onClick={handleBulkDelete}
                className="px-3 py-1.5 bg-red-950/80 hover:bg-red-900 text-red-400 text-xs font-semibold uppercase tracking-wider rounded-lg border border-red-800 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleClearSelection}
              className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
              title="Deselect all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Products Table */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[var(--theme-text)]">
            <thead>
              <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                {/* Select All Checkbox */}
                <th className="py-3 px-4 w-10">
                  <button
                    type="button"
                    onClick={handleToggleSelectAll}
                    className="cursor-pointer text-[var(--theme-text)] hover:text-[var(--theme-accent)] flex items-center"
                    title={allFilteredSelected ? 'Deselect all filtered' : 'Select all filtered'}
                  >
                    {allFilteredSelected ? (
                      <CheckSquare className="w-4 h-4 text-[var(--theme-accent)]" />
                    ) : someFilteredSelected ? (
                      <MinusSquare className="w-4 h-4 text-[var(--theme-accent)]" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3 px-4">Surface Specimen</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Material / Format</th>
                <th className="py-3 px-4">Color Variants</th>
                <th className="py-3 px-4">Price Range (GHS)</th>
                <th className="py-3 px-4">Total Stock</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--theme-border-subtle)]">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-stone-400">
                    <Package className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="font-semibold">No surface specimens found</p>
                    <p className="text-[11px]">Try adjusting your search or category filter.</p>
                  </td>
                </tr>
              ) : (
                filteredProducts.map(p => {
                  const isSelected = selectedProductIds.includes(p.id);
                  const totalStock = p.variants.reduce((acc, v) => acc + v.stock, 0);
                  const minPrice = Math.min(...p.variants.map(v => v.price));
                  const maxPrice = Math.max(...p.variants.map(v => v.price));

                  return (
                    <tr 
                      key={p.id} 
                      className={`transition-colors ${
                        isSelected 
                          ? 'bg-amber-500/10 hover:bg-amber-500/15' 
                          : 'hover:bg-[var(--theme-surface-subtle)]/50'
                      }`}
                    >
                      {/* Individual Checkbox */}
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => handleToggleSelectOne(p.id)}
                          className="cursor-pointer text-[var(--theme-text)] hover:text-[var(--theme-accent)] flex items-center"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-amber-500" />
                          ) : (
                            <Square className="w-4 h-4 text-[var(--theme-border)]" />
                          )}
                        </button>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.variants[0]?.images[0]?.startsWith('/src/assets/') ? p.variants[0]?.images[0]?.replace('/src/assets/', '/assets/') : (p.variants[0]?.images[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg')}
                            alt={p.name}
                            className="w-12 h-12 object-cover border border-[var(--theme-border)] bg-stone-100 shrink-0"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                            }}
                          />
                          <div>
                            <span className="font-semibold text-sm text-[var(--theme-text)] block">{p.name}</span>
                            <span className="font-mono text-[10px] text-[var(--theme-text-muted)]">{p.slug}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium">{p.categoryName}</span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="block">{p.material} · {p.finish}</span>
                        <span className="text-[11px] text-[var(--theme-text-muted)] font-mono">{p.size} ({p.thickness})</span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          {p.variants.map(v => (
                            <span
                              key={v.id}
                              className="w-3.5 h-3.5 rounded-full border border-black/20"
                              style={{ backgroundColor: v.colorHex }}
                              title={`${v.colorName} (${v.sku})`}
                            />
                          ))}
                          <span className="text-[11px] text-[var(--theme-text-muted)] ml-1 tabular-nums">
                            ({p.variants.length})
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-semibold tabular-nums">
                        {minPrice === maxPrice ? (
                          <span>GH₵{minPrice.toLocaleString()}</span>
                        ) : (
                          <span>GH₵{minPrice.toLocaleString()} – {maxPrice.toLocaleString()}</span>
                        )}
                        <span className="text-[10px] text-[var(--theme-text-muted)] block font-normal">
                          per {p.variants[0]?.unit}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <span className={`font-bold tabular-nums ${totalStock <= 50 ? 'text-amber-600' : 'text-emerald-700'}`}>
                          {totalStock} {p.variants[0]?.unit}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <button
                          onClick={() => handleToggleActive(p.id)}
                          disabled={!canEdit}
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-xs transition-colors cursor-pointer ${
                            p.active 
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' 
                              : 'bg-stone-200 text-stone-600 hover:bg-stone-300'
                          }`}
                        >
                          {p.active ? 'Published' : 'Draft'}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Link
                            href={`/product/${p.slug}`}
                            target="_blank"
                            className="p-1 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
                            title="View public storefront page"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </Link>
                          {canEdit && (
                            <Link
                              href={`/admin/products/${p.id}/edit`}
                              className="p-1 text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)]"
                              title="Edit product and variants"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </Link>
                          )}
                          {canDelete && (
                            <button
                              onClick={() => handleDeleteProduct(p.id, p.name)}
                              className="p-1 text-[var(--theme-text-muted)] hover:text-red-600 cursor-pointer"
                              title="Delete product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bulk Price Update Modal */}
      {isBulkPriceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div 
            className="w-full max-w-lg bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-5 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-serif font-bold text-stone-100">
                    Bulk Price Adjustment
                  </h3>
                  <p className="text-xs text-stone-400">
                    Updating all variant prices for {selectedProductIds.length} selected products
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsBulkPriceModalOpen(false)}
                className="text-stone-400 hover:text-stone-100 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleApplyBulkPrices} className="p-6 space-y-6 text-xs">
              
              {/* Mode Selection */}
              <div>
                <label className="block text-stone-400 uppercase font-mono text-[11px] mb-2">
                  Price Adjustment Strategy
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPriceUpdateMode('percentage')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      priceUpdateMode === 'percentage'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    <TrendingUp className="w-4 h-4 mx-auto mb-1" />
                    <span>Percentage (+/- %)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPriceUpdateMode('fixed_adjust')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      priceUpdateMode === 'fixed_adjust'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    <DollarSign className="w-4 h-4 mx-auto mb-1" />
                    <span>Fixed (+/- GH₵)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPriceUpdateMode('set_fixed')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      priceUpdateMode === 'set_fixed'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-400 font-bold'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 mx-auto mb-1" />
                    <span>Set Exact (GH₵)</span>
                  </button>
                </div>
              </div>

              {/* Value Input */}
              <div>
                <label className="block text-stone-400 uppercase font-mono text-[11px] mb-1">
                  {priceUpdateMode === 'percentage' && 'Percentage Value (e.g. 10 for +10%, -5 for 5% discount)'}
                  {priceUpdateMode === 'fixed_adjust' && 'Adjustment Amount (e.g. 50 to add GH₵50, -20 to deduct)'}
                  {priceUpdateMode === 'set_fixed' && 'New Price For All Variants (GH₵)'}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    required
                    value={priceUpdateValue}
                    onChange={e => setPriceUpdateValue(parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-2.5 bg-stone-950 border border-stone-700 rounded-xl text-stone-100 text-sm font-mono focus:outline-none focus:border-amber-500"
                  />
                  <div className="absolute right-3 top-2.5 text-stone-400 font-mono text-xs">
                    {priceUpdateMode === 'percentage' ? '%' : 'GH₵'}
                  </div>
                </div>
              </div>

              {/* Sample Price Previews */}
              <div className="p-4 bg-stone-950 rounded-xl border border-stone-800 space-y-2">
                <span className="text-[10px] uppercase font-mono text-stone-400 font-bold block">
                  Live Preview on Selected Samples:
                </span>
                <div className="space-y-1.5 divide-y divide-stone-900">
                  {sampleProductsForPricePreview.map(p => {
                    const firstVar = p.variants[0];
                    if (!firstVar) return null;
                    const oldPrice = firstVar.price;
                    let newPrice = oldPrice;
                    if (priceUpdateMode === 'percentage') {
                      newPrice = Math.max(1, Math.round(oldPrice * (1 + priceUpdateValue / 100)));
                    } else if (priceUpdateMode === 'fixed_adjust') {
                      newPrice = Math.max(1, Math.round(oldPrice + priceUpdateValue));
                    } else if (priceUpdateMode === 'set_fixed') {
                      newPrice = Math.max(1, Math.round(priceUpdateValue));
                    }

                    return (
                      <div key={p.id} className="pt-1.5 flex items-center justify-between text-xs">
                        <span className="text-stone-300 truncate max-w-[200px]">{p.name}</span>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-stone-500 line-through">GH₵{oldPrice.toLocaleString()}</span>
                          <span className="text-amber-400 font-bold">→ GH₵{newPrice.toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-2 flex justify-end gap-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsBulkPriceModalOpen(false)}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold uppercase rounded-lg shadow-lg shadow-amber-950 cursor-pointer"
                >
                  Apply to {selectedProductIds.length} Products
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Category Modal */}
      {isBulkCategoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div 
            className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="px-6 py-5 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <FolderSync className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-serif font-bold text-stone-100">
                    Bulk Category Reassignment
                  </h3>
                  <p className="text-xs text-stone-400">
                    Reassign {selectedProductIds.length} products to a new surface category
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsBulkCategoryModalOpen(false)}
                className="text-stone-400 hover:text-stone-100 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleApplyBulkCategory} className="p-6 space-y-5 text-xs">
              <div>
                <label className="block text-stone-400 uppercase font-mono text-[11px] mb-2">
                  Select Target Category
                </label>
                <select
                  value={selectedTargetCategoryId}
                  onChange={e => setSelectedTargetCategoryId(e.target.value)}
                  className="w-full px-4 py-2.5 bg-stone-950 border border-stone-700 rounded-xl text-stone-100 text-xs focus:outline-none focus:border-amber-500"
                >
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-stone-950 border border-stone-800 rounded-xl text-stone-400 text-[11px] leading-relaxed">
                All {selectedProductIds.length} selected products will instantly appear under the chosen category on the storefront catalog and navigation menus.
              </div>

              <div className="pt-2 flex justify-end gap-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsBulkCategoryModalOpen(false)}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold uppercase rounded-lg shadow-lg shadow-amber-950 cursor-pointer"
                >
                  Reassign Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Manual Product Upload & Live Publication Modal */}
      <ManualProductUploadModal
        isOpen={isManualUploadOpen}
        onClose={() => setIsManualUploadOpen(false)}
        onSuccess={handleManualUploadSuccess}
        companyId={activeCompany.id}
      />
    </AdminLayout>
  );
}
