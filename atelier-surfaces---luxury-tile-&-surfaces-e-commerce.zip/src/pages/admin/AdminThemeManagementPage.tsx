import { useState, useMemo } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { THEME_FAMILIES } from '../../data/themes';
import { ThemePreset, ThemeTokens } from '../../types';
import { 
  Palette, 
  Search, 
  Check, 
  Eye, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Copy, 
  AlertTriangle, 
  Sparkles,
  Sliders
} from 'lucide-react';

export function AdminThemeManagementPage() {
  const { 
    activeTheme, 
    previewTheme, 
    setPreviewTheme, 
    applyTheme, 
    allPresets, 
    customThemes, 
    saveCustomTheme, 
    deleteCustomTheme, 
    resetToBrandDefault,
    contrastRatio
  } = useTheme();

  const { currentUser, hasPermission } = useAuth();
  const canPublishTheme = hasPermission('theme_management', 'publish') || hasPermission('theme_management', 'edit');

  // Search & Filter
  const [search, setSearch] = useState('');
  const [selectedFamily, setSelectedFamily] = useState<string>('All');
  const [modeFilter, setModeFilter] = useState<'all' | 'light' | 'dark'>('all');

  // Custom Theme Editor Modal / State
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingThemeName, setEditingThemeName] = useState('My Custom Atelier Theme');
  const [editingTokens, setEditingTokens] = useState<ThemeTokens>({ ...activeTheme.tokens });

  // Filtered preset list
  const filteredThemes = useMemo(() => {
    return allPresets.filter(theme => {
      if (selectedFamily !== 'All' && theme.family !== selectedFamily) return false;
      if (modeFilter !== 'all' && theme.appearanceMode !== modeFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = theme.name.toLowerCase().includes(q);
        const matchesFamily = theme.family.toLowerCase().includes(q);
        const matchesDesc = theme.description.toLowerCase().includes(q);
        if (!matchesName && !matchesFamily && !matchesDesc) return false;
      }
      return true;
    });
  }, [allPresets, selectedFamily, modeFilter, search]);

  const handleOpenEditorForTheme = (theme: ThemePreset) => {
    setEditingThemeName(`${theme.name} (Custom)`);
    setEditingTokens({ ...theme.tokens });
    setIsEditorOpen(true);
  };

  const handleSaveCustom = () => {
    if (!canPublishTheme) {
      alert('Your user role lacks permission to publish or save global themes.');
      return;
    }
    saveCustomTheme(editingThemeName, editingTokens, currentUser?.name);
    setIsEditorOpen(false);
  };

  return (
    <AdminLayout
      title="Advanced Theme Engine & 64+ Curated Palettes"
      subtitle="Architectural color theory with strict token isolation, WCAG contrast verification, live preview, and CSS variable persistence."
      actions={
        <div className="flex items-center gap-2">
          {previewTheme && (
            <button
              onClick={() => setPreviewTheme(null)}
              className="px-3 py-2 bg-amber-100 text-amber-900 border border-amber-300 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Cancel Preview</span>
            </button>
          )}
          <button
            onClick={() => {
              setEditingThemeName('Custom Architectural Theme');
              setEditingTokens({ ...activeTheme.tokens });
              setIsEditorOpen(true);
            }}
            className="px-4 py-2 bg-[var(--theme-accent)] text-white text-xs font-semibold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Create Custom Theme</span>
          </button>
          <button
            onClick={resetToBrandDefault}
            className="px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] transition-colors"
            title="Reset to Atelier Signature Ivory & Gold"
          >
            Reset Default
          </button>
        </div>
      }
    >
      {/* Active Theme Status Bar with WCAG Contrast Ratio */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
            Active Global Website Theme
          </span>
          <div className="flex items-center gap-3 mt-1">
            <h2 className="font-serif-luxury text-2xl font-bold text-[var(--theme-text)]">
              {activeTheme.name}
            </h2>
            <span className="text-xs px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text-muted)] font-medium capitalize">
              {activeTheme.appearanceMode} Mode · {activeTheme.family}
            </span>
          </div>
          <p className="text-xs text-[var(--theme-text-muted)] mt-1">
            {activeTheme.description}
          </p>
        </div>

        {/* Contrast status */}
        <div className="flex items-center gap-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] px-4 py-2.5 text-xs">
          <div>
            <span className="text-[10px] text-[var(--theme-text-muted)] block uppercase font-bold">Contrast Ratio</span>
            <span className="font-bold tabular-nums text-sm text-[var(--theme-text)]">{contrastRatio.toFixed(2)} : 1</span>
          </div>
          {contrastRatio >= 4.5 ? (
            <span className="text-emerald-700 font-semibold text-[11px] flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>WCAG AA Passed</span>
            </span>
          ) : (
            <span className="text-amber-700 font-semibold text-[11px] flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Low Text Contrast</span>
            </span>
          )}
        </div>
      </div>

      {/* Preview Active Notice */}
      {previewTheme && (
        <div className="p-4 bg-amber-500/10 border border-amber-500 text-amber-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Previewing Theme:</strong> "{previewTheme.name}". The whole website is temporarily rendering this palette. Click "Apply & Publish" to persist globally.
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => applyTheme(previewTheme.id, currentUser?.name)}
              className="px-3 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase text-[11px]"
            >
              Apply & Publish Globally
            </button>
            <button
              onClick={() => setPreviewTheme(null)}
              className="px-3 py-1.5 bg-white border border-stone-300 text-stone-800 font-bold uppercase text-[11px]"
            >
              Exit Preview
            </button>
          </div>
        </div>
      )}

      {/* Search and Filters Bar */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Keyword Search */}
          <div className="relative w-full md:w-80">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search 64+ curated presets..."
              className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
            />
            <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          {/* Mode Tabs */}
          <div className="flex items-center gap-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-1 text-xs">
            <button
              onClick={() => setModeFilter('all')}
              className={`px-3 py-1 font-semibold transition-colors ${
                modeFilter === 'all' ? 'bg-[var(--theme-surface)] shadow-xs text-[var(--theme-text)]' : 'text-[var(--theme-text-muted)]'
              }`}
            >
              All (64)
            </button>
            <button
              onClick={() => setModeFilter('light')}
              className={`px-3 py-1 font-semibold transition-colors ${
                modeFilter === 'light' ? 'bg-[var(--theme-surface)] shadow-xs text-[var(--theme-text)]' : 'text-[var(--theme-text-muted)]'
              }`}
            >
              Light Stone
            </button>
            <button
              onClick={() => setModeFilter('dark')}
              className={`px-3 py-1 font-semibold transition-colors ${
                modeFilter === 'dark' ? 'bg-[var(--theme-surface)] shadow-xs text-[var(--theme-text)]' : 'text-[var(--theme-text-muted)]'
              }`}
            >
              Nocturne Dark
            </button>
          </div>
        </div>

        {/* 16 Theme Families Filter Strip */}
        <div className="pt-2 border-t border-[var(--theme-border-subtle)] flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="font-bold uppercase tracking-wider text-[var(--theme-text-muted)] text-[10px] shrink-0">
            Theme Families:
          </span>
          <button
            onClick={() => setSelectedFamily('All')}
            className={`px-2.5 py-1 shrink-0 transition-colors ${
              selectedFamily === 'All'
                ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold'
                : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            All Families
          </button>
          {THEME_FAMILIES.map(fam => (
            <button
              key={fam}
              onClick={() => setSelectedFamily(fam)}
              className={`px-2.5 py-1 shrink-0 transition-colors ${
                selectedFamily === fam
                  ? 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold'
                  : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
              }`}
            >
              {fam}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Themes Created by Admin */}
      {customThemes.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
            Custom Created Themes ({customThemes.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {customThemes.map(ct => (
              <div
                key={ct.id}
                className={`p-4 bg-[var(--theme-surface)] border transition-all ${
                  activeTheme.id === ct.id ? 'border-[var(--theme-accent)] shadow-md' : 'border-[var(--theme-border)]'
                }`}
              >
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-bold text-sm text-[var(--theme-text)]">{ct.name}</h4>
                  <button
                    onClick={() => {
                      if (window.confirm(`Delete custom theme "${ct.name}"?`)) {
                        deleteCustomTheme(ct.id, currentUser?.name);
                      }
                    }}
                    className="text-red-500 hover:text-red-700 p-1"
                    title="Delete custom theme"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                {/* Color swatches strip */}
                <div className="flex h-5 w-full border border-black/10 overflow-hidden mb-3">
                  <div style={{ backgroundColor: ct.tokens.bg }} className="flex-1" title="Background" />
                  <div style={{ backgroundColor: ct.tokens.surface }} className="flex-1" title="Surface" />
                  <div style={{ backgroundColor: ct.tokens.text }} className="flex-1" title="Text" />
                  <div style={{ backgroundColor: ct.tokens.primary }} className="flex-1" title="Primary" />
                  <div style={{ backgroundColor: ct.tokens.accent }} className="flex-1" title="Accent" />
                </div>
                <div className="flex gap-2 text-xs">
                  <button
                    onClick={() => applyTheme(ct.id, currentUser?.name)}
                    className="flex-1 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-semibold uppercase text-[11px]"
                  >
                    {activeTheme.id === ct.id ? 'Currently Active' : 'Apply Theme'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 64 Curated Presets Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)]">
          <span>
            Displaying <strong className="text-[var(--theme-text)] tabular-nums">{filteredThemes.length}</strong> curated palettes across 16 architectural families
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredThemes.map(theme => {
            const isActive = activeTheme.id === theme.id;
            const isPreviewing = previewTheme?.id === theme.id;

            return (
              <div
                key={theme.id}
                className={`bg-[var(--theme-surface)] border flex flex-col justify-between p-4 transition-all relative ${
                  isActive 
                    ? 'border-[var(--theme-accent)] ring-1 ring-[var(--theme-accent)] shadow-md' 
                    : isPreviewing 
                    ? 'border-amber-500 shadow-md' 
                    : 'border-[var(--theme-border)] hover:border-[var(--theme-text)]'
                }`}
              >
                <div>
                  {/* Swatch preview container */}
                  <div className="p-3 border border-black/10 mb-3 space-y-2 rounded-xs" style={{ backgroundColor: theme.tokens.bg }}>
                    <div className="flex justify-between items-center text-[10px]" style={{ color: theme.tokens.text }}>
                      <span className="font-bold">{theme.name.split('(')[0]}</span>
                      <span className="opacity-70 uppercase">{theme.appearanceMode}</span>
                    </div>

                    {/* Color bar */}
                    <div className="grid grid-cols-5 h-6 border border-black/15 overflow-hidden">
                      <div style={{ backgroundColor: theme.tokens.bg }} title="Canvas BG" />
                      <div style={{ backgroundColor: theme.tokens.surface }} title="Card Surface" />
                      <div style={{ backgroundColor: theme.tokens.text }} title="Primary Text" />
                      <div style={{ backgroundColor: theme.tokens.primary }} title="Primary Brand" />
                      <div style={{ backgroundColor: theme.tokens.accent }} title="Brushed Accent" />
                    </div>

                    {/* Sample button render */}
                    <div className="flex gap-1.5 pt-1">
                      <div
                        className="flex-1 py-1 text-[10px] text-center font-bold"
                        style={{ backgroundColor: theme.tokens.primary, color: theme.tokens.primaryContrast }}
                      >
                        Action
                      </div>
                      <div
                        className="px-2 py-1 text-[10px] text-center font-bold"
                        style={{ backgroundColor: theme.tokens.accent, color: theme.tokens.accentContrast }}
                      >
                        Accent
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-accent)] block">
                      {theme.family}
                    </span>
                    <h4 className="font-serif-luxury text-base font-semibold text-[var(--theme-text)]">
                      {theme.name}
                    </h4>
                    <p className="text-[11px] text-[var(--theme-text-muted)] line-clamp-2">
                      {theme.description}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="mt-4 pt-3 border-t border-[var(--theme-border-subtle)] space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      onClick={() => setPreviewTheme(theme)}
                      className={`py-1.5 border font-semibold uppercase text-[10px] flex items-center justify-center gap-1 transition-colors ${
                        isPreviewing 
                          ? 'border-amber-500 bg-amber-50 text-amber-800' 
                          : 'border-[var(--theme-border)] hover:border-[var(--theme-text)] text-[var(--theme-text)]'
                      }`}
                    >
                      <Eye className="w-3 h-3" />
                      <span>{isPreviewing ? 'Previewing' : 'Preview'}</span>
                    </button>

                    <button
                      onClick={() => applyTheme(theme.id, currentUser?.name)}
                      disabled={isActive}
                      className={`py-1.5 font-bold uppercase text-[10px] transition-colors ${
                        isActive
                          ? 'bg-emerald-700 text-white cursor-default'
                          : 'bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] hover:opacity-90'
                      }`}
                    >
                      {isActive ? 'Published ✓' : 'Apply Theme'}
                    </button>
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-[var(--theme-text-muted)] pt-1">
                    <button
                      onClick={() => handleOpenEditorForTheme(theme)}
                      className="hover:text-[var(--theme-text)] flex items-center gap-1"
                    >
                      <Sliders className="w-3 h-3" />
                      <span>Customize Tokens</span>
                    </button>
                    <button
                      onClick={() => {
                        saveCustomTheme(`${theme.name} (Copy)`, theme.tokens, currentUser?.name);
                      }}
                      className="hover:text-[var(--theme-text)] flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Duplicate</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Theme Editor Modal */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-2xl p-6 shadow-2xl space-y-6 my-8 text-[var(--theme-text)]">
            <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)]">
                  Architectural Palette Studio
                </span>
                <h3 className="font-serif-luxury text-xl font-semibold">
                  Customize Theme Tokens
                </h3>
              </div>
              <button onClick={() => setIsEditorOpen(false)} className="text-stone-400 hover:text-stone-700 text-lg font-bold">
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Theme Name
                </label>
                <input
                  type="text"
                  value={editingThemeName}
                  onChange={e => setEditingThemeName(e.target.value)}
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-medium text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              {/* Token Pickers Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Canvas Background</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.bg}
                      onChange={e => setEditingTokens(prev => ({ ...prev, bg: e.target.value, navBg: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.bg}
                      onChange={e => setEditingTokens(prev => ({ ...prev, bg: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Surface (Cards & Modal)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.surface}
                      onChange={e => setEditingTokens(prev => ({ ...prev, surface: e.target.value, inputBg: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.surface}
                      onChange={e => setEditingTokens(prev => ({ ...prev, surface: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Primary Text</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.text}
                      onChange={e => setEditingTokens(prev => ({ ...prev, text: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.text}
                      onChange={e => setEditingTokens(prev => ({ ...prev, text: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Brand Accent (Gold / Brass)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.accent}
                      onChange={e => setEditingTokens(prev => ({ ...prev, accent: e.target.value, accentHover: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.accent}
                      onChange={e => setEditingTokens(prev => ({ ...prev, accent: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Primary Button Fill</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.primary}
                      onChange={e => setEditingTokens(prev => ({ ...prev, primary: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.primary}
                      onChange={e => setEditingTokens(prev => ({ ...prev, primary: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Hairline Border</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingTokens.border}
                      onChange={e => setEditingTokens(prev => ({ ...prev, border: e.target.value, borderSubtle: e.target.value }))}
                      className="w-8 h-8 rounded border border-black/10 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={editingTokens.border}
                      onChange={e => setEditingTokens(prev => ({ ...prev, border: e.target.value }))}
                      className="flex-1 px-2.5 py-1.5 font-mono text-xs uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[var(--theme-border)] flex items-center justify-end gap-3 text-xs">
              <button
                type="button"
                onClick={() => setIsEditorOpen(false)}
                className="px-4 py-2 border border-[var(--theme-border)] font-semibold uppercase"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCustom}
                className="px-6 py-2 bg-[var(--theme-accent)] text-white font-bold uppercase tracking-wider hover:opacity-90"
              >
                Save & Publish Global Palette
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
