import { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { useRouter } from '../../router/Router';
import { StockAdjustment } from '../../types';
import { 
  Boxes, 
  AlertTriangle, 
  Check, 
  Plus, 
  Minus, 
  History, 
  Search,
  Filter
} from 'lucide-react';

export function AdminInventoryPage() {
  const { searchParams } = useRouter();
  const { currentUser, hasPermission } = useAuth();
  const [products, setProducts] = useState(() => storeService.getProducts());
  const [adjustments, setAdjustments] = useState<StockAdjustment[]>(() => storeService.getStockAdjustments());
  const [search, setSearch] = useState(() => searchParams.get('search') || searchParams.get('product') || '');
  const [lowStockOnly, setLowStockOnly] = useState(() => searchParams.get('lowStock') === 'true' || searchParams.get('filter') === 'low_stock');

  // Manual Adjustment Modal State
  const [adjustModalItem, setAdjustModalItem] = useState<{
    productId: string;
    productName: string;
    variantId: string;
    colorName: string;
    currentStock: number;
    unit: string;
  } | null>(null);

  const [adjustQuantity, setAdjustQuantity] = useState<number>(10);
  const [adjustType, setAdjustType] = useState<'add' | 'subtract'>('add');
  const [adjustReason, setAdjustReason] = useState<StockAdjustment['reason']>('Received shipment');
  const [modalError, setModalError] = useState('');

  const canAdjustStock = hasPermission('stock_adjustments', 'create') || hasPermission('inventory', 'edit');


  // Flatten all variants with their parent products
  const flatVariants: {
    productId: string;
    productName: string;
    variantId: string;
    colorName: string;
    colorHex: string;
    sku: string;
    stock: number;
    lowStockThreshold: number;
    unit: string;
    boxCoverage: number;
    price: number;
  }[] = [];

  products.forEach(p => {
    p.variants.forEach(v => {
      flatVariants.push({
        productId: p.id,
        productName: p.name,
        variantId: v.id,
        colorName: v.colorName,
        colorHex: v.colorHex,
        sku: v.sku,
        stock: v.stock,
        lowStockThreshold: v.lowStockThreshold,
        unit: v.unit,
        boxCoverage: v.boxCoverage,
        price: v.price
      });
    });
  });

  const filteredVariants = flatVariants.filter(item => {
    if (lowStockOnly && item.stock > item.lowStockThreshold) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchP = item.productName.toLowerCase().includes(q);
      const matchC = item.colorName.toLowerCase().includes(q);
      const matchS = item.sku.toLowerCase().includes(q);
      if (!matchP && !matchC && !matchS) return false;
    }
    return true;
  });

  const handleOpenAdjust = (item: typeof flatVariants[0]) => {
    if (!canAdjustStock) {
      alert('Your user role lacks permission to adjust warehouse inventory.');
      return;
    }
    setAdjustModalItem({
      productId: item.productId,
      productName: item.productName,
      variantId: item.variantId,
      colorName: item.colorName,
      currentStock: item.stock,
      unit: item.unit
    });
    setAdjustQuantity(10);
    setAdjustType('add');
    setAdjustReason('Received shipment');
    setModalError('');
  };

  // Deep-link integration: Auto open adjustment modal if target variant is in query param
  useEffect(() => {
    const adjustVariantId = searchParams.get('adjustVariant');
    if (adjustVariantId) {
      const target = flatVariants.find(v => v.variantId === adjustVariantId);
      if (target) {
        handleOpenAdjust(target);
      }
    }
  }, [searchParams.get('adjustVariant')]);


  const handleExecuteAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustModalItem) return;

    const delta = adjustType === 'add' ? adjustQuantity : -adjustQuantity;
    const res = storeService.adjustStock({
      productId: adjustModalItem.productId,
      variantId: adjustModalItem.variantId,
      adjustment: delta,
      reason: adjustReason,
      actorName: currentUser?.name || 'Staff'
    });

    if (!res.success) {
      setModalError(res.error || 'Failed to adjust stock.');
      return;
    }

    setProducts(storeService.getProducts());
    setAdjustments(storeService.getStockAdjustments());
    setAdjustModalItem(null);
  };

  return (
    <AdminLayout
      title="Warehouse Inventory & Stock Adjustments"
      subtitle="Quarry allocation levels, safety thresholds, and transaction-safe stock adjustment audit history."
    >
      {/* Controls & Filter Bar */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by surface name, SKU, or color..."
            className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
          />
          <Search className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-4 text-xs">
          <label className="flex items-center gap-2 cursor-pointer font-medium text-[var(--theme-text)]">
            <input
              type="checkbox"
              checked={lowStockOnly}
              onChange={e => setLowStockOnly(e.target.checked)}
              className="accent-[var(--theme-accent)]"
            />
            <span>Show Low Stock Only ({flatVariants.filter(v => v.stock <= v.lowStockThreshold).length})</span>
          </label>
        </div>
      </div>

      {/* Live Variants Stock Table */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[var(--theme-text)]">
            <thead>
              <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                <th className="py-3 px-4">Surface Specimen</th>
                <th className="py-3 px-4">Variant Color</th>
                <th className="py-3 px-4">SKU Reference</th>
                <th className="py-3 px-4">Current Stock</th>
                <th className="py-3 px-4">Reorder Threshold</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Adjustment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--theme-border-subtle)]">
              {filteredVariants.map(v => {
                const isLow = v.stock <= v.lowStockThreshold;
                const isTarget = searchParams.get('adjustVariant') === v.variantId || searchParams.get('search') === v.sku;
                return (
                  <tr 
                    key={`${v.productId}_${v.variantId}`} 
                    className={`transition-colors ${
                      isTarget 
                        ? 'bg-[var(--theme-accent)]/10 ring-2 ring-inset ring-[var(--theme-accent)]' 
                        : 'hover:bg-[var(--theme-surface-subtle)]/50'
                    }`}
                  >
                    <td className="py-3 px-4 font-semibold text-[var(--theme-text)]">
                      {v.productName}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/20"
                          style={{ backgroundColor: v.colorHex }}
                        />
                        <span>{v.colorName}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px] text-[var(--theme-text-muted)]">
                      {v.sku}
                    </td>

                    <td className="py-3 px-4 font-bold tabular-nums text-sm">
                      {v.stock} {v.unit}
                    </td>

                    <td className="py-3 px-4 tabular-nums text-[var(--theme-text-muted)]">
                      {v.lowStockThreshold} {v.unit}
                    </td>

                    <td className="py-3 px-4">
                      {isLow ? (
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-amber-100 text-amber-800 rounded-xs flex items-center gap-1 w-fit">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          <span>Reorder Alert</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-xs flex items-center gap-1 w-fit">
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Optimal</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      {canAdjustStock && (
                        <button
                          onClick={() => handleOpenAdjust(v)}
                          className="px-3 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold hover:border-[var(--theme-accent)] transition-colors"
                        >
                          Adjust Stock
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock Adjustment Audit Trail */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
        <h3 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] flex items-center gap-2 border-b border-[var(--theme-border)] pb-3">
          <History className="w-5 h-5 text-[var(--theme-accent)]" />
          <span>Stock Adjustment Audit Log</span>
        </h3>

        {adjustments.length === 0 ? (
          <p className="text-xs text-[var(--theme-text-muted)] py-4 text-center">
            No manual adjustments recorded in this period.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[var(--theme-text)]">
              <thead>
                <tr className="border-b border-[var(--theme-border)] uppercase text-[10px] font-bold text-[var(--theme-text-muted)]">
                  <th className="pb-2">Timestamp</th>
                  <th className="pb-2">Specimen & Color</th>
                  <th className="pb-2">Adjustment</th>
                  <th className="pb-2">Previous &rarr; New</th>
                  <th className="pb-2">Reason</th>
                  <th className="pb-2 text-right">Authorized Actor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                {adjustments.slice(0, 8).map(adj => (
                  <tr key={adj.id} className="hover:bg-[var(--theme-surface-subtle)]/40 transition-colors">
                    <td className="py-2.5 font-mono text-[11px] text-[var(--theme-text-muted)]">
                      {new Date(adj.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 font-medium">
                      {adj.productName} ({adj.colorName})
                    </td>
                    <td className="py-2.5 tabular-nums font-bold">
                      <span className={adj.adjustment > 0 ? 'text-emerald-700' : 'text-red-600'}>
                        {adj.adjustment > 0 ? `+${adj.adjustment}` : adj.adjustment}
                      </span>
                    </td>
                    <td className="py-2.5 tabular-nums font-mono text-[11px]">
                      {adj.previousStock} &rarr; {adj.newStock}
                    </td>
                    <td className="py-2.5 text-[var(--theme-text-muted)]">
                      {adj.reason}
                    </td>
                    <td className="py-2.5 text-right font-medium">
                      {adj.actorName}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Stock Adjustment Dialog Modal */}
      {adjustModalItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-md p-6 space-y-4 shadow-2xl text-[var(--theme-text)]">
            <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
              <h3 className="font-serif-luxury text-xl font-semibold">
                Adjust Inventory Level
              </h3>
              <button onClick={() => setAdjustModalItem(null)} className="text-stone-400 hover:text-stone-700 font-bold">
                ✕
              </button>
            </div>

            <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs space-y-1">
              <span className="font-semibold block">{adjustModalItem.productName}</span>
              <span className="text-[var(--theme-text-muted)]">
                Variant: {adjustModalItem.colorName} · Current Stock: <strong className="text-[var(--theme-text)]">{adjustModalItem.currentStock} {adjustModalItem.unit}</strong>
              </span>
            </div>

            {modalError && (
              <div className="p-2.5 bg-red-50 text-red-700 border border-red-200 text-xs">
                {modalError}
              </div>
            )}

            <form onSubmit={handleExecuteAdjustment} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAdjustType('add')}
                  className={`py-2 text-center font-bold uppercase transition-colors ${
                    adjustType === 'add' ? 'bg-emerald-700 text-white' : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)]'
                  }`}
                >
                  + Add Stock
                </button>
                <button
                  type="button"
                  onClick={() => setAdjustType('subtract')}
                  className={`py-2 text-center font-bold uppercase transition-colors ${
                    adjustType === 'subtract' ? 'bg-red-700 text-white' : 'bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)]'
                  }`}
                >
                  - Deduct Stock
                </button>
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Quantity ({adjustModalItem.unit})
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={adjustQuantity}
                  onChange={e => setAdjustQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-sm font-bold tabular-nums"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Adjustment Reason
                </label>
                <select
                  value={adjustReason}
                  onChange={e => setAdjustReason(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                >
                  <option value="Received shipment">Received quarry container shipment</option>
                  <option value="Damaged in transit">Damaged in handling/transit</option>
                  <option value="Sample allocated">Sample box cut for architect</option>
                  <option value="Cycle count">Cycle count physical audit correction</option>
                  <option value="Customer return">Customer excess full box return</option>
                </select>
              </div>

              <div className="pt-2 border-t border-[var(--theme-border)] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAdjustModalItem(null)}
                  className="px-4 py-2 border border-[var(--theme-border)] font-semibold uppercase text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase text-xs"
                >
                  Confirm Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
