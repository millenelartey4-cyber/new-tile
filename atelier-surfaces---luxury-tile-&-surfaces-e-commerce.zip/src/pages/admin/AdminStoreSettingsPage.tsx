import { useState, useEffect } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { realtimeSyncService } from '../../services/realtimeSync';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { Link } from '../../router/Router';
import { StoreSettings, CompanyTenant } from '../../types';
import { 
  Settings, 
  Save, 
  CheckCircle2, 
  ShieldCheck, 
  MapPin, 
  Building2, 
  Copy, 
  Check, 
  Lock, 
  Unlock, 
  KeyRound, 
  Video, 
  Phone, 
  Mail, 
  RefreshCw, 
  Globe,
  ExternalLink,
  ArrowRight,
  AlertCircle,
  X,
  MessageSquare,
  Smartphone,
  Boxes,
  CreditCard,
  Trash2,
  RotateCcw,
  Sparkles,
  ShieldAlert,
  AlertTriangle
} from 'lucide-react';

export function AdminStoreSettingsPage() {
  const { currentUser, hasPermission, isAdminConsoleUnlocked, unlockAdminConsole } = useAuth();
  const { activeCompany, updateCompany, getCompanyShareUrl } = useCompany();
  const currentSettings = storeService.getStoreSettings(activeCompany.id);

  const [settings, setSettings] = useState<StoreSettings>({ ...currentSettings });
  const [isApplyingCredentials, setIsApplyingCredentials] = useState(false);
  const [credentialsApplySuccess, setCredentialsApplySuccess] = useState(false);
  const [isApplyingWhatsApp, setIsApplyingWhatsApp] = useState(false);
  const [whatsAppApplySuccess, setWhatsAppApplySuccess] = useState(false);

  // Admin Unlock Modal for Contact Edit
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockError, setUnlockError] = useState('');

  // Master Reset & Zeroing Security State
  const [masterResetLock, setMasterResetLock] = useState(() => storeService.getMasterResetLock(activeCompany.id));
  const [isZeroConfirmModalOpen, setIsZeroConfirmModalOpen] = useState(false);
  const [zeroActionType, setZeroActionType] = useState<'products' | 'revenues' | 'dashboard' | 'restore' | null>(null);
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [confirmZeroError, setConfirmZeroError] = useState('');
  const [isMasterUnlockModalOpen, setIsMasterUnlockModalOpen] = useState(false);
  const [masterUnlockPassword, setMasterUnlockPassword] = useState('');
  const [masterUnlockError, setMasterUnlockError] = useState('');
  const [masterToast, setMasterToast] = useState<{ title: string; message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [settingsVersion, setSettingsVersion] = useState(0);

  const productsCount = storeService.getProducts(activeCompany.id).length;
  const ordersCount = storeService.getOrders(activeCompany.id).length;
  const isZeroState = storeService.isDashboardZeroed(activeCompany.id) || (productsCount === 0 && ordersCount === 0);

  useEffect(() => {
    const latest = storeService.getStoreSettings(activeCompany.id);
    setSettings({ ...latest });
    setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
    setSettingsVersion(v => v + 1);
  }, [activeCompany.id]);

  useEffect(() => {
    const handleSync = () => {
      setSettingsVersion(v => v + 1);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
    };
    window.addEventListener('atelier_dashboard_reset', handleSync);
    window.addEventListener('atelier_revenue_reset', handleSync);
    window.addEventListener('atelier_products_updated', handleSync);
    window.addEventListener('master_reset_lock_changed', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('atelier_dashboard_reset', handleSync);
      window.removeEventListener('atelier_revenue_reset', handleSync);
      window.removeEventListener('atelier_products_updated', handleSync);
      window.removeEventListener('master_reset_lock_changed', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, [activeCompany.id]);

  const handleToggleMasterLock = () => {
    if (masterResetLock.isLocked) {
      setMasterUnlockPassword('');
      setMasterUnlockError('');
      setIsMasterUnlockModalOpen(true);
    } else {
      storeService.toggleMasterResetLock(true, currentUser?.name, activeCompany.id);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
      setMasterToast({
        title: 'Master Controls Secured',
        message: 'Master Reset & Zeroing controls locked against accidental execution.',
        type: 'info'
      });
      setTimeout(() => setMasterToast(null), 4000);
    }
  };

  const handleConfirmMasterUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    setMasterUnlockError('');
    const input = masterUnlockPassword.trim();
    const validPassword = activeCompany.adminPassword || 'admin123';

    if (input === validPassword || input === 'admin123' || currentUser?.roleId === 'super-admin') {
      storeService.toggleMasterResetLock(false, currentUser?.name, activeCompany.id);
      setMasterResetLock(storeService.getMasterResetLock(activeCompany.id));
      setIsMasterUnlockModalOpen(false);
      setMasterToast({
        title: 'Master Controls Unlocked',
        message: 'Administrator authorization confirmed. Zeroing controls are armed.',
        type: 'success'
      });
      setTimeout(() => setMasterToast(null), 4000);
    } else {
      setMasterUnlockError('Incorrect administrator credentials. Default is "admin123" or company admin password.');
    }
  };

  const handleOpenZeroAction = (action: 'products' | 'revenues' | 'dashboard' | 'restore') => {
    if (masterResetLock.isLocked && action !== 'restore') {
      setMasterUnlockPassword('');
      setMasterUnlockError('');
      setIsMasterUnlockModalOpen(true);
      return;
    }
    setZeroActionType(action);
    setConfirmPasswordInput('');
    setConfirmZeroError('');
    setIsZeroConfirmModalOpen(true);
  };

  const handleExecuteZeroAction = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmZeroError('');
    const input = confirmPasswordInput.trim();
    const validPassword = activeCompany.adminPassword || 'admin123';

    let isAuthorized = false;
    if (input === validPassword || input === 'admin123') {
      isAuthorized = true;
    } else if (zeroActionType === 'products' && (input.toUpperCase() === 'DELETE-PRODUCTS' || input.toUpperCase() === 'DELETE')) {
      isAuthorized = true;
    } else if (zeroActionType === 'revenues' && (input.toUpperCase() === 'DELETE-REVENUES' || input.toUpperCase() === 'DELETE')) {
      isAuthorized = true;
    } else if (zeroActionType === 'dashboard' && (input.toUpperCase() === 'CONFIRM-ZERO' || input.toUpperCase() === 'RESTART' || input.toUpperCase() === 'ZERO')) {
      isAuthorized = true;
    } else if (zeroActionType === 'restore' && (input.toUpperCase() === 'RESTORE' || input.toUpperCase() === 'RESTORE-DEMO')) {
      isAuthorized = true;
    }

    if (!isAuthorized) {
      setConfirmZeroError('Invalid authorization PIN or confirmation phrase. Please enter "admin123" or the prompt keyword.');
      return;
    }

    try {
      if (zeroActionType === 'products') {
        storeService.deleteAllProducts(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Catalog Specimens Deleted',
          message: 'All catalog items deleted. Product count set to 0.',
          type: 'success'
        });
      } else if (zeroActionType === 'revenues') {
        storeService.deleteAllRevenues(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Dashboard Revenues Deleted',
          message: 'All customer order history and POS receipts cleared. Verified revenue reset to GH₵0.00.',
          type: 'success'
        });
      } else if (zeroActionType === 'dashboard') {
        storeService.restartDashboardToZero(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Dashboard Restarted to Zero',
          message: 'Master reset complete: all products, orders, POS sales, and revenues set to 0.',
          type: 'success'
        });
      } else if (zeroActionType === 'restore') {
        storeService.restoreDemoData(currentUser?.name, activeCompany.id);
        setMasterToast({
          title: 'Factory Demo Data Restored',
          message: 'Catalog specimens, inventory records, and demo orders have been repopulated.',
          type: 'success'
        });
      }

      setIsZeroConfirmModalOpen(false);
      setSettingsVersion(v => v + 1);
      setTimeout(() => setMasterToast(null), 5000);
    } catch (err: any) {
      setConfirmZeroError(err?.message || 'Failed to execute operation.');
    }
  };

  const handleSaveAndApplyZero = () => {
    window.dispatchEvent(new CustomEvent('atelier_dashboard_reset', { detail: { tenantId: activeCompany.id } }));
    window.dispatchEvent(new CustomEvent('storage'));
    storeService.addAuditLog(
      currentUser?.name || 'Administrator',
      'super-admin',
      'SAVE_AND_APPLY_DASHBOARD',
      'StoreSettings',
      activeCompany.id,
      'Saved and applied master system reset and zeroing configurations.',
      activeCompany.id
    );
    setSettingsVersion(v => v + 1);
    setMasterToast({
      title: 'Changes Saved & Applied',
      message: 'Dashboard and store configuration saved to storage and synchronized across system.',
      type: 'success'
    });
    setTimeout(() => setMasterToast(null), 4000);
  };

  const [adminPassword, setAdminPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const canManage = hasPermission('store_settings', 'manage_settings') || currentUser?.roleId === 'super-admin';

  const handleCopyLink = () => {
    const url = getCompanyShareUrl(activeCompany.slug);
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!canManage) {
      alert('You lack permission to edit store settings.');
      return;
    }

    if (adminPassword) {
      if (adminPassword.length < 6) {
        setPasswordError('Admin password must be at least 6 characters.');
        return;
      }
      if (adminPassword !== confirmPassword) {
        setPasswordError('Passwords do not match. Please verify.');
        return;
      }
    }

    // Save Store Settings for this tenant
    storeService.updateStoreSettings(settings, currentUser?.name, activeCompany.id);

    // Sync to backend video config & contact
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        isLocked: !!settings.videoConsultationLocked,
        lockReason: settings.videoLockMessage,
        consultantName: settings.videoConsultantName,
        consultantTitle: settings.videoConsultantTitle,
        consultantLocation: settings.videoConsultantLocation,
        consultantAvailable: !!settings.videoConsultantAvailable,
        consultantHours: settings.videoConsultantHours,
        showroomContact: {
          address: settings.showroomAddress,
          gps: settings.ghanaPostGps,
          phone: settings.contactPhone,
          email: settings.contactEmail,
          isLocked: !!settings.contactLocked
        }
      })
    }).catch(() => {});

    // Sync Company record
    const updatedCompany: CompanyTenant = {
      ...activeCompany,
      name: settings.brandName,
      tagline: settings.tagline,
      currency: settings.currency,
      currencySymbol: settings.currencySymbol || (settings.currency === 'USD' ? '$' : settings.currency === 'EUR' ? '€' : settings.currency === 'GBP' ? '£' : 'GH₵'),
      contactEmail: settings.contactEmail,
      contactPhone: settings.contactPhone,
      showroomAddress: settings.showroomAddress,
      ghanaPostGps: settings.ghanaPostGps,
      adminPassword: adminPassword ? adminPassword.trim() : activeCompany.adminPassword || 'admin123'
    };
    updateCompany(updatedCompany);

    setSaveSuccess(true);
    setAdminPassword('');
    setConfirmPassword('');
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  const handleToggleContactLock = () => {
    if (settings.contactLocked) {
      // Need to unlock: if admin console is not authenticated, request password
      if (!isAdminConsoleUnlocked) {
        setUnlockError('');
        setUnlockPassword('');
        setIsUnlockModalOpen(true);
        return;
      }
      setSettings(prev => ({ ...prev, contactLocked: false }));
      storeService.toggleContactDetailsLock(false, currentUser?.name, activeCompany.id);
    } else {
      setSettings(prev => ({ ...prev, contactLocked: true, contactLastSavedBy: currentUser?.name || 'Administrator' }));
      storeService.toggleContactDetailsLock(true, currentUser?.name, activeCompany.id);
    }
  };

  const handleConfirmAdminUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const res = unlockAdminConsole(unlockPassword);
    if (res.success) {
      setIsUnlockModalOpen(false);
      setUnlockPassword('');
      setUnlockError('');
      setSettings(prev => ({ ...prev, contactLocked: false }));
      storeService.toggleContactDetailsLock(false, currentUser?.name, activeCompany.id);
    } else {
      setUnlockError(res.error || 'Invalid administrator master password.');
    }
  };

  const handleApplyOfficialAccraDefaults = () => {
    setSettings(prev => ({
      ...prev,
      brandName: 'ATELIER SURFACES',
      showroomAddress: '14 Independence Avenue, Ridge West, Accra, Ghana',
      ghanaPostGps: 'GA-110-3849',
      contactPhone: '0542443125/0596334488',
      whatsAppNumber: '0542443125/0596334488',
      contactEmail: 'concierge@ateliersurfaces.com'
    }));
  };

  const handleApplyAndSaveShowroomCredentials = async (e?: React.MouseEvent, relockAfter: boolean = false) => {
    if (e) e.preventDefault();
    if (!canManage && !isAdminConsoleUnlocked) {
      alert('You lack permission to edit store settings. Please login as administrator.');
      return;
    }
    if (!settings.showroomAddress?.trim() || !settings.ghanaPostGps?.trim() || !settings.contactPhone?.trim() || !settings.contactEmail?.trim()) {
      alert('Please enter valid showroom address, GPS code, phone, WhatsApp number, and email before applying.');
      return;
    }

    setIsApplyingCredentials(true);

    const cleanAddress = settings.showroomAddress.trim();
    const cleanGps = settings.ghanaPostGps.trim().toUpperCase();
    const cleanPhone = settings.contactPhone.trim();
    const cleanWhatsApp = (settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488').trim();
    const cleanEmail = settings.contactEmail.trim();
    const willBeLocked = relockAfter ? true : settings.contactLocked;

    // 1. Update Store Settings (replaces old)
    storeService.updateStoreSettings({
      brandName: settings.brandName || activeCompany.name,
      showroomAddress: cleanAddress,
      ghanaPostGps: cleanGps,
      contactPhone: cleanPhone,
      whatsAppNumber: cleanWhatsApp,
      contactEmail: cleanEmail,
      contactLocked: willBeLocked,
      contactLastSavedBy: currentUser?.name || 'Administrator'
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 2. Update POS Settings & momo merchant number (replaces old)
    storeService.updatePOSSettings({
      showroomAddress: cleanAddress,
      ghanaPostGps: cleanGps,
      contactPhone: cleanPhone,
      whatsAppNumber: cleanWhatsApp,
      contactEmail: cleanEmail,
      momoMerchantNumber: cleanPhone
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 3. Update active company tenant record
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        showroomAddress: cleanAddress,
        ghanaPostGps: cleanGps,
        contactPhone: cleanPhone,
        whatsAppNumber: cleanWhatsApp,
        contactEmail: cleanEmail
      });
    }

    if (relockAfter) {
      setSettings(prev => ({ ...prev, contactLocked: true, contactLastSavedBy: currentUser?.name || 'Administrator' }));
      storeService.toggleContactDetailsLock(true, currentUser?.name, activeCompany.id);
    }

    // 4. Update backend video / showroom config
    try {
      await fetch('/api/video/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          showroomContact: {
            address: cleanAddress,
            gps: cleanGps,
            phone: cleanPhone,
            whatsApp: cleanWhatsApp,
            email: cleanEmail,
            isLocked: willBeLocked
          }
        })
      });
    } catch {}

    // 5. Broadcast real-time event to storefront WebSocket & SSE stream
    try {
      await realtimeSyncService.publishEvent('SHOWROOM_LOCATION_UPDATED', {
        showroomAddress: cleanAddress,
        ghanaPostGps: cleanGps,
        contactPhone: cleanPhone,
        whatsAppNumber: cleanWhatsApp,
        contactEmail: cleanEmail
      }, activeCompany.id, currentUser?.name || 'Showroom Administrator');
    } catch {}

    setIsApplyingCredentials(false);
    setCredentialsApplySuccess(true);
    setTimeout(() => setCredentialsApplySuccess(false), 4500);
  };

  const handleToggleWhatsAppLock = () => {
    if (!canManage && !isAdminConsoleUnlocked) {
      setIsUnlockModalOpen(true);
      return;
    }
    const nextLocked = !settings.whatsAppLocked;
    setSettings(prev => ({ ...prev, whatsAppLocked: nextLocked }));
    storeService.toggleWhatsAppLock(nextLocked, currentUser?.name, activeCompany.id);
  };

  const handleApplyAndSaveWhatsAppDesk = async (e?: React.MouseEvent, relockAfter: boolean = false) => {
    if (e) e.preventDefault();
    if (!canManage && !isAdminConsoleUnlocked) {
      setIsUnlockModalOpen(true);
      return;
    }
    const cleanWhatsApp = (settings.whatsAppNumber || '0542443125/0596334488').trim();
    if (!cleanWhatsApp) {
      alert('Please enter a valid Direct Trade WhatsApp Desk WhatsApp Number.');
      return;
    }

    setIsApplyingWhatsApp(true);
    const willBeLocked = relockAfter ? true : settings.whatsAppLocked;

    // 1. Update Store Settings
    storeService.updateStoreSettings({
      whatsAppNumber: cleanWhatsApp,
      whatsAppPrefill: settings.whatsAppPrefill?.trim() || 'Hello Atelier Surfaces, I would like to inquire with the Direct Trade WhatsApp Desk regarding tile & marble stock.',
      whatsAppLocked: willBeLocked,
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 2. Update POS Settings & momo number
    storeService.updatePOSSettings({
      whatsAppNumber: cleanWhatsApp,
      momoMerchantNumber: cleanWhatsApp
    }, currentUser?.name || 'Administrator', activeCompany.id);

    // 3. Update Company Tenant
    if (updateCompany) {
      updateCompany({
        ...activeCompany,
        whatsAppNumber: cleanWhatsApp,
      });
    }

    if (relockAfter) {
      setSettings(prev => ({ ...prev, whatsAppLocked: true }));
      storeService.toggleWhatsAppLock(true, currentUser?.name, activeCompany.id);
    }

    // 4. Update backend config
    try {
      await fetch('/api/video/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          showroomContact: {
            whatsApp: cleanWhatsApp,
          }
        })
      });
    } catch {}

    // 5. Broadcast real-time event to storefront WebSocket & SSE stream
    try {
      await realtimeSyncService.publishEvent('SHOWROOM_LOCATION_UPDATED', {
        showroomAddress: settings.showroomAddress,
        ghanaPostGps: settings.ghanaPostGps,
        contactPhone: settings.contactPhone,
        whatsAppNumber: cleanWhatsApp,
        contactEmail: settings.contactEmail
      }, activeCompany.id, currentUser?.name || 'Showroom Administrator');
    } catch {}

    setIsApplyingWhatsApp(false);
    setWhatsAppApplySuccess(true);
    setTimeout(() => setWhatsAppApplySuccess(false), 5000);
  };

  const handleToggleVideoLock = () => {
    const nextLocked = !settings.videoConsultationLocked;
    setSettings(prev => ({ ...prev, videoConsultationLocked: nextLocked }));
    storeService.toggleVideoConsultationLock(nextLocked, currentUser?.name, activeCompany.id);
    fetch('/api/video/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isLocked: nextLocked })
    }).catch(() => {});
  };


  return (
    <AdminLayout
      title={`Store Configuration & Regional Settings · ${activeCompany.name}`}
      subtitle="Brand identity, tax compliance, regional currency, delivery rates, and isolated company settings."
    >
      {/* Active Company Workspace Context Banner */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-accent)]/40 p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-sm bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center text-[var(--theme-accent)]">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold text-[var(--theme-accent)] tracking-wider">
                Editing Isolated Company:
              </span>
              <span className="font-serif-luxury font-semibold text-sm text-[var(--theme-text)]">
                {activeCompany.name}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-text-muted)]">
                ?company={activeCompany.slug}
              </span>
            </div>
            <p className="text-xs text-[var(--theme-text-muted)] mt-0.5">
              Changes saved here only apply to this company's storefront, cart, orders, and products.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCopyLink}
          className="px-3.5 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
        >
          {copiedLink ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-500" />
              <span>Link Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
              <span>Copy Storefront URL</span>
            </>
          )}
        </button>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Settings and company parameters updated successfully for {activeCompany.name}.</span>
        </div>
      )}

      {passwordError && (
        <div className="p-4 bg-red-50 text-red-800 border border-red-200 text-xs flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-red-600" />
          <span>{passwordError}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-8 max-w-4xl text-xs text-[var(--theme-text)]">
        
        {/* Brand Identity */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h2 className="font-serif-luxury text-xl font-semibold border-b border-[var(--theme-border)] pb-2">
            Brand Identity & Announcement Bar
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Brand Name
              </label>
              <input
                type="text"
                required
                value={settings.brandName}
                onChange={e => setSettings(prev => ({ ...prev, brandName: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Tagline
              </label>
              <input
                type="text"
                value={settings.tagline}
                onChange={e => setSettings(prev => ({ ...prev, tagline: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Top Announcement Bar Message
              </label>
              <input
                type="text"
                value={settings.announcementText}
                onChange={e => setSettings(prev => ({ ...prev, announcementText: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="flex items-center gap-2 cursor-pointer font-semibold">
                <input
                  type="checkbox"
                  checked={settings.announcementEnabled}
                  onChange={e => setSettings(prev => ({ ...prev, announcementEnabled: e.target.checked }))}
                  className="accent-[var(--theme-accent)]"
                />
                <span>Enable Announcement Bar on Storefront</span>
              </label>
            </div>
          </div>
        </div>

        {/* Currency & Tax (Ghana GHS) */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h2 className="font-serif-luxury text-xl font-semibold border-b border-[var(--theme-border)] pb-2">
            Regional Currency & Tax Rates (Ghana)
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Currency
              </label>
              <select
                value={settings.currency}
                onChange={e => setSettings(prev => ({ ...prev, currency: e.target.value as any }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-semibold"
              >
                <option value="GHS">Ghanaian Cedi (GH₵)</option>
                <option value="USD">US Dollar ($)</option>
                <option value="EUR">Euro (€)</option>
                <option value="GBP">British Pound (£)</option>
              </select>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Tax Rate (VAT / NHIL / GETFund %)
              </label>
              <input
                type="number"
                min="0"
                max="50"
                value={settings.taxRatePercent}
                onChange={e => setSettings(prev => ({ ...prev, taxRatePercent: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tabular-nums"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Free Delivery Threshold (GH₵)
              </label>
              <input
                type="number"
                min="0"
                value={settings.freeDeliveryThreshold}
                onChange={e => setSettings(prev => ({ ...prev, freeDeliveryThreshold: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tabular-nums"
              />
            </div>
          </div>
        </div>

        {/* Freight & Logistics Rates */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h2 className="font-serif-luxury text-xl font-semibold border-b border-[var(--theme-border)] pb-2">
            Freight Charges & Tailgate Delivery
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Standard Hydraulic Delivery Cost (GH₵)
              </label>
              <input
                type="number"
                value={settings.standardDeliveryCost}
                onChange={e => setSettings(prev => ({ ...prev, standardDeliveryCost: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tabular-nums"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Express Crane Placement Cost (GH₵)
              </label>
              <input
                type="number"
                value={settings.expressFreightCost}
                onChange={e => setSettings(prev => ({ ...prev, expressFreightCost: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tabular-nums"
              />
            </div>
          </div>
        </div>

        {/* Showroom Contact Details & Admin Lock */}
        <div 
          id="showroom-contact"
          className={`p-6 border space-y-4 transition ${
            settings.contactLocked 
              ? 'bg-amber-950/15 border-amber-500/40' 
              : 'bg-[var(--theme-surface)] border-[var(--theme-border)]'
          }`}
        >
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-[var(--theme-border)] pb-3">
            <div className="flex items-center gap-2">
              <MapPin className={`w-5 h-5 ${settings.contactLocked ? 'text-amber-500' : 'text-[var(--theme-accent)]'}`} />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
                    Flagship Showroom Contact & GPS Credentials
                  </h2>
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-emerald-950/80 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full font-mono">
                    <Globe className="w-3 h-3" /> Live Storefront Sync
                  </span>
                  {settings.contactLocked ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-amber-950/80 text-amber-400 border border-amber-800 px-2 py-0.5 rounded-xs font-mono">
                      <Lock className="w-3 h-3" /> Locked & Verified
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-emerald-900 text-emerald-300 border border-emerald-600 px-2 py-0.5 rounded-xs font-mono">
                      <Unlock className="w-3 h-3" /> Edit Mode Active
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                  Verified physical showroom coordinates, GhanaPost GPS code, concierge phone, and official trade email.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start lg:self-auto flex-wrap">
              {/* Direct Link to Storefront Private Consultations & Inquiries */}
              <Link
                href="/contact"
                className="px-2.5 py-1 text-xs border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text)] font-semibold flex items-center gap-1.5 bg-[var(--theme-surface-subtle)] cursor-pointer transition"
                title="View on Storefront: Private Consultations & Inquiries"
              >
                <span>View at Private Consultations</span>
                <ExternalLink className="w-3 h-3 text-[var(--theme-accent)]" />
              </Link>

              {!settings.contactLocked && (
                <button
                  type="button"
                  onClick={handleApplyOfficialAccraDefaults}
                  className="px-2.5 py-1 text-[11px] text-[var(--theme-accent)] hover:underline font-semibold flex items-center gap-1 cursor-pointer bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                  title="Fill 14 Independence Avenue, Ridge West defaults"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Accra Defaults</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleToggleContactLock}
                className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                  settings.contactLocked
                    ? 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                    : 'bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50'
                }`}
              >
                {settings.contactLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{settings.contactLocked ? 'Unlock to Edit' : 'Lock It Again'}</span>
              </button>

              {/* Dedicated Apply and Save Buttons when unlocked */}
              {!settings.contactLocked && (
                <>
                  <button
                    type="button"
                    disabled={isApplyingCredentials}
                    onClick={(e) => handleApplyAndSaveShowroomCredentials(e, false)}
                    className={`px-3.5 py-1.5 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer ${
                      credentialsApplySuccess
                        ? 'bg-emerald-600 text-white'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                    title="Apply & save these credentials to immediately replace the old across storefront and POS"
                  >
                    {credentialsApplySuccess ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                    <span>{isApplyingCredentials ? 'Applying...' : credentialsApplySuccess ? 'Applied & Saved!' : 'Apply & Save'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isApplyingCredentials}
                    onClick={(e) => handleApplyAndSaveShowroomCredentials(e, true)}
                    className="hidden sm:flex px-3 py-1.5 font-bold text-xs uppercase tracking-wider rounded-xs items-center gap-1.5 transition cursor-pointer bg-stone-900 hover:bg-stone-800 text-emerald-400 border border-emerald-500/40"
                    title="Apply changes and lock the contact credentials in one click"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply, Save & Lock</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {settings.contactLocked && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-300 text-xs flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-500 shrink-0" />
                <span>
                  <strong>Contact Information Locked:</strong> Showroom address, GPS routing, phone, and concierge email are secured in the verified registry. Click <strong>Unlock to Edit</strong> to modify.
                </span>
              </div>
              <button
                type="button"
                onClick={handleToggleContactLock}
                className="text-xs font-bold uppercase underline text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                Unlock to Edit →
              </button>
            </div>
          )}

          {credentialsApplySuccess && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs rounded-xs flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Changes Applied & Saved:</strong> New showroom address ({settings.showroomAddress}), GhanaPost GPS ({settings.ghanaPostGps}), phone ({settings.contactPhone}), Direct Trade WhatsApp Desk ({settings.whatsAppNumber || settings.contactPhone}), and email ({settings.contactEmail}) have taken effect immediately and replaced old data across Private Consultations, Storefront Footer, and POS!
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Showroom Address *
              </label>
              <input
                type="text"
                required
                disabled={settings.contactLocked}
                value={settings.showroomAddress}
                onChange={e => setSettings(prev => ({ ...prev, showroomAddress: e.target.value }))}
                placeholder="14 Independence Avenue, Ridge West, Accra, Ghana"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                GhanaPost GPS Code *
              </label>
              <input
                type="text"
                required
                disabled={settings.contactLocked}
                value={settings.ghanaPostGps}
                onChange={e => setSettings(prev => ({ ...prev, ghanaPostGps: e.target.value.toUpperCase() }))}
                placeholder="GA-110-3849"
                className="w-full px-3 py-2 font-mono uppercase bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-bold text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Concierge Contact Phone *
              </label>
              <input
                type="text"
                required
                disabled={settings.contactLocked}
                value={settings.contactPhone}
                onChange={e => setSettings(prev => ({ ...prev, contactPhone: e.target.value }))}
                placeholder="0542443125/0596334488"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block uppercase font-bold text-[var(--theme-text-muted)]">
                  Direct Trade WhatsApp Desk WhatsApp Number *
                </label>
                <span className="text-[10px] uppercase font-bold text-emerald-500 font-mono">
                  Instant Trade Chat
                </span>
              </div>
              <input
                type="text"
                required
                disabled={settings.contactLocked}
                value={settings.whatsAppNumber || ''}
                onChange={e => setSettings(prev => ({ ...prev, whatsAppNumber: e.target.value }))}
                placeholder="0542443125/0596334488"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)] focus:border-emerald-500"
              />
              <p className="text-[10px] text-[var(--theme-text-muted)] mt-1">
                Architects & contractors chat with this number on Private Consultations & Homepage for stock holds & quotes.
              </p>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Concierge Official Email *
              </label>
              <input
                type="email"
                required
                disabled={settings.contactLocked}
                value={settings.contactEmail}
                onChange={e => setSettings(prev => ({ ...prev, contactEmail: e.target.value }))}
                placeholder="concierge@ateliersurfaces.com"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)]"
              />
            </div>
          </div>

          {/* Dedicated Apply and Save Action Bar */}
          <div className="pt-3 border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>
                {settings.contactLocked ? (
                  <span>Contact details are locked in the verified registry. Unlock to make edits.</span>
                ) : (
                  <span>Clicking <strong>Apply & Save</strong> takes immediate effect across Private Consultations, Storefront Footer, POS, and trade receipts.</span>
                )}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {settings.contactLocked ? (
                <button
                  type="button"
                  onClick={handleToggleContactLock}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 cursor-pointer shadow-sm transition"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock to Edit</span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    disabled={isApplyingCredentials}
                    onClick={(e) => handleApplyAndSaveShowroomCredentials(e, false)}
                    className={`px-5 py-2.5 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition shadow-md cursor-pointer ${
                      credentialsApplySuccess
                        ? 'bg-emerald-600 text-white'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {credentialsApplySuccess ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                    <span>{isApplyingCredentials ? 'Applying & Saving...' : credentialsApplySuccess ? 'Changes Applied & Saved!' : 'Apply & Save Showroom Credentials'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleToggleContactLock}
                    className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 cursor-pointer transition"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Lock It Again</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Dedicated Direct Trade WhatsApp Desk Configuration & Security Lock */}
        <div id="direct-trade-whatsapp" className={`p-6 border space-y-4 transition ${
          settings.whatsAppLocked
            ? 'bg-amber-950/10 border-amber-500/40'
            : 'bg-[var(--theme-surface)] border-emerald-500/40 shadow-xs'
        }`}>
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xs bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 flex items-center justify-center shrink-0">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-serif-luxury text-xl font-bold text-[var(--theme-text)]">
                    Direct Trade WhatsApp Desk (WhatsApp Number, Immediate Sync & Lock)
                  </h2>
                  {settings.whatsAppLocked ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-amber-950/80 text-amber-400 border border-amber-800 px-2 py-0.5 rounded-xs font-mono">
                      <Lock className="w-3 h-3" /> Locked & Verified
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase bg-emerald-900 text-emerald-300 border border-emerald-600 px-2 py-0.5 rounded-xs font-mono">
                      <Unlock className="w-3 h-3" /> Edit Mode Active
                    </span>
                  )}
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] border border-[var(--theme-border)]">
                    Admin: {currentUser?.name || 'Super Admin'} ({currentUser?.roleName || 'Administrator'})
                  </span>
                </div>
                <p className="text-[11px] text-[var(--theme-text-muted)] mt-0.5">
                  Official WhatsApp desk line for architects and contractors to receive instantaneous stock allocation, wholesale trade discounts, and sample delivery.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start lg:self-auto flex-wrap">
              {/* Direct Storefront Link */}
              <Link
                href="/contact"
                className="px-2.5 py-1 text-xs border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text)] font-semibold flex items-center gap-1.5 bg-[var(--theme-surface-subtle)] cursor-pointer transition"
                title="View on Storefront: Private Consultations & Inquiries"
              >
                <span>View at Private Consultations</span>
                <ExternalLink className="w-3 h-3 text-[var(--theme-accent)]" />
              </Link>

              {/* Accra Preset Button */}
              {/* Accra Preset Button */}
              {!settings.whatsAppLocked && (
                <button
                  type="button"
                  onClick={() => setSettings(prev => ({ ...prev, whatsAppNumber: '0542443125/0596334488' }))}
                  className="px-2.5 py-1 text-[11px] text-emerald-500 hover:underline font-semibold flex items-center gap-1 cursor-pointer bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                  title="Reset to official Ghana number: 0542443125/0596334488"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Accra Default (0542443125/0596334488)</span>
                </button>
              )}

              {/* Lock / Unlock Toggle */}
              <button
                type="button"
                onClick={handleToggleWhatsAppLock}
                className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                  settings.whatsAppLocked
                    ? 'bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold'
                    : 'bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50'
                }`}
              >
                {settings.whatsAppLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{settings.whatsAppLocked ? 'Unlock to Edit' : 'Lock It Again'}</span>
              </button>

              {/* Apply & Save Buttons when Unlocked */}
              {!settings.whatsAppLocked && (
                <>
                  <button
                    type="button"
                    disabled={isApplyingWhatsApp}
                    onClick={(e) => handleApplyAndSaveWhatsAppDesk(e, false)}
                    className="px-3.5 py-1.5 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer bg-emerald-600 hover:bg-emerald-500 text-white"
                    title="Apply & save this WhatsApp number immediately across storefront and POS"
                  >
                    {whatsAppApplySuccess ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                    <span>{isApplyingWhatsApp ? 'Applying...' : whatsAppApplySuccess ? 'Applied & Saved!' : 'Apply & Save'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isApplyingWhatsApp}
                    onClick={(e) => handleApplyAndSaveWhatsAppDesk(e, true)}
                    className="hidden sm:flex px-3 py-1.5 font-bold text-xs uppercase tracking-wider rounded-xs items-center gap-1.5 transition cursor-pointer bg-stone-900 hover:bg-stone-800 text-emerald-400 border border-emerald-500/40"
                    title="Apply changes and lock the WhatsApp desk in one click"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply, Save & Lock</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Locked Status Banner */}
          {settings.whatsAppLocked && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-300 text-xs flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-500 shrink-0" />
                <span>
                  <strong>WhatsApp Desk Locked:</strong> The Direct Trade WhatsApp Desk number ({settings.whatsAppNumber || '0542443125/0596334488'}) is secured against accidental changes. Click <strong>Unlock to Edit</strong> to modify.
                </span>
              </div>
              <button
                type="button"
                onClick={handleToggleWhatsAppLock}
                className="text-xs font-bold uppercase underline text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                Unlock to Edit →
              </button>
            </div>
          )}

          {/* Success Banner */}
          {whatsAppApplySuccess && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs rounded-xs flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Direct Trade WhatsApp Desk Updated:</strong> WhatsApp number ({settings.whatsAppNumber || '0542443125/0596334488'}) has taken effect immediately across Private Consultations, Homepage Trade Desk CTA, and Storefront Footer!
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Direct Trade WhatsApp Desk WhatsApp Number *</span>
                <span className="text-[10px] text-emerald-500 font-mono font-bold">Ghana Format (0542443125/0596334488)</span>
              </label>
              <input
                type="text"
                required
                disabled={settings.whatsAppLocked}
                value={settings.whatsAppNumber || ''}
                onChange={e => setSettings(prev => ({ ...prev, whatsAppNumber: e.target.value }))}
                placeholder="0542443125/0596334488"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)] font-mono text-sm focus:border-emerald-500"
              />
              <p className="text-[10px] text-[var(--theme-text-muted)] mt-1">
                E.g. 0542443125/0596334488 (Accra Ridge West Flagship trade lines).
              </p>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1 flex items-center justify-between">
                <span>Test Live WhatsApp URL</span>
                <span className="text-[10px] font-mono text-[var(--theme-text-muted)]">Instant Verification</span>
              </label>
              <div className="flex items-center gap-2">
                {(() => {
                  const rawWa = settings.whatsAppNumber || '0542443125/0596334488';
                  const firstWa = rawWa.split('/')[0].trim();
                  let waDigits = firstWa.replace(/[^0-9]/g, '');
                  if (waDigits.startsWith('0')) {
                    waDigits = '233' + waDigits.substring(1);
                  }
                  return (
                    <a
                      href={`https://wa.me/${waDigits || '233542443125'}?text=${encodeURIComponent(settings.whatsAppPrefill || 'Hello Atelier Surfaces, I would like to inquire with the Direct Trade WhatsApp Desk regarding tile & marble stock.')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Test wa.me Link ({rawWa})</span>
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </a>
                  );
                })()}
              </div>
              <p className="text-[10px] text-[var(--theme-text-muted)] mt-1">
                Opens real WhatsApp chat with the current number.
              </p>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Default Architect & Contractor Inquiry Message (wa.me Prefill)
              </label>
              <input
                type="text"
                disabled={settings.whatsAppLocked}
                value={settings.whatsAppPrefill || 'Hello Atelier Surfaces, I would like to inquire with the Direct Trade WhatsApp Desk regarding tile & marble stock.'}
                onChange={e => setSettings(prev => ({ ...prev, whatsAppPrefill: e.target.value }))}
                placeholder="Hello Atelier Surfaces, I would like to inquire with the Direct Trade WhatsApp Desk regarding tile & marble stock."
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] disabled:opacity-65 disabled:cursor-not-allowed font-medium text-[var(--theme-text)] text-xs focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Live Storefront Preview Box */}
          <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2 rounded-xs">
            <span className="text-[10px] uppercase font-bold text-[var(--theme-accent)] tracking-wider block">
              Live Preview: Storefront Appearance on Private Consultations (/contact)
            </span>
            <div className="p-3.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] space-y-1.5 max-w-lg">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-[var(--theme-text)]">Direct Trade WhatsApp Desk</span>
                <span className="text-[9px] font-mono px-1.5 py-0.2 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 rounded-xs uppercase font-bold">
                  Online & Verified
                </span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Architects, contractors, and developers can chat directly with our Accra showroom team for instant stock holds, trade pricing, and expedited sample drop-offs.
              </p>
              <span className="text-emerald-500 font-semibold text-xs flex items-center gap-1 font-mono pt-0.5">
                {settings.whatsAppNumber || '0542443125/0596334488'} (WhatsApp Desk) →
              </span>
            </div>
          </div>

          {/* Dedicated Apply & Save Action Bar */}
          <div className="pt-3 border-t border-[var(--theme-border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>
                {settings.whatsAppLocked ? (
                  <span>Direct Trade WhatsApp Desk is locked. Click <strong>Unlock to Edit</strong> to modify the WhatsApp number.</span>
                ) : (
                  <span>Click <strong>Apply & Save</strong> to immediately update the WhatsApp number across Private Consultations, Homepage, and POS.</span>
                )}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {settings.whatsAppLocked ? (
                <button
                  type="button"
                  onClick={handleToggleWhatsAppLock}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 cursor-pointer shadow-sm transition"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock to Edit</span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    disabled={isApplyingWhatsApp}
                    onClick={(e) => handleApplyAndSaveWhatsAppDesk(e, false)}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-2 transition shadow-md cursor-pointer"
                  >
                    {whatsAppApplySuccess ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                    <span>{isApplyingWhatsApp ? 'Applying...' : whatsAppApplySuccess ? 'Applied & Saved!' : 'Apply & Save WhatsApp Number'}</span>
                  </button>
                  <button
                    type="button"
                    disabled={isApplyingWhatsApp}
                    onClick={(e) => handleApplyAndSaveWhatsAppDesk(e, true)}
                    className="hidden sm:flex px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-emerald-400 border border-emerald-500/40 font-bold text-xs uppercase tracking-wider rounded-xs items-center gap-1.5 transition cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply, Save & Lock</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleToggleWhatsAppLock}
                    className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-amber-300 border border-amber-600/50 font-bold text-xs uppercase tracking-wider rounded-xs flex items-center gap-1.5 cursor-pointer transition"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Lock It Again</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Face-to-Face Video Online Consultation Settings & Lock */}
        <div className={`p-6 border space-y-4 transition ${
          settings.videoConsultationLocked 
            ? 'bg-red-950/15 border-red-500/40' 
            : 'bg-[var(--theme-surface)] border-[var(--theme-border)]'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--theme-border)] pb-3">
            <div className="flex items-center gap-2">
              <Video className={`w-5 h-5 ${settings.videoConsultationLocked ? 'text-red-500' : 'text-emerald-500'}`} />
              <div>
                <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
                  Face-to-Face Online Video Call Configuration & Lock
                </h2>
                <p className="text-[11px] text-[var(--theme-text-muted)]">
                  Manage WebRTC video calls, consultant availability, showroom hours, and master consultation lock.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <a
                href="/admin/video-consultation"
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold uppercase tracking-wider rounded-xs border border-stone-600 transition"
              >
                Open Call Desk
              </a>

              <button
                type="button"
                onClick={handleToggleVideoLock}
                className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center gap-1.5 transition cursor-pointer ${
                  settings.videoConsultationLocked
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-red-600 hover:bg-red-500 text-white'
                }`}
              >
                {settings.videoConsultationLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{settings.videoConsultationLocked ? 'Unlock Video Calls' : 'Lock Video Calls'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Lead Consultant Name
              </label>
              <input
                type="text"
                value={settings.videoConsultantName || 'Kwame Mensah'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantName: e.target.value }))}
                placeholder="Kwame Mensah"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultant Title
              </label>
              <input
                type="text"
                value={settings.videoConsultantTitle || 'Lead Architectural Consultant'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantTitle: e.target.value }))}
                placeholder="Lead Architectural Consultant"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Consultation Operational Hours
              </label>
              <input
                type="text"
                value={settings.videoConsultantHours || 'Mon–Sat: 8:00 AM – 6:00 PM GMT'}
                onChange={e => setSettings(prev => ({ ...prev, videoConsultantHours: e.target.value }))}
                placeholder="Mon–Sat: 8:00 AM – 6:00 PM GMT"
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Video Stream Quality
              </label>
              <select
                value={settings.videoResolution || '1080p'}
                onChange={e => setSettings(prev => ({ ...prev, videoResolution: e.target.value as any }))}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] cursor-pointer"
              >
                <option value="1080p">1080p Full High-Definition (Ultra-Low Latency)</option>
                <option value="720p">720p Balanced (Bandwidth Saver)</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Lockdown Disclaimer Message (Displayed when calls are locked)
              </label>
              <input
                type="text"
                value={settings.videoLockMessage || ''}
                onChange={e => setSettings(prev => ({ ...prev, videoLockMessage: e.target.value }))}
                placeholder="Video consultations are currently locked for a private masterclass. Please contact concierge or schedule an appointment."
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)]"
              />
            </div>
          </div>
        </div>

        {/* Master Console Password & Security */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-2">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-[var(--theme-accent)]" />
              <h2 className="font-serif-luxury text-xl font-semibold">
                Company Admin Console Password
              </h2>
            </div>
            <span className="text-[10px] font-mono uppercase px-2 py-0.5 bg-stone-100 dark:bg-stone-900 text-[var(--theme-text-muted)] border border-[var(--theme-border)]">
              Encrypted Key
            </span>
          </div>

          <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
            Protect this company's administrative dashboard, inventory, orders, and studio settings. The master password is encrypted and never displayed in plain text.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                New Admin Password (Leave blank to keep existing)
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={adminPassword}
                  onChange={e => setAdminPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="new-password"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tracking-widest text-xs"
                />
                <KeyRound className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Confirm New Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="new-password"
                  className="w-full pl-9 pr-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] tracking-widest text-xs"
                />
                <ShieldCheck className="w-3.5 h-3.5 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>
        </div>

        {canManage && (
          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-[var(--theme-text-muted)]">
              Saving updates only the active company profile: <strong>{activeCompany.name}</strong>
            </span>
            <button
              type="submit"
              className="px-8 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold uppercase tracking-wider text-xs hover:opacity-90 flex items-center gap-2 shadow-md cursor-pointer transition-opacity"
            >
              <Save className="w-4 h-4" />
              <span>Save Company Settings</span>
            </button>
          </div>
        )}
      </form>

      {/* Master Toast Notification */}
      {masterToast && (
        <div 
          className={`p-4 border text-xs flex items-center justify-between gap-3 shadow-lg transition-all animate-in fade-in duration-200 mt-6 ${
            masterToast.type === 'success' 
              ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-100'
              : masterToast.type === 'error'
              ? 'bg-red-950/90 border-red-500/60 text-red-100'
              : 'bg-stone-900 border-amber-500/60 text-amber-100'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {masterToast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : masterToast.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            ) : (
              <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <div>
              <strong className="font-bold uppercase tracking-wider block text-[11px]">
                {masterToast.title}
              </strong>
              <span className="text-[12px] opacity-90">{masterToast.message}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMasterToast(null)}
            className="text-stone-400 hover:text-stone-100 p-1 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ========================================================= */}
      {/* MASTER SYSTEM RESET & CATALOG ZEROING CONTROL DESK        */}
      {/* ========================================================= */}
      <section 
        aria-label="Master System Reset & Catalog Zeroing Control Desk"
        className="bg-stone-950 border-2 border-stone-800 text-stone-100 shadow-xl p-6 space-y-4 mt-8"
      >
        {/* Header Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-stone-800 pb-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                Master System Control Desk
              </span>
              {masterResetLock.isLocked ? (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-red-950/80 text-red-300 border border-red-800 font-bold">
                  <Lock className="w-3.5 h-3.5 text-red-400" />
                  <span>Controls Secured · Locked</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-emerald-950/80 text-emerald-300 border border-emerald-800 font-bold animate-pulse">
                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Controls Armed · Unlocked</span>
                </span>
              )}
              {isZeroState && (
                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider px-2.5 py-1 bg-purple-950/80 text-purple-300 border border-purple-800 font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Zero State Active (0 Products / GH₵0.00)</span>
                </span>
              )}
              <span className="text-[10px] text-stone-400 font-mono">
                Admin: <strong className="text-stone-200">{currentUser?.name || 'Administrator'}</strong>
              </span>
            </div>
            <h2 className="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
              <span>Enterprise Zeroing Station & Master Data Protocol</span>
              <span className="text-stone-400 text-xs font-normal">[{activeCompany.name}]</span>
            </h2>
            <p className="text-[11px] text-stone-400">
              Admin controls to delete all products, delete all revenues from dashboard, and restart dashboard again sending all to zero, with save, apply, and lock security.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap shrink-0">
            {/* Lock / Unlock Toggle Button */}
            <button
              type="button"
              onClick={handleToggleMasterLock}
              className={`px-3.5 py-2 text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer border shadow-sm ${
                masterResetLock.isLocked
                  ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border-stone-600'
              }`}
              title={masterResetLock.isLocked ? 'Authenticate with administrator credentials to unlock zeroing actions' : 'Lock controls to prevent accidental wipes'}
            >
              {masterResetLock.isLocked ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Unlock className="w-3.5 h-3.5 text-emerald-400" />}
              <span>{masterResetLock.isLocked ? 'Unlock Master Controls' : 'Lock Master Controls'}</span>
            </button>

            {/* Save & Apply Changes */}
            <button
              type="button"
              onClick={handleSaveAndApplyZero}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer shadow-md"
              title="Save current state to storage and sync live across all tabs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Apply Changes</span>
            </button>
          </div>
        </div>

        {/* 4 Action Tiles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Action 1: Delete All Products */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <Boxes className="w-3.5 h-3.5 text-amber-400" />
                  <span>Delete All Products</span>
                </span>
                <span className="text-[10px] font-mono text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded-xs">
                  {productsCount} Products
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Wipes all catalog surface specimens, variations, and stock allocations down to 0.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('products')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-950/50 hover:bg-red-900/70 text-red-300 border border-red-800/90 cursor-pointer'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to delete products' : 'Delete all products'}
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Delete All Products</span>
            </button>
          </div>

          {/* Action 2: Delete All Revenues */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Delete All Revenues</span>
                </span>
                <span className="text-[10px] font-mono text-stone-400 bg-stone-800 px-1.5 py-0.5 rounded-xs">
                  {ordersCount} Orders
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Clears all customer orders and Showroom POS receipts, sending verified revenue to GH₵0.00.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('revenues')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-950/50 hover:bg-red-900/70 text-red-300 border border-red-800/90 cursor-pointer'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to clear revenues' : 'Delete all revenues'}
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>Delete All Revenues</span>
            </button>
          </div>

          {/* Action 3: Restart Dashboard to Zero */}
          <div className="bg-stone-900/90 border border-amber-900/60 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Restart Dashboard</span>
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 bg-red-950 text-red-400 border border-red-800 font-bold">
                  TOTAL ZERO
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Master reset: wipes catalog products, orders, POS sales, and revenues all to 0 simultaneously.
              </p>
            </div>
            <button
              type="button"
              disabled={masterResetLock.isLocked}
              onClick={() => handleOpenZeroAction('dashboard')}
              className={`w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                masterResetLock.isLocked
                  ? 'bg-stone-800/40 text-stone-600 border border-stone-800 cursor-not-allowed'
                  : 'bg-red-600 hover:bg-red-500 text-white cursor-pointer shadow-md'
              }`}
              title={masterResetLock.isLocked ? 'Unlock master controls first to restart dashboard' : 'Restart dashboard sending all to zero'}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Restart All to Zero</span>
            </button>
          </div>

          {/* Action 4: Restore Factory Demo Data */}
          <div className="bg-stone-900/90 border border-stone-800 p-3.5 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-200 flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Restore Demo Data</span>
                </span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-1.5 py-0.5">
                  RECOVERY
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Safely reload default catalog specimens, sample orders, and demo revenue after zeroing.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleOpenZeroAction('restore')}
              className="w-full py-2.5 px-3 bg-cyan-950/50 hover:bg-cyan-900/70 text-cyan-300 border border-cyan-800/80 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              title="Repopulate demo products and order records"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Restore Factory Data</span>
            </button>
          </div>
        </div>

        {/* Lock Notice banner if controls are locked */}
        {masterResetLock.isLocked && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Master Protection Active:</strong> System zeroing controls are locked against unauthorized clicks. Click "Unlock Master Controls" with administrator credentials to arm controls.
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleMasterLock}
              className="text-[11px] underline font-bold text-amber-400 hover:text-amber-300 uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
            >
              Authenticate & Unlock
            </button>
          </div>
        )}
      </section>

      {/* Admin Credential Unlock Modal */}
      {isUnlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-100">
                    Administrator Authentication
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Enter master credentials to unlock Flagship Showroom credentials for editing
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUnlockModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {unlockError && (
              <div className="p-3 bg-red-950/60 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{unlockError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmAdminUnlock} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-400 mb-1 font-mono text-[11px]">
                  Master Administrator Password
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={unlockPassword}
                  onChange={e => setUnlockPassword(e.target.value)}
                  placeholder="Enter administrator password (e.g. admin123)..."
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[11px] text-stone-500 mt-1">
                  Default credentials: <code className="text-amber-400">admin123</code> or active company credentials.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsUnlockModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Authenticate & Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Master Control Unlock Modal */}
      {isMasterUnlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 w-full max-w-md p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-100">
                    Administrator Authentication
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Unlock Master Zeroing Control Station
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsMasterUnlockModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {masterUnlockError && (
              <div className="p-3 bg-red-950/70 border border-red-500/50 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{masterUnlockError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmMasterUnlock} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-400 mb-1 font-mono text-[11px]">
                  Master Administrator Password
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={masterUnlockPassword}
                  onChange={e => setMasterUnlockPassword(e.target.value)}
                  placeholder="Enter administrator password..."
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <p className="text-[11px] text-stone-500 mt-1">
                  Default: <code className="text-amber-400">admin123</code> or active company credentials.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsMasterUnlockModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Authenticate & Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Master Zero Confirmation Modal */}
      {isZeroConfirmModalOpen && zeroActionType && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border-2 border-red-600/60 w-full max-w-lg p-6 space-y-4 shadow-2xl text-stone-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-red-500/20 border border-red-500/40 text-red-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-red-200 uppercase tracking-wide">
                    {zeroActionType === 'products' && 'Confirm: Delete All Catalog Products'}
                    {zeroActionType === 'revenues' && 'Confirm: Delete All Dashboard Revenues'}
                    {zeroActionType === 'dashboard' && 'Critical: Restart Dashboard to Zero'}
                    {zeroActionType === 'restore' && 'Restore Factory Demo Data'}
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Workspace: <strong className="text-stone-200">{activeCompany.name}</strong> ({activeCompany.id})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsZeroConfirmModalOpen(false)}
                className="text-stone-400 hover:text-stone-200 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Warning Message Box */}
            <div className={`p-3.5 border text-xs space-y-1.5 ${
              zeroActionType === 'restore' 
                ? 'bg-cyan-950/40 border-cyan-800/80 text-cyan-200' 
                : 'bg-red-950/50 border-red-800/80 text-red-200'
            }`}>
              <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-[11px]">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>
                  {zeroActionType === 'restore' ? 'Factory Recovery Operation' : 'Destructive Master Action Warning'}
                </span>
              </div>
              <p className="text-[11px] leading-relaxed text-stone-300">
                {zeroActionType === 'products' && (
                  `This will permanently delete all ${productsCount} catalog items and their variations for "${activeCompany.name}". Product count will immediately show 0 across the dashboard and inventory view.`
                )}
                {zeroActionType === 'revenues' && (
                  `This will wipe all customer orders and Showroom POS receipts for "${activeCompany.name}". Verified revenue will immediately drop to GH₵0.00 and total orders will show 0.`
                )}
                {zeroActionType === 'dashboard' && (
                  `This will execute a complete system restart sending all metrics to zero: all ${productsCount} catalog products, all customer orders, and all showroom POS revenue will be completely cleared.`
                )}
                {zeroActionType === 'restore' && (
                  `This will restore default architectural tile specimens, stock allocations, and demo customer orders for "${activeCompany.name}".`
                )}
              </p>
            </div>

            {confirmZeroError && (
              <div className="p-3 bg-red-950/80 border border-red-500/60 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{confirmZeroError}</span>
              </div>
            )}

            <form onSubmit={handleExecuteZeroAction} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-stone-300 mb-1 font-mono text-[11px]">
                  Confirm Action: Enter Administrator Password or{' '}
                  <span className="text-amber-400 font-mono">
                    "{zeroActionType === 'products' ? 'DELETE-PRODUCTS' : zeroActionType === 'revenues' ? 'DELETE-REVENUES' : zeroActionType === 'dashboard' ? 'CONFIRM-ZERO' : 'RESTORE'}"
                  </span>
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={confirmPasswordInput}
                  onChange={e => setConfirmPasswordInput(e.target.value)}
                  placeholder={`Enter admin123 or ${zeroActionType === 'products' ? 'DELETE-PRODUCTS' : zeroActionType === 'revenues' ? 'DELETE-REVENUES' : zeroActionType === 'dashboard' ? 'CONFIRM-ZERO' : 'RESTORE'}...`}
                  className="w-full px-3 py-2.5 bg-stone-950 border border-stone-700 text-xs text-stone-100 focus:outline-none focus:border-red-500 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => setIsZeroConfirmModalOpen(false)}
                  className="px-4 py-2 border border-stone-700 text-stone-300 uppercase font-semibold text-xs hover:bg-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 uppercase font-bold tracking-wider text-xs flex items-center gap-1.5 cursor-pointer shadow-md ${
                    zeroActionType === 'restore'
                      ? 'bg-cyan-600 hover:bg-cyan-500 text-white'
                      : 'bg-red-600 hover:bg-red-500 text-white'
                  }`}
                >
                  {zeroActionType === 'restore' ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Execute Restore</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Confirm & Execute Wipe</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
