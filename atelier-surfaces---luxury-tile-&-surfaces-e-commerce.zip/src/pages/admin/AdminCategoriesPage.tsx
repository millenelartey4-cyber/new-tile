import { useState } from 'react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { storeService } from '../../services/store';
import { useAuth } from '../../context/AuthContext';
import { Category } from '../../types';
import { Layers, Plus, Trash2, Edit3, Check, ExternalLink } from 'lucide-react';

export function AdminCategoriesPage() {
  const { currentUser, hasPermission } = useAuth();
  const [categories, setCategories] = useState(() => storeService.getCategories());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('/assets/images/category_porcelain_floors_1792523066985.jpg');

  const canManage = hasPermission('categories', 'edit') || hasPermission('categories', 'create');

  const handleOpenCreate = () => {
    setEditingCategory(null);
    setName('');
    setSlug('');
    setDescription('');
    setImageUrl('/assets/images/category_porcelain_floors_1792523066985.jpg');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Category) => {
    setEditingCategory(c);
    setName(c.name);
    setSlug(c.slug);
    setDescription(c.description);
    setImageUrl(c.imageUrl);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload: Category = {
      id: editingCategory?.id || `cat-${Date.now()}`,
      name: name.trim(),
      slug: slug.trim() || name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      description: description.trim(),
      imageUrl,
      sortOrder: editingCategory?.sortOrder || categories.length + 1,
      active: true
    };

    storeService.saveCategory(payload, currentUser?.name);
    setCategories(storeService.getCategories());
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    const res = storeService.deleteCategory(id, currentUser?.name);
    if (!res.success) {
      alert(res.error);
    } else {
      setCategories(storeService.getCategories());
    }
  };

  return (
    <AdminLayout
      title="Surface Categories & Architectural Taxonomies"
      subtitle="Organize surfaces by floor, wall, marble-look, natural stone, and specialized environments."
      actions={
        canManage && (
          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Create Category</span>
          </button>
        )
      }
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map(cat => {
          const productCount = storeService.getProducts().filter(p => p.categoryId === cat.id).length;
          return (
            <div
              key={cat.id}
              className="bg-[var(--theme-surface)] border border-[var(--theme-border)] overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="aspect-[16/9] bg-stone-100 relative overflow-hidden">
                  <img src={cat.imageUrl} alt={cat.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 right-2 bg-black/60 text-white text-[10px] font-bold px-2 py-0.5 backdrop-blur-xs">
                    {productCount} Products
                  </div>
                </div>
                <div className="p-4 space-y-1">
                  <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)]">
                    {cat.name}
                  </h3>
                  <span className="font-mono text-[10px] text-[var(--theme-text-muted)] block">
                    /{cat.slug}
                  </span>
                  <p className="text-xs text-[var(--theme-text-muted)] line-clamp-2 pt-1">
                    {cat.description}
                  </p>
                </div>
              </div>

              <div className="p-4 border-t border-[var(--theme-border-subtle)] flex items-center justify-between text-xs">
                <a
                  href={`/category/${cat.slug}`}
                  target="_blank"
                  className="text-[var(--theme-accent)] hover:underline flex items-center gap-1 font-medium"
                >
                  <span>View Public Page</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                {canManage && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenEdit(cat)}
                      className="p-1 text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)]"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete category "${cat.name}"?`)) handleDelete(cat.id);
                      }}
                      className="p-1 text-[var(--theme-text-muted)] hover:text-red-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Category Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] w-full max-w-md p-6 space-y-4 shadow-2xl text-[var(--theme-text)]">
            <h3 className="font-serif-luxury text-xl font-semibold">
              {editingCategory ? 'Edit Category' : 'Create Surface Category'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Category Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => {
                    setName(e.target.value);
                    if (!editingCategory) {
                      setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-'));
                    }
                  }}
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">URL Slug</label>
                <input
                  type="text"
                  required
                  value={slug}
                  onChange={e => setSlug(e.target.value)}
                  className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Image URL</label>
                <input
                  type="text"
                  value={imageUrl}
                  onChange={e => setImageUrl(e.target.value)}
                  className="w-full px-3 py-2 font-mono bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[var(--theme-border)]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-[var(--theme-border)] uppercase font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] uppercase font-bold"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
