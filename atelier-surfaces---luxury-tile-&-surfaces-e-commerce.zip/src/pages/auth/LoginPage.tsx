import { useState } from 'react';
import { useRouter } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, User, Lock, Mail, ArrowRight, Check } from 'lucide-react';

export function LoginPage() {
  const { navigate } = useRouter();
  const { login, register, availableUsers, switchUser, currentUser } = useAuth();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+233 ');
  const [errorMsg, setErrorMsg] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const success = login(email);
    if (success) {
      navigate('/account');
    } else {
      setErrorMsg('User not found. Try one of the quick test accounts below or register.');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      setErrorMsg('Please provide name and email.');
      return;
    }
    register(name, email, phone);
    navigate('/account');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16 space-y-8">
      
      <div className="text-center space-y-2">
        <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
          Atelier Access Protocol
        </span>
        <h1 className="font-serif-luxury text-3xl font-semibold text-[var(--theme-text)]">
          {mode === 'login' ? 'Client & Staff Authentication' : 'Create Trade Account'}
        </h1>
        <p className="text-xs text-[var(--theme-text-muted)]">
          Access order history, tracking timelines, trade specifications, and staff consoles.
        </p>
      </div>

      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 sm:p-8 space-y-6">
        
        {/* Toggle Mode */}
        <div className="grid grid-cols-2 p-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold">
          <button
            type="button"
            onClick={() => { setMode('login'); setErrorMsg(''); }}
            className={`py-2 text-center transition-colors ${
              mode === 'login' ? 'bg-[var(--theme-surface)] text-[var(--theme-text)] shadow-xs' : 'text-[var(--theme-text-muted)]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setErrorMsg(''); }}
            className={`py-2 text-center transition-colors ${
              mode === 'register' ? 'bg-[var(--theme-surface)] text-[var(--theme-text)] shadow-xs' : 'text-[var(--theme-text-muted)]'
            }`}
          >
            Register Trade
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-50 text-red-700 border border-red-200 text-xs">
            {errorMsg}
          </div>
        )}

        {mode === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="architect@domain.com"
                  className="w-full pl-9 pr-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
                <Mail className="w-4 h-4 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="uppercase font-bold text-[var(--theme-text-muted)]">Password</label>
                <button type="button" onClick={() => alert('Password reset instruction sent to email.')} className="text-[11px] text-[var(--theme-accent)] hover:underline">
                  Forgot?
                </button>
              </div>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
                <Lock className="w-4 h-4 text-[var(--theme-text-muted)] absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              <span>Authenticate</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Full Name / Practice
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Nana Addo Design Studio"
                className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="contact@nanaaddodesign.com"
                className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                Phone Number (WhatsApp)
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+233 24 000 0000"
                className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-[var(--theme-accent)] text-white text-xs font-bold uppercase tracking-wider hover:opacity-95 transition-opacity flex items-center justify-center gap-2"
            >
              <span>Create Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* 1-Click Evaluation Switcher for Testing Built-in Roles */}
        <div className="pt-6 border-t border-[var(--theme-border)] space-y-3">
          <div className="flex items-center gap-2 text-[var(--theme-text-muted)] text-[11px] font-bold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
            <span>Instant Role Evaluation (1-Click)</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {availableUsers.map(u => (
              <button
                key={u.uid}
                type="button"
                onClick={() => {
                  switchUser(u.uid);
                  navigate(u.roleId === 'customer' ? '/account' : '/admin');
                }}
                className={`p-2 text-left border transition-colors ${
                  currentUser?.uid === u.uid
                    ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] font-semibold'
                    : 'border-[var(--theme-border)] hover:border-[var(--theme-text)]'
                }`}
              >
                <span className="block font-medium truncate text-[var(--theme-text)]">{u.name}</span>
                <span className="text-[10px] text-[var(--theme-accent)] uppercase block">{u.roleName}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
