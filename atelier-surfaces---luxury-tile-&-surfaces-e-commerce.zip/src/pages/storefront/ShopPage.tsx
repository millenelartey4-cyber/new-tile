import { useState, useMemo, useEffect } from 'react';
import { useRouter, Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useCompany } from '../../context/CompanyContext';
import { Product, ProductVariant } from '../../types';
import { 
  Filter, 
  X, 
  ChevronDown, 
  Heart, 
  Check, 
  Search as SearchIcon,
  SlidersHorizontal,
  CheckCircle2,
  Zap,
  ScanLine
} from 'lucide-react';
import { SurfaceTextureScannerModal } from '../../components/scanner/SurfaceTextureScannerModal';

interface ShopPageProps {
  initialCategorySlug?: string;
}

export function ShopPage({ initialCategorySlug }: ShopPageProps) {
  const { searchParams, navigate } = useRouter();
  const { addToCart, toggleWishlist, isInWishlist } = useCartWishlist();
  const { activeCompany } = useCompany();
  
  // Real-time synchronization version counter
  const [productsVersion, setProductsVersion] = useState(0);
  const [liveSyncToast, setLiveSyncToast] = useState<{ message: string; type: 'stock' | 'price' } | null>(null);

  const allProducts = useMemo(() => {
    return storeService.getProducts(activeCompany.id);
  }, [activeCompany.id, productsVersion]);

  const allCategories = storeService.getCategories(activeCompany.id);
  const panelBrightness = storeService.getPanelBrightness(activeCompany.id);

  // Real-time Event Listeners for POS inventory and price mutations
  useEffect(() => {
    const handleInventorySync = (e: any) => {
      setProductsVersion(v => v + 1);
      const detail = e.detail;
      if (detail?.productName) {
        setLiveSyncToast({
          message: `Physical Showroom Sync: ${detail.productName} (${detail.colorName || 'Variant'}) stock updated to ${detail.newStock} m²`,
          type: 'stock'
        });
        setTimeout(() => setLiveSyncToast(null), 4000);
      }
    };

    const handlePriceSync = () => {
      setProductsVersion(v => v + 1);
      setLiveSyncToast({
        message: 'Showroom Price Sync: Catalog prices updated live from physical POS register',
        type: 'price'
      });
      setTimeout(() => setLiveSyncToast(null), 4000);
    };

    const handleSaleBroadcast = (e: any) => {
      setProductsVersion(v => v + 1);
      const detail = e.detail;
      setLiveSyncToast({
        message: `Physical Showroom Sale: Ticket #${detail?.transactionNumber || ''} completed at register. Slabs deducted live.`,
        type: 'stock'
      });
      setTimeout(() => setLiveSyncToast(null), 4500);
    };

    const handleGenericSync = () => {
      setProductsVersion(v => v + 1);
    };

    window.addEventListener('pos_inventory_synced', handleInventorySync);
    window.addEventListener('pos_price_synced', handlePriceSync);
    window.addEventListener('pos_sale_broadcast', handleSaleBroadcast);
    window.addEventListener('pos_realtime_event_received', handleGenericSync);
    window.addEventListener('atelier_settings_updated', handleGenericSync);
    window.addEventListener('storage', handleGenericSync);

    return () => {
      window.removeEventListener('pos_inventory_synced', handleInventorySync);
      window.removeEventListener('pos_price_synced', handlePriceSync);
      window.removeEventListener('pos_sale_broadcast', handleSaleBroadcast);
      window.removeEventListener('pos_realtime_event_received', handleGenericSync);
      window.removeEventListener('atelier_settings_updated', handleGenericSync);
      window.removeEventListener('storage', handleGenericSync);
    };
  }, [activeCompany.id]);

  // URL query params
  const querySearch = searchParams.get('q') || '';
  const querySpace = searchParams.get('space') || '';
  const queryMaterial = searchParams.get('material') || '';

  // Local filter states
  const [search, setSearch] = useState(querySearch);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategorySlug || '');
  const [selectedMaterial, setSelectedMaterial] = useState<string>(queryMaterial);
  const [selectedFinish, setSelectedFinish] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [priceMax, setPriceMax] = useState<number>(600);
  const [sortBy, setSortBy] = useState<'featured' | 'newest' | 'price-asc' | 'price-desc' | 'name'>('featured');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [isTextureScannerOpen, setIsTextureScannerOpen] = useState(false);

  // Variant selector tracking per product card
  const [selectedVariants, setSelectedVariants] = useState<Record<string, ProductVariant>>(() => {
    const map: Record<string, ProductVariant> = {};
    allProducts.forEach(p => {
      if (p.variants.length > 0) {
        map[p.id] = p.variants[0];
      }
    });
    return map;
  });

  // Unique attribute options derived from active products
  const materials = useMemo(() => Array.from(new Set(allProducts.map(p => p.material))), [allProducts]);
  const finishes = useMemo(() => Array.from(new Set(allProducts.map(p => p.finish))), [allProducts]);
  const sizes = useMemo(() => Array.from(new Set(allProducts.map(p => p.size))), [allProducts]);

  // Filter & Search Logic
  const filteredProducts = useMemo(() => {
    return allProducts.filter(product => {
      // Category filter
      if (selectedCategory && product.categoryId !== selectedCategory) {
        return false;
      }

      // Material filter
      if (selectedMaterial && product.material !== selectedMaterial) {
        return false;
      }

      // Finish filter
      if (selectedFinish && product.finish !== selectedFinish) {
        return false;
      }

      // Size filter
      if (selectedSize && product.size !== selectedSize) {
        return false;
      }

      // Space / Application
      if (querySpace && !product.applications.some(a => a.toLowerCase().includes(querySpace.toLowerCase()))) {
        return false;
      }

      // Search keyword (matches title, description, SKU, material, variant colors)
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(q);
        const matchesDesc = product.description.toLowerCase().includes(q);
        const matchesMaterial = product.material.toLowerCase().includes(q);
        const matchesSku = product.variants.some(v => v.sku.toLowerCase().includes(q));
        const matchesColor = product.variants.some(v => v.colorName.toLowerCase().includes(q));
        if (!matchesName && !matchesDesc && !matchesMaterial && !matchesSku && !matchesColor) {
          return false;
        }
      }

      // Price limit (based on lowest active variant)
      const minPrice = Math.min(...product.variants.map(v => v.price));
      if (minPrice > priceMax) {
        return false;
      }

      // In stock
      if (inStockOnly) {
        const totalStock = product.variants.reduce((acc, v) => acc + v.stock, 0);
        if (totalStock <= 0) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'price-asc') return Math.min(...a.variants.map(v => v.price)) - Math.min(...b.variants.map(v => v.price));
      if (sortBy === 'price-desc') return Math.max(...b.variants.map(v => v.price)) - Math.max(...a.variants.map(v => v.price));
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [allProducts, selectedCategory, selectedMaterial, selectedFinish, selectedSize, querySpace, search, priceMax, inStockOnly, sortBy]);

  const activeCategoryObj = allCategories.find(c => c.id === selectedCategory || c.slug === selectedCategory);

  const clearAllFilters = () => {
    setSearch('');
    setSelectedCategory('');
    setSelectedMaterial('');
    setSelectedFinish('');
    setSelectedSize('');
    setInStockOnly(false);
    setPriceMax(600);
    setSortBy('featured');
    navigate('/shop');
  };

  const hasActiveFilters = !!(search || selectedCategory || selectedMaterial || selectedFinish || selectedSize || inStockOnly || priceMax < 600 || querySpace);

  return (
    <div 
      style={{
        filter: `brightness(${panelBrightness.storefrontCatalogBrightness}%) contrast(${panelBrightness.storefrontCatalogContrast}%)`
      }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 transition-all duration-150"
    >
      {/* Page Header */}
      <div className="border-b border-[var(--theme-border)] pb-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
              {activeCategoryObj ? 'Collection Specimen' : 'Architectural Inventory'}
            </span>
            <h1 className="font-serif-luxury text-3xl sm:text-5xl font-semibold text-[var(--theme-text)] mt-1">
              {activeCategoryObj ? activeCategoryObj.name : 'All Surfaces & Slabs'}
            </h1>
            <p className="text-xs sm:text-sm text-[var(--theme-text-muted)] mt-2 max-w-2xl">
              {activeCategoryObj
                ? activeCategoryObj.description
                : 'Browse precision porcelain, bookmatched marble slabs, and quarried stone with real-time stock levels and color variant galleries.'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileFilterOpen(true)}
              className="lg:hidden px-4 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-semibold uppercase flex items-center gap-2"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters ({hasActiveFilters ? 'Active' : 'All'})</span>
            </button>

            {/* Surface Texture Scanner Shutter Button */}
            <button
              type="button"
              onClick={() => setIsTextureScannerOpen(true)}
              className="px-3.5 py-2 bg-[var(--theme-surface)] hover:bg-[var(--theme-primary)] hover:text-[var(--theme-primary-contrast)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-xs group"
              title="Use camera to scan floor or tile sample and match catalog"
            >
              <ScanLine className="w-3.5 h-3.5 text-[var(--theme-accent)] group-hover:text-[var(--theme-primary-contrast)]" />
              <span>Scan Texture</span>
            </button>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-[var(--theme-text-muted)] uppercase font-semibold hidden sm:inline">Sort:</span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="bg-[var(--theme-surface)] border border-[var(--theme-border)] px-3 py-2 text-xs font-medium focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
              >
                <option value="featured">Featured Editions</option>
                <option value="newest">Newest Specimens</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name">Alphabetical (A-Z)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Active Filter Chips (Clean unboxed/minimal buttons) */}
        {hasActiveFilters && (
          <div className="flex flex-wrap items-center gap-2 mt-6 pt-4 border-t border-[var(--theme-border-subtle)] text-xs">
            <span className="text-[var(--theme-text-muted)] font-semibold">Active Filters:</span>
            {selectedCategory && (
              <button
                onClick={() => setSelectedCategory('')}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>Category: {activeCategoryObj?.name || selectedCategory}</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            {selectedMaterial && (
              <button
                onClick={() => setSelectedMaterial('')}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>Material: {selectedMaterial}</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            {selectedFinish && (
              <button
                onClick={() => setSelectedFinish('')}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>Finish: {selectedFinish}</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            {selectedSize && (
              <button
                onClick={() => setSelectedSize('')}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>Size: {selectedSize}</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            {search && (
              <button
                onClick={() => setSearch('')}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>Keyword: "{search}"</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            {inStockOnly && (
              <button
                onClick={() => setInStockOnly(false)}
                className="px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] hover:border-red-400 flex items-center gap-1.5 transition-colors"
              >
                <span>In Stock Only</span>
                <X className="w-3 h-3 text-[var(--theme-text-muted)]" />
              </button>
            )}
            <button
              onClick={clearAllFilters}
              className="text-xs text-[var(--theme-accent)] hover:underline ml-2 font-semibold"
            >
              Clear All
            </button>
          </div>
        )}
      </div>

      {/* Main Grid with Sidebar Filter */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block space-y-8 pr-4 border-r border-[var(--theme-border)]">
          {/* Keyword Search Input */}
          <div>
            <label className="block text-xs uppercase font-bold tracking-wider text-[var(--theme-text)] mb-2">
              Filter by Keyword / SKU
            </label>
            <div className="relative">
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search..."
                className="w-full pl-8 pr-3 py-2 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
              />
              <SearchIcon className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--theme-text-muted)]" />
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-wider text-[var(--theme-text)] mb-3">
              Surface Categories
            </h3>
            <div className="space-y-1.5 text-xs">
              <button
                onClick={() => setSelectedCategory('')}
                className={`w-full text-left py-1 px-2 rounded-xs transition-colors flex items-center justify-between ${
                  !selectedCategory ? 'bg-[var(--theme-surface-subtle)] font-bold text-[var(--theme-accent)]' : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                }`}
              >
                <span>All Categories</span>
                <span className="tabular-nums">({allProducts.length})</span>
              </button>
              {allCategories.map(cat => {
                const count = allProducts.filter(p => p.categoryId === cat.id).length;
                const isSelected = selectedCategory === cat.id || selectedCategory === cat.slug;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(isSelected ? '' : cat.id)}
                    className={`w-full text-left py-1 px-2 rounded-xs transition-colors flex items-center justify-between ${
                      isSelected ? 'bg-[var(--theme-surface-subtle)] font-bold text-[var(--theme-accent)]' : 'text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="tabular-nums text-[11px]">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Material */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-wider text-[var(--theme-text)] mb-3">
              Material & Composition
            </h3>
            <div className="space-y-1 text-xs">
              {materials.map(mat => (
                <label key={mat} className="flex items-center gap-2 cursor-pointer py-0.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]">
                  <input
                    type="radio"
                    name="material"
                    checked={selectedMaterial === mat}
                    onChange={() => setSelectedMaterial(selectedMaterial === mat ? '' : mat)}
                    className="accent-[var(--theme-accent)]"
                  />
                  <span>{mat}</span>
                </label>
              ))}
              {selectedMaterial && (
                <button onClick={() => setSelectedMaterial('')} className="text-[11px] text-[var(--theme-accent)] hover:underline pt-1">
                  Reset Material
                </button>
              )}
            </div>
          </div>

          {/* Surface Finish */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-wider text-[var(--theme-text)] mb-3">
              Surface Finish
            </h3>
            <div className="flex flex-wrap gap-1.5 text-xs">
              {finishes.map(f => (
                <button
                  key={f}
                  onClick={() => setSelectedFinish(selectedFinish === f ? '' : f)}
                  className={`px-2.5 py-1 text-xs border transition-colors ${
                    selectedFinish === f 
                      ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] font-semibold text-[var(--theme-accent)]' 
                      : 'border-[var(--theme-border)] text-[var(--theme-text-muted)] hover:border-[var(--theme-text)]'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Format / Dimensions */}
          <div>
            <h3 className="text-xs uppercase font-bold tracking-wider text-[var(--theme-text)] mb-3">
              Slab & Tile Dimensions
            </h3>
            <div className="space-y-1 text-xs">
              {sizes.map(s => (
                <label key={s} className="flex items-center gap-2 cursor-pointer py-0.5 text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]">
                  <input
                    type="radio"
                    name="size"
                    checked={selectedSize === s}
                    onChange={() => setSelectedSize(selectedSize === s ? '' : s)}
                    className="accent-[var(--theme-accent)]"
                  />
                  <span className="tabular-nums">{s}</span>
                </label>
              ))}
              {selectedSize && (
                <button onClick={() => setSelectedSize('')} className="text-[11px] text-[var(--theme-accent)] hover:underline pt-1">
                  Reset Dimensions
                </button>
              )}
            </div>
          </div>

          {/* Maximum Price Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="uppercase font-bold tracking-wider text-[var(--theme-text)]">Max Price</span>
              <span className="font-semibold tabular-nums text-[var(--theme-accent)]">GH₵{priceMax}/m²</span>
            </div>
            <input
              type="range"
              min="200"
              max="600"
              step="25"
              value={priceMax}
              onChange={e => setPriceMax(parseInt(e.target.value, 10))}
              className="w-full accent-[var(--theme-accent)] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[var(--theme-text-muted)] mt-1 tabular-nums">
              <span>GH₵200</span>
              <span>GH₵600</span>
            </div>
          </div>

          {/* Availability */}
          <div className="pt-2 border-t border-[var(--theme-border-subtle)]">
            <label className="flex items-center gap-2 text-xs font-medium cursor-pointer text-[var(--theme-text)]">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={e => setInStockOnly(e.target.checked)}
                className="accent-[var(--theme-accent)]"
              />
              <span>In Stock Only (Warehouse Ready)</span>
            </label>
          </div>
        </aside>

        {/* Product Cards Grid */}
        <div className="lg:col-span-3">
          <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)] mb-6">
            <span>
              Displaying <strong className="text-[var(--theme-text)] tabular-nums">{filteredProducts.length}</strong> architectural surfaces
            </span>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 border border-dashed border-[var(--theme-border)] p-8 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-[var(--theme-surface-subtle)] flex items-center justify-center text-[var(--theme-text-muted)]">
                <SearchIcon className="w-8 h-8 opacity-40" />
              </div>
              <h3 className="font-serif-luxury text-2xl font-medium text-[var(--theme-text)]">
                No matching specimens found
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)] max-w-sm mx-auto">
                No products match your current combination of filters. Try clearing some filters or searching with alternative keywords.
              </p>
              <button
                onClick={clearAllFilters}
                className="mt-2 px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs uppercase font-semibold tracking-wider hover:opacity-90"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map(product => {
                const activeVariant = selectedVariants[product.id] || product.variants[0];
                const activeImage = activeVariant.images[0] || product.variants[0]?.images[0];
                const inWishlist = isInWishlist(product.id, activeVariant.id);

                return (
                  <div
                    key={product.id}
                    className="group flex flex-col bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-all p-4 relative"
                  >
                    {/* Wishlist toggle */}
                    <button
                      onClick={() => toggleWishlist(product.id, activeVariant.id)}
                      className={`absolute top-6 right-6 z-10 p-2 rounded-full backdrop-blur-md transition-colors ${
                        inWishlist 
                          ? 'bg-rose-50 text-rose-600' 
                          : 'bg-white/80 text-stone-700 hover:text-stone-900'
                      }`}
                      aria-label="Toggle wishlist"
                    >
                      <Heart className={`w-4 h-4 ${inWishlist ? 'fill-current text-rose-600' : ''}`} />
                    </button>

                    {/* Image with zoom on hover */}
                    <Link
                      href={`/product/${product.slug}?variant=${activeVariant.id}`}
                      className="block aspect-[4/3] overflow-hidden bg-stone-100 relative mb-4"
                    >
                      <img
                        src={activeImage}
                        alt={`${product.name} - ${activeVariant.colorName}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      />
                      {activeVariant.stock <= activeVariant.lowStockThreshold ? (
                        <span className="absolute bottom-2 left-2 bg-amber-600/90 text-white text-[10px] font-bold px-2 py-0.5 uppercase tracking-wider backdrop-blur-xs flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                          <span>Low Showroom Stock: {activeVariant.stock} {activeVariant.unit}</span>
                        </span>
                      ) : (
                        <span className="absolute bottom-2 left-2 bg-stone-950/80 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono px-2 py-0.5 backdrop-blur-xs flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>Showroom Stock: {activeVariant.stock} {activeVariant.unit}</span>
                        </span>
                      )}
                    </Link>

                    {/* Metadata line (Zero-pill format) */}
                    <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)] mb-1">
                      <span>{product.material}</span>
                      <span>·</span>
                      <span>{product.size}</span>
                      <span>·</span>
                      <span className="text-[var(--theme-text)] font-medium">{activeVariant.colorName}</span>
                    </div>

                    <Link
                      href={`/product/${product.slug}?variant=${activeVariant.id}`}
                      className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-colors line-clamp-1 mb-2"
                    >
                      {product.name}
                    </Link>

                    {/* Color Variation Swatches */}
                    <div className="flex items-center gap-1.5 my-2">
                      {product.variants.map(v => (
                        <button
                          key={v.id}
                          onClick={() => setSelectedVariants(prev => ({ ...prev, [product.id]: v }))}
                          title={`${v.colorName} (${v.sku})`}
                          className={`w-5 h-5 rounded-full border-2 transition-transform cursor-pointer ${
                            activeVariant.id === v.id
                              ? 'border-[var(--theme-accent)] scale-110 shadow-sm'
                              : 'border-transparent hover:scale-105'
                          }`}
                          style={{ backgroundColor: v.colorHex }}
                        />
                      ))}
                      <span className="text-[11px] text-[var(--theme-text-muted)] ml-1">
                        {product.variants.length} options
                      </span>
                    </div>

                    {/* Price & Add to Cart */}
                    <div className="mt-auto pt-3 border-t border-[var(--theme-border-subtle)] flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-base font-bold tabular-nums text-[var(--theme-text)]">
                            GH₵{activeVariant.price.toLocaleString()}
                          </span>
                          {activeVariant.compareAtPrice && (
                            <span className="text-xs text-[var(--theme-text-muted)] line-through tabular-nums">
                              GH₵{activeVariant.compareAtPrice.toLocaleString()}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-[var(--theme-text-muted)] block">
                          per {activeVariant.unit} (Coverage: {activeVariant.boxCoverage} m²/box)
                        </span>
                      </div>

                      <button
                        onClick={() => addToCart(product, activeVariant, 1)}
                        className="px-3 py-2 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] hover:opacity-90 text-xs font-semibold uppercase tracking-wider"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {isMobileFilterOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileFilterOpen(false)} />
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-xs bg-[var(--theme-surface)] p-6 overflow-y-auto space-y-6 text-[var(--theme-text)]">
              <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-4">
                <h3 className="font-serif-luxury text-lg font-semibold">Filter Surfaces</h3>
                <button onClick={() => setIsMobileFilterOpen(false)}>
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile categories */}
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider block">Category</span>
                <select
                  value={selectedCategory}
                  onChange={e => setSelectedCategory(e.target.value)}
                  className="w-full p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                >
                  <option value="">All Categories</option>
                  {allCategories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Mobile Material */}
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider block">Material</span>
                <select
                  value={selectedMaterial}
                  onChange={e => setSelectedMaterial(e.target.value)}
                  className="w-full p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                >
                  <option value="">All Materials</option>
                  {materials.map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              {/* Mobile Finish */}
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider block">Finish</span>
                <select
                  value={selectedFinish}
                  onChange={e => setSelectedFinish(e.target.value)}
                  className="w-full p-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs"
                >
                  <option value="">All Finishes</option>
                  {finishes.map(f => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>

              <div className="pt-4 border-t border-[var(--theme-border)] flex gap-2">
                <button
                  onClick={() => setIsMobileFilterOpen(false)}
                  className="flex-1 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase"
                >
                  Apply Filters ({filteredProducts.length})
                </button>
                <button
                  onClick={clearAllFilters}
                  className="px-4 py-3 border border-[var(--theme-border)] text-xs font-semibold"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Real-Time POS Physical Store Sync Toast */}
      {liveSyncToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-950/95 border border-emerald-500/50 text-emerald-300 text-xs px-4 py-3 rounded-xs shadow-2xl flex items-center gap-2.5 backdrop-blur-md animate-in slide-in-from-bottom-3 duration-200">
          <Zap className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
          <span className="font-sans font-medium">{liveSyncToast.message}</span>
        </div>
      )}

      {/* Surface Texture Scanner Modal */}
      <SurfaceTextureScannerModal
        isOpen={isTextureScannerOpen}
        onClose={() => setIsTextureScannerOpen(false)}
      />
    </div>
  );
}
