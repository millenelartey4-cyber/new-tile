import { useRouter, Link } from '../../router/Router';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag, Truck, ArrowLeft } from 'lucide-react';

export function CartPage() {
  const { navigate } = useRouter();
  const {
    cart,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    bulkDiscount,
    appliedBulkTiers,
    tax,
    shipping,
    total,
    freeShippingThreshold,
    freeShippingProgress,
    itemCount
  } = useCartWishlist();

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-full bg-[var(--theme-surface-subtle)] flex items-center justify-center text-[var(--theme-text-muted)]">
          <ShoppingBag className="w-8 h-8 opacity-40" />
        </div>
        <h1 className="font-serif-luxury text-3xl font-semibold">Your Specification Bag is Empty</h1>
        <p className="text-xs text-[var(--theme-text-muted)] max-w-sm mx-auto">
          Explore our collection of Italian porcelain slabs, Roman travertine, and handcrafted wall surfaces.
        </p>
        <Link
          href="/shop"
          className="inline-block mt-4 px-8 py-3.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs uppercase font-semibold tracking-wider hover:opacity-90"
        >
          Explore Collection
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[var(--theme-border)] pb-6">
        <div>
          <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
            Purchasing Specifications
          </span>
          <h1 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
            Shopping Cart ({itemCount} Units)
          </h1>
        </div>
        <Link
          href="/shop"
          className="text-xs font-semibold uppercase tracking-wider text-[var(--theme-accent)] hover:underline flex items-center gap-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Continue Sourcing</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Cart Items Table (Span 8) */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Free Shipping Alert */}
          <div className="bg-[var(--theme-surface-subtle)] p-4 border border-[var(--theme-border)] flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[var(--theme-accent)]" />
              <span>
                {subtotal >= freeShippingThreshold ? (
                  <strong className="text-emerald-700">Complimentary Site Tailgate Delivery Qualified!</strong>
                ) : (
                  <span>Add <strong>GH₵{(freeShippingThreshold - subtotal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong> more for free freight across Ghana.</span>
                )}
              </span>
            </div>
            <span className="tabular-nums font-semibold text-[var(--theme-accent)]">{Math.round(freeShippingProgress)}%</span>
          </div>

          <div className="divide-y divide-[var(--theme-border)] border border-[var(--theme-border)] bg-[var(--theme-surface)]">
            {cart.map(item => (
              <div key={item.id} className="p-6 flex flex-col sm:flex-row gap-6 items-start sm:items-center justify-between">
                
                {/* Thumb + Title */}
                <div className="flex items-center gap-4">
                  <img
                    src={item.image}
                    alt={item.productName}
                    className="w-20 h-20 object-cover bg-stone-100 border border-[var(--theme-border-subtle)]"
                  />
                  <div>
                    <Link
                      href={`/product/${item.productSlug}`}
                      className="font-serif-luxury text-lg font-semibold hover:text-[var(--theme-accent)] transition-colors"
                    >
                      {item.productName}
                    </Link>
                    <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)] mt-1">
                      <span
                        className="w-3 h-3 rounded-full border border-black/10 shrink-0"
                        style={{ backgroundColor: item.colorHex }}
                      />
                      <span className="font-medium text-[var(--theme-text)]">{item.colorName}</span>
                      <span>·</span>
                      <span className="font-mono text-[11px]">{item.sku}</span>
                    </div>
                    {item.isSample && (
                      <div className="mt-1 flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 text-[10px] uppercase font-bold tracking-wider">
                          4" × 4" Tactile Sample Swatch
                        </span>
                        <span className="text-[11px] text-[var(--theme-success)] font-medium">
                          100% credited toward full box order
                        </span>
                      </div>
                    )}
                    <span className="text-xs text-[var(--theme-text-muted)] mt-1 block">
                      {item.isSample ? (
                        <>Nominal Swatch Fee: GH₵{item.unitPrice.toLocaleString()} per sample piece (4" × 4" / 10×10 cm)</>
                      ) : (
                        <>GH₵{item.unitPrice.toLocaleString()}/{item.unit} (Coverage: {item.boxCoverage} m²/box)</>
                      )}
                    </span>
                  </div>
                </div>

                {/* Quantity and Line Total */}
                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto">
                  <div className="flex items-center border border-[var(--theme-border)] bg-[var(--theme-surface)]">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-1.5 hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)]"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs font-semibold tabular-nums">
                      {item.quantity} {item.unit}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      disabled={item.quantity >= item.maxStock}
                      className="p-1.5 hover:bg-[var(--theme-surface-subtle)] text-[var(--theme-text-muted)] disabled:opacity-30"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="text-right">
                    <span className="text-base font-bold tabular-nums block text-[var(--theme-text)]">
                      GH₵{(item.unitPrice * item.quantity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-[11px] text-red-600 hover:underline mt-1 flex items-center gap-1 ml-auto"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => {
                if (window.confirm('Clear all items from your cart?')) clearCart();
              }}
              className="text-xs text-red-600 hover:underline"
            >
              Clear Entire Cart
            </button>
          </div>
        </div>

        {/* Order Summary (Span 4) */}
        <div className="lg:col-span-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-6 space-y-4">
          <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] border-b border-[var(--theme-border)] pb-3">
            Order Summary
          </h2>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Catalog Subtotal</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                GH₵{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            {bulkDiscount > 0 && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xs space-y-1.5 my-1">
                <div className="flex justify-between font-bold text-xs">
                  <span>🏷️ Bulk Quantity Incentive:</span>
                  <span className="font-mono text-emerald-700">
                    -GH₵{bulkDiscount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                {appliedBulkTiers.map((tier, idx) => (
                  <div key={idx} className="text-[11px] text-emerald-800 flex justify-between">
                    <span>{tier.collectionName} ({tier.qualifyingSqm} m²): {tier.tierLabel}</span>
                    <span className="font-bold">{tier.discountType === 'percentage' ? `${tier.discountValue}% OFF` : `GH₵${tier.discountValue}/m²`}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Site Freight & Tailgate Delivery</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                {shipping === 0 ? (
                  <span className="text-emerald-700 font-bold">Complimentary</span>
                ) : (
                  `GH₵${shipping.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                )}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Ghana VAT / NHIL / GETFund (15%)</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                GH₵{tax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <div className="pt-3 border-t border-[var(--theme-border)] flex justify-between text-sm">
              <span className="font-bold text-[var(--theme-text)]">Estimated Total (GHS)</span>
              <span className="font-bold tabular-nums text-lg text-[var(--theme-accent)]">
                GH₵{total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <button
            onClick={() => navigate('/checkout')}
            className="w-full py-4 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2 mt-4"
          >
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
