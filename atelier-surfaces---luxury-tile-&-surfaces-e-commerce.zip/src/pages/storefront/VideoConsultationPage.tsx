import React, { useState, useEffect } from 'react';
import { useVideoCall } from '../../context/VideoCallContext';
import { useRouter } from '../../router/Router';
import { VideoCallStage } from '../../components/video/VideoCallStage';
import { VideoCallChatPanel } from '../../components/video/VideoCallChatPanel';
import { ShowroomLiveVideoFeed } from '../../components/video/ShowroomLiveVideoFeed';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { 
  Video, 
  MessageSquare, 
  Sparkles, 
  ShieldCheck, 
  PhoneCall, 
  Users, 
  CheckCircle2, 
  Copy, 
  Check, 
  Camera, 
  Mic, 
  ArrowRight,
  Layers,
  Building2,
  Calendar,
  Lock,
  Unlock,
  MapPin,
  Phone,
  Mail,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export function VideoConsultationPage() {
  const { isCallActive, startCall, endCall, activeRoomId, isChatOpen } = useVideoCall();
  const { searchParams } = useRouter();
  const { activeCompany } = useCompany();
  const { currentUser } = useAuth();
  const settings = useStoreSettings(activeCompany.id);

  const isAdminUser = currentUser?.roleId === 'super-admin' || currentUser?.roleId === 'manager';

  const roomParam = searchParams.get('room');
  const [roomIdInput, setRoomIdInput] = useState(roomParam || `atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`);
  const [clientName, setClientName] = useState('Client / Architect');
  const [clientRole, setClientRole] = useState<'client' | 'architect' | 'contractor'>('architect');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isStarting, setIsStarting] = useState(false);

  // Auto-join if room param is in URL and call not active yet
  useEffect(() => {
    if (roomParam && !isCallActive) {
      setRoomIdInput(roomParam);
    }
  }, [roomParam, isCallActive]);

  const handleStartCall = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsStarting(true);
    await startCall(roomIdInput.trim(), clientRole);
    setIsStarting(false);
  };

  const handleCopyLink = () => {
    const callUrl = `${window.location.origin}/video-consultation?room=${roomIdInput}`;
    navigator.clipboard.writeText(callUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // If in active call, render full-screen video stage & chat
  if (isCallActive) {
    return (
      <div className="h-[calc(100vh-80px)] flex flex-col lg:flex-row bg-stone-950 text-white overflow-hidden">
        <VideoCallStage />
        {isChatOpen && <VideoCallChatPanel />}
      </div>
    );
  }

  // Lobby / Booking & Join Interface
  return (
    <div className="bg-[var(--theme-bg)] text-[var(--theme-text)] min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Hero Banner */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--theme-accent)]/15 border border-[var(--theme-accent)]/30 text-xs font-bold uppercase tracking-widest text-[var(--theme-accent)]">
            <Video className="w-3.5 h-3.5" />
            <span>Face-to-Face Showroom Consultation</span>
          </div>

          <h1 className="font-serif-luxury text-3xl sm:text-5xl font-bold tracking-tight text-[var(--theme-text)]">
            Live Video Call & Material Consultation
          </h1>

          <p className="text-sm text-[var(--theme-text-muted)] leading-relaxed">
            Connect directly with an Atelier Senior Surface Consultant via encrypted two-way high-definition video. Review slab vein matching, simulate custom lighting, and inspect 3D specimens face-to-face.
          </p>
        </div>

        {/* Master Lock Banner (if locked by admin) */}
        {settings.videoConsultationLocked && (
          <div className="p-6 bg-red-950/30 border border-red-500/50 rounded-xs space-y-4 text-red-200 animate-in fade-in shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif-luxury font-bold text-lg text-white">
                    Video Consultations Currently Restricted
                  </h3>
                  <span className="text-[11px] text-stone-300">
                    Administrator has locked direct online calls for private sessions or offline showroom hours.
                  </span>
                </div>
              </div>

              <span className="px-3 py-1 bg-red-500/20 text-red-300 border border-red-500/40 text-[10px] font-mono font-bold uppercase rounded-xs self-start sm:self-auto">
                Desk Status: Locked
              </span>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed bg-black/20 p-3.5 border border-red-500/20 rounded-xs">
              {settings.videoLockMessage || 'Video consultations are currently locked for a private architectural masterclass. Please contact the concierge desk below to schedule an appointment.'}
            </p>

            {isAdminUser && (
              <div className="p-3 bg-stone-900/80 border border-stone-700/60 rounded-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-white">
                <span className="text-stone-300">
                  <strong className="text-emerald-400">Admin Mode Active:</strong> You can join any room as host or manage call permissions.
                </span>
                <a
                  href="/admin/video-consultations"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold uppercase tracking-wider text-[10px] rounded-xs flex items-center gap-1 self-start sm:self-auto"
                >
                  <Unlock className="w-3 h-3" />
                  <span>Manage in Admin Console</span>
                </a>
              </div>
            )}
          </div>
        )}

        {/* Official Showroom Coordinates & Concierge Desk Card */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--theme-border)] pb-3">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[var(--theme-accent)]" />
              <h2 className="font-serif-luxury text-sm font-bold text-[var(--theme-text)]">
                Accra Flagship Showroom & Concierge Desk
              </h2>
            </div>
            <span className="text-[10px] font-mono font-bold text-[var(--theme-accent)] uppercase">
              GPS: {settings.ghanaPostGps || 'GA-110-3849'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block">Physical Showroom</span>
              <p className="font-medium text-[var(--theme-text)]">
                {settings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana'}
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block">Direct Concierge</span>
              <div className="font-medium text-[var(--theme-text)] flex items-center gap-1.5 flex-wrap">
                <Phone className="w-3.5 h-3.5 text-[var(--theme-accent)] shrink-0" />
                {(settings.contactPhone || '0542443125/0596334488').includes('/') ? (
                  (settings.contactPhone || '0542443125/0596334488').split('/').map((num, idx, arr) => (
                    <span key={idx} className="inline-flex items-center gap-1">
                      <a href={`tel:${num.trim().replace(/[^0-9+]/g, '')}`} className="hover:underline">
                        {num.trim()}
                      </a>
                      {idx < arr.length - 1 && <span className="text-[var(--theme-border)]">/</span>}
                    </span>
                  ))
                ) : (
                  <a href={`tel:${(settings.contactPhone || '0542443125').replace(/[^0-9+]/g, '')}`} className="hover:underline">
                    {settings.contactPhone || '0542443125/0596334488'}
                  </a>
                )}
              </div>
              {(() => {
                const rawWa = settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488';
                const firstWa = rawWa.split('/')[0].trim();
                let waDigits = firstWa.replace(/[^0-9]/g, '');
                if (waDigits.startsWith('0')) {
                  waDigits = '233' + waDigits.substring(1);
                }
                return (
                  <p className="font-medium text-[var(--theme-text)] flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 flex items-center justify-center font-bold text-[9px] text-emerald-500 font-mono">WA</span>
                    <a
                      href={`https://wa.me/${waDigits || '233542443125'}?text=${encodeURIComponent(settings.whatsAppPrefill || `Hello ${settings.brandName || 'Atelier Surfaces'}, I would like to inquire with the Direct Trade WhatsApp Desk.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline text-emerald-600 dark:text-emerald-400 font-medium"
                    >
                      {rawWa} (WhatsApp Desk)
                    </a>
                  </p>
                );
              })()}
              <p className="font-medium text-[var(--theme-text)] flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                <a href={`mailto:${settings.contactEmail || 'concierge@ateliersurfaces.com'}`} className="hover:underline">
                  {settings.contactEmail || 'concierge@ateliersurfaces.com'}
                </a>
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-[var(--theme-text-muted)] block">Lead Consultant & Hours</span>
              <p className="font-bold text-[var(--theme-text)]">
                {settings.videoConsultantName || 'Kwame Mensah'}
              </p>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                {settings.videoConsultantHours || 'Mon–Sat: 8:00 AM – 6:00 PM GMT'}
              </p>
            </div>
          </div>
        </div>

        {/* Live Showroom Video Feed Preview Billboard */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <h2 className="font-serif-luxury text-sm font-bold text-[var(--theme-text)]">
                Accra Flagship Showroom · Live Video Feed Preview
              </h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 rounded-xs uppercase font-bold">
              Stream Active · 1080p 60FPS
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
            <div className="lg:col-span-2">
              <ShowroomLiveVideoFeed
                consultantName={settings.videoConsultantName || 'Kwame Mensah'}
                consultantTitle={settings.videoConsultantTitle || 'Lead Architectural Consultant'}
                showroomLocation={settings.showroomAddress || '14 Independence Avenue, Ridge West, Accra'}
                className="w-full shadow-lg"
                aspectRatio="aspect-[16/9]"
                showOverlay={true}
              />
            </div>
            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs space-y-1">
                <span className="text-[10px] uppercase font-bold text-[var(--theme-accent)] block">Consultant on Duty</span>
                <span className="font-bold text-[var(--theme-text)] text-sm">{settings.videoConsultantName || 'Kwame Mensah'}</span>
                <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                  Live at Ridge West Showroom with physical Calacatta Statuario, Roman Travertine & Pietra di Vals specimens ready for vein matching.
                </p>
              </div>
              <div className="p-3.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs space-y-1">
                <span className="text-[10px] uppercase font-bold text-[var(--theme-accent)] block">Audio & Video Protocols</span>
                <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                  End-to-end encrypted WebRTC stream with adaptive bitrate and high-fidelity virtual studio camera fallback. Video guaranteed across all browsers.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Lobby Form Card */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-xl p-6 sm:p-10 space-y-8">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-6">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-[var(--theme-accent)]">
                Direct Room Link
              </span>
              <h2 className="font-serif-luxury text-xl font-bold text-[var(--theme-text)] mt-0.5">
                Join or Create a Private Consultation
              </h2>
            </div>
            
            <button
              onClick={handleCopyLink}
              className="px-4 py-2 bg-[var(--theme-surface-subtle)] hover:bg-[var(--theme-surface-elevated)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-[var(--theme-accent)]" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Shareable Invite Link'}</span>
            </button>
          </div>

          <form onSubmit={handleStartCall} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
              <div>
                <label className="block font-bold uppercase text-[var(--theme-text-muted)] mb-1.5">
                  Your Name / Architectural Practice *
                </label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={e => setClientName(e.target.value)}
                  placeholder="e.g. Akosua Mensah (Studio Arch)"
                  className="w-full px-4 py-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-sm text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div>
                <label className="block font-bold uppercase text-[var(--theme-text-muted)] mb-1.5">
                  Consultation Role
                </label>
                <select
                  value={clientRole}
                  onChange={e => setClientRole(e.target.value as any)}
                  className="w-full px-4 py-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-sm text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)] cursor-pointer"
                >
                  <option value="architect">Licensed Architect / Interior Designer</option>
                  <option value="contractor">General Contractor / Quantity Surveyor</option>
                  <option value="client">Private Homeowner / Commercial Developer</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold uppercase text-[var(--theme-text-muted)] mb-1.5">
                  Consultation Room Identifier
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={roomIdInput}
                    onChange={e => setRoomIdInput(e.target.value)}
                    placeholder="e.g. atelier-consult-9812"
                    className="flex-1 px-4 py-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-mono text-sm text-[var(--theme-text)] focus:outline-none focus:border-[var(--theme-accent)]"
                  />
                  <button
                    type="button"
                    onClick={() => setRoomIdInput(`atelier-consult-${Math.floor(1000 + Math.random() * 9000)}`)}
                    className="px-4 py-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold hover:border-[var(--theme-text)] transition cursor-pointer"
                  >
                    Generate New Room
                  </button>
                </div>
              </div>
            </div>

            {/* Camera & Mic Ready Assurance */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] rounded-xs flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold block text-[var(--theme-text)]">
                    Hardware Check: Camera & Microphone Ready
                  </span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">
                    Browser WebRTC protocol enables encrypted real-time face-to-face video and live chat.
                  </span>
                </div>
              </div>
            </div>

            {/* Launch Button */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-4">
              {settings.videoConsultationLocked && !isAdminUser ? (
                <div className="w-full sm:w-auto flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <button
                    type="button"
                    disabled
                    className="w-full sm:w-auto px-8 py-4 bg-red-950/40 text-red-400 border border-red-500/30 font-bold text-xs uppercase tracking-wider cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Video Consultations Locked by Concierge</span>
                  </button>
                  <a
                    href={`tel:${(settings.contactPhone || '0542443125').split('/')[0].trim().replace(/[^0-9+]/g, '')}`}
                    className="text-xs font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Showroom Directly ({settings.contactPhone || '0542443125/0596334488'})</span>
                  </a>
                </div>
              ) : (
                <button
                  type="submit"
                  disabled={isStarting}
                  className="w-full sm:w-auto px-8 py-4 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] font-bold text-xs uppercase tracking-wider hover:opacity-90 transition flex items-center justify-center gap-2 cursor-pointer shadow-xl"
                >
                  <Video className="w-4 h-4" />
                  <span>
                    {isStarting 
                      ? 'Connecting to Room...' 
                      : settings.videoConsultationLocked && isAdminUser
                        ? 'Start Call (Admin Host Override)'
                        : 'Start Face-to-Face Video Call Now'}
                  </span>
                </button>
              )}
            </div>
          </form>

        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2.5">
            <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/15 text-[var(--theme-accent)] flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
              Two-Way HD Video & Mic
            </h3>
            <p className="text-[var(--theme-text-muted)] leading-relaxed">
              Crystal-clear video with adaptive lighting adjustments to inspect natural mineral veining and authentic stone finishes.
            </p>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2.5">
            <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/15 text-[var(--theme-accent)] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
              Interactive 3D Slab Co-Viewing
            </h3>
            <p className="text-[var(--theme-text-muted)] leading-relaxed">
              Present and rotate slabs on screen while speaking face-to-face. Test 2700K warm indoor vs 5500K daylight photometrics together.
            </p>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-2.5">
            <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/15 text-[var(--theme-accent)] flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <h3 className="font-serif-luxury font-bold text-base text-[var(--theme-text)]">
              Real-Time Consultation Chat
            </h3>
            <p className="text-[var(--theme-text-muted)] leading-relaxed">
              Share material specimen cards, technical specification PDFs, delivery schedules, and price estimates directly in the live call chat.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
