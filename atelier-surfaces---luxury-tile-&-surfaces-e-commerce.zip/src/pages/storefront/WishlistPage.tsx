import { useRouter, Link } from '../../router/Router';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { storeService } from '../../services/store';
import { Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

export function WishlistPage() {
  const { navigate } = useRouter();
  const { wishlist, toggleWishlist, addToCart } = useCartWishlist();
  const allProducts = storeService.getProducts();

  // Map wishlist entries to real product + variant objects
  const savedItems = wishlist.map(entry => {
    const product = allProducts.find(p => p.id === entry.productId);
    const variant = product?.variants.find(v => v.id === entry.variantId) || product?.variants[0];
    return { entry, product, variant };
  }).filter(item => item.product && item.variant);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      <div className="border-b border-[var(--theme-border)] pb-6 flex items-center justify-between">
        <div>
          <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
            Saved Specifications
          </span>
          <h1 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
            My Wishlist ({savedItems.length})
          </h1>
        </div>
        <Link
          href="/shop"
          className="text-xs uppercase font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1.5"
        >
          <span>Explore More</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {savedItems.length === 0 ? (
        <div className="text-center py-24 space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-[var(--theme-surface-subtle)] flex items-center justify-center text-[var(--theme-text-muted)]">
            <Heart className="w-8 h-8 opacity-40" />
          </div>
          <h2 className="font-serif-luxury text-2xl font-semibold">No Saved Specimens Yet</h2>
          <p className="text-xs text-[var(--theme-text-muted)] max-w-sm mx-auto">
            Save individual tile variants and slabs to review with your architect, contractor, or interior designer.
          </p>
          <Link
            href="/shop"
            className="inline-block mt-4 px-6 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90"
          >
            Browse Collections
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {savedItems.map(({ entry, product, variant }) => {
            if (!product || !variant) return null;
            return (
              <div
                key={`${product.id}_${variant.id}`}
                className="group flex flex-col bg-[var(--theme-surface)] border border-[var(--theme-border)] p-4 relative"
              >
                <button
                  onClick={() => toggleWishlist(product.id, variant.id)}
                  className="absolute top-6 right-6 z-10 p-1.5 text-rose-600 bg-white/80 rounded-full hover:bg-white transition-colors"
                  title="Remove from wishlist"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <Link
                  href={`/product/${product.slug}?variant=${variant.id}`}
                  className="aspect-[4/3] bg-stone-100 overflow-hidden mb-3 block"
                >
                  <img
                    src={variant.images[0] || product.variants[0]?.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </Link>

                <div className="text-xs text-[var(--theme-text-muted)] mb-1">
                  <span>{product.material}</span> · <span>{product.size}</span>
                </div>

                <Link
                  href={`/product/${product.slug}?variant=${variant.id}`}
                  className="font-serif-luxury text-base font-semibold text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-colors line-clamp-1"
                >
                  {product.name}
                </Link>

                <div className="flex items-center gap-2 text-xs my-2">
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/10 shrink-0"
                    style={{ backgroundColor: variant.colorHex }}
                  />
                  <span className="font-medium text-[var(--theme-text)]">{variant.colorName}</span>
                </div>

                <div className="mt-auto pt-3 border-t border-[var(--theme-border-subtle)] flex items-center justify-between">
                  <span className="font-bold tabular-nums text-sm text-[var(--theme-text)]">
                    GH₵{variant.price.toLocaleString()}/{variant.unit}
                  </span>

                  <button
                    onClick={() => addToCart(product, variant, 1)}
                    className="px-3 py-1.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90"
                  >
                    Add to Bag
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
