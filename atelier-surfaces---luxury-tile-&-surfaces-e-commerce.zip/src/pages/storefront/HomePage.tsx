import { useState } from 'react';
import { useRouter, Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useCompany } from '../../context/CompanyContext';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { Product, ProductVariant } from '../../types';
import { ShowroomLiveVideoFeed } from '../../components/video/ShowroomLiveVideoFeed';
import { 
  ArrowRight, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Truck, 
  Ruler, 
  MessageSquare, 
  Eye, 
  Heart,
  Lightbulb,
  Sun,
  Lamp,
  Video,
  Camera
} from 'lucide-react';

export function HomePage() {
  const { navigate } = useRouter();
  const { addToCart, toggleWishlist, isInWishlist } = useCartWishlist();
  const { activeCompany } = useCompany();
  const products = storeService.getProducts(activeCompany.id);
  const categories = storeService.getCategories(activeCompany.id);
  const settings = useStoreSettings(activeCompany.id);
  const panelBrightness = storeService.getPanelBrightness(activeCompany.id);

  // Featured and Best Sellers
  const bestSellers = products.filter(p => p.bestSeller || p.featured).slice(0, 4);

  // Track active variant per product card on the homepage
  const [selectedVariants, setSelectedVariants] = useState<Record<string, ProductVariant>>(() => {
    const map: Record<string, ProductVariant> = {};
    products.forEach(p => {
      if (p.variants.length > 0) {
        map[p.id] = p.variants[0];
      }
    });
    return map;
  });

  const handleVariantSelect = (productId: string, variant: ProductVariant) => {
    setSelectedVariants(prev => ({
      ...prev,
      [productId]: variant
    }));
  };

  const spaces = [
    { title: 'Master Bathrooms & Spas', filter: 'bathroom', desc: 'Bookmatched feature walls, wet-room floors, and non-slip surfaces.' },
    { title: 'Gourmet Kitchens', filter: 'kitchen', desc: 'Stain-impervious porcelain slabs for islands and countertops.' },
    { title: 'Grand Living Halls', filter: 'living-room', desc: 'Large format 120x240cm high-gloss and honed luxury floors.' },
    { title: 'Outdoor Living & Pools', filter: 'outdoor', desc: '20mm structural pavers with R11 high traction safety rating.' },
    { title: 'Commercial Foyers & Hotels', filter: 'commercial', desc: 'Heavy-traffic rated vitrified tiles built for decades.' }
  ];

  return (
    <div className="space-y-24">
      {/* Editorial Hero Section */}
      <section 
        style={{
          filter: `brightness(${panelBrightness.storefrontHeroBrightness}%) contrast(${panelBrightness.storefrontHeroContrast}%)`
        }}
        className="relative min-h-[85vh] flex items-center justify-center bg-[var(--theme-surface)] overflow-hidden transition-all duration-150"
      >
        {/* Background Image with Measured Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/assets/images/hero_luxury_marble_showroom_1792523066069.jpg"
            alt="Atelier Surfaces Luxury Showroom"
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/35" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-white">
          <div className="max-w-2xl space-y-6">
            <span className="text-xs uppercase tracking-widest text-[var(--theme-accent)] font-semibold flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Architectural Stone & Fine Porcelain</span>
            </span>

            <h1 className="font-serif-luxury text-4xl sm:text-6xl lg:text-7xl font-normal tracking-tight leading-[1.08] text-balance">
              Surfaces That Define Spaces.
            </h1>

            <p className="text-base sm:text-lg text-white/80 font-light leading-relaxed max-w-xl">
              Curated architectural porcelain slabs, Apuan Alpine marble, and Roman travertine engineered for generative residential sanctuaries and landmark commercial edifices.
            </p>

            <div className="pt-4 flex flex-wrap items-center gap-4">
              <Link
                href="/shop"
                className="px-8 py-4 bg-[var(--theme-accent)] text-white text-xs uppercase font-semibold tracking-widest hover:opacity-95 transition-opacity flex items-center gap-2.5 shadow-lg"
              >
                <span>Explore Catalog</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/category/natural-stone"
                className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white backdrop-blur-md text-xs uppercase font-semibold tracking-widest border border-white/30 transition-colors"
              >
                Discover Our Materials
              </Link>
            </div>

            {/* Quick trust metrics */}
            <div className="pt-8 grid grid-cols-3 gap-6 border-t border-white/20 text-xs text-white/90">
              <div>
                <span className="block font-bold text-lg text-white tabular-nums">0.05%</span>
                <span className="text-white/70">Ultra-low Porosity</span>
              </div>
              <div>
                <span className="block font-bold text-lg text-white tabular-nums">64+</span>
                <span className="text-white/70">Architectural Finishes</span>
              </div>
              <div>
                <span className="block font-bold text-lg text-white tabular-nums">25 Yrs</span>
                <span className="text-white/70">Warranty Standards</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Collections / Categories */}
      <section 
        style={{
          filter: `brightness(${panelBrightness.storefrontCatalogBrightness}%) contrast(${panelBrightness.storefrontCatalogContrast}%)`
        }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-150"
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4 pb-4 border-b border-[var(--theme-border)]">
          <div>
            <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
              Material Taxonomies
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
              Curated Surfaces by Application
            </h2>
          </div>
          <Link
            href="/shop"
            className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)] hover:underline flex items-center gap-1.5"
          >
            <span>View All Collections</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.slice(0, 4).map(cat => (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className="group block relative overflow-hidden bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-all"
            >
              <div className="aspect-[4/3] overflow-hidden bg-stone-100 relative">
                <img
                  src={cat.imageUrl}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <h3 className="font-serif-luxury text-xl font-semibold">{cat.name}</h3>
                </div>
              </div>
              <div className="p-4 bg-[var(--theme-surface)]">
                <p className="text-xs text-[var(--theme-text-muted)] line-clamp-2">
                  {cat.description}
                </p>
                <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-[var(--theme-accent)] group-hover:translate-x-1 transition-transform">
                  <span>Explore category</span>
                  <ArrowRight className="w-3 h-3" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Best Sellers Showcase with Live Color Swatches */}
      <section 
        style={{
          filter: `brightness(${panelBrightness.storefrontCatalogBrightness}%) contrast(${panelBrightness.storefrontCatalogContrast}%)`
        }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-150"
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4 pb-4 border-b border-[var(--theme-border)]">
          <div>
            <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
              Signature Editions
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
              Best Sellers & Architectural Favorites
            </h2>
          </div>
          <p className="text-xs text-[var(--theme-text-muted)] max-w-md">
            Each specimen features multiple independent color variants with dedicated photography, custom slip coefficients, and box-calibrated yardages.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {bestSellers.map(product => {
            const activeVariant = selectedVariants[product.id] || product.variants[0];
            const activeImage = activeVariant.images[0] || product.variants[0]?.images[0];
            const inWishlist = isInWishlist(product.id, activeVariant.id);

            return (
              <div
                key={product.id}
                className="group flex flex-col bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-all p-4 relative"
              >
                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id, activeVariant.id)}
                  className={`absolute top-6 right-6 z-10 p-2 rounded-full backdrop-blur-md transition-colors ${
                    inWishlist 
                      ? 'bg-rose-50 text-rose-600' 
                      : 'bg-white/80 text-stone-700 hover:text-stone-900'
                  }`}
                  aria-label="Toggle wishlist"
                >
                  <Heart className={`w-4 h-4 ${inWishlist ? 'fill-current text-rose-600' : ''}`} />
                </button>

                {/* Primary Image */}
                <Link
                  href={`/product/${product.slug}?variant=${activeVariant.id}`}
                  className="block aspect-[4/3] overflow-hidden bg-stone-100 relative mb-4"
                >
                  <img
                    src={activeImage}
                    alt={`${product.name} - ${activeVariant.colorName}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                  />
                  {activeVariant.stock <= activeVariant.lowStockThreshold && (
                    <span className="absolute bottom-2 left-2 bg-amber-500/90 text-white text-[10px] font-bold px-2 py-0.5 uppercase tracking-wider backdrop-blur-xs">
                      Low Stock: {activeVariant.stock} left
                    </span>
                  )}
                </Link>

                {/* Clean Metadata (Zero-Pill format) */}
                <div className="flex items-center gap-2 text-xs text-[var(--theme-text-muted)] mb-1">
                  <span>{product.material}</span>
                  <span>·</span>
                  <span>{product.size}</span>
                  <span>·</span>
                  <span className="text-[var(--theme-text)] font-medium">{activeVariant.colorName}</span>
                </div>

                <Link
                  href={`/product/${product.slug}?variant=${activeVariant.id}`}
                  className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)] hover:text-[var(--theme-accent)] transition-colors line-clamp-1 mb-2"
                >
                  {product.name}
                </Link>

                {/* Color Variations Swatches */}
                <div className="flex items-center gap-2 my-2">
                  {product.variants.map(v => (
                    <button
                      key={v.id}
                      onClick={() => handleVariantSelect(product.id, v)}
                      title={`${v.colorName} (${v.sku})`}
                      className={`w-5 h-5 rounded-full border-2 transition-transform cursor-pointer ${
                        activeVariant.id === v.id
                          ? 'border-[var(--theme-accent)] scale-110 shadow-sm'
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{ backgroundColor: v.colorHex }}
                    />
                  ))}
                  <span className="text-[11px] text-[var(--theme-text-muted)] ml-1">
                    {product.variants.length} colors
                  </span>
                </div>

                {/* Pricing & Actions */}
                <div className="mt-auto pt-3 border-t border-[var(--theme-border-subtle)] flex items-center justify-between">
                  <div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-base font-bold tabular-nums text-[var(--theme-text)]">
                        GH₵{activeVariant.price.toLocaleString()}
                      </span>
                      {activeVariant.compareAtPrice && (
                        <span className="text-xs text-[var(--theme-text-muted)] line-through tabular-nums">
                          GH₵{activeVariant.compareAtPrice.toLocaleString()}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[var(--theme-text-muted)] block">
                      per {activeVariant.unit} (Coverage: {activeVariant.boxCoverage} m²/box)
                    </span>
                  </div>

                  <button
                    onClick={() => addToCart(product, activeVariant, 1)}
                    className="p-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] hover:opacity-90 transition-opacity text-xs font-semibold flex items-center gap-1"
                    title="Quick Add 1 Unit"
                  >
                    <span>Add</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Shop By Space */}
      <section className="bg-[var(--theme-surface-subtle)] py-16 border-y border-[var(--theme-border)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
              Spatial Architecture
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
              Surfaces Engineered for Every Space
            </h2>
            <p className="text-xs text-[var(--theme-text-muted)] mt-2">
              Browse surfaces certified for wet areas, extreme heat, frost tolerance, and high-frequency footfall.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {spaces.map((s, idx) => (
              <Link
                key={idx}
                href={`/shop?space=${s.filter}`}
                className="group p-6 bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] hover:-translate-y-1 transition-all"
              >
                <div className="text-xs font-bold uppercase tracking-wider text-[var(--theme-accent)] mb-2">
                  0{idx + 1}. Room Type
                </div>
                <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)] group-hover:text-[var(--theme-accent)] transition-colors mb-2">
                  {s.title}
                </h3>
                <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
                  {s.desc}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Craftsmanship & Quarry Story */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
              Provenance & Authenticity
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl font-semibold text-[var(--theme-text)] leading-tight">
              Quarried in Italy. Tailored for Ghana & West Africa.
            </h2>
            <p className="text-sm text-[var(--theme-text-muted)] leading-relaxed">
              Every slab in the Atelier collection is inspected at origin in Sassuolo and Tivoli before transatlantic containerized transport to our central climate-controlled warehouse in Accra.
            </p>
            <p className="text-sm text-[var(--theme-text-muted)] leading-relaxed">
              We provide architects, developers, and homeowners with full technical dossiers: slip resistance ratings, frost tolerance certifications, and exact batch tone matching.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[var(--theme-accent)] mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-[var(--theme-text)] block">Full Box Inspection</span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">Zero chipping guarantee before delivery</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[var(--theme-accent)] mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-[var(--theme-text)] block">Hydraulic Freight</span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">Tailgate delivery across all 16 regions</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[var(--theme-accent)] mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-[var(--theme-text)] block">Free Specimen Box</span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">Available for licensed architects</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Check className="w-4 h-4 text-[var(--theme-accent)] mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs font-bold text-[var(--theme-text)] block">Paystack & MoMo Ready</span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">Secure instant Ghanaian payment</span>
                </div>
              </div>
            </div>

            <div className="pt-4">
              <Link
                href="/about"
                className="inline-flex items-center gap-2 text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)] hover:underline"
              >
                <span>Read The Atelier Chronicle</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="relative">
            <img
              src="/assets/images/category_stone_bathroom_1792523067646.jpg"
              alt="Atelier Stone Craftsmanship"
              className="w-full h-auto object-cover border border-[var(--theme-border)] shadow-xl"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=1600&q=80';
              }}
            />
            <div className="absolute -bottom-6 -right-6 p-6 bg-[var(--theme-surface)] border border-[var(--theme-border)] shadow-lg max-w-xs hidden sm:block">
              <div className="flex items-center gap-2 text-[var(--theme-accent)] mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Certified ISO 10545</span>
              </div>
              <p className="text-xs text-[var(--theme-text-muted)]">
                Vitrified porcelain with thermal shock and acid resistance certification.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Architectural Lighting & Texture Response Feature Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-8 sm:p-12 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold text-[var(--theme-accent)] uppercase tracking-wider">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Proprietary Photometric Visualizer</span>
              </div>
              <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] leading-tight">
                Evaluate Tile Sheen & Micro-Textures Under Real Lighting
              </h2>
              <p className="text-xs sm:text-sm text-[var(--theme-text-muted)] leading-relaxed">
                Will your marble look authentic in morning sunlight or warm incandescent downlights? Our interactive photometric tool on every product page simulates <strong>Natural Daylight (5500K)</strong>, <strong>Warm Indoor (2700K)</strong>, and <strong>Cool Studio (6500K)</strong> environments. Drag the spotlight angle to inspect specular gloss and raking relief shadows.
              </p>
              
              <div className="grid grid-cols-3 gap-3 pt-2 text-xs">
                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                  <Sun className="w-4 h-4 text-amber-500 mb-1" />
                  <strong className="block text-[11px] text-[var(--theme-text)]">Natural Daylight</strong>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">5500K True Pigment</span>
                </div>
                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                  <Lamp className="w-4 h-4 text-amber-600 mb-1" />
                  <strong className="block text-[11px] text-[var(--theme-text)]">Warm Indoor</strong>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">2700K Amber Glow</span>
                </div>
                <div className="p-3 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                  <Sparkles className="w-4 h-4 text-blue-500 mb-1" />
                  <strong className="block text-[11px] text-[var(--theme-text)]">Cool Studio</strong>
                  <span className="text-[10px] text-[var(--theme-text-muted)]">6500K Gallery Relief</span>
                </div>
              </div>

              <div className="pt-2">
                <Link
                  href="/product/calacatta-statuario-imperiale"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-[var(--theme-accent)] text-white text-xs uppercase font-bold tracking-widest hover:opacity-90 transition-opacity shadow-md"
                >
                  <span>Launch Live Lighting Simulator</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5 relative">
              <div className="aspect-[4/3] bg-stone-900 border border-[var(--theme-border)] overflow-hidden relative shadow-2xl group">
                <img
                  src="/assets/images/hero_luxury_marble_showroom_1792523066069.jpg"
                  alt="Lighting Simulation Preview"
                  className="w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80';
                  }}
                  style={{
                    filter: 'contrast(1.08) brightness(1.02)'
                  }}
                />
                <div 
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: 'radial-gradient(circle at 60% 35%, rgba(255, 220, 160, 0.45) 0%, transparent 60%)'
                  }}
                />
                <div className="absolute top-3 left-3 bg-black/80 text-white text-[10px] font-bold px-2.5 py-1 tracking-wider uppercase backdrop-blur-xs">
                  Simulated: Warm Indoor (2700K)
                </div>
                <div className="absolute bottom-3 right-3 bg-black/80 text-white text-[10px] font-bold px-2.5 py-1 tracking-wider uppercase backdrop-blur-xs flex items-center gap-1.5">
                  <Lightbulb className="w-3 h-3 text-amber-300 animate-pulse" />
                  <span>Interactive 3D Light</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Face-to-Face Online Video Call & Live Chat Consultation */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-stone-950 text-white border border-stone-800 p-8 sm:p-12 relative overflow-hidden">
          {/* Subtle marble vein background */}
          <div 
            className="absolute inset-0 opacity-15 pointer-events-none bg-cover bg-center"
            style={{ backgroundImage: `url('/assets/images/hero_luxury_marble_showroom_1792523066069.jpg')` }}
          />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <Video className="w-3.5 h-3.5" />
                <span>Face-to-Face Online Video Call & Chat</span>
              </div>

              <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold leading-tight text-white">
                Live Video Consultation with Senior Surface Consultants
              </h2>

              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                Experience the showroom from anywhere in the world. Connect via encrypted two-way HD video to review slab vein matching, inspect tactile specimens in real-time, test 2700K vs 5500K lighting, and receive technical quantity surveying estimates in live chat.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                <div className="p-3 bg-stone-900/80 border border-stone-800 rounded-xs">
                  <Camera className="w-4 h-4 text-emerald-400 mb-1.5" />
                  <strong className="block text-white font-serif-luxury">Face-to-Face HD Video</strong>
                  <span className="text-[10px] text-stone-400">Two-way camera & audio with showroom consultants</span>
                </div>
                <div className="p-3 bg-stone-900/80 border border-stone-800 rounded-xs">
                  <Sparkles className="w-4 h-4 text-[var(--theme-accent)] mb-1.5" />
                  <strong className="block text-white font-serif-luxury">Co-View 3D Slabs</strong>
                  <span className="text-[10px] text-stone-400">Interactive 3D model rotation during live call</span>
                </div>
                <div className="p-3 bg-stone-900/80 border border-stone-800 rounded-xs">
                  <MessageSquare className="w-4 h-4 text-blue-400 mb-1.5" />
                  <strong className="block text-white font-serif-luxury">Live Specimen Chat</strong>
                  <span className="text-[10px] text-stone-400">Share material cards, pricing & technical PDFs</span>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap items-center gap-4">
                <Link
                  href="/video-consultation"
                  className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs uppercase font-bold tracking-widest flex items-center gap-2 transition-colors shadow-lg"
                >
                  <Video className="w-4 h-4" />
                  <span>Start Face-to-Face Video Call</span>
                </Link>

                <span className="text-xs text-stone-400 font-mono">
                  ● Consultants Online in Accra & Carrara
                </span>
              </div>
            </div>

            <div className="lg:col-span-5 relative">
              <ShowroomLiveVideoFeed
                consultantName={settings.videoConsultantName || 'Kwame Mensah'}
                consultantTitle={settings.videoConsultantTitle || 'Lead Surface Consultant'}
                showroomLocation={settings.showroomAddress || 'Ridge West Showroom, Accra'}
                className="w-full shadow-2xl"
                aspectRatio="aspect-[4/3]"
                onJoinClick={() => navigate('/video-consultation')}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Trade Concierge Banner (Inspired by WhatsApp Extension integration from attachment) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] p-8 sm:p-12 border border-[var(--theme-border)] flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl">
            <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)]">
              Direct Trade Desk
            </span>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-semibold">
              Need Instant Stock Allocation or Contractor Pricing?
            </h3>
            <p className="text-xs text-white/80 leading-relaxed">
              Connect with our {settings.showroomAddress || 'Ridge West Showroom'} team for immediate inventory reservation, WhatsApp order verification, and area calculation support.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            {(() => {
              const rawWa = settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488';
              const firstWa = rawWa.split('/')[0].trim();
              let waDigits = firstWa.replace(/[^0-9]/g, '');
              if (waDigits.startsWith('0')) {
                waDigits = '233' + waDigits.substring(1);
              }
              return (
                <a
                  href={`https://wa.me/${waDigits || '233542443125'}?text=${encodeURIComponent(settings.whatsAppPrefill || `Hello ${settings.brandName || 'Atelier Surfaces'}, I would like to inquire with the Direct Trade Desk regarding tile & slab stock.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3.5 bg-emerald-600 text-white text-xs font-bold uppercase tracking-wider hover:bg-emerald-700 flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp Trade Desk ({rawWa})</span>
                </a>
              );
            })()}
            <Link
              href="/contact"
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold uppercase tracking-wider border border-white/20 text-center transition-colors"
            >
              Book Private Consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
