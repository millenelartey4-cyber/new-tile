import { useState } from 'react';
import { useRouter, Link } from '../../router/Router';
import { useAuth } from '../../context/AuthContext';
import { storeService } from '../../services/store';
import { Order, OrderStatus } from '../../types';
import { 
  Package, 
  Clock, 
  MapPin, 
  User, 
  Printer, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Truck
} from 'lucide-react';

interface CustomerAccountPageProps {
  orderIdParam?: string;
}

export function CustomerAccountPage({ orderIdParam }: CustomerAccountPageProps) {
  const { navigate } = useRouter();
  const { currentUser, logout, availableUsers, switchUser } = useAuth();
  const orders = storeService.getOrders();

  // If specific order is requested
  const selectedOrder = orderIdParam ? orders.find(o => o.id === orderIdParam || o.orderNumber === orderIdParam) : null;

  // Filter orders belonging to this user or show all recent for testing
  const customerOrders = orders.filter(o => 
    o.customerId === currentUser?.uid || 
    o.customerSnapshot.email.toLowerCase() === currentUser?.email.toLowerCase() ||
    currentUser?.roleId === 'super-admin' // Super admin can see all
  );

  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'addresses'>('orders');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Account Hero Banner */}
      <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] flex items-center justify-center text-[var(--theme-accent)]">
            <User className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif-luxury text-2xl sm:text-3xl font-semibold text-[var(--theme-text)]">
                {currentUser?.name || 'Architectural Client'}
              </h1>
              <span className="text-xs uppercase font-bold px-2 py-0.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-[var(--theme-accent)]">
                {currentUser?.roleName || 'Customer'}
              </span>
            </div>
            <p className="text-xs text-[var(--theme-text-muted)] mt-1">
              {currentUser?.email} · Member since {currentUser?.createdAt ? new Date(currentUser.createdAt).getFullYear() : '2026'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {currentUser?.roleId !== 'customer' && (
            <Link
              href="/admin"
              className="px-4 py-2 bg-[var(--theme-accent)] text-white text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity flex items-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Open Admin Console</span>
            </Link>
          )}
          <button
            onClick={() => {
              logout();
              navigate('/login');
            }}
            className="px-4 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[var(--theme-border)] gap-8 text-xs uppercase font-bold tracking-wider">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 border-b-2 transition-colors ${
            activeTab === 'orders' 
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          My Orders & Shipments ({customerOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('addresses')}
          className={`pb-3 border-b-2 transition-colors ${
            activeTab === 'addresses' 
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          Saved Site Addresses
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 border-b-2 transition-colors ${
            activeTab === 'profile' 
              ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
              : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
          }`}
        >
          Trade Verification & Profile
        </button>
      </div>

      {/* Tab 1: Orders */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          {selectedOrder && (
            <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-6 space-y-4 mb-6">
              <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-3">
                <span className="font-mono text-sm font-bold text-[var(--theme-text)]">
                  Focused Order #{selectedOrder.orderNumber}
                </span>
                <Link href="/account" className="text-xs text-[var(--theme-accent)] hover:underline">
                  View All Orders
                </Link>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-[var(--theme-text-muted)] block">Payment Status</span>
                  <strong className="capitalize text-emerald-700">{selectedOrder.paymentStatus}</strong>
                </div>
                <div>
                  <span className="text-[var(--theme-text-muted)] block">Delivery Status</span>
                  <strong className="capitalize">{selectedOrder.orderStatus}</strong>
                </div>
                <div>
                  <span className="text-[var(--theme-text-muted)] block">Site Destination</span>
                  <strong>{selectedOrder.shippingAddress.city} ({selectedOrder.shippingAddress.ghanaPostGps || 'Accra'})</strong>
                </div>
                <div>
                  <span className="text-[var(--theme-text-muted)] block">Total Settlement</span>
                  <strong className="tabular-nums">GH₵{selectedOrder.total.toLocaleString()}</strong>
                </div>
              </div>
            </div>
          )}

          {customerOrders.length === 0 ? (
            <div className="text-center py-20 border border-[var(--theme-border)] bg-[var(--theme-surface)] space-y-3">
              <Package className="w-12 h-12 text-[var(--theme-text-muted)] mx-auto opacity-40" />
              <h3 className="font-serif-luxury text-xl font-semibold">No Order History Found</h3>
              <p className="text-xs text-[var(--theme-text-muted)]">
                You have not placed any architectural orders yet.
              </p>
              <Link
                href="/shop"
                className="inline-block mt-2 px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider"
              >
                Browse Catalog
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {customerOrders.map(order => (
                <div
                  key={order.id}
                  className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4 hover:border-[var(--theme-accent)] transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--theme-border-subtle)] pb-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-base font-bold text-[var(--theme-text)]">
                          {order.orderNumber}
                        </span>
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 ${
                          order.orderStatus === 'delivered' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : order.orderStatus === 'shipped' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {order.orderStatus}
                        </span>
                        <span className="text-[10px] uppercase font-semibold text-[var(--theme-text-muted)]">
                          Payment: {order.paymentStatus}
                        </span>
                      </div>
                      <span className="text-xs text-[var(--theme-text-muted)] mt-1 block">
                        Placed on {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <Link
                        href={`/order-confirmation/${order.id}`}
                        className="px-3 py-1.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold hover:border-[var(--theme-accent)] flex items-center gap-1.5 transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Receipt</span>
                      </Link>
                    </div>
                  </div>

                  {/* Purchased items line */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="space-y-2">
                      <span className="font-bold uppercase tracking-wider text-[var(--theme-text-muted)] block text-[10px]">
                        Allocated Surfaces ({order.itemsSnapshot.length})
                      </span>
                      {order.itemsSnapshot.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                          <img src={item.image} alt={item.productName} className="w-10 h-10 object-cover border border-[var(--theme-border-subtle)]" />
                          <div>
                            <span className="font-medium text-[var(--theme-text)] block line-clamp-1">{item.productName}</span>
                            <span className="text-[11px] text-[var(--theme-text-muted)]">
                              {item.colorName} · {item.quantity} {item.unit}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-1 sm:border-l sm:border-[var(--theme-border-subtle)] sm:pl-6 text-[11px]">
                      <span className="font-bold uppercase tracking-wider text-[var(--theme-text-muted)] block text-[10px]">
                        Site Delivery & GPS
                      </span>
                      <p className="font-medium text-[var(--theme-text)]">{order.shippingAddress.addressLine1}</p>
                      <p className="text-[var(--theme-text-muted)]">{order.shippingAddress.city}, {order.shippingAddress.region}</p>
                      {order.shippingAddress.ghanaPostGps && (
                        <p className="font-mono text-[var(--theme-accent)]">GPS: {order.shippingAddress.ghanaPostGps}</p>
                      )}
                      <div className="pt-2 text-xs font-bold text-[var(--theme-text)]">
                        Total Settlement: <span className="tabular-nums text-sm text-[var(--theme-accent)]">GH₵{order.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Saved Addresses */}
      {activeTab === 'addresses' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[var(--theme-border)]">
              <span className="font-bold uppercase tracking-wider text-[var(--theme-text)]">Primary Architectural Studio</span>
              <span className="text-[10px] text-[var(--theme-accent)] font-semibold">Default</span>
            </div>
            <p className="font-semibold text-sm">{currentUser?.name}</p>
            <p className="text-[var(--theme-text-muted)]">Plot 48, Airport Residential Area</p>
            <p className="text-[var(--theme-text-muted)]">Accra, Greater Accra Region</p>
            <p className="font-mono text-[var(--theme-accent)] font-bold">GhanaPost GPS: GA-082-4190</p>
            <p className="text-[var(--theme-text-muted)]">Contact: {currentUser?.phone || '0542443125/0596334488'}</p>
          </div>

          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[var(--theme-border)]">
              <span className="font-bold uppercase tracking-wider text-[var(--theme-text)]">Active Project Site (Villa 12)</span>
              <span className="text-[10px] text-stone-500 font-semibold">Site #2</span>
            </div>
            <p className="font-semibold text-sm">Site Engineer Office</p>
            <p className="text-[var(--theme-text-muted)]">Trassaco Valley Phase 2, East Legon</p>
            <p className="text-[var(--theme-text-muted)]">Accra, Greater Accra Region</p>
            <p className="font-mono text-[var(--theme-accent)] font-bold">GhanaPost GPS: GD-204-9831</p>
            <p className="text-[var(--theme-text-muted)]">Hydraulic clearance verified for 10-wheel trucks.</p>
          </div>
        </div>
      )}

      {/* Tab 3: Trade Profile */}
      {activeTab === 'profile' && (
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 sm:p-8 space-y-6 max-w-2xl text-xs">
          <div className="space-y-1">
            <h3 className="font-serif-luxury text-xl font-semibold">Architectural Trade Credentials</h3>
            <p className="text-[var(--theme-text-muted)]">
              Registered trade buyers receive priority warehouse pallet reservation, specimen box allowances, and credit terms.
            </p>
          </div>

          <div className="space-y-4 pt-2">
            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Full Legal Name</label>
              <input
                type="text"
                readOnly
                value={currentUser?.name || ''}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-semibold"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Email</label>
              <input
                type="text"
                readOnly
                value={currentUser?.email || ''}
                className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs text-[var(--theme-text)] font-semibold"
              />
            </div>

            <div>
              <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Architectural Council / GIA Registration</label>
              <input
                type="text"
                readOnly
                value="GIA-ARC-2024-8492 (Verified)"
                className="w-full px-3 py-2 bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-semibold"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
