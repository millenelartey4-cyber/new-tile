import { useState } from 'react';
import { Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { useCompany } from '../../context/CompanyContext';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { MapPin, Phone, Mail, Clock, ShieldCheck, CheckCircle2, Lock, Video, ArrowRight } from 'lucide-react';

export function AboutPage() {
  const { activeCompany } = useCompany();
  const settings = useStoreSettings(activeCompany.id);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="border-b border-[var(--theme-border)] pb-6">
        <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
          The Atelier Chronicle
        </span>
        <h1 className="font-serif-luxury text-4xl sm:text-5xl font-semibold text-[var(--theme-text)] mt-1">
          Surfaces That Endure
        </h1>
      </div>

      <div className="aspect-[16/9] overflow-hidden bg-stone-100 border border-[var(--theme-border)]">
        <img
          src="/assets/images/hero_luxury_marble_showroom_1792523066069.jpg"
          alt="Atelier Marble Quarrying"
          className="w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80';
          }}
        />
      </div>

      <div className="prose prose-stone max-w-none space-y-6 text-sm text-[var(--theme-text-muted)] leading-relaxed">
        <p className="text-base text-[var(--theme-text)] font-medium leading-relaxed">
          Founded on the conviction that architectural surfaces are the physical bedrock of how spaces feel and endure, Atelier Surfaces operates at the intersection of historic European stone extraction and precision vitrified engineering.
        </p>

        <h2 className="font-serif-luxury text-2xl font-semibold text-[var(--theme-text)] pt-4">
          Quarry Relationships in Italy and Spain
        </h2>
        <p>
          We source directly from multi-generational quarries in Carrara, Sassuolo, Tivoli, and Castellón. By bypassing intermediary brokers, we provide architects and property developers in Ghana with batch-matched specimens, continuous bookmatched vein sequencing, and guaranteed flatness tolerances under EN 14411.
        </p>

        <h2 className="font-serif-luxury text-2xl font-semibold text-[var(--theme-text)] pt-4">
          Showroom & Central Logistics Center
        </h2>
        <p>
          Located at {settings.showroomAddress || '14 Independence Avenue in Ridge West, Accra'}{settings.ghanaPostGps ? ` (GPS: ${settings.ghanaPostGps})` : ''}, our climate-controlled warehouse maintains live stock of thousands of square metres of large-format slabs, reducing project lead times from months to 24–48 hours.
        </p>
      </div>
    </div>
  );
}

export function ContactPage() {
  const { activeCompany } = useCompany();
  const settings = useStoreSettings(activeCompany.id);
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 6000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="border-b border-[var(--theme-border)] pb-6">
        <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
          Showroom & Concierge
        </span>
        <h1 className="font-serif-luxury text-4xl sm:text-5xl font-semibold text-[var(--theme-text)] mt-1">
          Private Consultations & Inquiries
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-6 text-xs text-[var(--theme-text)]">
          <div className="space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-bold uppercase tracking-wider text-[var(--theme-text)]">
                {settings.brandName || activeCompany.name || 'ATELIER SURFACES'} Flagship Showroom
              </h3>
              <div className="flex items-center gap-2">
                {settings.contactLocked && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-xs border border-amber-500/30">
                    <Lock className="w-3 h-3" />
                    <span>Verified Registry</span>
                  </span>
                )}
                <Link
                  href="/admin/settings#showroom-contact"
                  className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-[var(--theme-accent)] hover:underline border border-[var(--theme-border)] px-2 py-0.5 bg-[var(--theme-surface-subtle)]"
                  title="Admin: Edit showroom contact credentials in Settings"
                >
                  <span>Edit in Settings</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </Link>
              </div>
            </div>
            <div className="flex items-start gap-2.5 text-[var(--theme-text-muted)]">
              <MapPin className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
              <span>
                {settings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana'} {settings.ghanaPostGps ? `(GPS: ${settings.ghanaPostGps})` : '(GPS: GA-110-3849)'}
              </span>
            </div>
            <div className="flex items-center gap-2.5 text-[var(--theme-text-muted)]">
              <Phone className="w-4 h-4 text-[var(--theme-accent)] shrink-0" />
              <div className="flex items-center gap-1.5 flex-wrap font-semibold text-[var(--theme-text)]">
                {(settings.contactPhone || '0542443125/0596334488').includes('/') ? (
                  (settings.contactPhone || '0542443125/0596334488').split('/').map((num, idx, arr) => (
                    <span key={idx} className="inline-flex items-center gap-1">
                      <a href={`tel:${num.trim().replace(/[^0-9+]/g, '')}`} className="hover:underline">
                        {num.trim()}
                      </a>
                      {idx < arr.length - 1 && <span className="text-[var(--theme-border)]">/</span>}
                    </span>
                  ))
                ) : (
                  <a href={`tel:${(settings.contactPhone || '0542443125').replace(/[^0-9+]/g, '')}`} className="hover:underline">
                    {settings.contactPhone || '0542443125/0596334488'}
                  </a>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2.5 text-[var(--theme-text-muted)]">
              <Mail className="w-4 h-4 text-[var(--theme-accent)] shrink-0" />
              <a href={`mailto:${settings.contactEmail || 'concierge@ateliersurfaces.com'}`} className="hover:underline font-semibold text-[var(--theme-text)]">
                {settings.contactEmail || 'concierge@ateliersurfaces.com'}
              </a>
            </div>
          </div>

          {/* Face-to-Face Online Video Call Quick Card */}
          <div className={`p-4 border rounded-xs space-y-2 ${
            settings.videoConsultationLocked
              ? 'bg-red-950/15 border-red-500/30'
              : 'bg-emerald-950/10 border-emerald-500/30'
          }`}>
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)] flex items-center gap-1.5">
                <Video className={`w-3.5 h-3.5 ${settings.videoConsultationLocked ? 'text-red-500' : 'text-emerald-500'}`} />
                <span>Face-to-Face Video Online Consultation</span>
              </span>
              <span className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded-xs ${
                settings.videoConsultationLocked
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {settings.videoConsultationLocked ? 'Calls Locked' : 'Online & Active'}
              </span>
            </div>
            <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
              {settings.videoConsultationLocked
                ? settings.videoLockMessage || 'Video consultations are currently locked for private architectural sessions. Please call our concierge desk.'
                : `Connect with lead consultant ${settings.videoConsultantName || 'Kwame Mensah'} face-to-face over two-way HD video with 3D slab co-viewing.`}
            </p>
            <Link
              href="/video-consultation"
              className="text-xs font-semibold text-[var(--theme-accent)] hover:underline inline-flex items-center gap-1 pt-1"
            >
              <span>{settings.videoConsultationLocked ? 'View Video Desk Status' : 'Launch Video Call & Chat'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="space-y-2 pt-4 border-t border-[var(--theme-border)]">
            <h3 className="font-bold uppercase tracking-wider text-[var(--theme-text)]">Showroom Hours</h3>
            <p className="text-[var(--theme-text-muted)]">Monday – Friday: 8:00 AM – 6:00 PM GMT</p>
            <p className="text-[var(--theme-text-muted)]">Saturday: 9:00 AM – 4:00 PM GMT</p>
            <p className="text-[var(--theme-text-muted)]">Sunday: By Private Architectural Appointment</p>
          </div>

          <div id="direct-trade-whatsapp" className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="font-bold block text-[var(--theme-text)]">Direct Trade WhatsApp Desk</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 rounded-xs uppercase font-bold">
                  {settings.whatsAppLocked ? 'Verified & Locked' : 'Online & Active'}
                </span>
                <Link
                  href="/admin/settings#direct-trade-whatsapp"
                  className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 hover:underline border border-[var(--theme-border)] px-1.5 py-0.5 bg-[var(--theme-surface)]"
                  title="Admin: Edit Direct Trade WhatsApp Desk in Settings"
                >
                  <span>Edit in Settings</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </Link>
              </div>
            </div>
            <p className="text-[var(--theme-text-muted)] text-[11px] leading-relaxed">
              Architects, contractors, and developers can chat directly with our Accra showroom team for instant stock holds, trade pricing, and expedited sample drop-offs.
            </p>
            {(() => {
              const rawWa = settings.whatsAppNumber || settings.contactPhone || '0542443125/0596334488';
              const firstWa = rawWa.split('/')[0].trim();
              let waDigits = firstWa.replace(/[^0-9]/g, '');
              if (waDigits.startsWith('0')) {
                waDigits = '233' + waDigits.substring(1);
              }
              return (
                <a
                  href={`https://wa.me/${waDigits || '233542443125'}?text=${encodeURIComponent(settings.whatsAppPrefill || `Hello ${settings.brandName || 'Atelier Surfaces'}, I would like to inquire with the Direct Trade WhatsApp Desk regarding marble & porcelain stock.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-500 hover:text-emerald-400 font-semibold text-xs flex items-center gap-1.5 pt-1 transition-colors"
                >
                  <span>{rawWa} (WhatsApp Desk)</span>
                  <ArrowRight className="w-3 h-3" />
                </a>
              );
            })()}
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h3 className="font-serif-luxury text-xl font-semibold">Book Showroom Walkthrough</h3>
          {submitted ? (
            <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Your appointment request has been scheduled. Our concierge will call you within 2 hours.</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Kofi Owusu"
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Email *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="kofi@studio.com"
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">Project Details / Estimated Area (m²)</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Master suite floor and bathroom walls (~85 m²). Looking for Calacatta Gold or Travertine."
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity"
              >
                Send Request
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export function ShippingReturnsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-8 text-xs text-[var(--theme-text-muted)] leading-relaxed">
      <div className="border-b border-[var(--theme-border)] pb-6">
        <span className="text-xs uppercase font-semibold tracking-widest text-[var(--theme-accent)]">
          Logistics Policy
        </span>
        <h1 className="font-serif-luxury text-4xl font-semibold text-[var(--theme-text)] mt-1">
          Freight & Breakage Guarantee
        </h1>
      </div>

      <div className="space-y-4">
        <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
          1. Nationwide Site Tailgate Delivery
        </h2>
        <p>
          Tiles and stone slabs are heavy materials. We transport all goods on custom fumigated timber pallets secured with industrial steel strapping. Our delivery fleet features hydraulic tailgates to lower pallets safely to ground level at your building site.
        </p>
      </div>

      <div className="space-y-4">
        <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
          2. Zero-Breakage Policy & Immediate Replacement
        </h2>
        <p>
          We inspect every box before crating. Customers and site managers have the right to inspect pallets upon delivery before signing the electronic waybill. If any tile is broken during transit, take a photo with the driver present and we will dispatch a replacement crate from our Accra depot within 24 hours at zero cost.
        </p>
      </div>

      <div className="space-y-4">
        <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)]">
          3. Returns & Excess Full Boxes
        </h2>
        <p>
          We accept returns of unopened, undamaged full boxes within 30 days of delivery, subject to tone/batch number verification to ensure consistency for future clients. A 10% restocking fee applies to cover warehouse pallet re-crating.
        </p>
      </div>
    </div>
  );
}

export function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-6 text-xs text-[var(--theme-text-muted)] leading-relaxed">
      <h1 className="font-serif-luxury text-3xl font-semibold text-[var(--theme-text)]">
        Terms of Commercial Supply
      </h1>
      <p>
        These terms govern the sale of architectural tiles, porcelain slabs, and masonry materials by Atelier Surfaces Ghana Ltd. All orders placed through this platform or through our showroom desk constitute acceptance of these conditions.
      </p>
      <p>
        Tile dimensions are subject to nominal manufacturing tolerances under European Standard EN 14411. Color variations are inherent to natural stone and high-definition vitrified porcelain. Always verify batch and calibration numbers before cutting or fixing.
      </p>
    </div>
  );
}

export function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-6 text-xs text-[var(--theme-text-muted)] leading-relaxed">
      <h1 className="font-serif-luxury text-3xl font-semibold text-[var(--theme-text)]">
        Privacy & Data Governance
      </h1>
      <p>
        Atelier Surfaces respects client confidentiality. Information collected during checkout (including names, site addresses, GhanaPost GPS coordinates, and phone numbers) is utilized solely for order crating, freight routing, and payment verification.
      </p>
      <p>
        We do not sell client project details or contact numbers to third-party advertisers. Financial transactions processed via Paystack are encrypted with TLS 1.3 standards.
      </p>
    </div>
  );
}
