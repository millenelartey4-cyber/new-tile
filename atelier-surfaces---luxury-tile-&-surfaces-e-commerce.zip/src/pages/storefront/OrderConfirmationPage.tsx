import { useState } from 'react';
import { useRouter, Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { 
  CheckCircle2, 
  Printer, 
  ArrowRight, 
  Truck, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldCheck, 
  Download,
  WifiOff,
  CloudCheck,
  Lock,
  Layers,
  ExternalLink
} from 'lucide-react';
import { offlineSyncService } from '../../services/offlineSync';
import { ecomspineService } from '../../services/ecomspineService';
import { EcomSpineTrackingModal } from '../../components/common/EcomSpineTrackingModal';

interface OrderConfirmationPageProps {
  orderId: string;
}

export function OrderConfirmationPage({ orderId }: OrderConfirmationPageProps) {
  const { navigate } = useRouter();
  const order = storeService.getOrderById(orderId);
  const settings = storeService.getStoreSettings();
  const [isTrackingModalOpen, setIsTrackingModalOpen] = useState(false);

  // Retrieve or link EcomSpine waybill for this order
  const waybill = order ? (ecomspineService.getWaybillByOrderId(order.id) || (order.ecomspineWaybillNumber ? ecomspineService.getWaybillByNumber(order.ecomspineWaybillNumber) : undefined)) : undefined;

  const handlePrint = () => {
    window.print();
  };

  if (!order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <h2 className="font-serif-luxury text-3xl font-semibold">Order Reference Not Found</h2>
        <p className="text-xs text-[var(--theme-text-muted)]">
          Could not locate order #{orderId}.
        </p>
        <Link
          href="/shop"
          className="inline-block px-6 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider"
        >
          Return to Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      
      {/* Printable Receipt Container */}
      <div id="printable-receipt" className="space-y-10">
        
        {/* Success Banner */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-8 text-center space-y-3 relative overflow-hidden">
          <div className="w-14 h-14 mx-auto rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <span className="text-xs font-bold uppercase tracking-widest text-[var(--theme-accent)]">
            Architectural Order Confirmed
          </span>
          <h1 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)]">
            Thank You For Your Specification
          </h1>
          <p className="text-xs text-[var(--theme-text-muted)] max-w-md mx-auto">
            Order Reference <strong className="text-[var(--theme-text)] font-mono">{order.orderNumber}</strong> has been created in the Atelier database. Inventory has been allocated from our warehouse.
          </p>

          {!offlineSyncService.isOnline() && (
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-950/20 border border-amber-600/40 text-amber-500 text-xs font-semibold rounded-xs mt-2">
              <WifiOff className="w-3.5 h-3.5" />
              <span>Offline Outbox: Order stored locally and will automatically synchronize to cloud database upon reconnecting.</span>
            </div>
          )}

          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handlePrint}
              className="px-5 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider hover:border-[var(--theme-text)] flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-[var(--theme-accent)]" />
              <span>Print / Download PDF Receipt</span>
            </button>
            <Link
              href={`/account/orders/${order.id}`}
              className="px-5 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider hover:opacity-90 transition-opacity"
            >
              Track in Account
            </Link>
          </div>
        </div>

        {/* EcomSpine Live Waybill & Logistics Engine Widget */}
        {waybill && (
          <div className="bg-gradient-to-r from-stone-900 via-stone-900 to-stone-950 border border-amber-500/40 rounded-xl p-6 text-stone-100 shadow-xl relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-amber-500/5 -skew-x-12 pointer-events-none" />
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-stone-800">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                  <Truck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">EcomSpine Logistics Engine</span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Anti-Theft Protected
                    </span>
                  </div>
                  <h3 className="text-lg font-serif font-medium text-stone-100 flex items-center gap-2">
                    Waybill: <span className="font-mono text-amber-400 font-bold">{waybill.waybillNumber}</span>
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="bg-stone-950 px-3 py-2 rounded-lg border border-stone-800 text-right">
                  <span className="block text-[10px] text-stone-400 uppercase font-mono">Site Verification PIN</span>
                  <span className="font-mono text-base font-bold text-amber-400 tracking-widest">{waybill.verificationPin}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsTrackingModalOpen(true)}
                  className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-amber-950 cursor-pointer"
                >
                  <MapPin className="w-4 h-4" />
                  <span>Live GPS Tracking</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-xs">
              <div className="space-y-1">
                <span className="text-stone-400 block text-[11px]">Fleet Truck & Driver</span>
                <p className="font-semibold text-stone-200">{waybill.vehiclePlate} ({waybill.vehicleType.split(' ')[0]})</p>
                <p className="text-stone-400 text-[11px]">{waybill.driverName} · {waybill.driverPhone}</p>
              </div>
              <div className="space-y-1">
                <span className="text-stone-400 block text-[11px]">Freight Handling</span>
                <p className="font-semibold text-stone-200">{waybill.packageDetails.totalPallets} Pallets · {waybill.packageDetails.totalWeightKg} kg</p>
                <p className="text-amber-400 text-[11px] flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Heavy Hydraulic Tailgate Rigging
                </p>
              </div>
              <div className="space-y-1">
                <span className="text-stone-400 block text-[11px]">Anti-Theft Settlement Guard</span>
                <p className="font-semibold text-emerald-400 font-mono text-[11px]">
                  ✓ 100% Zero-Theft Guaranteed
                </p>
                <p className="text-stone-400 text-[11px]">Direct Stanbic Bank & MasterCard Linked Payout</p>
              </div>
            </div>
          </div>
        )}

        {/* Order Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          
          {/* Summary & Settlement */}
          <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-6 space-y-3">
            <h3 className="font-bold uppercase tracking-wider text-[var(--theme-text)] pb-2 border-b border-[var(--theme-border)]">
              Payment & Settlement Status
            </h3>
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Order Number:</span>
                <span className="font-mono font-bold text-[var(--theme-text)]">{order.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Payment Method:</span>
                <span className="capitalize font-medium text-[var(--theme-text)]">
                  {order.paymentMethod.replace('_', ' ')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--theme-text-muted)]">Verification Status:</span>
                <span className={`font-bold uppercase ${
                  order.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'
                }`}>
                  {order.paymentStatus.replace('_', ' ')}
                </span>
              </div>
              {order.paymentReference && (
                <div className="flex justify-between">
                  <span className="text-[var(--theme-text-muted)]">Gateway Reference:</span>
                  <span className="font-mono text-[11px] text-[var(--theme-text-muted)]">{order.paymentReference}</span>
                </div>
              )}
              <div className="flex justify-between pt-1 border-t border-[var(--theme-border-subtle)]">
                <span className="text-[var(--theme-text-muted)]">Order Placed:</span>
                <span className="tabular-nums">{new Date(order.createdAt).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Delivery Site Information */}
          <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-6 space-y-3">
            <h3 className="font-bold uppercase tracking-wider text-[var(--theme-text)] pb-2 border-b border-[var(--theme-border)]">
              Site Delivery Destination
            </h3>
            <div className="space-y-1 text-[var(--theme-text-muted)]">
              <p className="font-semibold text-[var(--theme-text)]">{order.shippingAddress.fullName}</p>
              <p>{order.shippingAddress.addressLine1}</p>
              <p>{order.shippingAddress.city}, {order.shippingAddress.region}</p>
              {order.shippingAddress.ghanaPostGps && (
                <p className="font-mono text-[var(--theme-accent)] font-semibold">
                  GPS: {order.shippingAddress.ghanaPostGps}
                </p>
              )}
              <p className="pt-1">{order.shippingAddress.phone}</p>
            </div>
          </div>
        </div>

        {/* Tracking Timeline */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)] flex items-center gap-2">
            <Truck className="w-5 h-5 text-[var(--theme-accent)]" />
            <span>Fulfillment & Tailgate Freight Milestones</span>
          </h3>

          <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[var(--theme-border)]">
            {order.trackingTimeline.map((step, idx) => (
              <div key={idx} className="relative flex items-start gap-4 text-xs">
                <div className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full border-2 bg-[var(--theme-surface)] ${
                  step.completed 
                    ? 'border-emerald-600 bg-emerald-600' 
                    : 'border-[var(--theme-border)]'
                }`} />
                <div>
                  <span className={`font-bold block ${step.completed ? 'text-[var(--theme-text)]' : 'text-[var(--theme-text-muted)]'}`}>
                    {step.title}
                  </span>
                  <span className="text-[var(--theme-text-muted)] block text-[11px]">{step.description}</span>
                  <span className="text-[10px] text-[var(--theme-accent)] font-mono block mt-0.5">{step.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Itemized Purchased Specifications Table */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
          <h3 className="font-serif-luxury text-lg font-semibold text-[var(--theme-text)]">
            Itemized Material Breakdown
          </h3>

          <div className="divide-y divide-[var(--theme-border)] text-xs">
            {order.itemsSnapshot.map((item, idx) => (
              <div key={idx} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <img src={item.image} alt={item.productName} className="w-12 h-12 object-cover border border-[var(--theme-border)]" />
                  <div>
                    <span className="font-semibold text-[var(--theme-text)] block">{item.productName}</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {item.isSample && (
                        <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 border border-amber-300 text-[9px] uppercase font-bold">
                          4"×4" Sample Specimen
                        </span>
                      )}
                      <span className="text-[11px] text-[var(--theme-text-muted)]">
                        Color: {item.colorName} · SKU: {item.sku}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-semibold tabular-nums block text-[var(--theme-text)]">
                    GH₵{item.lineTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className="text-[11px] text-[var(--theme-text-muted)]">
                    {item.quantity} {item.unit} @ GH₵{item.unitPrice}/{item.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-[var(--theme-border)] space-y-2 text-xs text-right max-w-xs ml-auto">
            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Subtotal:</span>
              <span className="tabular-nums font-semibold">GH₵{order.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Site Freight:</span>
              <span className="tabular-nums font-semibold">{order.shippingCost === 0 ? 'Complimentary' : `GH₵${order.shippingCost}`}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">VAT / NHIL (15%):</span>
              <span className="tabular-nums font-semibold">GH₵{order.tax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-[var(--theme-border)] text-sm font-bold text-[var(--theme-text)]">
              <span>Final Settlement:</span>
              <span className="tabular-nums text-[var(--theme-accent)]">GH₵{order.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        {/* Showroom & Support Footer */}
        <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-center text-xs text-[var(--theme-text-muted)] space-y-1">
          <p className="font-semibold text-[var(--theme-text)]">{settings.brandName} Ghana Concierge</p>
          <p>{settings.showroomAddress} · Phone: {settings.contactPhone}</p>
          <p className="text-[11px]">All surfaces inspected for flatness and dimension tolerance according to EN 14411.</p>
        </div>
      </div>

      <div className="flex justify-between items-center pt-4">
        <Link
          href="/shop"
          className="text-xs uppercase font-semibold text-[var(--theme-accent)] hover:underline flex items-center gap-1.5"
        >
          <span>Return to Material Catalog</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
        <Link
          href="/account"
          className="text-xs uppercase font-semibold text-[var(--theme-text)] hover:underline"
        >
          Manage All Orders
        </Link>
      </div>

      {/* EcomSpine Waybill & GPS Telemetrics Modal */}
      {waybill && (
        <EcomSpineTrackingModal
          waybill={waybill}
          isOpen={isTrackingModalOpen}
          onClose={() => setIsTrackingModalOpen(false)}
        />
      )}
    </div>
  );
}
