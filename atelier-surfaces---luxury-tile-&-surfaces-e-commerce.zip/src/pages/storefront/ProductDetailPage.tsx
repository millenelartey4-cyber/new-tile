import { useState, useEffect, useMemo } from 'react';
import { useRouter, Link } from '../../router/Router';
import { storeService } from '../../services/store';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useCompany } from '../../context/CompanyContext';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { ProductVariant } from '../../types';
import { TileAreaCalculator } from '../../components/calculator/TileAreaCalculator';
import { SurfaceROICalculator } from '../../components/calculator/SurfaceROICalculator';
import { SurfaceLightingSimulator } from '../../components/product/SurfaceLightingSimulator';
import { ThreeDTextureStudio } from '../../components/product/ThreeDTextureStudio';
import { 
  Heart, 
  Share2, 
  Check, 
  Truck, 
  ShieldCheck, 
  Ruler, 
  Package, 
  ArrowRight, 
  Sparkles,
  Info,
  Lightbulb,
  Sun,
  Lamp,
  Box,
  Video,
  MessageSquare,
  Lock,
  Zap,
  TrendingUp,
  Scale,
  ScanLine
} from 'lucide-react';
import { useVideoCall } from '../../context/VideoCallContext';
import { SurfaceTextureScannerModal } from '../../components/scanner/SurfaceTextureScannerModal';

interface ProductDetailPageProps {
  slug: string;
}

export function ProductDetailPage({ slug }: ProductDetailPageProps) {
  const { navigate, searchParams } = useRouter();
  const { addToCart, requestSample, toggleWishlist, isInWishlist } = useCartWishlist();
  const { activeCompany } = useCompany();
  const { startCall } = useVideoCall();
  const [isStartingVideo, setIsStartingVideo] = useState(false);
  const settings = useStoreSettings(activeCompany.id);
  const panelBrightness = storeService.getPanelBrightness(activeCompany.id);

  // Real-time synchronization version counter
  const [productsVersion, setProductsVersion] = useState(0);
  const [livePushedToast, setLivePushedToast] = useState<string | null>(null);

  const product = useMemo(() => {
    return storeService.getProductBySlug(slug, activeCompany.id);
  }, [slug, activeCompany.id, productsVersion]);

  const initialVariantId = searchParams.get('variant');

  // Active Variant State
  const [activeVariant, setActiveVariant] = useState<ProductVariant | null>(() => {
    if (!product) return null;
    if (initialVariantId) {
      const found = product.variants.find(v => v.id === initialVariantId);
      if (found) return found;
    }
    return product.variants[0] || null;
  });

  // Active Gallery Image Index
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Gallery, 2D Lighting Simulator, or Three.js 3D Specimen Studio
  const [galleryViewMode, setGalleryViewMode] = useState<'gallery' | 'lighting' | '3d'>('gallery');
  const [lightingTabTool, setLightingTabTool] = useState<'3d' | 'photometric'>('3d');

  // Quantity in m² or boxes
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'specs' | 'lighting' | 'roi' | 'applications' | 'freight'>('specs');
  const [copiedLink, setCopiedLink] = useState(false);
  const [sampleFeedback, setSampleFeedback] = useState(false);
  const [isPDPScannerOpen, setIsPDPScannerOpen] = useState(false);

  // Bulk pricing rule for product collection
  const bulkRule = useMemo(() => {
    if (!product) return null;
    return storeService.getBulkPricingRuleForCategory(product.categoryId, activeCompany.id);
  }, [product?.categoryId, activeCompany.id, productsVersion]);

  // Current qualifying bulk tier based on selected quantity
  const activeBulkTier = useMemo(() => {
    if (!bulkRule || !bulkRule.tiers || bulkRule.tiers.length === 0) return null;
    const sortedDesc = [...bulkRule.tiers].sort((a, b) => b.minQuantitySqm - a.minQuantitySqm);
    return sortedDesc.find(t => {
      const meetsMin = quantity >= t.minQuantitySqm;
      const meetsMax = t.maxQuantitySqm == null || quantity <= t.maxQuantitySqm;
      return meetsMin && meetsMax;
    }) || null;
  }, [bulkRule, quantity]);

  const effectiveUnitPrice = useMemo(() => {
    if (!activeVariant) return 0;
    if (!activeBulkTier) return activeVariant.price;
    if (activeBulkTier.discountType === 'percentage') {
      return activeVariant.price * (1 - activeBulkTier.discountValue / 100);
    } else {
      return Math.min(activeVariant.price, activeBulkTier.discountValue);
    }
  }, [activeVariant, activeBulkTier]);

  // Real-time Event Listeners for POS inventory and price mutations
  useEffect(() => {
    const handleInventorySync = (e: any) => {
      setProductsVersion(v => v + 1);
      const detail = e.detail;
      if (product && detail?.productId === product.id) {
        setLivePushedToast(`Physical Showroom Stock Updated: ${detail.newStock} m² available`);
        setTimeout(() => setLivePushedToast(null), 4000);
      }
    };

    const handlePriceSync = (e: any) => {
      setProductsVersion(v => v + 1);
      const detail = e.detail;
      if (!detail?.productId || detail.productId === product?.id) {
        setLivePushedToast('Specimen Price Updated Live from Ridge West POS Register');
        setTimeout(() => setLivePushedToast(null), 4000);
      }
    };

    const handleSaleBroadcast = (e: any) => {
      setProductsVersion(v => v + 1);
      const detail = e.detail;
      const soldItem = detail?.items?.find((item: any) => item.productId === product?.id);
      if (soldItem) {
        setLivePushedToast(`⚡ In-Store Sale: ${soldItem.quantity} m² just purchased at Accra Showroom counter.`);
        setTimeout(() => setLivePushedToast(null), 5000);
      }
    };

    const handleGenericSync = () => {
      setProductsVersion(v => v + 1);
    };

    window.addEventListener('pos_inventory_synced', handleInventorySync);
    window.addEventListener('pos_price_synced', handlePriceSync);
    window.addEventListener('pos_sale_broadcast', handleSaleBroadcast);
    window.addEventListener('pos_realtime_event_received', handleGenericSync);
    window.addEventListener('atelier_settings_updated', handleGenericSync);
    window.addEventListener('storage', handleGenericSync);

    return () => {
      window.removeEventListener('pos_inventory_synced', handleInventorySync);
      window.removeEventListener('pos_price_synced', handlePriceSync);
      window.removeEventListener('pos_sale_broadcast', handleSaleBroadcast);
      window.removeEventListener('pos_realtime_event_received', handleGenericSync);
      window.removeEventListener('atelier_settings_updated', handleGenericSync);
      window.removeEventListener('storage', handleGenericSync);
    };
  }, [product?.id]);

  // Synchronize activeVariant when product or initial variant query changes
  useEffect(() => {
    if (product) {
      if (activeVariant) {
        const fresh = product.variants.find(v => v.id === activeVariant.id);
        if (fresh) {
          setActiveVariant(fresh);
          return;
        }
      }
      if (initialVariantId) {
        const found = product.variants.find(v => v.id === initialVariantId);
        if (found) {
          setActiveVariant(found);
          setActiveImageIndex(0);
          return;
        }
      }
      setActiveVariant(product.variants[0] || null);
      setActiveImageIndex(0);
    }
  }, [slug, initialVariantId, product]);

  if (!product || !activeVariant) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center space-y-4">
        <h2 className="font-serif-luxury text-3xl font-semibold">Surface Not Found</h2>
        <p className="text-xs text-[var(--theme-text-muted)]">
          The requested architectural tile specimen does not exist or may have been retired.
        </p>
        <Link
          href="/shop"
          className="inline-block px-6 py-3 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-semibold uppercase tracking-wider"
        >
          Return to Catalog
        </Link>
      </div>
    );
  }

  // Gallery images for active variant
  const galleryImages = activeVariant.images.length > 0
    ? activeVariant.images
    : product.variants[0]?.images || ['/assets/images/hero_luxury_marble_showroom_1792523066069.jpg'];

  const currentMainImage = galleryImages[activeImageIndex] || galleryImages[0];
  const inWishlist = isInWishlist(product.id, activeVariant.id);
  const isOutOfStock = activeVariant.stock <= 0;

  // Handle color change (Mandatory Behavior from prompt)
  const handleVariantChange = (variant: ProductVariant) => {
    setActiveVariant(variant);
    setActiveImageIndex(0);
    // Sync URL without full reload
    window.history.replaceState({}, '', `/product/${product.slug}?variant=${variant.id}`);
  };

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addToCart(product, activeVariant, quantity);
  };

  const handleBuyNow = () => {
    if (isOutOfStock) return;
    addToCart(product, activeVariant, quantity);
    navigate('/checkout');
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleRequestSample = () => {
    requestSample(product, activeVariant, 35);
    setSampleFeedback(true);
    setTimeout(() => setSampleFeedback(false), 3500);
  };

  const handleStartConsultationWithProduct = async () => {
    if (!product || !activeVariant) return;
    setIsStartingVideo(true);
    await startCall(undefined, 'architect', {
      name: product.name,
      material: product.material,
      price: activeVariant.price,
      image: currentMainImage
    });
    setIsStartingVideo(false);
    navigate('/video-consultation');
  };

  // Related products in the same category
  const relatedProducts = storeService
    .getProducts()
    .filter(p => p.id !== product.id && p.categoryId === product.categoryId)
    .slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      
      {/* Breadcrumb (Zero-pill text format) */}
      <nav aria-label="Breadcrumb" className="text-xs text-[var(--theme-text-muted)] flex items-center gap-2">
        <Link href="/" className="hover:text-[var(--theme-text)]">Home</Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-[var(--theme-text)]">Catalog</Link>
        <span>/</span>
        <Link href={`/category/${product.categoryId}`} className="hover:text-[var(--theme-text)]">
          {product.categoryName}
        </Link>
        <span>/</span>
        <span className="text-[var(--theme-text)] font-medium truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main PDP Grid (Contiguous purchase module: Sticky gallery left, Sticky purchase right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Image Gallery & Surface Lighting Studio (Span 7) */}
        <div 
          style={{
            filter: `brightness(${panelBrightness.storefrontSpecimenBrightness}%) contrast(${panelBrightness.storefrontSpecimenContrast}%)`
          }}
          className="lg:col-span-7 space-y-4 transition-all duration-150"
        >
          
          {/* Visual Mode Switcher (Zero-pill clean luxury tabs) */}
          <div className="flex flex-wrap items-center justify-between border-b border-[var(--theme-border)] pb-2 text-xs gap-2">
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => setGalleryViewMode('gallery')}
                className={`pb-1.5 font-bold uppercase tracking-wider transition-colors cursor-pointer border-b-2 ${
                  galleryViewMode === 'gallery'
                    ? 'border-[var(--theme-text)] text-[var(--theme-text)]'
                    : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
                }`}
              >
                Gallery ({galleryImages.length})
              </button>
              <button
                type="button"
                onClick={() => setGalleryViewMode('lighting')}
                className={`pb-1.5 font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 border-b-2 ${
                  galleryViewMode === 'lighting'
                    ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                    : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)]'
                }`}
              >
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Lighting Studio</span>
                <span className="text-[9px] uppercase px-1.5 py-0.5 bg-[var(--theme-accent)] text-white font-bold">
                  Photometry
                </span>
              </button>
              <button
                type="button"
                onClick={() => setGalleryViewMode('3d')}
                className={`pb-1.5 font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 border-b-2 ${
                  galleryViewMode === '3d'
                    ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                    : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-accent)]'
                }`}
              >
                <Box className="w-3.5 h-3.5" />
                <span>Three.js 3D Studio</span>
                <span className="text-[9px] uppercase px-1.5 py-0.5 bg-amber-600 text-white font-bold">
                  WebGL
                </span>
              </button>
            </div>

            {/* Quick condition toggles right in header */}
            <div className="flex items-center gap-1.5 text-[10px]">
              <button
                type="button"
                onClick={() => setGalleryViewMode('lighting')}
                className="px-2 py-1 border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] font-semibold transition-colors cursor-pointer bg-[var(--theme-surface)]"
                title="Switch to Natural Daylight (5500K) simulation"
              >
                ☀️ Daylight
              </button>
              <button
                type="button"
                onClick={() => setGalleryViewMode('lighting')}
                className="px-2 py-1 border border-[var(--theme-border)] hover:border-[var(--theme-accent)] text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] font-semibold transition-colors cursor-pointer bg-[var(--theme-surface)]"
                title="Switch to Warm Indoor (2700K) simulation"
              >
                💡 Warm Indoor
              </button>
              <button
                type="button"
                onClick={() => setGalleryViewMode('3d')}
                className="px-2 py-1 border border-[var(--theme-accent)] text-[var(--theme-accent)] font-semibold transition-colors cursor-pointer bg-[var(--theme-surface)]"
                title="Launch Three.js 3D Specimen"
              >
                🪐 3D Orbit
              </button>
            </div>
          </div>

          {galleryViewMode === '3d' ? (
            /* Three.js 3D Interactive Specimen & PBR Lighting Studio */
            <div className="space-y-4">
              <ThreeDTextureStudio
                product={product}
                variant={activeVariant}
                onClose={() => setGalleryViewMode('gallery')}
              />
            </div>
          ) : galleryViewMode === 'lighting' ? (
            /* Interactive Photometric Studio */
            <div className="space-y-4">
              <SurfaceLightingSimulator
                product={product}
                variant={activeVariant}
                currentImage={currentMainImage}
                onClose={() => setGalleryViewMode('gallery')}
              />
            </div>
          ) : (
            /* Standard High-Definition Gallery */
            <div className="space-y-4">
              {/* Main Large Image */}
              <div className="aspect-[4/3] bg-stone-100 overflow-hidden border border-[var(--theme-border)] relative group">
                <img
                  src={currentMainImage}
                  alt={`${product.name} - ${activeVariant.colorName}`}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/images/hero_luxury_marble_showroom_1792523066069.jpg';
                  }}
                />

                {/* Floating Interactive Switch Buttons */}
                <div className="absolute bottom-4 right-4 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setGalleryViewMode('lighting')}
                    className="bg-black/85 hover:bg-black text-white text-xs font-semibold px-3 py-2 flex items-center gap-1.5 backdrop-blur-md shadow-xl border border-white/20 transition-all cursor-pointer"
                  >
                    <Lightbulb className="w-3.5 h-3.5 text-amber-300" />
                    <span>2D Lighting</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setGalleryViewMode('3d')}
                    className="bg-[var(--theme-accent)] hover:opacity-90 text-white text-xs font-semibold px-3.5 py-2 flex items-center gap-1.5 shadow-xl transition-all cursor-pointer"
                  >
                    <Box className="w-3.5 h-3.5 text-white" />
                    <span>Three.js 3D Specimen</span>
                  </button>
                </div>

                {activeVariant.stock <= activeVariant.lowStockThreshold && activeVariant.stock > 0 && (
                  <span className="absolute top-4 left-4 bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 uppercase tracking-wider shadow-md">
                    Low Stock: Only {activeVariant.stock} {activeVariant.unit} Available
                  </span>
                )}
                {isOutOfStock && (
                  <span className="absolute top-4 left-4 bg-red-600 text-white text-[10px] font-bold px-2.5 py-1 uppercase tracking-wider shadow-md">
                    Sold Out (Next Quarry Batch in Transit)
                  </span>
                )}
              </div>

              {/* Thumbnails (Replaced dynamically on variant switch) */}
              {galleryImages.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  {galleryImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`w-20 h-20 shrink-0 border-2 overflow-hidden transition-all cursor-pointer ${
                        activeImageIndex === idx 
                          ? 'border-[var(--theme-accent)] shadow-sm' 
                          : 'border-[var(--theme-border)] opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img 
                        src={img} 
                        alt="Specimen view" 
                        className="w-full h-full object-cover" 
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                        }}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Quick trust assurance badges */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[var(--theme-border)] text-xs text-[var(--theme-text-muted)]">
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
              <span>Full batch calibration & zero shade variance guarantee.</span>
            </div>
            <div className="flex items-start gap-2">
              <Truck className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
              <span>Hydraulic tailgate site delivery in Greater Accra & Kumasi.</span>
            </div>
            <div className="flex items-start gap-2">
              <Package className="w-4 h-4 text-[var(--theme-accent)] shrink-0 mt-0.5" />
              <span>Wood pallet crating with industrial corner protection.</span>
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase Module (Span 5) */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
          
          <div>
            <div className="flex items-center justify-between text-xs text-[var(--theme-text-muted)] mb-1">
              <div className="flex items-center gap-2">
                <span>{product.material} · {product.finish} Finish</span>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => {
                    setGalleryViewMode('lighting');
                    window.scrollTo({ top: 120, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-[var(--theme-accent)] hover:underline cursor-pointer"
                >
                  <Lightbulb className="w-3 h-3" />
                  <span>Test Lighting</span>
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => setIsPDPScannerOpen(true)}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                  title="Scan an existing floor sample to find matching or complementary tiles"
                >
                  <ScanLine className="w-3 h-3" />
                  <span>Scan Floor Match</span>
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleShare}
                  className="hover:text-[var(--theme-text)] transition-colors flex items-center gap-1"
                  title="Share link"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{copiedLink ? 'Copied' : 'Share'}</span>
                </button>
                <span>·</span>
                <button
                  onClick={() => toggleWishlist(product.id, activeVariant.id)}
                  className={`flex items-center gap-1 hover:text-rose-600 transition-colors ${
                    inWishlist ? 'text-rose-600 font-semibold' : ''
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${inWishlist ? 'fill-current' : ''}`} />
                  <span>{inWishlist ? 'Saved' : 'Wishlist'}</span>
                </button>
              </div>
            </div>

            <h1 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] leading-tight">
              {product.name}
            </h1>

            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold tabular-nums text-[var(--theme-text)]">
                  GH₵{activeVariant.price.toLocaleString()}
                </span>
                {activeVariant.compareAtPrice && (
                  <span className="text-sm text-[var(--theme-text-muted)] line-through tabular-nums">
                    GH₵{activeVariant.compareAtPrice.toLocaleString()}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--theme-text-muted)]">
                <span>per {activeVariant.unit} (Coverage: {activeVariant.boxCoverage} m²/box)</span>
                <span>·</span>
                <button
                  type="button"
                  onClick={handleRequestSample}
                  className="text-xs text-[var(--theme-accent)] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Request 4" × 4" Sample (GH₵35)</span>
                </button>
              </div>
            </div>

            {/* Live Showroom Real-Time Stock Status */}
            <div className="mt-3 flex items-center justify-between p-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${activeVariant.stock > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                <span className="text-[var(--theme-text)] font-semibold">Live Physical Showroom Stock:</span>
                <span className={`font-mono font-bold ${activeVariant.stock > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {activeVariant.stock > 0 ? `${activeVariant.stock} ${activeVariant.unit} in Accra` : 'Sold Out at Showroom'}
                </span>
              </div>
              <span className="text-[10px] text-[var(--theme-text-muted)] font-mono hidden sm:inline">
                GPS: {settings.ghanaPostGps || 'GA-110-3849'}
              </span>
            </div>
          </div>

          {/* Color Variant Selector (Mandatory Functional Swatches) */}
          <div className="space-y-3 pt-4 border-t border-[var(--theme-border)]">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-[var(--theme-text)]">
                Selected Color: <span className="text-[var(--theme-accent)] font-semibold">{activeVariant.colorName}</span>
              </span>
              <span className="font-mono text-[11px] text-[var(--theme-text-muted)]">
                SKU: {activeVariant.sku}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {product.variants.map(v => {
                const isSelected = activeVariant.id === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => handleVariantChange(v)}
                    className={`flex items-center gap-2 p-1.5 border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)] shadow-xs'
                        : 'border-[var(--theme-border)] hover:border-[var(--theme-text)]'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full border border-black/10 shrink-0"
                      style={{ backgroundColor: v.colorHex }}
                    />
                    <span className="text-xs font-medium text-[var(--theme-text)] pr-1">
                      {v.colorName}
                    </span>
                    {isSelected && <Check className="w-3 h-3 text-[var(--theme-accent)]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-[var(--theme-text-muted)] leading-relaxed">
            {product.description}
          </p>

          {/* Tile Area Calculator Integrated */}
          <TileAreaCalculator
            variant={activeVariant}
            onApplyCalculatedQuantity={qty => setQuantity(qty)}
          />

          {/* Architectural ROI & Durability Comparison Callout */}
          <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-3.5 space-y-2.5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 shrink-0">
                  <TrendingUp className="w-3.5 h-3.5" />
                </span>
                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                    Longevity & ROI Appraisal
                  </h4>
                  <p className="text-[11px] text-[var(--theme-text-muted)]">
                    Natural stone & vitrified porcelain avoid ~3 replacement cycles vs lower-tier alternatives.
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/30 shrink-0">
                +140% ROI
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[var(--theme-border)] text-xs">
              <span className="text-[10px] text-[var(--theme-text-muted)]">
                Models 25-yr maintenance & replacement costs.
              </span>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('roi');
                  const tabsEl = document.getElementById('product-specs-tabs');
                  if (tabsEl) {
                    tabsEl.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="font-bold text-[11px] text-[var(--theme-accent)] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Compare ROI</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Volume Trade Pricing Matrix for Collection */}
          {bulkRule && bulkRule.tiers && bulkRule.tiers.length > 0 && (
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[var(--theme-accent)]" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--theme-text)]">
                    Volume Trade Pricing ({bulkRule.collectionName})
                  </h4>
                </div>
                <span className="text-[10px] text-[var(--theme-text-muted)] font-mono">
                  Auto-Applied in Cart
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-[var(--theme-border)] bg-[var(--theme-surface)]">
                  <thead>
                    <tr className="bg-[var(--theme-surface-subtle)] border-b border-[var(--theme-border)] text-[10px] uppercase font-bold text-[var(--theme-text-muted)]">
                      <th className="p-2">Order Area</th>
                      <th className="p-2">Incentive</th>
                      <th className="p-2">Est. Rate/m²</th>
                      <th className="p-2 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--theme-border-subtle)]">
                    {bulkRule.tiers.map((tier) => {
                      const isQualifying = quantity >= tier.minQuantitySqm && (tier.maxQuantitySqm == null || quantity <= tier.maxQuantitySqm);
                      const estimatedPerM2 = tier.discountType === 'percentage' 
                        ? (activeVariant ? activeVariant.price * (1 - tier.discountValue / 100) : 0)
                        : tier.discountValue;

                      return (
                        <tr 
                          key={tier.id}
                          className={`transition-colors ${
                            isQualifying 
                              ? 'bg-emerald-50/80 font-bold text-emerald-950 border-l-2 border-l-emerald-600' 
                              : 'hover:bg-[var(--theme-surface-subtle)]/50 text-[var(--theme-text)]'
                          }`}
                        >
                          <td className="p-2 font-mono text-[11px]">
                            {tier.minQuantitySqm}
                            {tier.maxQuantitySqm ? ` – ${Math.floor(tier.maxQuantitySqm)} m²` : '+ m²'}
                          </td>
                          <td className="p-2">
                            <span className="font-bold text-emerald-700">
                              {tier.discountType === 'percentage' ? `${tier.discountValue}% OFF` : `Special Rate`}
                            </span>
                          </td>
                          <td className="p-2 tabular-nums">
                            GH₵{estimatedPerM2.toFixed(2)}
                          </td>
                          <td className="p-2 text-right">
                            {isQualifying ? (
                              <span className="inline-block px-1.5 py-0.5 bg-emerald-600 text-white text-[9px] uppercase font-bold rounded-2xs">
                                Active Tier
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setQuantity(tier.minQuantitySqm)}
                                className="text-[10px] uppercase font-semibold text-[var(--theme-accent)] hover:underline"
                              >
                                Select {tier.minQuantitySqm}m²
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Quantity Selector & Purchase Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              <div className="w-32 border border-[var(--theme-border)] bg-[var(--theme-surface)] flex items-center justify-between p-2">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-2 font-bold text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  max={activeVariant.stock}
                  value={quantity}
                  onChange={e => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-12 text-center text-xs font-bold tabular-nums bg-transparent focus:outline-none"
                />
                <button
                  onClick={() => setQuantity(Math.min(activeVariant.stock, quantity + 1))}
                  disabled={quantity >= activeVariant.stock}
                  className="px-2 font-bold text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] disabled:opacity-30"
                >
                  +
                </button>
              </div>

              <div className="text-xs text-[var(--theme-text-muted)]">
                <span>Total: </span>
                <strong className="text-sm font-semibold tabular-nums text-[var(--theme-text)]">
                  GH₵{(effectiveUnitPrice * quantity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </strong>
                {activeBulkTier && (
                  <span className="block text-[10px] text-emerald-700 font-semibold">
                    ✓ {activeBulkTier.tierLabel} Applied
                  </span>
                )}
                <span className="block text-[10px]">
                  (~{Math.ceil(quantity / activeVariant.boxCoverage)} boxes)
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                className="py-4 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-widest hover:opacity-90 disabled:opacity-50 transition-opacity cursor-pointer"
              >
                {isOutOfStock ? 'Sold Out' : 'Add to Specification Bag'}
              </button>

              <button
                onClick={handleBuyNow}
                disabled={isOutOfStock}
                className="py-4 bg-[var(--theme-accent)] text-white text-xs font-bold uppercase tracking-widest hover:opacity-95 disabled:opacity-50 transition-opacity shadow-md cursor-pointer"
              >
                Instant Checkout
              </button>
            </div>

            {/* Request 4" × 4" Tactile Sample Specimen Card */}
            <div className="pt-4 border-t border-[var(--theme-border)]">
              <div className="bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="p-1 bg-[var(--theme-accent)] text-white">
                        <Package className="w-3.5 h-3.5" />
                      </span>
                      <h4 className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                        Request 4" × 4" Tactile Specimen Sample
                      </h4>
                    </div>
                    <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                      Evaluate stone calibration, edge bevels, and surface sheen in your room's natural lighting prior to ordering full boxes. Hand-cut in <strong>{activeVariant.colorName} ({product.finish} finish)</strong>.
                    </p>
                  </div>
                  
                  <div className="text-right shrink-0">
                    <span className="text-sm font-bold tabular-nums block text-[var(--theme-text)]">
                      GH₵35.00
                    </span>
                    <span className="text-[10px] text-emerald-700 font-semibold block">
                      100% Credited
                    </span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[var(--theme-border)]">
                  <div className="flex items-center gap-1.5 text-[11px] text-[var(--theme-text-muted)]">
                    <ShieldCheck className="w-3.5 h-3.5 text-[var(--theme-accent)] shrink-0" />
                    <span>Courier dispatch in padded archival envelope within 24–48h.</span>
                  </div>

                  <button
                    type="button"
                    onClick={handleRequestSample}
                    className="px-4 py-2.5 bg-[var(--theme-surface)] hover:bg-[var(--theme-primary)] hover:text-[var(--theme-primary-contrast)] border border-[var(--theme-border)] text-[var(--theme-text)] text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    {sampleFeedback ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Sample Added to Bag!</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5 text-[var(--theme-accent)]" />
                        <span>Add 4"×4" Sample (GH₵35)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Face-to-Face Video Consultation & Chat Card */}
            <div className="pt-4 border-t border-[var(--theme-border)]">
              <div className={`p-4 space-y-3 transition-colors ${
                settings.videoConsultationLocked
                  ? 'bg-red-950/15 border border-red-500/30'
                  : 'bg-emerald-950/10 border border-emerald-500/30'
              }`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`p-1 rounded-xs text-white ${
                        settings.videoConsultationLocked ? 'bg-red-600' : 'bg-emerald-600'
                      }`}>
                        {settings.videoConsultationLocked ? <Lock className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5" />}
                      </span>
                      <h4 className="font-bold text-xs uppercase tracking-wider text-[var(--theme-text)]">
                        Face-to-Face Online Video Call & Chat
                      </h4>
                    </div>
                    <p className="text-[11px] text-[var(--theme-text-muted)] leading-relaxed">
                      {settings.videoConsultationLocked
                        ? `Video calls are temporarily locked by the concierge desk. Contact our Ridge West showroom at ${settings.showroomAddress || '14 Independence Avenue, Ridge West, Accra, Ghana'} (GPS: ${settings.ghanaPostGps || 'GA-110-3849'}) or call ${settings.contactPhone || '0542443125/0596334488'}.`
                        : `Connect live face-to-face with an Atelier Surface Consultant in Ridge West / Carrara. Inspect ${product.name} under real-time lighting, examine high-resolution vein continuity, and chat in real-time.`}
                    </p>
                  </div>
                  
                  <div className="text-right shrink-0">
                    <span className={`text-[10px] font-mono uppercase px-2 py-0.5 font-bold rounded-xs ${
                      settings.videoConsultationLocked
                        ? 'bg-red-500/20 text-red-500 border border-red-500/30'
                        : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                    }`}>
                      {settings.videoConsultationLocked ? 'Calls Locked' : 'Live Available'}
                    </span>
                  </div>
                </div>

                <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t ${
                  settings.videoConsultationLocked ? 'border-red-500/20' : 'border-emerald-500/20'
                }`}>
                  <span className="text-[11px] text-[var(--theme-text-muted)] flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${settings.videoConsultationLocked ? 'bg-red-500' : 'bg-emerald-500 animate-pulse'}`} />
                    {settings.videoConsultationLocked
                      ? 'Private Showroom Consultations Available'
                      : 'Encrypted WebRTC HD Video & Live Chat'}
                  </span>

                  {settings.videoConsultationLocked ? (
                    <button
                      type="button"
                      onClick={() => navigate('/video-consultation')}
                      className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      <span>View Concierge Desk</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleStartConsultationWithProduct}
                      disabled={isStartingVideo}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>{isStartingVideo ? 'Connecting...' : 'Inspect Face-to-Face Over Video'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Specifications Tabs */}
      <div className="pt-12 border-t border-[var(--theme-border)]">
        <div id="product-specs-tabs" className="flex border-b border-[var(--theme-border)] gap-6 sm:gap-8 text-xs uppercase font-bold tracking-wider overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('specs')}
            className={`pb-3 border-b-2 transition-colors shrink-0 ${
              activeTab === 'specs' 
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            Technical Specifications
          </button>
          <button
            onClick={() => setActiveTab('roi')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 shrink-0 ${
              activeTab === 'roi' 
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)] font-semibold' 
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
            <span>Lifecycle ROI & Longevity</span>
            <span className="text-[9px] uppercase px-1.5 py-0.5 bg-emerald-600 text-white font-bold ml-1">
              Save GH₵40k+
            </span>
          </button>
          <button
            onClick={() => setActiveTab('lighting')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 shrink-0 ${
              activeTab === 'lighting' 
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)] font-semibold' 
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>Lighting & Finish Response</span>
            <span className="text-[9px] uppercase px-1.5 py-0.5 bg-[var(--theme-accent)] text-white font-bold ml-1">
              5500K / 2700K / 6500K
            </span>
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`pb-3 border-b-2 transition-colors shrink-0 ${
              activeTab === 'applications' 
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            Spatial Applications
          </button>
          <button
            onClick={() => setActiveTab('freight')}
            className={`pb-3 border-b-2 transition-colors shrink-0 ${
              activeTab === 'freight' 
                ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]' 
                : 'border-transparent text-[var(--theme-text-muted)] hover:text-[var(--theme-text)]'
            }`}
          >
            Freight & Ghanaian Logistics
          </button>
        </div>

        <div className="py-8">
          {activeTab === 'lighting' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
                <div className="max-w-2xl space-y-1">
                  <h4 className="font-serif-luxury text-xl font-semibold">
                    Architectural Lighting & Texture Response Evaluation
                  </h4>
                  <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
                    Tile textures, veining depth, and surface sheens transform under different Kelvin color temperatures. Toggle between our Three.js 3D WebGL PBR specimen or 2D photometric simulator.
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setLightingTabTool('3d')}
                    className={`px-3 py-1.5 border text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                      lightingTabTool === '3d'
                        ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white shadow-xs'
                        : 'border-[var(--theme-border)] bg-[var(--theme-surface)] text-[var(--theme-text)]'
                    }`}
                  >
                    <Box className="w-3.5 h-3.5" />
                    <span>Three.js 3D Studio</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setLightingTabTool('photometric')}
                    className={`px-3 py-1.5 border text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                      lightingTabTool === 'photometric'
                        ? 'border-[var(--theme-accent)] bg-[var(--theme-accent)] text-white shadow-xs'
                        : 'border-[var(--theme-border)] bg-[var(--theme-surface)] text-[var(--theme-text)]'
                    }`}
                  >
                    <Lightbulb className="w-3.5 h-3.5" />
                    <span>2D Photometry & Split</span>
                  </button>
                </div>
              </div>

              {lightingTabTool === '3d' ? (
                <ThreeDTextureStudio
                  product={product}
                  variant={activeVariant}
                />
              ) : (
                <SurfaceLightingSimulator
                  product={product}
                  variant={activeVariant}
                  currentImage={currentMainImage}
                />
              )}
            </div>
          )}

          {activeTab === 'specs' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-xs">
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Format Dimensions</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.size}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Thickness</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.thickness}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Water Absorption</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.specifications.waterAbsorption || '< 0.05%'}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Slip Coefficient</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.specifications.slipResistance || 'R10'}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Rectification</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.specifications.rectified ? 'Precision Rectified 90°' : 'Natural Cushioned Edge'}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Shade Variation</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.specifications.shadeVariation || 'V2 Slight'}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Quarry Origin</span>
                <strong className="text-sm text-[var(--theme-text)]">{product.specifications.origin || 'Italy'}</strong>
              </div>
              <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)]">
                <span className="text-[var(--theme-text-muted)] block uppercase font-bold text-[10px]">Box Coverage</span>
                <strong className="text-sm text-[var(--theme-text)] tabular-nums">{activeVariant.boxCoverage} m² per box</strong>
              </div>
            </div>
          )}

          {activeTab === 'roi' && (
            <div className="space-y-6">
              <SurfaceROICalculator
                product={product}
                variant={activeVariant}
                onApplyCalculatedArea={sqm => setQuantity(sqm)}
                currencySymbol="GH₵"
                defaultArea={quantity > 5 ? quantity : 50}
              />
            </div>
          )}

          {activeTab === 'applications' && (
            <div className="space-y-4 max-w-3xl text-xs text-[var(--theme-text)] leading-relaxed">
              <h4 className="font-serif-luxury text-lg font-semibold">Recommended Environments</h4>
              <div className="flex flex-wrap gap-2">
                {product.applications.map((app, i) => (
                  <span key={i} className="px-3 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] font-medium">
                    {app}
                  </span>
                ))}
              </div>
              <p className="pt-2 text-[var(--theme-text-muted)]">
                Suitable for both residential luxury spaces and commercial high-traffic locations. Calibrated for underfloor heating and zero moisture seepage when paired with epoxy grout.
              </p>
            </div>
          )}

          {activeTab === 'freight' && (
            <div className="space-y-4 max-w-3xl text-xs text-[var(--theme-text)] leading-relaxed">
              <h4 className="font-serif-luxury text-lg font-semibold">Nationwide Delivery by Hydraulic Tailgate</h4>
              <p className="text-[var(--theme-text-muted)]">
                All tile shipments are crated on fumigated wooden pallets and transported on dedicated flatbed trucks equipped with hydraulic tailgates for safe curb or driveway offloading.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-[var(--theme-text-muted)]">
                <li><strong>Greater Accra & Tema:</strong> 24–48 hours delivery.</li>
                <li><strong>Kumasi & Western Region:</strong> 2–4 business days via regional freight line.</li>
                <li><strong>Site Requirements:</strong> Paved access for 10-tonne trucks. Inspection on handover.</li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="pt-12 border-t border-[var(--theme-border)]">
          <h3 className="font-serif-luxury text-2xl font-semibold mb-6">
            Complementary Surfaces in {product.categoryName}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relatedProducts.map(rel => (
              <Link
                key={rel.id}
                href={`/product/${rel.slug}`}
                className="group block bg-[var(--theme-surface)] border border-[var(--theme-border)] hover:border-[var(--theme-accent)] transition-all p-4"
              >
                <div className="aspect-[4/3] bg-stone-100 overflow-hidden mb-3">
                  <img
                    src={rel.variants[0]?.images[0] || '/assets/images/category_porcelain_floors_1792523066985.jpg'}
                    alt={rel.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/images/category_porcelain_floors_1792523066985.jpg';
                    }}
                  />
                </div>
                <div className="text-xs text-[var(--theme-text-muted)] mb-1">
                  <span>{rel.material}</span> · <span>{rel.size}</span>
                </div>
                <h4 className="font-serif-luxury text-base font-semibold group-hover:text-[var(--theme-accent)] transition-colors line-clamp-1">
                  {rel.name}
                </h4>
                <span className="text-sm font-bold tabular-nums text-[var(--theme-text)] mt-2 block">
                  From GH₵{rel.variants[0]?.price.toLocaleString()}/{rel.variants[0]?.unit}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Real-time Physical POS Sync Toast */}
      {livePushedToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-950/95 border border-emerald-500/50 text-emerald-300 text-xs px-4 py-3 rounded-xs shadow-2xl flex items-center gap-2.5 backdrop-blur-md animate-in slide-in-from-bottom-3 duration-200">
          <Zap className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
          <span className="font-sans font-medium">{livePushedToast}</span>
        </div>
      )}

      {/* Surface Texture Scanner Modal */}
      <SurfaceTextureScannerModal
        isOpen={isPDPScannerOpen}
        onClose={() => setIsPDPScannerOpen(false)}
      />
    </div>
  );
}
