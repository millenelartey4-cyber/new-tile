import { useState } from 'react';
import { useRouter } from '../../router/Router';
import { useCartWishlist } from '../../context/CartWishlistContext';
import { useAuth } from '../../context/AuthContext';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { useStoreSettings } from '../../hooks/useStoreSettings';
import { PaymentMethod } from '../../types';
import { 
  ShieldCheck, 
  CreditCard, 
  Upload, 
  Truck, 
  MapPin, 
  Check, 
  AlertCircle,
  Lock,
  ArrowRight,
  WifiOff,
  HardDrive,
  CheckCircle2,
  KeyRound,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { offlineSyncService } from '../../services/offlineSync';
import { ecomspineService } from '../../services/ecomspineService';

export function CheckoutPage() {
  const { navigate } = useRouter();
  const { cart, subtotal, bulkDiscount, appliedBulkTiers, clearCart } = useCartWishlist();
  const { currentUser } = useAuth();
  const { activeCompany } = useCompany();
  const settings = useStoreSettings(activeCompany.id);

  // Form State
  const [fullName, setFullName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '+233 ');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('Accra');
  const [region, setRegion] = useState('Greater Accra');
  const [ghanaPostGps, setGhanaPostGps] = useState('GA-');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // Delivery Method
  const [deliveryMethod, setDeliveryMethod] = useState<'standard' | 'express' | 'pickup'>('standard');

  // Payment Method & EcomSpine Card State
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('ecomspine_secure_pay');
  const [receiptFile, setReceiptFile] = useState<string | null>(null);

  // EcomSpine Card Details
  const [cardNumber, setCardNumber] = useState('5399 4182 9901 8492');
  const [cardHolder, setCardHolder] = useState(currentUser?.name || 'KWAME MENSAH');
  const [cardExpiry, setCardExpiry] = useState('08/29');
  const [cardCvv, setCardCvv] = useState('849');
  const [is3DsChallengeOpen, setIs3DsChallengeOpen] = useState(false);
  const [challengeOtp, setChallengeOtp] = useState('749201');

  // Status & processing
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  // Delivery Cost calculation
  const effectiveSubtotal = Math.max(0, subtotal - bulkDiscount);
  let deliveryCost = settings.standardDeliveryCost;
  if (deliveryMethod === 'pickup') {
    deliveryCost = 0;
  } else if (deliveryMethod === 'express') {
    deliveryCost = settings.expressFreightCost;
  } else if (effectiveSubtotal >= settings.freeDeliveryThreshold) {
    deliveryCost = 0;
  }

  const tax = effectiveSubtotal * (settings.taxRatePercent / 100);
  const total = effectiveSubtotal + deliveryCost + tax;

  const ghanaRegions = [
    'Greater Accra',
    'Ashanti (Kumasi)',
    'Western (Sekondi-Takoradi)',
    'Central (Cape Coast)',
    'Eastern (Koforidua)',
    'Volta (Ho)',
    'Northern (Tamale)',
    'Bono (Sunyani)',
    'Upper East',
    'Upper West',
    'Ahafo',
    'Bono East',
    'North East',
    'Oti',
    'Savannah',
    'Western North'
  ];

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Form validations
    if (!fullName.trim() || !email.trim() || !phone.trim() || !addressLine1.trim()) {
      setErrorMsg('Please complete all mandatory delivery fields.');
      return;
    }

    setIsProcessing(true);

    try {
      // Create pending order securely in StoreService
      const order = storeService.createOrder({
        customerId: currentUser?.uid || 'guest-checkout',
        customerSnapshot: {
          name: fullName,
          email,
          phone
        },
        itemsSnapshot: cart.map(item => ({
          productId: item.productId,
          productName: item.productName,
          productSlug: item.productSlug,
          variantId: item.variantId,
          colorName: item.colorName,
          colorHex: item.colorHex,
          image: item.image,
          sku: item.sku,
          unitPrice: item.unitPrice,
          quantity: item.quantity,
          unit: item.unit,
          lineTotal: item.unitPrice * item.quantity,
          isSample: item.isSample,
          sampleDimensions: item.sampleDimensions
        })),
        shippingAddress: {
          fullName,
          email,
          phone,
          addressLine1,
          city,
          region,
          ghanaPostGps,
          deliveryNotes
        },
        subtotal,
        discount: bulkDiscount,
        shippingCost: deliveryCost,
        tax,
        total,
        currency: settings.currency || activeCompany.currency || 'GHS',
        paymentMethod,
        paymentStatus: paymentMethod === 'paystack' || paymentMethod === 'ecomspine_secure_pay' ? 'paid' : 'verification_required',
        orderStatus: paymentMethod === 'paystack' || paymentMethod === 'ecomspine_secure_pay' ? 'processing' : 'pending',
        paymentReference: paymentMethod === 'paystack' 
          ? `pstk_test_${Math.floor(100000000 + Math.random() * 900000000)}` 
          : paymentMethod === 'ecomspine_secure_pay'
            ? `ESP-SET-${Math.floor(1000 + Math.random() * 9000)}`
            : `WIRE-GH-${Math.floor(10000 + Math.random() * 90000)}`,
        paymentReceiptUrl: receiptFile || undefined,
        internalNotes: `Method: ${deliveryMethod}. GPS: ${ghanaPostGps}${bulkDiscount > 0 ? `. Bulk Tier Discount: GH₵${bulkDiscount.toLocaleString()} (${appliedBulkTiers.map(t => t.tierLabel).join(', ')})` : ''}`
      });

      // If EcomSpine Secure Pay was selected, generate waybill and bank settlement
      if (paymentMethod === 'ecomspine_secure_pay') {
        const last4 = cardNumber.replace(/\s+/g, '').slice(-4) || '8492';
        const settlement = ecomspineService.recordSettlement(
          order,
          {
            brand: 'mastercard',
            last4,
            cardholderName: cardHolder || fullName || 'Kwame Mensah',
            antiTheftScore: 99.9
          },
          activeCompany.id
        );

        const waybill = ecomspineService.createWaybillFromOrder(
          order,
          {
            destinationAddress: addressLine1,
            destinationCity: `${city}, ${region}`,
            destinationGps: ghanaPostGps,
            clientName: fullName,
            clientPhone: phone
          },
          activeCompany.id
        );

        order.ecomspineWaybillNumber = waybill.waybillNumber;
        order.ecomspineSettlementId = settlement.settlementNumber;
        storeService.updateOrder(order);
      } else {
        // Also auto-generate an EcomSpine waybill for freight tracking if customer selected delivery
        const waybill = ecomspineService.createWaybillFromOrder(
          order,
          {
            destinationAddress: addressLine1,
            destinationCity: `${city}, ${region}`,
            destinationGps: ghanaPostGps,
            clientName: fullName,
            clientPhone: phone
          },
          activeCompany.id
        );
        order.ecomspineWaybillNumber = waybill.waybillNumber;
        storeService.updateOrder(order);
      }

      // Enqueue to hybrid offline sync outbox
      offlineSyncService.enqueueTransaction({
        type: 'ORDER_CREATE',
        entityId: order.id,
        companyId: activeCompany.id,
        summary: `Order ${order.orderNumber} - ${order.customerSnapshot.name} (${order.currency} ${order.total.toLocaleString()})`,
        payload: order
      });

      // Clear shopping cart
      clearCart();

      // Navigate to order confirmation
      setTimeout(() => {
        setIsProcessing(false);
        navigate(`/order-confirmation/${order.id}`);
      }, 800);
    } catch (err: any) {
      setIsProcessing(false);
      setErrorMsg(err?.message || 'Could not place order. Please review your details.');
    }
  };

  const handleSimulateReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      // In production, uploads to Firebase Storage; here simulates a receipt reference
      setReceiptFile('/assets/images/category_stone_bathroom_1792523067646.jpg');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Title */}
      <div className="border-b border-[var(--theme-border)] pb-6">
        <span className="text-xs font-semibold tracking-widest uppercase text-[var(--theme-accent)] flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5" />
          <span>Encrypted Checkout Protocol</span>
        </span>
        <h1 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[var(--theme-text)] mt-1">
          Finalize Architectural Order
        </h1>
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-50 text-red-800 border border-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {!offlineSyncService.isOnline() && (
        <div className="p-4 bg-amber-950/20 border border-amber-600/40 text-amber-500 text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0 text-amber-500" />
            <span>
              <strong>Offline Mode Active:</strong> You can place this order right now. It will be stored safely in your local device outbox and automatically synchronized with the cloud payment processor upon reconnection.
            </span>
          </div>
          <span className="font-mono text-[10px] bg-amber-500/20 px-2 py-0.5 rounded-xs shrink-0 font-bold uppercase">
            Queued Outbox
          </span>
        </div>
      )}

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Delivery & Payment Details (Span 7) */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Section 1: Customer & Site Contact */}
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
            <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs flex items-center justify-center font-bold">1</span>
              <span>Client & Project Contact</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Full Name / Firm Name *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder="e.g. Akosua Adomako (Design Studio)"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Email Address (For Invoices) *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="architect@domain.com"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Phone / WhatsApp Number (For Driver Site Call) *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="0542443125/0596334488"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Ghanaian Delivery & GPS */}
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
            <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs flex items-center justify-center font-bold">2</span>
              <span>Site Delivery & GhanaPost GPS</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Site Street Address *
                </label>
                <input
                  type="text"
                  required
                  value={addressLine1}
                  onChange={e => setAddressLine1(e.target.value)}
                  placeholder="Plot 18, Airport Residential Area / Trassaco Phase 2"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  City / Town *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  placeholder="Accra / Kumasi / Takoradi"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Region *
                </label>
                <select
                  value={region}
                  onChange={e => setRegion(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                >
                  {ghanaRegions.map(reg => (
                    <option key={reg} value={reg}>{reg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  GhanaPost GPS Address
                </label>
                <input
                  type="text"
                  value={ghanaPostGps}
                  onChange={e => setGhanaPostGps(e.target.value.toUpperCase())}
                  placeholder="GA-183-9024"
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs uppercase font-mono focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>

              <div>
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Delivery Method
                </label>
                <select
                  value={deliveryMethod}
                  onChange={e => setDeliveryMethod(e.target.value as any)}
                  className="w-full px-3 py-2.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                >
                  <option value="standard">Standard Hydraulic Freight ({settings.currencySymbol}{settings.standardDeliveryCost})</option>
                  <option value="express">Express Site Crane Placement ({settings.currencySymbol}{settings.expressFreightCost})</option>
                  <option value="pickup">Client Warehouse Pickup ({settings.showroomAddress || 'Ridge West'} - Free)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block uppercase font-bold text-[var(--theme-text-muted)] mb-1">
                  Special Handling / Site Instructions
                </label>
                <textarea
                  rows={2}
                  value={deliveryNotes}
                  onChange={e => setDeliveryNotes(e.target.value)}
                  placeholder="Gate code, access clearance for 10-wheel trucks, contact person on site..."
                  className="w-full px-3 py-2 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs focus:outline-none focus:border-[var(--theme-accent)] text-[var(--theme-text)]"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Payment Method */}
          <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-4">
            <h2 className="font-serif-luxury text-xl font-semibold text-[var(--theme-text)] flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs flex items-center justify-center font-bold">3</span>
              <span>Settlement & Payment Method</span>
            </h2>

            <div className="space-y-4 text-xs">
              {/* EcomSpine Secure Pay (Direct Bank & MasterCard Shield) */}
              <div className={`p-5 border transition-all ${
                paymentMethod === 'ecomspine_secure_pay'
                  ? 'border-amber-500 bg-amber-950/10 shadow-lg shadow-amber-950/20'
                  : 'border-[var(--theme-border)] hover:border-[var(--theme-text-muted)] bg-[var(--theme-surface)]'
              }`}>
                <label className="flex items-start justify-between cursor-pointer">
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'ecomspine_secure_pay'}
                      onChange={() => setPaymentMethod('ecomspine_secure_pay')}
                      className="mt-1 accent-amber-500"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-[var(--theme-text)] flex items-center gap-1.5">
                          EcomSpine Secure Pay
                        </span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-stone-950 uppercase tracking-wide">
                          Recommended • Anti-Theft Shield
                        </span>
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                          Direct MasterCard Settlement
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--theme-text-muted)] mt-1">
                        Encrypted payment with instant direct merchant settlement into <strong>Stanbic Bank Ghana (Acct: 9040003928174)</strong> & linked <strong>MasterCard (5399 •••• •••• 8492)</strong>. Zero fraud liability.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1.5 shrink-0 pl-2">
                    <span className="text-[10px] font-bold font-mono px-2 py-1 bg-stone-900 border border-stone-700 text-amber-400 rounded">
                      MasterCard
                    </span>
                    <ShieldCheck className="w-5 h-5 text-emerald-500" />
                  </div>
                </label>

                {paymentMethod === 'ecomspine_secure_pay' && (
                  <div className="mt-4 pt-4 border-t border-amber-900/30 space-y-4">
                    {/* Live Anti-Theft Banner */}
                    <div className="p-3 bg-stone-950/80 border border-amber-500/30 rounded-lg flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                        <Lock className="w-4 h-4" />
                      </div>
                      <div className="text-[11px] leading-relaxed">
                        <span className="font-semibold text-amber-400 block">EcomSpine Anti-Theft & FraudShield Active</span>
                        <span className="text-stone-300">
                          Every transaction is protected by EMV 3D-Secure 2.2, biometric device risk scoring, and Ghana Interbank Payment (GhIPSS) anti-theft clearing. Funds settle directly into your verified bank account without intermediary theft risks.
                        </span>
                      </div>
                    </div>

                    {/* Interactive Card Inputs */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-stone-950/60 p-4 rounded-lg border border-stone-800">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-mono uppercase text-stone-400 mb-1">
                          Cardholder Full Name
                        </label>
                        <input
                          type="text"
                          value={cardHolder}
                          onChange={e => setCardHolder(e.target.value)}
                          placeholder="KWAME MENSAH"
                          className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded text-stone-100 font-mono text-xs focus:outline-none focus:border-amber-500 uppercase"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-mono uppercase text-stone-400 mb-1 flex items-center justify-between">
                          <span>MasterCard / Visa Card Number</span>
                          <span className="text-emerald-400 text-[10px] flex items-center gap-1 font-sans">
                            <CheckCircle2 className="w-3 h-3" /> 256-Bit TLS Encrypted
                          </span>
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            value={cardNumber}
                            onChange={e => setCardNumber(e.target.value)}
                            placeholder="5399 •••• •••• 8492"
                            maxLength={19}
                            className="w-full pl-3 pr-20 py-2 bg-stone-900 border border-stone-700 rounded text-stone-100 font-mono text-xs focus:outline-none focus:border-amber-500 tracking-wider"
                          />
                          <div className="absolute right-2 top-2 flex items-center space-x-1">
                            <span className="text-[9px] font-mono bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/30">
                              3DS 2.2
                            </span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-mono uppercase text-stone-400 mb-1">
                          Expiry Date (MM/YY)
                        </label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={e => setCardExpiry(e.target.value)}
                          placeholder="MM/YY"
                          maxLength={5}
                          className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded text-stone-100 font-mono text-xs focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-mono uppercase text-stone-400 mb-1 flex items-center justify-between">
                          <span>Security Code (CVV)</span>
                          <span className="text-[10px] text-stone-500">3-digits</span>
                        </label>
                        <input
                          type="password"
                          value={cardCvv}
                          onChange={e => setCardCvv(e.target.value)}
                          placeholder="•••"
                          maxLength={4}
                          className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded text-stone-100 font-mono text-xs focus:outline-none focus:border-amber-500 tracking-widest"
                        />
                      </div>
                    </div>

                    {/* Direct Settlement Summary Badges */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-stone-400 border-t border-stone-800/80 pt-3">
                      <div className="flex items-center gap-1.5">
                        <Truck className="w-3.5 h-3.5 text-amber-500" />
                        <span>Instant EcomSpine Waybill Dispatch (`ESP-GH-XXXX`)</span>
                      </div>
                      <div className="flex items-center gap-1.5 font-mono text-emerald-400">
                        <Check className="w-3 h-3" />
                        <span>Direct Merchant Bank Settlement Confirmed</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Paystack */}
              <label className={`block p-4 border cursor-pointer transition-colors ${
                paymentMethod === 'paystack'
                  ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]'
                  : 'border-[var(--theme-border)] hover:border-[var(--theme-text-muted)]'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'paystack'}
                      onChange={() => setPaymentMethod('paystack')}
                      className="accent-[var(--theme-accent)]"
                    />
                    <div>
                      <span className="font-bold text-sm block text-[var(--theme-text)]">
                        Paystack Ghana (Cards & Mobile Money)
                      </span>
                      <span className="text-[11px] text-[var(--theme-text-muted)]">
                        Instant automated verification: Visa, Mastercard, MTN MoMo, Telecel Cash.
                      </span>
                    </div>
                  </div>
                  <CreditCard className="w-5 h-5 text-[var(--theme-accent)] shrink-0" />
                </div>
              </label>

              {/* Direct Bank Wire */}
              <label className={`block p-4 border cursor-pointer transition-colors ${
                paymentMethod === 'bank_transfer'
                  ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]'
                  : 'border-[var(--theme-border)] hover:border-[var(--theme-text-muted)]'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'bank_transfer'}
                      onChange={() => setPaymentMethod('bank_transfer')}
                      className="accent-[var(--theme-accent)]"
                    />
                    <div>
                      <span className="font-bold text-sm block text-[var(--theme-text)]">
                        Corporate Bank Wire Transfer (Stanbic Bank / Ecobank Ghana)
                      </span>
                      <span className="text-[11px] text-[var(--theme-text-muted)]">
                        Upload payment slip for instant administrative Order Total Verification.
                      </span>
                    </div>
                  </div>
                </div>

                {paymentMethod === 'bank_transfer' && (
                  <div className="mt-4 pt-3 border-t border-[var(--theme-border)] space-y-2 text-[11px] text-[var(--theme-text-muted)] bg-[var(--theme-surface)] p-3">
                    <p><strong>Bank:</strong> Stanbic Bank Ghana Ltd (Ridge West Branch)</p>
                    <p><strong>Account Name:</strong> Atelier Surfaces Ghana Ltd</p>
                    <p><strong>Account Number:</strong> 9040003928174</p>
                    
                    <div className="pt-2">
                      <span className="block font-bold text-[var(--theme-text)] mb-1">
                        Upload Wire Receipt Screenshot (Optional for Faster Dispatch):
                      </span>
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={handleSimulateReceiptUpload}
                        className="text-xs"
                      />
                      {receiptFile && (
                        <span className="text-emerald-700 font-medium block mt-1">
                          ✓ Receipt attached for review.
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </label>

              {/* Cash On Delivery / Site Inspection */}
              <label className={`block p-4 border cursor-pointer transition-colors ${
                paymentMethod === 'cash_on_delivery'
                  ? 'border-[var(--theme-accent)] bg-[var(--theme-surface-subtle)]'
                  : 'border-[var(--theme-border)] hover:border-[var(--theme-text-muted)]'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'cash_on_delivery'}
                    onChange={() => setPaymentMethod('cash_on_delivery')}
                    className="accent-[var(--theme-accent)]"
                  />
                  <div>
                    <span className="font-bold text-sm block text-[var(--theme-text)]">
                      Pay on Delivery / Tailgate Handover Inspection
                    </span>
                    <span className="text-[11px] text-[var(--theme-text-muted)]">
                      Available for Greater Accra orders. Driver accepts certified MoMo or Manager's Cheque on site.
                    </span>
                  </div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Order Review & Submit (Span 5) */}
        <div className="lg:col-span-5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] p-6 space-y-6 lg:sticky lg:top-28">
          <h2 className="font-serif-luxury text-xl font-semibold border-b border-[var(--theme-border)] pb-3 text-[var(--theme-text)]">
            Order Review ({cart.length} Lines)
          </h2>

          {/* Mini items list */}
          <div className="max-h-60 overflow-y-auto divide-y divide-[var(--theme-border-subtle)] text-xs">
            {cart.map(item => (
              <div key={item.id} className="py-2.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <img src={item.image} alt={item.productName} className="w-10 h-10 object-cover border border-[var(--theme-border)]" />
                  <div>
                    <span className="font-medium text-[var(--theme-text)] line-clamp-1">{item.productName}</span>
                    <div className="flex items-center gap-1.5 text-[11px] text-[var(--theme-text-muted)]">
                      {item.isSample && (
                        <span className="px-1 py-0.2 bg-amber-100 text-amber-900 border border-amber-300 text-[9px] uppercase font-bold">
                          4"×4" Sample
                        </span>
                      )}
                      <span>{item.colorName} · {item.quantity} {item.unit}</span>
                    </div>
                  </div>
                </div>
                <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                  GH₵{(item.unitPrice * item.quantity).toLocaleString()}
                </span>
              </div>
            ))}
          </div>

          {/* Financial summary */}
          <div className="pt-3 border-t border-[var(--theme-border)] space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Subtotal</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                GH₵{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            {bulkDiscount > 0 && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xs space-y-1">
                <div className="flex justify-between font-bold text-xs">
                  <span>🏷️ Bulk Quantity Savings:</span>
                  <span className="font-mono text-emerald-700">
                    -GH₵{bulkDiscount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                {appliedBulkTiers.map((tier, idx) => (
                  <div key={idx} className="text-[10px] text-emerald-800 flex justify-between">
                    <span>{tier.collectionName} ({tier.qualifyingSqm} m²): {tier.tierLabel}</span>
                    <span className="font-semibold">{tier.discountType === 'percentage' ? `${tier.discountValue}% OFF` : `GH₵${tier.discountValue}/m²`}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Delivery & Site Freight</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                {deliveryCost === 0 ? (
                  <span className="text-emerald-700 font-bold">Complimentary</span>
                ) : (
                  `GH₵${deliveryCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                )}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-[var(--theme-text-muted)]">Ghana VAT / NHIL / GETFund (15%)</span>
              <span className="font-semibold tabular-nums text-[var(--theme-text)]">
                GH₵{tax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <div className="pt-3 border-t border-[var(--theme-border)] flex justify-between text-base">
              <span className="font-bold text-[var(--theme-text)]">Payable Total</span>
              <span className="font-bold tabular-nums text-xl text-[var(--theme-accent)]">
                GH₵{total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-4 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-widest hover:opacity-90 disabled:opacity-50 transition-opacity flex items-center justify-center gap-2 shadow-lg cursor-pointer"
          >
            {isProcessing ? (
              <span>Verifying & Reserving Stock...</span>
            ) : (
              <>
                <span>Complete Purchase</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-[var(--theme-text-muted)]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>256-Bit SSL Protection · Certified Quarry Inventory</span>
          </div>
        </div>
      </form>
    </div>
  );
}
