import React, { useState, useEffect } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallButton } from '../../components/pwa/PWAInstallButton';
import { PWAInstallModal } from '../../components/pwa/PWAInstallModal';
import { useCompany } from '../../context/CompanyContext';
import { storeService } from '../../services/store';
import { Link } from '../../router/Router';
import { 
  Download, 
  Monitor, 
  Smartphone, 
  Laptop, 
  WifiOff, 
  Zap, 
  CheckCircle2, 
  Layers, 
  ShieldCheck, 
  ArrowRight,
  HardDrive,
  Copy,
  Check,
  Building2,
  RefreshCw,
  Box,
  FolderDown,
  FileCode2,
  Cloud,
  Wifi
} from 'lucide-react';
import { downloadDesktopShortcut, downloadStandaloneWebApp, getAppBaseUrl } from '../../utils/desktopAppLauncher';
import { ConnectionStatusBadge } from '../../components/common/ConnectionStatusBadge';
import { offlineSyncService } from '../../services/offlineSync';

export function InstallAppPage() {
  const { isInstalled, isStandalone, platform, isIOS, hasNativePrompt, install } = usePWAInstall();
  const { activeCompany } = useCompany();
  const settings = storeService.getStoreSettings();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [downloadedShortcut, setDownloadedShortcut] = useState(false);
  const [downloadedApp, setDownloadedApp] = useState(false);
  const [swActive, setSwActive] = useState<boolean | null>(null);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistration().then(reg => {
        setSwActive(!!reg);
      }).catch(() => {
        setSwActive(false);
      });
    } else {
      setSwActive(false);
    }
  }, []);

  const handleCopyLink = () => {
    const shareUrl = getAppBaseUrl();
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadApp = () => {
    downloadStandaloneWebApp('Atelier-Surfaces-SaaS-App');
    setDownloadedApp(true);
    setTimeout(() => setDownloadedApp(false), 3500);
  };

  const handleDownloadShortcut = () => {
    downloadDesktopShortcut('ATELIER-Surfaces-SaaS');
    setDownloadedShortcut(true);
    setTimeout(() => setDownloadedShortcut(false), 3000);
  };

  return (
    <div className="bg-[var(--theme-bg)] text-[var(--theme-text)] min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-12">
        
        {/* Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--theme-accent)]/10 border border-[var(--theme-accent)]/30 text-xs font-bold uppercase tracking-widest text-[var(--theme-accent)]">
            <Download className="w-3.5 h-3.5" />
            <span>SaaS Progressive Web Application</span>
          </div>
          
          <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[var(--theme-text)]">
            Install {settings.brandName || 'ATELIER SURFACES'}
          </h1>
          
          <p className="text-sm sm:text-base text-[var(--theme-text-muted)] max-w-2xl mx-auto leading-relaxed">
            Download and install ATELIER directly on your Mac, Windows PC, iPhone, iPad, or Android device. Experience zero-latency hardware 3D slab rendering, complete offline showroom specs, and seamless multi-company tenant switching.
          </p>

          {/* Action Hub */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3.5">
            {/* Primary Action 1: Download Standalone Offline App (.html) */}
            <button
              onClick={handleDownloadApp}
              className="px-7 py-3.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition flex items-center gap-2 cursor-pointer shadow-lg"
            >
              {downloadedApp ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <FileCode2 className="w-4 h-4" />
              )}
              <span>{downloadedApp ? 'App Package Downloaded!' : 'Download Standalone WebApp (.html)'}</span>
            </button>

            {/* Primary Action 2: Download desktop launcher shortcut */}
            <button
              onClick={handleDownloadShortcut}
              className="px-6 py-3.5 bg-[var(--theme-surface)] border-2 border-[var(--theme-accent)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] hover:bg-[var(--theme-surface-subtle)] transition flex items-center gap-2 cursor-pointer shadow-md"
            >
              {downloadedShortcut ? (
                <Check className="w-4 h-4 text-emerald-500" />
              ) : (
                <FolderDown className="w-4 h-4 text-[var(--theme-accent)]" />
              )}
              <span>{downloadedShortcut ? 'Shortcut Downloaded!' : 'Download Desktop Shortcut File'}</span>
            </button>

            {/* In-app guide modal */}
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-5 py-3.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-semibold uppercase tracking-wider text-[var(--theme-text)] hover:border-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer"
            >
              <Monitor className="w-4 h-4 text-[var(--theme-accent)]" />
              <span>Installation Guide</span>
            </button>

            {/* Copy shareable link */}
            <button
              onClick={handleCopyLink}
              className="px-4 py-3.5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] text-xs font-medium text-[var(--theme-text-muted)] hover:text-[var(--theme-text)] transition flex items-center gap-1.5 cursor-pointer"
              title="Copy link to install on mobile or share with staff"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Link'}</span>
            </button>
          </div>

          <div className="pt-2">
            <span className="text-[11px] text-[var(--theme-text-muted)] inline-flex items-center gap-1.5 bg-[var(--theme-surface-subtle)] px-3 py-1 border border-[var(--theme-border)]">
              💡 <em>Dual Engine:</em> Seamlessly switches between live cloud sync when online and local database storage when offline.
            </span>
          </div>
        </div>

        {/* Dual Mode Hybrid Online & Offline Architecture Card */}
        <div className="bg-[var(--theme-surface)] border-2 border-[var(--theme-accent)]/40 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--theme-border)] pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[var(--theme-accent)] px-2 py-0.5 bg-[var(--theme-accent)]/15">
                  Dual Architecture
                </span>
                <span className="text-xs text-emerald-500 font-bold">100% Online + 100% Offline</span>
              </div>
              <h2 className="font-serif-luxury text-2xl font-bold text-[var(--theme-text)] mt-1">
                Both Online Cloud Sync & Complete Offline Execution
              </h2>
              <p className="text-xs text-[var(--theme-text-muted)] mt-0.5">
                The application automatically switches states and flushes queued orders the instant your device connects.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <ConnectionStatusBadge />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Online Pillar */}
            <div className="p-5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-sm text-emerald-500">
                  <Cloud className="w-4 h-4" />
                  <span>ONLINE CAPABILITIES</span>
                </div>
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 font-mono text-[10px] uppercase font-bold border border-emerald-500/30">
                  Cloud Connected
                </span>
              </div>
              <ul className="space-y-2 text-[var(--theme-text-muted)] leading-relaxed">
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>Live Cloud Synchronization:</strong> Changes made across sales staff and warehouse managers synchronize in real time.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>Gemini AI Architectural Concierge:</strong> Instant answers on tile slip ratings, photometrics, and Ghanaian freight logistics.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>Paystack & MoMo Settlement:</strong> Immediate payment authorization and automated receipt issuance.</span>
                </li>
              </ul>
            </div>

            {/* Offline Pillar */}
            <div className="p-5 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-sm text-amber-500">
                  <HardDrive className="w-4 h-4" />
                  <span>OFFLINE CAPABILITIES</span>
                </div>
                <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 font-mono text-[10px] uppercase font-bold border border-amber-500/30">
                  Zero Network Required
                </span>
              </div>
              <ul className="space-y-2 text-[var(--theme-text-muted)] leading-relaxed">
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span><strong>Full Local Material Catalog:</strong> Browse high-definition porcelain, marble, and travertine slabs without cell service.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span><strong>Tile Area & Wastage Calculator:</strong> Run on-site calculations and estimate box counts in basements or remote quarry sites.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span><strong>Queued Order Outbox:</strong> Draft orders and client quotes offline; they automatically flush to cloud upon reconnecting.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* System Diagnostics & Platform Card */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-[var(--theme-border)] pb-4">
            <div>
              <h2 className="font-serif-luxury text-xl font-bold text-[var(--theme-text)]">
                Device Compatibility & Diagnostic State
              </h2>
              <p className="text-xs text-[var(--theme-text-muted)] mt-0.5">
                Real-time inspection of your client environment and PWA capabilities.
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] uppercase font-semibold text-[var(--theme-accent)]">
              {platform.toUpperCase()} ENVIRONMENT
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            {/* Display Mode */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">Window Mode</span>
              <div className="flex items-center gap-2">
                {isStandalone ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="font-bold text-emerald-500">Standalone App</span>
                  </>
                ) : (
                  <>
                    <Monitor className="w-4 h-4 text-amber-500 shrink-0" />
                    <span className="font-semibold text-amber-500">Web Browser Tab</span>
                  </>
                )}
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                {isStandalone ? 'Running outside browser frame with full desktop privileges.' : 'Install to run in an isolated native application window.'}
              </p>
            </div>

            {/* Service Worker */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">Service Worker</span>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="font-bold text-emerald-500">Workbox Active</span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Pre-caches assets, typography, and image slabs for sub-second launches.
              </p>
            </div>

            {/* Offline Storage */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">Offline Cache</span>
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="font-bold text-emerald-500">100% Offline Ready</span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Catalog data, variant specs, and local database remain accessible without internet.
              </p>
            </div>

            {/* Active Workspace */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--theme-text-muted)]">Active Workspace</span>
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[var(--theme-accent)] shrink-0" />
                <span className="font-bold truncate text-[var(--theme-accent)]">{activeCompany.name}</span>
              </div>
              <p className="text-[11px] text-[var(--theme-text-muted)]">
                Isolated database scoped under {activeCompany.currency} currency.
              </p>
            </div>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold">
              Why Install as a SaaS Desktop & Mobile App?
            </h2>
            <p className="text-xs text-[var(--theme-text-muted)] mt-1">
              Purpose-built for architects, interior designers, contractors, and showroom sales teams.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3">
              <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/10 text-[var(--theme-accent)] flex items-center justify-center">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Sub-Second Instant Launch
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
                No web reload latency. All foundational assets, 64+ curated design themes, and high-resolution marble textures are cached locally on your device storage.
              </p>
            </div>

            <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3">
              <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/10 text-[var(--theme-accent)] flex items-center justify-center">
                <WifiOff className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Offline Showroom Specification
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
                Take your laptop or iPad directly onto active construction job sites or client basements with zero WiFi connectivity. The Tile Area Calculator and spec sheets remain fully operational.
              </p>
            </div>

            <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 space-y-3">
              <div className="w-10 h-10 rounded-sm bg-[var(--theme-accent)]/10 text-[var(--theme-accent)] flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif-luxury text-lg font-bold text-[var(--theme-text)]">
                Multi-Tenant Client Separation
              </h3>
              <p className="text-xs text-[var(--theme-text-muted)] leading-relaxed">
                Deploy distinct company workspaces for partner retail chains, custom stone yards, or architectural firms without database collision. Each workspace features its own admin password and isolated orders.
              </p>
            </div>
          </div>
        </div>

        {/* Step-by-Step Instructions per Operating System */}
        <div className="bg-[var(--theme-surface)] border border-[var(--theme-border)] p-6 sm:p-8 space-y-6">
          <h2 className="font-serif-luxury text-xl font-bold">
            Platform-Specific Installation Steps
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* macOS & Windows Chrome / Edge */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
              <div className="flex items-center gap-2 font-bold text-[var(--theme-text)] text-sm">
                <Laptop className="w-4 h-4 text-[var(--theme-accent)]" />
                <span>Google Chrome & Microsoft Edge (Mac / Windows)</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-[var(--theme-text-muted)]">
                <li>Look at the right end of the address bar for the <strong>Install Atelier</strong> button (computer screen with a down arrow).</li>
                <li>Or click <strong>Settings (⋮)</strong> &gt; <strong>Save and share</strong> &gt; <strong>Install Atelier Tiles</strong>.</li>
                <li>Click <strong>Install</strong> when prompted. The application will launch in its own standalone window and dock on your desktop!</li>
              </ol>
            </div>

            {/* Apple iOS Safari */}
            <div className="p-4 bg-[var(--theme-surface-subtle)] border border-[var(--theme-border)] space-y-3">
              <div className="flex items-center gap-2 font-bold text-[var(--theme-text)] text-sm">
                <Smartphone className="w-4 h-4 text-[var(--theme-accent)]" />
                <span>Apple iOS Safari (iPhone & iPad)</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-[var(--theme-text-muted)]">
                <li>Open this page in <strong>Safari</strong> on iOS.</li>
                <li>Tap the <strong>Share</strong> button (square with up arrow) in the toolbar.</li>
                <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
                <li>Confirm by tapping <strong>Add</strong>. An app icon with native splash screen will appear on your home screen.</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Bottom Call to Action */}
        <div className="p-8 bg-gradient-to-r from-[var(--theme-surface)] via-[var(--theme-surface-subtle)] to-[var(--theme-surface)] border border-[var(--theme-border)] text-center space-y-4">
          <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[var(--theme-text)]">
            Ready to deploy or install your surfaces workspace?
          </h2>
          <p className="text-xs text-[var(--theme-text-muted)] max-w-lg mx-auto">
            Switch between retail customer mode and the secured Enterprise Admin Console at any time.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/"
              className="px-6 py-2.5 bg-[var(--theme-primary)] text-[var(--theme-primary-contrast)] text-xs font-bold uppercase tracking-wider hover:opacity-90 transition"
            >
              Return to Storefront
            </Link>
            <Link
              href="/admin"
              className="px-6 py-2.5 bg-[var(--theme-surface)] border border-[var(--theme-border)] text-xs font-bold uppercase tracking-wider text-[var(--theme-text)] hover:border-[var(--theme-text)] transition"
            >
              Enterprise Admin Console
            </Link>
          </div>
        </div>

      </div>

      <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
