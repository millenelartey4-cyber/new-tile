import { useState, useEffect } from 'react';
import { StoreSettings } from '../types';
import { storeService } from '../services/store';
import { useCompany } from '../context/CompanyContext';

export function useStoreSettings(tenantId?: string): StoreSettings {
  const companyContext = useCompany();
  const effectiveTenantId = tenantId || companyContext?.activeCompany?.id || storeService.getActiveTenantId() || 'atelier-surfaces';
  
  const [settings, setSettings] = useState<StoreSettings>(() => 
    storeService.getStoreSettings(effectiveTenantId)
  );

  useEffect(() => {
    // Immediately refresh state when tenant changes
    const initial = storeService.getStoreSettings(effectiveTenantId);
    setSettings(initial);

    // Subscribe to storeService internal pub/sub
    const unsubscribe = storeService.onSettingsChange((newSettings, tid) => {
      if (!tid || tid === effectiveTenantId) {
        setSettings({ ...newSettings });
      }
    });

    // Subscribe to browser custom events (for cross-component and fast UI reactivity)
    const handleSettingsEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ tenantId?: string; settings?: StoreSettings }>;
      if (!customEvent.detail?.tenantId || customEvent.detail.tenantId === effectiveTenantId) {
        setSettings(storeService.getStoreSettings(effectiveTenantId));
      }
    };

    const handleStorageEvent = () => {
      setSettings(storeService.getStoreSettings(effectiveTenantId));
    };

    window.addEventListener('atelier_settings_updated', handleSettingsEvent);
    window.addEventListener('storage', handleStorageEvent);

    return () => {
      unsubscribe();
      window.removeEventListener('atelier_settings_updated', handleSettingsEvent);
      window.removeEventListener('storage', handleStorageEvent);
    };
  }, [effectiveTenantId]);

  return settings;
}
