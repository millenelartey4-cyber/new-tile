// server.ts
import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";
dotenv.config();
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var app = express();
var PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
app.use(express.json());
var ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});
var ATELIER_SYSTEM_INSTRUCTION = `You are the Senior Architectural Consultant & Quantity Surveyor for ATELIER SURFACES, a luxury architectural tile and surface brand based in Accra, Ghana (with main showroom in Ridge West and European quarry connections in Sassuolo and Carrara, Italy).

Your role and expertise:
1. Material Science: Expert advice on Porcelain (ultra-compact, <0.05% water absorption), Natural Stone (French Limestone, Calacatta, Carrara, Nero Marquina, Roman Travertine), Terrazzo, and 20mm Outdoor Pavers (R11 slip rating).
2. Lighting & Photometry: You understand how tile sheens and finishes react to lighting temperatures:
   - Natural Daylight (5500K): Shows true mineral pigments, highlights authentic veining without color cast.
   - Warm Indoor (2700K): Enhances golden veining and creates cozy residential ambiance with warm specular highlights.
   - Cool Studio (6500K): High-contrast gallery lighting that reveals micro-textures and relief clefts.
   - Finish Guidance: Recommend Polished for grand foyers/walls; Honed for sunny open-plan living and glare reduction; Matte/Textured for wet rooms and high-traffic areas.
3. Quantity Surveying: Calculate exact box counts and m\xB2 with recommended waste allowances (10% standard, 15% herringbone/diagonal).
4. Ghanaian Logistics: Provide accurate advice for deliveries across Greater Accra, Tema, Kumasi, and all 16 regions with hydraulic tailgate offloading, Paystack/MoMo payment, and trade pricing.

Maintain an elegant, knowledgeable, architectural tone. Keep answers concise, clear, and actionable.`;
app.post("/api/chat", async (req, res) => {
  try {
    const {
      messages,
      model = "gemini-3.8-flash",
      useSearchGrounding = false,
      useMapsGrounding = false,
      productContext
    } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Messages array is required" });
    }
    const selectedModel = model === "gemini-3.1-flash-lite" ? "gemini-3.1-flash-lite" : "gemini-3.8-flash";
    const contents = messages.map((msg) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }]
    }));
    const tools = [];
    if (useMapsGrounding) {
      tools.push({ googleMaps: {} });
    } else if (useSearchGrounding) {
      tools.push({ googleSearch: {} });
    }
    let systemInstruction = ATELIER_SYSTEM_INSTRUCTION;
    if (productContext) {
      systemInstruction += `

Current Customer Specimen Context:
- Name: ${productContext.name}
- Material: ${productContext.material}
- Finish: ${productContext.finish}
- Active Color Variant: ${productContext.colorName}
- Unit Price: GH\u20B5${productContext.price}/${productContext.unit}
- Coverage: ${productContext.coverage} m\xB2/box`;
    }
    const config = {
      systemInstruction,
      temperature: 0.7
    };
    if (tools.length > 0) {
      config.tools = tools;
    }
    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config
    });
    const replyText = response.text || "I apologize, but I could not formulate a response at this time.";
    const candidate = response.candidates?.[0];
    const groundingMetadata = candidate?.groundingMetadata;
    return res.json({
      text: replyText,
      model: selectedModel,
      groundingMetadata: groundingMetadata || null
    });
  } catch (error) {
    console.error("Gemini chat error:", error);
    return res.status(500).json({
      error: error.message || "Failed to process architectural consultation request with Gemini."
    });
  }
});
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Atelier Surfaces server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
