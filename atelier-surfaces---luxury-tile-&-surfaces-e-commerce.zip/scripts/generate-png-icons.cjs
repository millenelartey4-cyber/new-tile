const fs = require('fs');
const zlib = require('zlib');

function crc32(buf) {
  let table = [];
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  let crc = 0 ^ (-1);
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ (-1)) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  const crcVal = crc32(Buffer.concat([typeBuf, data]));
  crcBuf.writeUInt32BE(crcVal, 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function createPng(width, height, isMaskable = false) {
  const rawData = Buffer.alloc(height * (1 + width * 4));
  let pos = 0;

  const cx = width / 2;
  const cy = height / 2;
  const rOuter = (width * 0.42);

  for (let y = 0; y < height; y++) {
    rawData[pos++] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background color: #141311 (obsidian dark)
      let r = 20, g = 19, b = 17, a = 255;

      // Outer gold diamond border
      const rotX = (dx + dy) * 0.7071;
      const rotY = (dy - dx) * 0.7071;
      const diamondRadius = width * 0.28;
      const diamondDist = Math.max(Math.abs(rotX), Math.abs(rotY));

      if (diamondDist > diamondRadius - 6 && diamondDist < diamondRadius + 4) {
        // Gold diamond stroke
        r = 179; g = 135; b = 75; a = 240;
      } else if (diamondDist > diamondRadius * 0.75 - 3 && diamondDist < diamondRadius * 0.75 + 3) {
        r = 212; g = 175; b = 55; a = 180;
      }

      // Draw stylized 'A' in center
      // Left leg: line from (cx - w*0.14, cy + h*0.16) to (cx, cy - h*0.18)
      // Right leg: line from (cx, cy - h*0.18) to (cx + w*0.14, cy + h*0.16)
      // Crossbar: y between cy + h*0.02 and cy + h*0.06
      const aTopY = cy - height * 0.16;
      const aBotY = cy + height * 0.16;
      const aWidth = width * 0.13;

      if (y >= aTopY && y <= aBotY) {
        const progress = (y - aTopY) / (aBotY - aTopY);
        const expectedXLeft = cx - progress * aWidth;
        const expectedXRight = cx + progress * aWidth;
        const thickness = width * 0.024;

        if (Math.abs(x - expectedXLeft) < thickness || Math.abs(x - expectedXRight) < thickness) {
          // Warm gold gradient
          r = 229; g = 195; b = 120; a = 255;
        }

        // Crossbar
        if (y >= cy + height * 0.03 && y <= cy + height * 0.06) {
          if (x >= expectedXLeft && x <= expectedXRight) {
            r = 179; g = 135; b = 75; a = 255;
          }
        }
      }

      // Base gold ingot
      if (y >= cy + height * 0.21 && y <= cy + height * 0.23) {
        if (Math.abs(x - cx) < width * 0.08) {
          r = 179; g = 135; b = 75; a = 255;
        }
      }

      // Ambient circular gold glow behind
      if (dist < rOuter && a !== 255) {
        const factor = (1 - dist / rOuter) * 0.35;
        r = Math.min(255, Math.round(r + 179 * factor));
        g = Math.min(255, Math.round(g + 135 * factor));
        b = Math.min(255, Math.round(b + 75 * factor));
      }

      // Rounded corners for non-maskable icons
      if (!isMaskable) {
        const cornerR = width * 0.18;
        let inCorner = false;
        if (x < cornerR && y < cornerR) inCorner = Math.hypot(x - cornerR, y - cornerR) > cornerR;
        if (x > width - cornerR && y < cornerR) inCorner = Math.hypot(x - (width - cornerR), y - cornerR) > cornerR;
        if (x < cornerR && y > height - cornerR) inCorner = Math.hypot(x - cornerR, y - (height - cornerR)) > cornerR;
        if (x > width - cornerR && y > height - cornerR) inCorner = Math.hypot(x - (width - cornerR), y - (height - cornerR)) > cornerR;
        if (inCorner) a = 0;
      }

      rawData[pos++] = r;
      rawData[pos++] = g;
      rawData[pos++] = b;
      rawData[pos++] = a;
    }
  }

  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const idatData = zlib.deflateSync(rawData);

  return Buffer.concat([
    sig,
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', idatData),
    makeChunk('IEND', Buffer.alloc(0))
  ]);
}

if (!fs.existsSync('public')) {
  fs.mkdirSync('public', { recursive: true });
}

fs.writeFileSync('public/pwa-192x192.png', createPng(192, 192, false));
fs.writeFileSync('public/pwa-512x512.png', createPng(512, 512, false));
fs.writeFileSync('public/pwa-maskable-512x512.png', createPng(512, 512, true));
fs.writeFileSync('public/apple-touch-icon.png', createPng(180, 180, false));
fs.writeFileSync('public/favicon.png', createPng(64, 64, false));

console.log('Successfully generated all compliant PWA icons in public/ directory!');
